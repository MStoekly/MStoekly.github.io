"""Regenerates the Ren'Py GUI images (game/gui/**) as atomic-age sci-fi pixel
art (1950s chrome and teal enamel, cream pinstripes, neon green accent), from pixel_ui / pixel_title.
Everything is drawn at 3x (1 art px = 3 screen px) so all 9-slice borders are
multiples of 3. Original files are copied once to tools/_to_delete/backup_gui/
before the first overwrite.

    python tools/make_gui_assets.py            write the files
    python tools/make_gui_assets.py --check    verify sizes / borders without writing

Pair with gui.rpy (borders, sizes, colours, fonts) and ui_theme.rpy (style tweaks).
"""
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "game", "python-packages"))

import pixel_art as pa
from pixel_art import Canvas, C, _rgb, _B4
import pixel_ui as ui
import pixel_title

GUI = os.path.join(ROOT, "game", "gui")
BACKUP = os.path.join(HERE, "_to_delete", "backup_gui")
Z = 3


U = ui.UI


def rgba(h, a=255):
    r, g, b, _ = _rgb(h)
    return (r, g, b, a)


def transpose(c):
    o = Canvas(c.h, c.w)
    for y in range(c.h):
        for x in range(c.w):
            o.p[x][y] = c.p[y][x]
    return o


def bayer(x, y):
    return (_B4[y & 3][x & 3] + 0.5) / 16.0


# -- frames ------------------------------------------------------------------

def slot_frame(w, h, border="c2", field="ink2", fill=None):
    """Inset chrome track: ink outline, chrome rim, ink, enamel well (or a lit fill). Used for bars/sliders."""
    c = Canvas(w, h)
    c.rect(0, 0, w, h, U["ink"])
    c.rect(1, 1, w - 1, h - 1, U[border])
    c.rect(1, h - 2, w - 1, h - 1, U["c4"] if border == "c2" else U["neon_l"])   # chrome catches light below
    c.rect(2, 2, w - 2, h - 2, U["ink"])
    c.rect(3, 3, w - 3, h - 3, U[fill] if fill else (7, 28, 31, 255))
    if fill:
        c.rect(3, 3, w - 3, 5, U["neon"])
        c.rect(3, 3, w - 3, 4, U["neon_l"])
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        c.p[y][x] = None
    return c


def thumb(w, h, hover=False):
    """Chrome slider knob (neon when hovered)."""
    c = Canvas(w, h)
    body, light, dark = ("neon", "neon_l", "neon_d") if hover else ("c3", "c4", "c1")
    c.rect(0, 0, w, h, U["ink"])
    c.rect(1, 1, w - 1, h - 1, U[body])
    c.rect(1, 1, 2, h - 1, U[light])
    c.rect(w - 2, 1, w - 1, h - 1, U[dark])
    c.rect(1, h - 2, w - 1, h - 1, U[dark])
    c.rect(2, h // 2, w - 2, h // 2 + 1, U["turq"] if not hover else U["neon_dd"])   # enamel inlay
    return c


def scroll_bar(length, thick=6):
    c = Canvas(length, thick)
    rows = ("ink", "c1", "en", "en", "c2", "ink")
    for y in range(thick):
        c.rect(0, y, length, y + 1, U[rows[y]])
    return c


def scroll_thumb(length, thick=6, hover=False):
    c = Canvas(length, thick)
    rows = ("ink", "neon_l", "neon", "neon_d", "neon_d", "ink") if hover else ("ink", "c4", "c3", "c2", "c1", "ink")
    for y in range(thick):
        c.rect(0, y, length, y + 1, U[rows[y]])
    return c


def check_glyph(selected):
    c = Canvas(9, 16)
    c.rect(0, 3, 9, 12, U["ink"])
    c.rect(1, 4, 8, 11, U["neon"] if selected else U["c2"])
    c.rect(1, 4, 8, 5, U["neon_l"] if selected else U["c4"])
    c.rect(2, 5, 7, 10, U["en"])
    if selected:
        for x, y in ((2, 7), (3, 8), (4, 9), (5, 8), (6, 7), (7, 6), (7, 5)):
            c.px(x, y - 1 if x > 4 else y, U["neon_l"])
            c.px(x, y, U["neon"])
    return c


def radio_glyph(selected):
    c = Canvas(9, 16)
    c.blit(ui.pip(selected), 0, 3)
    return c


# -- big flat pieces -----------------------------------------------------------

def _gleam_star(c, cx, cy, arm, tip):
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, -1), (1, -1), (-1, 1)):
        c.px(cx + dx, cy + dy, arm)
    for dx, dy in ((2, 0), (-2, 0), (0, 2), (0, -2)):
        c.px(cx + dx, cy + dy, tip)
    c.px(cx, cy, U["white"])


def textbox():
    """640x93 dialogue band: chrome top trim, cream pinstripe, glossy teal enamel."""
    w, h = 640, 93
    c = Canvas(w, h)
    for y in range(h):
        k = max(0.0, 1.0 - (y - 9) / 26.0) if y >= 9 else 0.0       # gloss fading down from the trim
        base = (int(15 + 10 * k), int(59 + 18 * k), int(64 + 18 * k))
        for x in range(w):
            c.p[y][x] = base + (236,)
    top = ("ink", "c4", "c3", "c2", "c1", "c0", "ink", "eng", "cream")
    for y, name in enumerate(top):
        c.rect(0, y, w, y + 1, U[name])
    for i, x in enumerate(range(40, w, 80)):                       # starbursts riding the trim
        _gleam_star(c, x, 3, U["turq"] if i % 2 else U["cream"], U["turq_l"])
    return c


def strip_overlay(full_alpha=None, strip_w=160):
    """640x360 overlay: a chrome-edged enamel strip on the left; optionally a veil over the rest."""
    w, h = 640, 360
    c = Canvas(w, h)
    tile = ui.bg_tile()
    ring = ("cream", "en", "ink", "c1", "c2", "c3", "c4", "ink")          # inner -> outer
    body_w = strip_w - len(ring)
    for y in range(h):
        for x in range(w):
            if x < body_w:
                r, g, b, _ = tile.p[y % tile.h][x % tile.w]
                c.p[y][x] = (r + 4, g + 10, b + 10, 246)                     # formica, a shade lighter
            elif x < strip_w:
                c.p[y][x] = U[ring[x - body_w]]
            elif full_alpha:
                c.p[y][x] = rgba("#05141a", full_alpha)
    for i, y in enumerate(range(20, h, 40)):                                 # starbursts on the chrome
        _gleam_star(c, body_w + 5, y, U["turq"] if i % 2 else U["cream"], U["turq_l"])
    return c


def veil(alpha):
    c = Canvas(640, 360)
    for y in range(360):
        c.rect(0, y, 640, y + 1, rgba("#05141a", alpha))
    return c


# -- manifest ------------------------------------------------------------------

def manifest():
    """{relative path: (Canvas, scale)}"""
    m = {}
    m["gui/main_menu.png"] = (pixel_title.title_scene(), Z)
    m["gui/game_menu.png"] = (pixel_title.brick_wall(), Z)
    m["gui/overlay/main_menu.png"] = (strip_overlay(None), Z)
    m["gui/overlay/game_menu.png"] = (strip_overlay(190), Z)
    m["gui/overlay/confirm.png"] = (veil(176), Z)
    m["gui/textbox.png"] = (textbox(), Z)
    m["gui/namebox.png"] = (ui.card("gold"), Z)
    m["gui/frame.png"] = (ui.panel("stone"), Z)
    m["gui/confirm_frame.png"] = (ui.panel("blood"), Z)
    m["gui/skip.png"] = (ui.card("dim"), Z)
    m["gui/notify.png"] = (ui.card("stone"), Z)
    for state, name in (("idle", "idle"), ("hover", "hover")):
        m["gui/button/%s_background.png" % name] = (ui.button(state), Z)
        m["gui/button/choice_%s_background.png" % name] = (ui.button(state), Z)
    m["gui/button/selected_idle_background.png"] = (ui.button("hover"), Z)
    m["gui/button/selected_hover_background.png"] = (ui.button("hover"), Z)
    m["gui/button/insensitive_background.png"] = (ui.button("insensitive"), Z)
    m["gui/button/slot_idle_background.png"] = (ui.card("stone"), Z)
    m["gui/button/slot_hover_background.png"] = (ui.card("gold"), Z)
    m["gui/button/radio_foreground.png"] = (radio_glyph(False), Z)
    m["gui/button/radio_selected_foreground.png"] = (radio_glyph(True), Z)
    m["gui/button/check_foreground.png"] = (check_glyph(False), Z)
    m["gui/button/check_selected_foreground.png"] = (check_glyph(True), Z)
    # sliders + bars: 13 art px thick (gui.slider_size / gui.bar_size = 39)
    for state, border in (("idle", "c2"), ("hover", "neon")):
        bar = slot_frame(12, 13, border)
        m["gui/slider/horizontal_%s_bar.png" % state] = (bar, Z)
        m["gui/slider/vertical_%s_bar.png" % state] = (transpose(bar), Z)
        th = thumb(5, 13, state == "hover")
        m["gui/slider/horizontal_%s_thumb.png" % state] = (th, Z)
        m["gui/slider/vertical_%s_thumb.png" % state] = (transpose(th), Z)
        sb, st = scroll_bar(16), scroll_thumb(16, hover=(state == "hover"))
        m["gui/scrollbar/horizontal_%s_bar.png" % state] = (sb, Z)
        m["gui/scrollbar/horizontal_%s_thumb.png" % state] = (st, Z)
        m["gui/scrollbar/vertical_%s_bar.png" % state] = (transpose(sb), Z)
        m["gui/scrollbar/vertical_%s_thumb.png" % state] = (transpose(st), Z)
    full, empty = slot_frame(12, 13, "c2", fill="neon_d"), slot_frame(12, 13, "c2")
    m["gui/bar/left.png"] = (full, Z)
    m["gui/bar/right.png"] = (empty, Z)
    m["gui/bar/bottom.png"] = (transpose(full), Z)
    m["gui/bar/top.png"] = (transpose(empty), Z)
    return m


EXPECT = {                                    # path -> (w, h) in screen px
    "gui/main_menu.png": (1920, 1080), "gui/game_menu.png": (1920, 1080),
    "gui/overlay/main_menu.png": (1920, 1080), "gui/overlay/game_menu.png": (1920, 1080),
    "gui/overlay/confirm.png": (1920, 1080), "gui/textbox.png": (1920, 279),
    "gui/namebox.png": (48, 48), "gui/frame.png": (72, 72), "gui/button/idle_background.png": (48, 48),
    "gui/slider/horizontal_idle_bar.png": (36, 39), "gui/slider/horizontal_idle_thumb.png": (15, 39),
    "gui/slider/vertical_idle_bar.png": (39, 36), "gui/slider/vertical_idle_thumb.png": (39, 15),
    "gui/scrollbar/horizontal_idle_bar.png": (48, 18), "gui/scrollbar/vertical_idle_bar.png": (18, 48),
    "gui/button/radio_foreground.png": (27, 48), "gui/button/check_foreground.png": (27, 48),
}


def main():
    check = "--check" in sys.argv
    m = manifest()
    ok = True
    for path, (canvas, z) in sorted(m.items()):
        want = EXPECT.get(path)
        got = (canvas.w * z, canvas.h * z)
        if want and got != want:
            print("SIZE MISMATCH %s: got %s want %s" % (path, got, want))
            ok = False
    print("%d files, size check %s" % (len(m), "PASS" if ok else "FAIL"))
    if check or not ok:
        return 0 if ok else 1
    if not os.path.isdir(BACKUP):
        os.makedirs(BACKUP)
        shutil.copytree(GUI, os.path.join(BACKUP, "gui"))
        print("originals backed up to tools/_to_delete/backup_gui/gui")
    for path, (canvas, z) in sorted(m.items()):
        dest = os.path.join(ROOT, "game", path)
        d = os.path.dirname(dest)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(dest, "wb") as f:
            f.write(canvas.png(z))
    print("written to game/gui/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
