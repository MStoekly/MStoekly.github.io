"""Approximate 1920x1080 mock-ups of the hunt/shop screens, composed with PIL from the
same pixel_ui assets and fonts. Layout numbers mirror hunt.rpy / shop.rpy by hand, so this
is a look/overlap check, NOT Ren'Py output. Usage: python tools/mock_ui_layout.py outdir"""
import io, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "game", "python-packages"))
from PIL import Image, ImageDraw, ImageFont
import pixel_ui as ui, pixel_art as pa

Z = 3
G = os.path.join(HERE, "..", "game", "fonts")
def F(name, size):
    path = os.path.join(G, name)
    if not os.path.exists(path): path = os.path.join(G, "PixelifySans-Bold.ttf")   # title font fallback
    return ImageFont.truetype(path, size)
REG, BOLD, TITLE = "PixelifySans-Regular.ttf", "PixelifySans-Bold.ttf", "Creepster-Regular.ttf"
GOLD, TEXT, DIM, BLOOD, LOCK = "#8dff5a", "#f4ecd8", "#8aa3a6", "#ff4f5e", "#55666b"   # accent, text, dim, danger, locked

def img(c, z=Z): return Image.open(io.BytesIO(c.png(z))).convert("RGBA")
def png(b): return Image.open(io.BytesIO(b)).convert("RGBA")

def nine(c, border, w, h):
    src = img(c); b = border * Z; W, H = w, h; sw, sh = src.size
    out = Image.new("RGBA", (W, H))
    def tile(box, dst):
        piece = src.crop(box)
        for y in range(dst[1], dst[3], piece.size[1]):
            for x in range(dst[0], dst[2], piece.size[0]):
                out.paste(piece.crop((0, 0, min(piece.size[0], dst[2] - x), min(piece.size[1], dst[3] - y))), (x, y))
    tile((b, b, sw - b, sh - b), (b, b, W - b, H - b))
    tile((b, 0, sw - b, b), (b, 0, W - b, b)); tile((b, sh - b, sw - b, sh), (b, H - b, W - b, H))
    tile((0, b, b, sh - b), (0, b, b, H - b)); tile((sw - b, b, sw, sh - b), (W - b, b, W, H - b))
    for box, pos in (((0, 0, b, b), (0, 0)), ((sw - b, 0, sw, b), (W - b, 0)), ((0, sh - b, b, sh), (0, H - b)), ((sw - b, sh - b, sw, sh), (W - b, H - b))):
        out.paste(src.crop(box), pos)
    return out

def backdrop(w=1920, h=1080):
    t = img(ui.bg_tile()); o = Image.new("RGBA", (w, h))
    for y in range(0, h, t.size[1]):
        for x in range(0, w, t.size[0]): o.paste(t, (x, y))
    return o

class Scene:
    def __init__(self, bg=None):
        self.im = bg.copy() if bg else backdrop()
        self.d = ImageDraw.Draw(self.im)
    def panel(self, kind, x, y, w, h): self.im.alpha_composite(nine(ui.panel(kind), ui.PANEL_BORDER, w, h), (x, y))
    def card(self, kind, x, y, w, h): self.im.alpha_composite(nine(ui.card(kind), ui.CARD_BORDER, w, h), (x, y))
    def button(self, state, x, y, w, h): self.im.alpha_composite(nine(ui.button(state), ui.BUTTON_BORDER, w, h), (x, y))
    def slot(self, x, y, w, h): self.im.alpha_composite(nine(ui.slot(), ui.SLOT_BORDER, w, h), (x, y))
    def paste(self, im, x, y): self.im.alpha_composite(im, (int(x), int(y)))
    def text(self, s, x, y, font, size, col, anchor="l", outline=None):
        f = F(font, size); w = self.d.textlength(s, font=f)
        if anchor == "c": x -= w / 2
        elif anchor == "r": x -= w
        if outline:
            for dx, dy in ((0, outline), (outline, outline), (-outline, outline)):
                self.d.text((x + dx, y + dy), s, font=f, fill="#060e13")
        self.d.text((x, y), s, font=f, fill=col)
        return w
    def save(self, p): self.im.convert("RGB").save(p)

def title_block(sc, cx, y, s, col=GOLD, size=88):
    sc.text(s, cx, y, TITLE, size, col, "c", 4)
    sc.paste(img(ui.divider(110)), cx - 165, y + size + 8)

def level_select(out):
    sc = Scene()
    levels = [("Wailing Wood", True, "payout x1.00"), ("Old Coast Road", True, "payout x1.20"), ("Village Outskirts", True, "payout x1.45"),
              ("Blackmere Village", False, "needs 10 vampiric strength"), ("Harrow's Gate", False, "needs 20 vampiric strength")]
    W, H = 1100 + 144, 840
    px, py = (1920 - W) // 2, (1080 - H) // 2
    sc.panel("stone", px, py, W, H)
    cx = 960; y = py + 56
    title_block(sc, cx, y - 6, "Choose your hunting ground")
    y += 150
    sc.paste(img(ui.icon("strength"), 2), cx - 330, y); sc.text("Vampiric strength  4", cx - 290, y + 2, REG, 28, TEXT)
    sc.paste(img(ui.drop(True), 2), cx + 90, y); sc.text("120", cx + 130, y + 2, REG, 28, GOLD)
    y += 56
    for name, ok, sub in levels:
        sc.card("stone" if ok else "dim", px + 72, y, 1100, 90)
        sc.text(name, px + 72 + 34, y + 12, BOLD, 36, TEXT if ok else LOCK)
        if ok:
            sc.paste(img(ui.drop(True), 2), px + 72 + 34, y + 54); sc.text(sub, px + 72 + 70, y + 56, REG, 22, DIM)
            sc.button("idle", px + 72 + 1100 - 34 - 200, y + 14, 200, 62); sc.text("Hunt", px + 72 + 1100 - 34 - 100, y + 18, BOLD, 32, TEXT, "c")
        else:
            sc.text(sub, px + 72 + 34, y + 56, REG, 22, LOCK); sc.paste(img(ui.lock()), px + 72 + 1100 - 34 - 40 - 39, y + 24)
        y += 98
    y += 8
    sc.button("idle", 960 - 160, y, 320, 66); sc.text("Blood Market", 960, y + 18, BOLD, 32, TEXT, "c")
    sc.save(out)

def shop(out, cost_ok=2):
    sc = Scene()
    W, H = 1600 + 128, 1024
    px, py = (1920 - W) // 2, (1080 - H) // 2
    sc.panel("stone", px, py, W, H)
    x0 = px + 64; y = py + 44
    sc.text("Blood Market", x0, y, TITLE, 88, GOLD, outline=4)
    sc.paste(img(ui.drop(True)), x0 + 1600 - 180, y + 24); sc.text("1240", x0 + 1600, y + 12, BOLD, 52, GOLD, "r")
    sc.paste(img(ui.divider(110)), 960 - 165, y + 96)
    y += 96 + 27 + 18
    H = 584
    sc.card("dim", x0, y, 400, H)
    t = backdrop(370, H - 30); sc.paste(t, x0 + 15, y + 15)
    ring = png(pa.ring_png(14 + 3 * 3, 5)); sc.paste(ring, x0 + 200 - ring.size[0] // 2, y + H * 0.46 - ring.size[1] // 2)
    v = png(pa.character_png("vampire", "down", 10)); sc.paste(v, x0 + 200 - v.size[0] // 2, int(y + H * 0.46 - v.size[1] // 2))
    sc.text("Dorak", x0 + 200, y + H - 92 - 50, TITLE, 64, GOLD, "c", 3)
    sc.text("Allure  3 / 5", x0 + 200, y + H - 48 - 22, REG, 24, DIM, "c")
    ups = [("speed", "Swiftness", "Move faster. The hunters keep pace with you, so this buys reach, not escape.", 5, 5),
           ("constitution", "Constitution", "One more touch before the night takes you.", 5, 5),
           ("allure", "Allure", "Feed from further away, draw richer prey, and calm it so it runs less.", 5, 5),
           ("strength", "Strength", "Blood Shock: when a hunter wounds you, the pack around you is hurled back and stunned.", 3, 5)]
    ry = y; rx = x0 + 432; speed = 5
    for key, title, blurb, lv, mx in ups:
        maxed = lv >= mx
        need = False; offer = (key == "speed")
        owned = (key == "allure")
        if offer: title, key, lv, mx = "Blink", "blink", 0, 1
        if owned: title, key, lv, mx = "Charm", "charm", 1, 1
        if owned: blurb = "Mastered. Charm: bends the nearest few to your will."
        if offer: blurb = "Swiftness is mastered. Unlock Blink: press F to pass through walls and buildings."
        sc.card("blood" if offer else ("gold" if maxed else "stone"), rx, ry, 1150, 140)
        sc.card("dim", rx + 28, ry + 22, 96, 96); sc.paste(img(ui.icon(key)), rx + 28 + 48 - 27, ry + 22 + 48 - 27)
        tx = rx + 28 + 96 + 24
        sc.text(title, tx, ry + 14, BOLD, 34, LOCK if need else TEXT)
        f = F(REG, 22); words = blurb.split(); line = ""; ly = ry + 56
        for w in words:
            if sc.d.textlength((line + " " + w).strip(), font=f) > 500: sc.text(line, tx, ly, REG, 22, DIM); ly += 25; line = w
            else: line = (line + " " + w).strip()
        sc.text(line, tx, ly, REG, 22, DIM)
        cx = tx + 500 + 24 + 95
        sc.text("Level %d / %d" % (lv, mx), cx, ry + 28, REG, 26, TEXT, "c")
        for n in range(mx): sc.paste(img(ui.pip(n < lv)), cx - mx * 31 // 2 + n * 31, ry + 68)
        bx = rx + 1150 - 28 - 210
        if offer:
            sc.button("idle", bx, ry + 37, 210, 66); sc.paste(img(ui.drop(True), 2), bx + 40, ry + 49); sc.text("2500", bx + 84, ry + 41, BOLD, 32, TEXT)
        elif owned:
            sc.text("UNLOCKED", bx + 105, ry + 34, BOLD, 32, GOLD, "c")
            sc.text("Press E", bx + 105, ry + 78, REG, 26, DIM, "c")
        elif maxed: sc.text("MAXED", bx + 105, ry + 32, BOLD, 38, GOLD, "c")
        elif need:
            sc.paste(img(ui.lock(), 2), bx + 8, ry + 40); sc.text("Swiftness %d / 5" % speed, bx + 50, ry + 44, REG, 22, LOCK)
        else:
            sc.button("idle", bx, ry + 28, 210, 66); sc.paste(img(ui.drop(True), 2), bx + 52, ry + 40); sc.text("%d" % (100 * (lv + 1)), bx + 90, ry + 32, BOLD, 32, TEXT)
        ry += 152
    sc.button("idle", 960 - 160, y + H + 14, 320, 66); sc.text("Back to the hunt", 960, y + H + 14 + 18, BOLD, 32, TEXT, "c")
    sc.save(out)

def hud(out):
    # Mirrors HuntDisplayable.draw_hud in hunt.rpy: panel 190 tall, bezel 24px, rows inside it.
    sc = Scene(Image.new("RGBA", (1920, 1080), (14, 34, 40, 255)))
    x0, y0, pw, ph = 260, 8, 1400, 190
    sc.panel("stone", x0, y0, pw, ph)
    sc.text("BIOMASS", x0 + 40, y0 + 34, REG, 22, DIM)
    sc.paste(img(ui.drop(True)), x0 + 40, y0 + 74); sc.text("0", x0 + 92, y0 + 60, BOLD, 56, TEXT)
    sc.text("Fort Dalton", x0 + pw / 2, y0 + 30, "Creepster-Regular.ttf", 60, GOLD, "c", 3)
    sc.text("3:28 AM", x0 + pw / 2, y0 + 106, REG, 32, BLOOD, "c")
    right = x0 + pw - 40
    for i in range(7):
        f = (1.0, 1.0, 1.0, 0.75, 0.25, 0.0, 0.0)[i]
        sc.paste(img(ui.heart(f > 0, f or 1.0)), right - (7 - i) * 51 + 6, y0 + 26)
    bw, bh, inset = 300, 24, 9
    for i, (nm, fr, col) in enumerate((("PHASE", 1.0, "#e8c04a"), ("THRALL", 1.0, "#e8c04a"), ("FRENZY", 0.0, "#c81428"))):
        bx, by = right - bw, y0 + 74 + 30 * i
        sc.text(nm, bx - 14, by - 3, REG, 22, GOLD if fr >= 1 else DIM, "r"); sc.slot(bx, by, bw, bh)
        if fr > 0:
            sc.d.rectangle((bx + inset, by + inset, bx + bw - inset, by + bh - inset), fill=col)
    bx, by = x0 + 40, y0 + 134
    sc.slot(bx, by, bw, bh); sc.d.rectangle((bx + inset, by + inset, bx + bw - inset, by + bh - inset), fill="#4fb8e8")
    sc.text("STASIS", bx + bw + 14, by - 3, REG, 22, GOLD)
    sc.save(out)

def results(out):
    sc = Scene(Image.new("RGBA", (1920, 1080), (8, 14, 20, 255)))
    W, H = 640 + 180, 780
    px, py = (1920 - W) // 2, (1080 - H) // 2
    sc.panel("blood", px, py, W, H)
    title_block(sc, 960, py + 60, "The night closes in", BLOOD)
    y = py + 60 + 150
    for ico, name, val in (("drop", "Blood taken", "64"), ("fangs", "Prey drained", "9"), ("heart", "Survived", "73 s")):
        c = ui.drop(True) if ico == "drop" else (ui.icon("strength") if ico == "fangs" else ui.heart(True))
        sc.paste(img(c, 2), px + 90, y + 10); sc.text(name, px + 90 + 64, y + 6, REG, 36, TEXT); sc.text(val, px + 90 + 640, y + 4, BOLD, 36, TEXT, "r"); y += 70
    y += 8; sc.paste(img(ui.drop(True), 2), 960 - 170, y); sc.text("Blood on hand  1304", 960 - 130, y + 2, REG, 34, GOLD); y += 70
    for lab in ("Hunt again", "Choose another hunting ground", "Blood market", "Leave the streets"):
        sc.button("idle", 960 - 280, y, 560, 66); sc.text(lab, 960, y + 18, BOLD, 32, TEXT, "c"); y += 76
    sc.save(out)

def loading(out):
    sc = Scene()
    sc.text("Entering", 960, 380, REG, 34, DIM, "c"); sc.text("Blackmere Village", 960, 430, TITLE, 88, GOLD, "c", 4)
    sc.paste(img(ui.divider(110)), 960 - 165, 540)
    for i in range(3): sc.paste(img(ui.drop(True)), 960 - 70 + i * 55, 600)
    sc.save(out)

if __name__ == "__main__":
    o = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "_sheets")
    os.makedirs(o, exist_ok=True)
    for fn in (level_select, shop, hud, results, loading): fn(os.path.join(o, "mock_%s.png" % fn.__name__))
    print("ok")
