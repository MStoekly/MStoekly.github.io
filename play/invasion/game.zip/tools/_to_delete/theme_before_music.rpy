# THE THEME LAYER. Everything that makes this game "Invasion" rather than
# another skin of the same engine lives here: the words the player reads, the
# colours and fonts of the interface, level names and music. The rules
# (hunt_core.py, hunt_mapgen.py) and the screens (hunt.rpy, shop.rpy) read
# these names and never spell a themed word themselves. A new skin edits this
# file, the art modules (pixel_art.py, pixel_fifties.py, pixel_ui.py,
# pixel_title.py) and the sound recipes (tools/make_sfx.py), and nothing else.
# tools/leak_scan.py checks that no word of the old skin is left on screen.

init -2 python:

    TH_FONT = "fonts/PixelifySans-Regular.ttf"
    TH_FONT_BOLD = "fonts/PixelifySans-Bold.ttf"
    TH_TITLE_FONT = "fonts/Creepster-Regular.ttf"     # SIL OFL, Font Diner (see fonts/OFL-Creepster.txt)

    TH_COL = {
        "accent": "#8dff5a",     # neon green: headings, prices, ready states
        "text": "#f4ecd8",       # cream
        "dim": "#8aa3a6",
        "danger": "#ff4f5e",     # cherry red
        "locked": "#55666b",
        "ink": "#06121a",        # text outlines
        "extract": "#c8ffd8",    # the tractor beam
    }

    TH_LEVEL_NAMES = {
        "forest": "Crash Site",
        "road": "Route 9",
        "outskirts": "Hollister Farm",
        "village": "Main Street",
        "town": "Fort Dalton",
    }

    # Drop a track at any of these paths and it plays; missing files are skipped.
    TH_MUSIC = {
        "forest": "music/crash_site.ogg",
        "road": "music/route_9.ogg",
        "outskirts": "music/hollister_farm.ogg",
        "village": "music/main_street.ogg",
        "town": "music/fort_dalton.ogg",
    }

    # Names of the stats, powers and the ultimate (the keys are the engine's).
    TH_STAT = {
        "speed": ("Locomotion", "Move faster. The soldiers keep pace with you, so this buys reach, not escape."),
        "constitution": ("Resilience", "One more hit before they take you."),
        "allure": ("Pheromones", "Feed from further away, draw richer prey, and calm it so it runs less."),
        "strength": ("Carapace", "Chitin plates: shrug off 8% of soldier hits per level, and hurl back the squad around you."),
    }
    TH_POWER = {"blink": "Phase", "charm": "Thrall", "bloodlust": "Frenzy", "drain": "Regenerate", "ultimate": "Stasis"}
    TH_VERB = {"blink": "phase", "charm": "enthrall", "bloodlust": "frenzy", "ultimate": "freeze time"}
    TH_POWER_TEXT = {
        "blink": ("Locomotion mastered. Unlock Phase: slip through walls and buildings.",
                  "Mastered. Phase: slip through walls and buildings."),
        "charm": ("Pheromones mastered. Unlock Thrall: bend the nearest few to your will.",
                  "Mastered. Thrall: bends the nearest few to your will."),
        "bloodlust": ("Carapace mastered. Unlock Frenzy: feed to fill it, soldiers flee and die at your touch.",
                      "Mastered. Frenzy: feed to fill it, soldiers flee and die at your touch."),
        "drain": ("Resilience mastered. Unlock Regenerate: 3 unhurt kills in a row mend half a cell.",
                  "Mastered. Regenerate: 3 unhurt kills in a row mend half a cell (25s rest)."),
    }

    TH = {
        "hero": "Kreel",
        "currency": "Biomass",
        "hud_currency": "BIOMASS",
        "shop": "Mutation Lab",
        "shop_button": "Mutation lab",
        "power_meter": "Mutation level  %d",
        "needs": "needs mutation level %d",
        "stage": "Stage %d / %d",
        "ground_title": "Choose a feeding ground",
        "ground_button": "Feeding ground",
        "go": "Hunt",
        "entering": "Landing at",
        "again": "Hunt again",
        "leave": "Lie low",
        "won_title": "Extracted",
        "lost_title": "Captured",
        "taken": "Biomass absorbed",
        "bonus": "Extraction bonus",
        "fed": "Humans absorbed",
        "survived": "Survived",
        "on_hand": "Biomass stored  %d",
        "near_end": "Extraction soon",
        "win_banner": "Extracted",
        "win_bonus": "Extraction bonus  +%d",
        "lose_banner": "Captured",
        "frenzy_ready": "Frenzy ready",
        "stasis_title": "Stasis",
        "blocked": "Deflected",
        "ultimate_owned": "Once a night, time stops for 5 seconds. Everything is frozen and at your mercy.",
        "ultimate_locked": "The final mutation. Complete all four lines above to unlock it.",
        "cheat": "Biomass: %d",
        "move_hint": "%s / arrows to move",
    }
