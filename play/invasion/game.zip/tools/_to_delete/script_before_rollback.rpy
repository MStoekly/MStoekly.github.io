# The script of the game goes in this file.

define narrator_k = Character(None, what_italic=True)


# The game starts here.

label start:

    scene black

    narrator_k "The saucer came down in the woods behind Hollister Farm and did not get up again."

    narrator_k "Something crawled out of it. It is small, and it is hungry, and every meal teaches it something new."

    # Hunt entry point. Replace with the real story when it exists.
    call hunt_demo

    # This ends the game.

    return
