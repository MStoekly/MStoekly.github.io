"""Approximate mock-ups (PIL) of the VN screens using the generated game/gui PNGs and the
stock screens.rpy layout numbers. Look/overlap check only, NOT Ren'Py output.
Usage: python tools/mock_gui_layout.py outdir"""
import os, sys
from PIL import Image, ImageDraw, ImageFont
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
G = os.path.join(ROOT, "game")
def gi(p): return Image.open(os.path.join(G, p)).convert("RGBA")
def F(n, s):
    path = os.path.join(G, "fonts", n)
    if not os.path.exists(path): path = os.path.join(G, "fonts", "PixelifySans-Bold.ttf")   # title font fallback
    return ImageFont.truetype(path, s)
REG, BOLD, TITLE = "PixelifySans-Regular.ttf", "PixelifySans-Bold.ttf", "PirataOne-Regular.ttf"

def nine(src, b, w, h):
    sw, sh = src.size; out = Image.new("RGBA", (w, h))
    def tile(box, dst):
        piece = src.crop(box)
        for y in range(dst[1], dst[3], piece.size[1]):
            for x in range(dst[0], dst[2], piece.size[0]):
                out.paste(piece.crop((0, 0, min(piece.size[0], dst[2] - x), min(piece.size[1], dst[3] - y))), (x, y))
    tile((b, b, sw - b, sh - b), (b, b, w - b, h - b))
    tile((b, 0, sw - b, b), (b, 0, w - b, b)); tile((b, sh - b, sw - b, sh), (b, h - b, w - b, h))
    tile((0, b, b, sh - b), (0, b, b, h - b)); tile((sw - b, b, sw, sh - b), (w - b, b, w, h - b))
    for box, pos in (((0, 0, b, b), (0, 0)), ((sw - b, 0, sw, b), (w - b, 0)), ((0, sh - b, b, sh), (0, h - b)), ((sw - b, sh - b, sw, sh), (w - b, h - b))):
        out.paste(src.crop(box), pos)
    return out

def txt(d, s, x, y, font, size, col, anchor="l", outline=0):
    f = F(font, size); w = d.textlength(s, font=f)
    if anchor == "c": x -= w / 2
    elif anchor == "r": x -= w
    if outline:
        for dx, dy in ((0, outline), (outline, outline), (-outline, outline)): d.text((x + dx, y + dy), s, font=f, fill="#060e13")
    d.text((x, y), s, font=f, fill=col); return w

def main_menu(out):
    im = gi("gui/main_menu.png"); im.alpha_composite(gi("gui/overlay/main_menu.png")); d = ImageDraw.Draw(im)
    items = ["Start", "Load", "Preferences", "About", "Help", "Quit"]; bh = 72; total = len(items) * bh + (len(items) - 1) * 12
    y = (1080 - total) // 2; btn = gi("gui/button/idle_background.png"); hov = gi("gui/button/hover_background.png")
    for i, t in enumerate(items):
        im.alpha_composite(nine(hov if i == 0 else btn, 12, 330, bh), (75, y)); d = ImageDraw.Draw(im)
        txt(d, t, 75 + 165, y + 14, BOLD, 33, "#8dff5a" if i == 0 else "#f4ecd8", "c"); y += bh + 12
    txt(d, "INVASION", 1920 - 30, 1080 - 30 - 150 - 36, TITLE, 140, "#8dff5a", "r", 5)
    txt(d, "1.0", 1920 - 30, 1080 - 30 - 36, REG, 26, "#8aa3a6", "r")
    im.convert("RGB").save(out)

def say(out):
    im = gi("gui/main_menu.png"); im.alpha_composite(Image.new("RGBA", im.size, (0, 0, 0, 90)))
    im.alpha_composite(gi("gui/textbox.png"), (0, 1080 - 279)); d = ImageDraw.Draw(im)
    pw = int(d.textlength("Dorak", font=F(TITLE, 60))) + 30
    im.alpha_composite(nine(gi("gui/namebox.png"), 15, max(pw, 150), 96), (360, 801 - 45)); d = ImageDraw.Draw(im)
    txt(d, "Dorak", 360 + 15, 801 - 45 + 14, TITLE, 60, "#8dff5a", outline=3)
    lines = ["The streets of Harrow's Gate are never truly empty. Something watches", "from every shuttered window, and tonight, so do I."]
    for i, l in enumerate(lines): txt(d, l, 402, 801 + 84 + i * 46, REG, 36, "#f4ecd8")
    x = 1920 // 2 - 380
    for q in ("Back", "History", "Skip", "Auto", "Save", "Q.Save", "Q.Load", "Prefs"): x += txt(d, q, x, 1080 - 30, REG, 21, "#8aa3a6") + 28
    im.convert("RGB").save(out)

def choice(out):
    im = gi("gui/main_menu.png"); im.alpha_composite(Image.new("RGBA", im.size, (0, 0, 0, 90))); d = ImageDraw.Draw(im)
    btn = gi("gui/button/choice_idle_background.png"); hov = gi("gui/button/choice_hover_background.png"); y = 405 - 80
    for i, t in enumerate(("Follow the crying child into the alley", "Climb the church wall and watch from above", "Drink from the drunkard at the tavern door")):
        im.alpha_composite(nine(hov if i == 1 else btn, 12, 1185, 72), (1920 // 2 - 592, y)); d = ImageDraw.Draw(im)
        txt(d, t, 960, y + 15, REG, 36, "#8dff5a" if i == 1 else "#f4ecd8", "c"); y += 72 + 33
    im.convert("RGB").save(out)

def prefs(out):
    im = gi("gui/game_menu.png"); im.alpha_composite(gi("gui/overlay/game_menu.png")); d = ImageDraw.Draw(im)
    txt(d, "Preferences", 75, 40, TITLE, 84, "#8dff5a", outline=4)
    btn = gi("gui/button/idle_background.png"); y = 300
    for t in ("History", "Save", "Load", "Preferences", "Main Menu"):
        im.alpha_composite(nine(gi("gui/button/hover_background.png") if t == "Preferences" else btn, 12, 330, 72), (75, y)); d = ImageDraw.Draw(im)
        txt(d, t, 240, y + 14, BOLD, 33, "#8dff5a", "c"); y += 84
    x0 = 600
    txt(d, "Display", x0, 250, REG, 38, "#8dff5a")
    for i, (t, sel) in enumerate((("Window", True), ("Fullscreen", False))):
        im.alpha_composite(gi("gui/button/radio_selected_foreground.png" if sel else "gui/button/radio_foreground.png"), (x0 + i * 330, 305)); d = ImageDraw.Draw(im)
        txt(d, t, x0 + i * 330 + 40, 310, BOLD, 33, "#8dff5a" if sel else "#f4ecd8")
    txt(d, "Skip", x0, 420, REG, 38, "#8dff5a")
    for i, (t, sel) in enumerate((("Unseen Text", False), ("After Choices", True))):
        im.alpha_composite(gi("gui/button/check_selected_foreground.png" if sel else "gui/button/check_foreground.png"), (x0 + i * 400, 475)); d = ImageDraw.Draw(im)
        txt(d, t, x0 + i * 400 + 40, 480, BOLD, 33, "#8dff5a" if sel else "#f4ecd8")
    txt(d, "Music Volume", x0, 600, REG, 38, "#8dff5a")
    im.alpha_composite(nine(gi("gui/slider/horizontal_idle_bar.png"), 9, 700, 39), (x0, 660)); im.alpha_composite(gi("gui/slider/horizontal_idle_thumb.png"), (x0 + 380, 660))
    # confirm box
    im.alpha_composite(gi("gui/overlay/confirm.png")); fw, fh = 900, 380
    im.alpha_composite(nine(gi("gui/confirm_frame.png"), 24, fw, fh), (510, 350)); d = ImageDraw.Draw(im)
    txt(d, "Are you sure you want to quit?", 960, 420, REG, 40, "#f4ecd8", "c")
    for i, t in enumerate(("Yes", "No")):
        im.alpha_composite(nine(gi("gui/button/hover_background.png" if i == 0 else "gui/button/idle_background.png"), 12, 200, 72), (700 + i * 320, 560)); d = ImageDraw.Draw(im)
        txt(d, t, 800 + i * 320, 574, BOLD, 33, "#8dff5a", "c")
    im.convert("RGB").save(out)

if __name__ == "__main__":
    o = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "tools", "_sheets"); os.makedirs(o, exist_ok=True)
    for fn in (main_menu, say, choice, prefs): fn(os.path.join(o, "gmock_%s.png" % fn.__name__))
    print("ok")
