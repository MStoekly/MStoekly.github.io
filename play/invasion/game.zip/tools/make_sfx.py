"""Synthesize the hunt minigame's sound effects (1950s sci-fi: theremin wails,
saucer hums and wet alien gulps over chiptune blips), pure stdlib.

    python tools/make_sfx.py            # writes game/audio/sfx_*.wav
    python tools/make_sfx.py --check    # also asserts every file is sane

22050 Hz, mono, 16-bit. Deterministic (seeded noise), so re-running gives
identical files. Tweak the recipes below and re-run; no engine restart needed
beyond what Ren'Py already needs for new audio files.
"""
import math
import os
import random
import struct
import sys
import wave

RATE = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "game", "audio")


def n_samples(sec):
    return int(sec * RATE)


def square(freq, sec, duty=0.5, sweep_to=None):
    n = n_samples(sec)
    out = []
    phase = 0.0
    for i in range(n):
        f = freq if sweep_to is None else freq + (sweep_to - freq) * (i / float(n))
        phase = (phase + f / RATE) % 1.0
        out.append(1.0 if phase < duty else -1.0)
    return out


def sine(freq, sec, sweep_to=None):
    n = n_samples(sec)
    out = []
    phase = 0.0
    for i in range(n):
        f = freq if sweep_to is None else freq + (sweep_to - freq) * (i / float(n))
        phase += 2.0 * math.pi * f / RATE
        out.append(math.sin(phase))
    return out


def theremin(freq, sec, glide_to=None, vib_rate=6.0, vib_depth=0.035, wob=0.0):
    """A sine with vibrato and portamento: the B-movie theremin. wob adds a slow
    second vibrato for the woozy, hypnotic sounds."""
    n = n_samples(sec)
    out = []
    phase = 0.0
    for i in range(n):
        t = i / float(RATE)
        u = i / float(max(1, n))
        f = freq if glide_to is None else freq * (glide_to / freq) ** u
        f *= 1.0 + vib_depth * math.sin(2.0 * math.pi * vib_rate * t) + wob * math.sin(2.0 * math.pi * 1.7 * t)
        phase += 2.0 * math.pi * f / RATE
        out.append(math.sin(phase) + 0.18 * math.sin(2.0 * phase))
    return out


def noise(sec, rnd, lp_start=1.0, lp_end=1.0):
    """White noise through a one-pole low-pass whose coefficient glides."""
    n = n_samples(sec)
    out = []
    y = 0.0
    for i in range(n):
        a = lp_start + (lp_end - lp_start) * (i / float(n))
        y += a * (rnd.uniform(-1.0, 1.0) - y)
        out.append(y)
    return out


def env(samples, attack=0.003, decay=4.0, release=0.01):
    """Fast attack, exponential decay, short release to avoid clicks."""
    n = len(samples)
    a = max(1, n_samples(attack))
    r = max(1, n_samples(release))
    out = []
    for i, s in enumerate(samples):
        g = min(1.0, i / float(a)) * math.exp(-decay * i / float(n))
        if i > n - r:
            g *= (n - i) / float(r)
        out.append(s * g)
    return out


def mix(*tracks):
    n = max(len(t) for t in tracks)
    out = [0.0] * n
    for t in tracks:
        for i, s in enumerate(t):
            out[i] += s
    return out


def seq(*parts):
    out = []
    for p in parts:
        out.extend(p)
    return out


def gain(samples, g):
    return [s * g for s in samples]


def note(semitones_from_a4):
    return 440.0 * 2.0 ** (semitones_from_a4 / 12.0)


def write(name, samples, vol=0.5):
    peak = max(1e-9, max(abs(s) for s in samples))
    path = os.path.join(OUT, name)
    w = wave.open(path, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(RATE)
    w.writeframes(b"".join(struct.pack("<h", int(s / peak * vol * 32767)) for s in samples))
    w.close()
    return path


def build():
    rnd = random.Random(7)
    files = {}

    # feed (absorb): a wet descending gulp, then a rising zap arpeggio that gets
    # longer and higher for richer prey. tier 0..4
    for tier in range(5):
        base = -7 + tier * 3                      # semitones from A4
        notes = [base, base + 5, base + 10] + ([base + 15] if tier >= 2 else []) + ([base + 19] if tier >= 4 else [])
        seg = 0.05 + 0.01 * tier
        gulp = env(theremin(320.0, 0.12, glide_to=90.0, vib_rate=30.0, vib_depth=0.12), attack=0.005, decay=3.0)
        arp = seq(*[env(sine(note(s), seg), decay=2.5) for s in notes])
        slurp = env(noise(0.16, rnd, 0.05, 0.4), attack=0.02, decay=3.0)
        files["sfx_feed_%d.wav" % tier] = mix(gain(gulp, 0.7), gain([0.0] * n_samples(0.07) + arp, 0.6), gain(slurp, 0.3))

    # hurt: an alien squeal over a body hit
    squeal = env(theremin(1400.0, 0.26, glide_to=380.0, vib_rate=22.0, vib_depth=0.08), attack=0.003, decay=3.0)
    thud = env(square(190.0, 0.22, duty=0.5, sweep_to=50.0), decay=3.5)
    crunch = env(noise(0.1, rnd, 1.0, 0.3), attack=0.001, decay=5.0)
    files["sfx_hurt.wav"] = mix(gain(squeal, 0.55), gain(thud, 0.6), gain(crunch, 0.5))

    c1 = env(noise(0.14, rnd, 1.0, 0.5), attack=0.001, decay=6.0)
    c2 = env(square(note(-2), 0.1, duty=0.125), decay=6.0)
    c3 = env(square(note(-1) * 1.0, 0.1, duty=0.125), decay=6.0)
    files["sfx_clash.wav"] = mix(gain(c1, 0.8), gain(c2, 0.3), gain(c3, 0.3))

    # captured: a long falling theremin wail
    wail = env(theremin(note(7), 1.1, glide_to=note(-22), vib_rate=7.0, vib_depth=0.05), attack=0.03, decay=1.6)
    files["sfx_death.wav"] = mix(gain(wail, 0.8), gain(env(noise(0.9, rnd, 0.05, 0.02), attack=0.1, decay=2.0), 0.25))

    # start: the classic rising theremin "whoo-ooo"
    files["sfx_start.wav"] = env(theremin(note(-5), 0.5, glide_to=note(10), vib_rate=6.5, vib_depth=0.05), attack=0.04, decay=2.0)

    # phase: a quick upward zap with a crackle of static
    pop = env(sine(240.0, 0.13, sweep_to=1600.0), attack=0.002, decay=3.5)
    puff = env(noise(0.15, rnd, 0.9, 0.15), attack=0.001, decay=5.0)
    files["sfx_blink.wav"] = mix(gain(pop, 0.8), gain(puff, 0.5))

    # dawn: the mothership arrives, a shimmering chord over a low hum
    chord = mix(*[env(theremin(note(s), 1.2, vib_rate=5.0 + i, vib_depth=0.02), attack=0.15, decay=1.4) for i, s in enumerate((-12, -5, 0, 4))])
    hum = env(square(55.0, 1.2, duty=0.5), attack=0.2, decay=1.2)
    files["sfx_dawn.wav"] = mix(gain(chord, 0.7), gain(hum, 0.18))

    # beam: the tractor beam locks on and lifts, a rising hum with a pulsing whine
    lift = env(theremin(110.0, 0.9, glide_to=660.0, vib_rate=14.0, vib_depth=0.06), attack=0.02, decay=1.2)
    whine = env(sine(note(24), 0.9, sweep_to=note(36)), attack=0.05, decay=2.0)
    files["sfx_beam.wav"] = mix(gain(lift, 0.8), gain(whine, 0.2))

    # thrall: a woozy, hypnotic theremin swirl
    swirl = env(theremin(note(2), 0.85, glide_to=note(9), vib_rate=4.0, vib_depth=0.07, wob=0.04), attack=0.05, decay=2.0)
    ping = env(sine(note(26), 0.3), attack=0.01, decay=4.0)
    files["sfx_charm.wav"] = mix(gain(swirl, 0.8), gain(ping, 0.2))

    # frenzy: a gargling roar, noise over a growl with a fast wobble
    growl = env(theremin(140.0, 0.75, glide_to=55.0, vib_rate=28.0, vib_depth=0.25), attack=0.01, decay=1.6)
    roar = env(noise(0.7, rnd, 0.35, 0.08), attack=0.02, decay=1.8)
    files["sfx_bloodlust.wav"] = mix(gain(growl, 0.8), gain(roar, 0.6))

    # meter full: a bright two-note ping
    files["sfx_ready.wav"] = seq(env(square(note(7), 0.09, duty=0.25), decay=3.0),
                                 env(square(note(14), 0.2, duty=0.25), decay=2.5))

    # a hunter killed during bloodlust: heavy crunch with a rising snarl
    kthud = env(square(150.0, 0.22, duty=0.5, sweep_to=45.0), decay=3.0)
    kcrunch = env(noise(0.12, rnd, 1.0, 0.25), attack=0.001, decay=5.0)
    ksnarl = env(sine(180.0, 0.16, sweep_to=520.0), decay=3.0)
    files["sfx_kill.wav"] = mix(gain(kthud, 0.8), gain(kcrunch, 0.7), gain(ksnarl, 0.3))

    # extraction bonus: a quick rising run of computer blips
    coins = seq(*[env(sine(note(s), 0.07), decay=2.5) for s in (4, 9, 12, 16, 21)])
    files["sfx_bonus.wav"] = mix(gain(coins, 0.8), gain([0.0] * n_samples(0.2) + env(sine(note(33), 0.6), attack=0.02, decay=3.0), 0.25))

    # Harvest start: time stops. A record-stop pitch fall, a deep boom, an icy ring on top.
    fall = env(square(520.0, 0.55, duty=0.5, sweep_to=38.0), attack=0.005, decay=1.8)
    boom = env(sine(70.0, 0.7, sweep_to=28.0), attack=0.005, decay=2.2)
    ice = env(sine(note(39), 0.9), attack=0.15, decay=2.2)
    hush = env(noise(0.5, rnd, 0.25, 0.05), attack=0.02, decay=3.0)
    files["sfx_harvest.wav"] = mix(gain(fall, 0.7), gain(boom, 0.9), gain([0.0] * n_samples(0.25) + ice, 0.3), gain(hush, 0.35))

    # Harvest end: the frozen moment shatters. A glass crack of noise, then falling tinkles.
    crack = env(noise(0.25, rnd, 1.0, 0.4), attack=0.001, decay=5.0)
    tink = [0.0] * n_samples(0.04)
    for i, nn in enumerate((43, 48, 40, 51, 46, 53, 44, 49)):
        tink = mix(tink, [0.0] * n_samples(0.05 * i) + env(sine(note(nn), 0.22), attack=0.002, decay=4.0))
    files["sfx_shatter.wav"] = mix(gain(crack, 0.9), gain(tink, 0.45), gain(env(sine(110.0, 0.5, sweep_to=45.0), attack=0.003, decay=3.5), 0.5))

    # regenerate: soft bubbling, cells knitting back together
    heal = seq(*[env(theremin(note(n), 0.13, vib_rate=25.0, vib_depth=0.04), attack=0.01, decay=2.2) for n in (0, 4, 7, 12)])
    files["sfx_heal.wav"] = mix(gain(heal, 0.8), gain([0.0] * n_samples(0.08) + env(sine(note(19), 0.5), attack=0.05, decay=3.0), 0.25))

    # low-HP heartbeat: two soft low thumps
    def thump(f):
        return env(sine(f, 0.14, sweep_to=f * 0.5), attack=0.004, decay=5.0)
    files["sfx_beat.wav"] = seq(thump(90.0), [0.0] * n_samples(0.06), gain(thump(75.0), 0.8), [0.0] * n_samples(0.05))
    return files


def main():
    if not os.path.isdir(OUT):
        os.makedirs(OUT)
    files = build()
    total = 0
    for name in sorted(files):
        p = write(name, files[name])
        total += os.path.getsize(p)
        print("%-18s %.2fs  %5d KB" % (name, len(files[name]) / float(RATE), os.path.getsize(p) // 1024))
    if "--check" in sys.argv:
        for name in files:
            w = wave.open(os.path.join(OUT, name), "rb")
            assert w.getnchannels() == 1 and w.getsampwidth() == 2 and w.getframerate() == RATE
            frames = w.readframes(w.getnframes())
            vals = struct.unpack("<%dh" % w.getnframes(), frames)
            assert 0.05 < w.getnframes() / float(RATE) < 1.5, name
            assert max(abs(v) for v in vals) > 8000, name + " too quiet"
            assert abs(vals[0]) < 800 and abs(vals[-1]) < 800, name + " clicks at the edges"
            w.close()
        print("CHECK OK (%d files, %d KB)" % (len(files), total // 1024))


if __name__ == "__main__":
    main()
