"""Contact sheet of the pixel UI assets, incl. 9-slice panels stretched to sizes.
Usage: python tools/make_ui_sheet.py [out.png]   (default tools/_sheets/ui_sheet.png)"""
import io, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "game", "python-packages"))
from PIL import Image, ImageDraw, ImageFont
import pixel_ui as ui

S = 3
FONTS = os.path.join(HERE, "..", "game", "fonts")
def img(c, s=S): return Image.open(io.BytesIO(c.png(s))).convert("RGBA")

def nine(c, border, w, h):
    """Stretch-free 9-slice at native scale: corners kept, edges/centre tiled."""
    src = img(c); b = border * S
    W, H = w * S, h * S
    out = Image.new("RGBA", (W, H))
    sw, sh = src.size
    def tile(box, dst):
        piece = src.crop(box)
        for y in range(dst[1], dst[3], piece.size[1]):
            for x in range(dst[0], dst[2], piece.size[0]):
                out.paste(piece.crop((0, 0, min(piece.size[0], dst[2] - x), min(piece.size[1], dst[3] - y))), (x, y))
    # centre first, then edges, then corners, so nothing overpaints a border
    tile((b, b, sw - b, sh - b), (b, b, W - b, H - b))
    tile((b, 0, sw - b, b), (b, 0, W - b, b)); tile((b, sh - b, sw - b, sh), (b, H - b, W - b, H))
    tile((0, b, b, sh - b), (0, b, b, H - b)); tile((sw - b, b, sw, sh - b), (W - b, b, W, H - b))
    out.paste(src.crop((0, 0, b, b)), (0, 0)); out.paste(src.crop((sw - b, 0, sw, b)), (W - b, 0))
    out.paste(src.crop((0, sh - b, b, sh)), (0, H - b)); out.paste(src.crop((sw - b, sh - b, sw, sh)), (W - b, H - b))
    return out

def main(out):
    sheet = Image.new("RGBA", (1700, 1150))
    t = img(ui.bg_tile())
    for y in range(0, sheet.size[1], t.size[1]):
        for x in range(0, sheet.size[0], t.size[0]): sheet.paste(t, (x, y))
    fnt = ImageFont.truetype(os.path.join(FONTS, "PixelifySans-Regular.ttf"), 26)
    bold = ImageFont.truetype(os.path.join(FONTS, "PixelifySans-Bold.ttf"), 44)
    d = ImageDraw.Draw(sheet)
    x = 20
    for kind in ("stone", "blood", "gold", "dim"):
        p = nine(ui.panel(kind), ui.PANEL_BORDER, 120, 70); sheet.alpha_composite(p, (x, 20))
        d.text((x + 40, 40), kind, font=fnt, fill="#f4ecd8"); x += p.size[0] + 14
    d.text((60, 90), "INVASION", font=bold, fill="#8dff5a")
    d.text((60, 140), "Cream body text  /  dim  /", font=fnt, fill="#f4ecd8")
    d.text((420, 140), "dim text", font=fnt, fill="#8aa3a6"); d.text((560, 140), "danger", font=fnt, fill="#ff4f5e")
    x = 20
    for st in ("idle", "hover", "insensitive"):
        b = nine(ui.button(st), ui.BUTTON_BORDER, 90, 22); sheet.alpha_composite(b, (x, 260))
        d.text((x + 70, 278), st, font=fnt, fill={"idle": "#f4ecd8", "hover": "#8dff5a", "insensitive": "#55666b"}[st]); x += b.size[0] + 14
    x = 20
    for kind in ("stone", "gold", "blood", "dim"):
        cd = nine(ui.card(kind), ui.CARD_BORDER, 96, 30); sheet.alpha_composite(cd, (x, 350))
        d.text((x + 30, 380), "card " + kind, font=fnt, fill="#f4ecd8" if kind != "dim" else "#55666b"); x += cd.size[0] + 14
    sl = nine(ui.slot(), ui.SLOT_BORDER, 100, 9); sheet.alpha_composite(sl, (20, 470))
    d.rectangle((20 + 9, 470 + 9, 20 + 9 + 160, 470 + 17), fill="#3a9a30"); d.rectangle((29, 479, 189, 481), fill="#8dff5a")
    x = 20; y = 540
    for f in (1.0, 0.75, 0.5, 0.25, 0.0):
        h = img(ui.heart(True, f), 4); sheet.alpha_composite(h, (x, y)); d.text((x, y + 56), "%.2f" % f, font=fnt, fill="#8aa3a6"); x += h.size[0] + 16
    h = img(ui.heart(False), 4); sheet.alpha_composite(h, (x, y)); d.text((x, y + 56), "empty", font=fnt, fill="#8aa3a6"); x += h.size[0] + 30
    for f in (True, False):
        h = img(ui.drop(f), 4); sheet.alpha_composite(h, (x, y)); x += h.size[0] + 16
    h = img(ui.lock(), 4); sheet.alpha_composite(h, (x, y)); x += h.size[0] + 16
    for f in (True, False):
        h = img(ui.pip(f), 4); sheet.alpha_composite(h, (x, y)); x += h.size[0] + 16
    # HUD-scale (3x) row of hearts, as hunt.rpy uses them
    x = 1000
    for f in (1.0, 1.0, 0.75, 0.5, 0.25, 0.0):
        h = img(ui.heart(f > 0, f if f > 0 else 1.0), 3); sheet.alpha_composite(h, (x, y)); x += 51
    x = 20; y = 660
    for n in ("speed", "constitution", "allure", "strength", "blink", "charm", "bloodlust", "drain", "ultimate"):
        bg = nine(ui.card("dim"), ui.CARD_BORDER, 32, 32); sheet.alpha_composite(bg, (x, y))
        h = img(ui.icon(n), 4); sheet.alpha_composite(h, (x + 48 - 36, y + 48 - 36))
        d.text((x, y + 104), n, font=fnt, fill="#8aa3a6"); x += 96 + 80
    x = 20; y = 860
    for n in ("speed", "constitution", "allure", "strength", "blink", "charm", "bloodlust", "drain", "ultimate"):
        h = img(ui.icon(n), 2); sheet.alpha_composite(h, (x, y)); x += 60
    sheet.alpha_composite(img(ui.divider(120)), (20, 960))
    sheet.alpha_composite(img(ui.divider(60)), (420, 960))
    sheet.alpha_composite(nine(ui.panel("stone"), ui.PANEL_BORDER, 200, 40), (800, 900))
    sheet.convert("RGB").save(out)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "_sheets", "ui_sheet.png")
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    main(out)
    print("wrote", out)
