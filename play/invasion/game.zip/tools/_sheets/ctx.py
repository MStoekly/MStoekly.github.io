import os, sys
sys.path.insert(0, os.environ["PP"])
import pixel_fifties
sys.modules["pixel_medieval"] = pixel_fifties      # building() does `import pixel_medieval`
import pixel_art as pa
import mps_env as mps
import hunt_core
out = sys.argv[1]
for lv in hunt_core.LEVELS:
    c, m = mps.map_sheet(lv["biome"], lv["tiles"], 11)
    with open(os.path.join(out, "ctx_%s.png" % lv["key"]), "wb") as f:
        f.write(c.png(1))
    print(lv["key"], c.w, c.h, len(m["objects"]))
