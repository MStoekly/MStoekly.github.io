import sys, os
sys.path.insert(0, os.environ["PP"])
import pixel_art as pa, importlib
mod = importlib.import_module(sys.argv[1]); out = sys.argv[2]; scale = int(sys.argv[3])
items = [a.split(":") for a in sys.argv[4:]]
cs = [mod.build(kk, int(v)) for kk, v in items]
W = sum(c.w + 4 for c in cs) + 4; H = max(c.h for c in cs) + 8
s = pa.Canvas(W, H); s.rect(0, 0, W, H, pa._rgb("#0c1626"))
x = 4
for c in cs:
    s.blit(c, x, H - 4 - c.h); x += c.w + 4
open(out, "wb").write(s.png(scale)); print("ok")
