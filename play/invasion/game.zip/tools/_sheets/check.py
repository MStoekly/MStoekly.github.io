import sys, os
sys.path.insert(0, os.environ["PP"])
import pixel_art as pa, pixel_medieval as pm, pixel_fifties as pf
bad = 0
for kind in sorted(pa.BUILDINGS):
    for v in range(8):
        a, b = pm.build(kind, v), pf.build(kind, v)
        if (a.w, a.h) != (b.w, b.h):
            bad += 1; print("MISMATCH", kind, v, (a.w, a.h), (b.w, b.h))
        # determinism
        c = pf.build(kind, v)
        assert c.p == b.p, (kind, v)
        # bottom row coverage
        row = b.p[b.h - 2]
        cov = sum(1 for p in row[1:-1] if p is not None)
print("kinds", len(pa.BUILDINGS), "bad", bad)
