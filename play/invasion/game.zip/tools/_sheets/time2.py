import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "game", "python-packages"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hunt_mapgen, pixel_art as new, pixel_art_before as old
sizes = {"forest": (34, 22), "road": (40, 26), "outskirts": (48, 30), "village": (56, 34), "town": (96, 64)}
for b in ("forest", "road", "village", "town"):
    m = hunt_mapgen.generate(b, sizes[b][0], sizes[b][1], 11)
    r = {}
    for rep in range(3):
        for name, mod in (("old", old), ("new", new)):
            t = time.time(); mod.render_ground(m); d = time.time() - t
            r[name] = min(r.get(name, 9), d)
    print(b, "old %.2fs new %.2fs (%+.0f%%)" % (r["old"], r["new"], 100 * (r["new"] / r["old"] - 1)))
