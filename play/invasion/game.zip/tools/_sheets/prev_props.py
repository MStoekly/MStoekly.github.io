import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "game", "python-packages"))
import pixel_art as pa
items = []
for kind in sorted(pa.OBJECTS):
    spec = pa.OBJECTS[kind]
    if spec.get("building"): continue
    for v in range(spec["variants"]):
        for layer in ("base", "crown"):
            c = pa.object_canvas(kind, v, layer)
            if c is not None: items.append(c)
W = int(sys.argv[1]) if len(sys.argv) > 1 else 300
x, y, rowh, placed = 4, 4, 0, []
for c in items:
    if x + c.w + 4 > W:
        x, y, rowh = 4, y + rowh + 4, 0
    placed.append((c, x, y)); x += c.w + 4; rowh = max(rowh, c.h)
sh = pa.Canvas(W, y + rowh + 4)
sh.rect(0, 0, W, sh.h, pa.C["f_grass1"])
sh.rect(0, sh.h // 2, W, sh.h, pa.C["f_asph2"])
for c, a, b in placed: sh.blit(c, a, b)
open(os.path.join(HERE, "props.png"), "wb").write(sh.png(int(sys.argv[2]) if len(sys.argv) > 2 else 3))
print("ok", sh.w, sh.h)
