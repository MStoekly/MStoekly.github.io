import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "game", "python-packages"))
import pixel_art as pa
W, H = 4 * 18 * 2 + 10, 7 * 18 + 4
sh = pa.Canvas(W, H)
sh.rect(0, 0, W // 2, H, pa.C["f_grass1"])
sh.rect(W // 2, 0, W, H, pa.C["f_asph2"])
for half in (0, 1):
    ox = half * (W // 2) + 4
    for s in range(5):
        for i, f in enumerate(("down", "up", "right", "left")):
            sh.blit(pa.character_canvas("vampire", f, s), ox + i * 18, 2 + s * 18)
    for i, f in enumerate(("down", "up", "right", "left")):
        sh.blit(pa.character_canvas("hunter", f), ox + i * 18, 2 + 5 * 18)
    for t in range(5):
        sh.blit(pa.character_canvas("prey", "down", t), ox + t * 15 - 2, 2 + 6 * 18)
open(os.path.join(HERE, "chars.png"), "wb").write(sh.png(6))
print("ok")
