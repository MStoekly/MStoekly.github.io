"""Splice part files into pixel_art.py between markers (re-reads the file right before writing)."""
import io, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(HERE, "..", "..", "game", "python-packages", "pixel_art.py")

def part(name):
    return io.open(os.path.join(HERE, name), encoding="utf-8").read()

def between(text, start, end, new):
    assert text.count(start) == 1, ("start", start)
    i = text.index(start)
    j = text.index(end, i)
    assert text.count(end) >= 1, ("end", end)
    return text[:i] + new + text[j:]

def rep(text, old, new, count=1):
    assert text.count(old) == count, (old[:60], text.count(old))
    return text.replace(old, new)

jobs = sys.argv[1:]
text = io.open(PATH, encoding="utf-8").read()
for job in jobs:
    if job == "palette":
        pal = part("part_palette.txt")
        if '"f_alien_d"' in text:
            i = text.index("    # ---- Invasion (1950s")
            j = text.index("}.items())", i)
            text = text[:i] + pal + text[j:]
        else:
            text = rep(text, '"shutter_r": "#7a2a2a",\n}.items())', '"shutter_r": "#7a2a2a",\n' + pal + '}.items())')
    elif job == "chars":
        start = "def _alien_eye(" if "def _alien_eye(" in text else "def vampire("
        text = between(text, start, "def lunge_ring(", part("part_chars.txt"))
        old = '        c = vampire(face)\n'
        if old in text:
            text = rep(text, old, '        c = vampire(face, tier)\n')
    elif job == "props":
        text = between(text, "def _trunk(", "# ---------------------------------------------------------------------------\n# buildings.", part("part_props.txt"))
    elif job == "props2":
        text = between(text, "def bench(", "# kind -> sprite builders.", part("part_props2.txt"))
    elif job == "ground":
        text = between(text, "_BIOME_STYLE = {", "class _Noise(", part("part_style.txt"))
        text = between(text, "def _zone_color(", "# ---------------------------------------------------------------------------\n# cache:", part("part_ground.txt"))
    elif job == "arrows":
        i = text.index("_ARROW_COLORS = {")
        j = text.index("\n", i)
        text = text[:i] + '_ARROW_COLORS = {"hunter": "red_l", 0: "f_cow_w", 1: "f_denim_l", 2: "f_mint", 3: "f_chrome", 4: "gold"}' + text[j:]
    else:
        raise SystemExit("unknown job " + job)
cur = io.open(PATH, encoding="utf-8").read()   # re-read right before writing (nobody else owns it; just a sanity check)
io.open(PATH, "w", encoding="utf-8", newline="\n").write(text)
print("spliced", jobs, len(cur), "->", len(text))
