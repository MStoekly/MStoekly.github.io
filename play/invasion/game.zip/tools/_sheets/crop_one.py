import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "game", "python-packages"))
sys.path.insert(0, os.path.join(HERE, ".."))
import pixel_art as pa, hunt_core, make_pixel_sheet as mps
lv = [l for l in hunt_core.LEVELS if l["biome"] == sys.argv[1]][0]
c, m = mps.map_sheet(lv["biome"], lv["tiles"], int(sys.argv[2]) if len(sys.argv) > 2 else 11)
fx, fy = float(sys.argv[3]), float(sys.argv[4])
w, h = 220, 130
x0, y0 = int(c.w * fx) - w // 2, int(c.h * fy) - h // 2
o = pa.Canvas(w, h)
for y in range(h):
    o.p[y] = list(c.p[y0 + y][x0:x0 + w])
open(os.path.join(HERE, "crop.png"), "wb").write(o.png(4))
print("ok")
