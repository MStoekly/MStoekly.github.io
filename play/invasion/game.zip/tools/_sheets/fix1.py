import io
p = "part_chars.txt"
t = io.open(p, encoding="utf-8").read()
def rep(old, new, n=1):
    global t
    assert t.count(old) == n, (old, t.count(old))
    t = t.replace(old, new)
# side: spikes after the body, outside it
rep('''        if s >= 2:                                             # spikes along the back
            for i, (sx, sy) in enumerate(((3, 9), (2, 11), (4, 7))):
                c.px(sx, sy, dark)
                c.px(sx - 1, sy - 1, "f_neon_d" if s >= 3 else dark)
        c.rect(5, 13, 7, 15, dark)                             # feet
        c.rect(8, 13, 10, 15, dark)
        c.shade_ellipse(bcx, bcy, bx, by, skin)
        c.shade_ellipse(hcx, hcy, hx, hy, skin)
''', '''        c.rect(5, 13, 7, 15, dark)                             # feet
        c.rect(8, 13, 10, 15, dark)
        c.shade_ellipse(bcx, bcy, bx, by, skin)
        c.shade_ellipse(hcx, hcy, hx, hy, skin)
        if s >= 2:                                             # spikes along the back
            for sx, sy in ((3, 5), (2, 9), (2, 12)):
                c.px(sx + 1, sy, dark)
                c.px(sx, sy, dark)
                c.px(sx, sy + 1, dark)
                c.px(sx - 1, sy - 1, "f_neon" if s >= 3 else "f_alien_l")
''')
# side eye: slanted almond
rep('''        for px_, py_ in ((ex, ey), (ex + 1, ey), (ex, ey + 1), (ex + 1, ey + 1), (ex + 2, ey + 1), (ex + 1, ey + 2)):
            c.px(px_, py_, "f_eye")
        c.px(ex, ey, "f_eye_l")''', '''        for px_, py_ in ((ex - 1, ey), (ex, ey), (ex + 1, ey), (ex, ey + 1), (ex + 1, ey + 1), (ex + 2, ey + 1), (ex + 2, ey + 2)):
            c.px(px_, py_, "f_eye")
        c.px(ex, ey, "f_eye_l")''')
# down: clearer shoulder spikes
rep('''        if s >= 2:                                             # shoulder spikes
            c.px(3, 10, dark)
            c.px(2, 9, "f_neon_d" if s >= 3 else dark)
            c.px(12, 10, dark)
            c.px(13, 9, "f_neon_d" if s >= 3 else dark)
''', '''        if s >= 2:                                             # shoulder spikes
            for sx, d in ((3, -1), (12, 1)):
                c.px(sx, 11, dark)
                c.px(sx, 10, dark)
                c.px(sx + d, 10, dark)
                c.px(sx + d, 9, dark)
                c.px(sx + 2 * d, 8, "f_neon" if s >= 3 else "f_alien_l")
''')
rep('''        if s >= 2:                                             # ridge of spikes down the back
            for y in range(top, 14, 2):
                c.px(8, y, "f_neon_d" if s >= 3 else dark)
                c.px(7, y + 1, dark)
                c.px(9, y + 1, dark)
            c.px(3, 10, dark)
            c.px(12, 10, dark)
''', '''        if s >= 2:                                             # ridge of spikes down the back
            for y in range(top + 1, 13, 2):
                c.px(8, y, "f_alien_l" if s < 3 else "f_neon")
                c.px(7, y + 1, dark)
                c.px(8, y + 1, dark)
                c.px(9, y + 1, dark)
            for sx, d in ((3, -1), (12, 1)):
                c.px(sx, 11, dark)
                c.px(sx, 10, dark)
                c.px(sx + d, 10, dark)
                c.px(sx + d, 9, dark)
                c.px(sx + 2 * d, 8, "f_neon" if s >= 3 else "f_alien_l")
''')
# veins: fewer
rep('''            for vx, vy in ((5, 11), (6, 12), (11, 11), (10, 12), (5, 7), (11, 7)):
                c.px(vx, vy, "f_neon")''', '''            for vx, vy in ((5, 11), (6, 12), (11, 11), (10, 12)):
                c.px(vx, vy, "f_neon")''')
rep('''            for vx, vy in ((6, 11), (7, 12), (10, 11), (9, 12), (4, 8), (11, 8)):
                c.px(vx, vy, "f_neon")''', '''            for vx, vy in ((6, 11), (7, 12), (10, 11), (9, 12)):
                c.px(vx, vy, "f_neon_d")''')
rep('''            for vx, vy in ((6, 11), (7, 12), (8, 11), (5, 7), (6, 8)):
                c.px(vx, vy, "f_neon_d")''', '''            for vx, vy in ((6, 11), (7, 12), (8, 11)):
                c.px(vx, vy, "f_neon_d")''')
# crown of tentacles: staggered curls
rep('''    if s >= 4 and facing != "side":                            # tentacle crown
        for (x0, x1, x2) in ((4, 3, 2), (6, 5, 5), (8, 8, 8), (10, 11, 11), (12, 13, 14)):
            c.px(x0, top, dark)
            c.px(x0, top - 1, dark)
            c.px(x1, top - 2, "f_alien")
            c.px(x2, top - 3, "f_neon")
''', '''    if s >= 4 and facing != "side":                            # tentacle crown
        for pts in (((4, 0), (3, -1), (2, -1), (1, -2)), ((6, 0), (6, -1), (5, -2)), ((8, 0), (8, -1), (9, -2)),
                    ((10, 0), (10, -1), (11, -2)), ((12, 0), (13, -1), (14, -1), (14, -2))):
            for i, (x, y) in enumerate(pts):
                c.px(x, top + y, "f_neon" if i == len(pts) - 1 else dark)
''')
rep('''            for (x0, x1, x2) in ((5, 4, 3), (7, 6, 6), (9, 9, 10), (11, 12, 13)):
                c.px(x0, top - 1, dark)
                c.px(x1, top - 2, "f_alien")
                c.px(x2, top - 3, "f_neon")
            c.px(4, top - 1, dark)
            c.px(12, top - 1, dark)''', '''            for pts in (((5, 0), (4, -1), (3, -1), (2, -2)), ((7, 0), (7, -1), (6, -2)), ((9, 0), (9, -1), (10, -2)),
                        ((11, 0), (12, -1), (13, -2))):
                for i, (x, y) in enumerate(pts):
                    c.px(x, top + y, "f_neon" if i == len(pts) - 1 else dark)''')
rep('''                        if _hash(x, y, 91 + stage) > 0.62:''', '''                        if _hash(x, y, 91 + stage) > 0.84:''')
rep('''        c.p[y][x] = C["f_neon"] if _hash(x, y, 17) > 0.45 else C["f_neon_l"]''', '''        c.p[y][x] = C["f_neon"]''')
# soldier rifle contrast
rep('''        c.line(3, 13, 11, 9, "f_wood")                         # rifle across the chest
        c.line(11, 9, 14, 7, "f_steel")''', '''        c.line(3, 13, 11, 9, "wood_l")                         # rifle across the chest
        c.line(11, 9, 14, 7, "f_steel_l")''')
rep('''        c.line(5, 10, 14, 10, "f_wood")                        # rifle, held forward
        c.line(10, 10, 14, 10, "f_steel")''', '''        c.line(5, 10, 14, 10, "wood_l")                        # rifle, held forward
        c.line(10, 10, 14, 10, "f_steel_l")''')
rep('''        c.line(3, 13, 12, 6, "f_wood")                         # rifle slung across the back
        c.line(10, 8, 13, 5, "f_steel")''', '''        c.line(3, 13, 12, 6, "wood_l")                         # rifle slung across the back
        c.line(10, 8, 13, 5, "f_steel_l")''')
rep("(6, 14), (10, 14), (7, 9), (13, 13), (3, 13)):", "(6, 14), (10, 14), (7, 9), (4, 13), (12, 13)):")
rep('''        c.shade_ellipse(8, 4.4, 3.4, 2.2, ramp("f_cherry_d", "f_cherry", "f_cherry_l"))''', '''        c.shade_ellipse(8, 4.2, 3.2, 1.9, ramp("f_cherry_d", "f_cherry", "f_cherry_l"))''')
io.open(p, "w", encoding="utf-8", newline="\n").write(t)
print("ok")
