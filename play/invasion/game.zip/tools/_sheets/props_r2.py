import io
t = io.open("part_props.txt", encoding="utf-8").read()
def swap(start, end, new):
    global t
    i = t.index(start); j = t.index(end, i)
    t = t[:i] + new + t[j:]
swap("def dead_tree(", "def rock(", '''def dead_tree(variant=0):
    """A scorched, burnt tree: charred black limbs with a few live embers."""
    rnd = random.Random(300 + variant)
    c = Canvas(24, 32)
    cols = ramp("f_char0", "f_char1", "f_char2", "f_char3")
    for y in range(8, 30):
        flare = 1 if y >= 27 else 0
        for x in range(10 - flare, 14 + flare):
            c.px(x, y, cols[3 if x == 10 else (2 if x < 12 else 1)])
    c.line(12, 14, 5, 6, cols[2])
    c.line(12, 12, 19, 4, cols[2])
    c.line(12, 18, 20, 13, cols[1])
    c.line(5, 6, 3, 2, cols[1])
    c.line(19, 4, 21, 1, cols[1])
    c.line(5, 6, 7, 3, cols[1])
    for _ in range(4):                                         # charcoal cracks
        c.px(10 + rnd.randint(0, 3), rnd.randint(10, 26), cols[0])
    for x, y in ((3, 2), (21, 1), (20, 13)):                   # smouldering tips
        c.px(x, y, "f_ember")
    for _ in range(3):                                         # embers in the bark
        y = rnd.randint(12, 26)
        c.px(11 + rnd.randint(0, 1), y, "f_ember")
        c.px(11 + rnd.randint(0, 1), y + 1, "f_ember_l" if rnd.random() < 0.5 else "f_ember")
    c.outline("ink")
    return c


''')
swap("def gravestone(", "def crate(", '''def gravestone(variant=0):
    """(Kept under its old name, map key "grave".) Crash debris: a twisted,
    torn fragment of silver saucer hull half buried in scorched earth, its torn
    edge still glowing faintly green."""
    c = Canvas(11, 14)
    c.ellipse(5.5, 11.5, 4.6, 1.6, "f_char1")                 # scorched mound
    c.px(2, 11, "f_char2")
    c.px(8, 12, "f_char2")
    rows = {2: (7, 8), 3: (6, 8), 4: (6, 9), 5: (5, 9), 6: (4, 8), 7: (4, 8),
            8: (3, 8), 9: (3, 8), 10: (2, 7), 11: (2, 6)}
    for y, (x0, x1) in rows.items():
        for x in range(x0, x1 + 1):
            t = (x - x0) / float(max(1, x1 - x0))
            col = "f_chrome" if t < 0.2 else ("silver" if t < 0.6 else "silver_d")
            c.px(x, y, col)
        c.px(x0, y, "white" if y in (4, 5, 8) else "f_chrome")  # moonlit curl
    c.line(5, 4, 3, 10, "silver_d")                           # bent seam
    for x, y in ((7, 6), (6, 8), (5, 10)):                    # rivets
        c.px(x, y, "f_steel")
    c.rect(7, 10, 10, 12, C["silver_d"])                      # a smaller shard
    c.px(7, 10, "f_chrome")
    for x, y in ((9, 4), (9, 5), (8, 3), (8, 6)):             # glowing torn edge
        c.px(x, y, "f_neon")
    c.px(9, 11, "f_neon_d")
    c.outline("ink")
    for x, y in ((10, 4), (10, 5), (9, 2), (9, 7), (10, 10)):   # faint green glow
        if c.get(x, y) is None:
            c.px(x, y, (124, 255, 79, 90))
    return c


''')
swap("def grave_cross(", "\n\n", '''def grave_cross(variant=0):
    """(Kept under its old name, map key "cross".) A red fire hydrant."""
    c = Canvas(12, 18)
    c.rect(3, 15, 9, 17, C["f_cherry_d"])                     # base flange
    c.rect(3, 15, 9, 16, C["f_cherry"])
    body = ["f_cherry_l", "f_cherry", "f_cherry", "f_cherry_d"]
    for y in range(7, 15):
        for i, col in enumerate(body):
            c.px(4 + i, y, col)
    for x in (2, 3, 8, 9):                                    # side nozzles
        c.px(x, 9, "f_cherry_d")
        c.px(x, 10, "f_cherry_d")
    c.px(2, 9, "f_chrome")
    c.px(9, 9, "f_chrome")
    c.rect(5, 10, 7, 12, C["f_chrome"])                       # pumper cap
    c.px(5, 10, "white")
    c.rect(3, 6, 9, 7, C["f_cherry_d"])                       # bonnet rim
    c.rect(4, 5, 8, 6, C["f_cherry"])
    c.px(4, 5, "f_cherry_l")
    c.rect(5, 4, 7, 5, C["f_chrome"])                         # operating nut
    c.px(5, 4, "white")
    c.outline("ink")
    return c''')
io.open("part_props.txt", "w", encoding="utf-8", newline="\n").write(t)
p = io.open("part_palette.txt", encoding="utf-8").read()
old = '''    "f_dead0": "#121218",'''
assert p.count(old) == 1
p = p.replace(old, '''    "f_char0": "#09080a", "f_char1": "#171416", "f_char2": "#272121", "f_char3": "#3a302b",
    "f_ember": "#ff6a24", "f_ember_l": "#ffc060",
''' + old)
io.open("part_palette.txt", "w", encoding="utf-8", newline="\n").write(p)
print("ok")
