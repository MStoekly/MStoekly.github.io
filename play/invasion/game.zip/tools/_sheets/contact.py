"""One contact sheet: alien stages x facings, soldier, prey, props, and a ground
crop from a generated map of every biome (objects + characters composited)."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "game", "python-packages"))
sys.path.insert(0, os.path.join(HERE, ".."))
import pixel_art as pa
import hunt_core
import make_pixel_sheet as mps

CW, CH = 150, 92                       # crop size (native px)
SCALE = int(sys.argv[1]) if len(sys.argv) > 1 else 3

def crop(c, x0, y0, w, h):
    o = pa.Canvas(w, h)
    for y in range(h):
        o.p[y] = list(c.p[min(c.h - 1, y0 + y)][x0:x0 + w])
    return o

def pick(m, c):
    """Window with the most zone variety (structured maps) or around the road."""
    if m.get("road"):
        k = pa.TILE_PX / float(hunt_mapgen.TILE)
        x0 = c.w // 3
        y0 = int(hunt_mapgen.road_center(m["road"], (x0 + CW / 2) / k) * k) - CH // 2
        return x0, max(0, min(c.h - CH, y0))
    if not m.get("grid"):
        return c.w // 2 - CW // 2, c.h // 2 - CH // 2
    g = m["grid"]; tw, th = m["tiles_w"], m["tiles_h"]
    best, at = -1, (0, 0)
    for ty in range(0, th - 6, 2):
        for tx in range(0, tw - 9, 2):
            codes = {}
            for yy in range(ty, ty + 6):
                for ch in g[yy][tx:tx + 9]:
                    codes[ch] = codes.get(ch, 0) + 1
            score = len(codes) * 10 + min(codes.get("w", 0), 8) + min(codes.get("f", 0), 8) + min(codes.get("y", 0), 6)
            if score > best:
                best, at = score, (tx * 16, ty * 16)
    return at

import hunt_mapgen
crops = []
for lv in hunt_core.LEVELS:
    c, m = mps.map_sheet(lv["biome"], lv["tiles"], 11)
    x0, y0 = pick(m, c)
    crops.append(crop(c, x0, y0, CW, CH))

W = CW * 2 + 12
sprites_h = 5 * 18 + 2 * 18 + 6
props = []
for kind in sorted(pa.OBJECTS):
    spec = pa.OBJECTS[kind]
    if spec.get("building"):
        continue
    for v in range(spec["variants"]):
        for layer in ("base", "crown"):
            cc = pa.object_canvas(kind, v, layer)
            if cc is not None:
                props.append(cc)
x, y, rowh, placed = 4, sprites_h, 0, []
for cc in props:
    if x + cc.w + 4 > W:
        x, y, rowh = 4, y + rowh + 3, 0
    placed.append((cc, x, y)); x += cc.w + 3; rowh = max(rowh, cc.h)
gy = y + rowh + 6
H = gy + 3 * (CH + 4)
sh = pa.Canvas(W, H)
sh.rect(0, 0, W, gy, pa.C["f_grass1"])
sh.rect(W // 2, 0, W, sprites_h, pa.C["f_asph2"])
for half in (0, 1):
    ox = half * (W // 2) + 4
    for s in range(5):
        for i, f in enumerate(("down", "up", "right", "left")):
            sh.blit(pa.character_canvas("vampire", f, s), ox + i * 18, 2 + s * 18)
    for i, f in enumerate(("down", "up", "right", "left")):
        sh.blit(pa.character_canvas("hunter", f), ox + i * 18, 2 + 5 * 18)
    for t in range(5):
        sh.blit(pa.character_canvas("prey", "down", t), ox + t * 17, 2 + 6 * 18)
    for t, who in enumerate(("hunter", 0, 1, 2, 3, 4)):
        sh.blit(pa.arrow(4, pa._ARROW_COLORS[who]), ox + 76 + (t % 2) * 12, 2 + (t // 2) * 12)
for cc, a, b in placed:
    sh.blit(cc, a, b)
for i, cc in enumerate(crops):
    sh.blit(cc, 4 + (i % 2) * (CW + 4), gy + (i // 2) * (CH + 4))
open(os.path.join(HERE, "contact.png"), "wb").write(sh.png(SCALE))
print("ok", W * SCALE, H * SCALE)
