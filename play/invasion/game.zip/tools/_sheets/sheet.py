"""Contact sheets for building modules. usage: python sheet.py <module> <out.png> [scale]"""
import os, sys, importlib
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "game", "python-packages"))
import pixel_art as pa

ORDER = ["church", "windmill", "tavern", "stable", "tower", "house_l", "house_m", "house_s", "shed",
         "wall_h", "wall_v", "fence_h", "fence_v"]
BG = pa._rgb("#0c1626")

def sheet(mods, W=1400, variants=4):
    items = []
    for kind in ORDER:
        for v in range(variants):
            row = [m.build(kind, v) for m in mods]
            items.append(row)
    x, y, rowh, placed = 6, 6, 0, []
    for row in items:
        ww = sum(c.w + 4 for c in row) + 6
        if x + ww > W:
            x, y, rowh = 6, y + rowh + 10, 0
        xx = x
        for c in row:
            placed.append((c, xx, y))
            xx += c.w + 4
        x += ww + 6
        rowh = max(rowh, max(c.h for c in row))
    s = pa.Canvas(W, y + rowh + 8)
    s.rect(0, 0, W, s.h, BG)
    for c, px_, py_ in placed:
        # mark footprint area faintly
        s.blit(c, px_, py_)
    return s

if __name__ == "__main__":
    mods = [importlib.import_module(n) for n in sys.argv[1].split(",")]
    scale = int(sys.argv[3]) if len(sys.argv) > 3 else 3
    W = int(sys.argv[4]) if len(sys.argv) > 4 else 900
    with open(sys.argv[2], "wb") as f:
        f.write(sheet(mods, W).png(scale))
    print("ok")
