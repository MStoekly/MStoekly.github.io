import sys, os
mod = sys.argv[1] if len(sys.argv) > 1 else "pixel_art"
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "game", "python-packages"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
pa = __import__(mod)
for k in sorted(pa.OBJECTS):
    s = pa.OBJECTS[k]
    if s.get("building"): continue
    out = []
    for v in range(s["variants"]):
        fp = pa.footprint(k, v); c = s["base"](v); t, b, l, r = pa._bounds(c)
        out.append("v%d r=%.1f cx=%.1f size=%dx%d bbox=%d-%d" % (v, fp["r"], fp["cx"], c.w, c.h, t, b))
    print(k, " | ".join(out))
