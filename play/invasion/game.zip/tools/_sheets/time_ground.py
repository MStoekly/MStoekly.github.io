import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "game", "python-packages"))
import hunt_mapgen, pixel_art as pa
sizes = {"forest": (34, 22), "road": (40, 26), "outskirts": (48, 30), "village": (56, 34), "town": (96, 64)}
for b in ("forest", "road", "outskirts", "village", "town"):
    m = hunt_mapgen.generate(b, sizes[b][0], sizes[b][1], 11)
    best = 1e9; bp = 1e9
    for _ in range(2):
        t = time.time(); c = pa.render_ground(m); t1 = time.time(); c.png(3); t2 = time.time()
        best = min(best, t1 - t); bp = min(bp, t2 - t1)
    print(b, "ground %.2fs png %.2fs" % (best, bp))
