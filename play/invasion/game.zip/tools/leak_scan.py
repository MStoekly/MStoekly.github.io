"""Leak scanner: does any word of the old skin (Crimson Wake) reach the player?

    python tools/leak_scan.py                 # scans this project's game/ folder
    python tools/leak_scan.py <game folder>   # scans another one (the control)

It reads every string literal in the .rpy files that looks like text a player
could see (has a space or starts with a capital letter, and is not a path, a
colour, a style or a key) and fails on any banned word. It also checks that
every level gets a themed name and that every font file referenced exists.
Exit code 0 = clean. Run it on Crimson Wake's game/ folder too: it MUST find
leaks there, or the scanner is blind.
"""
import ast
import io
import os
import re
import sys

BANNED = ["vampire", "vampiric", "blood", "bloodlust", "dawn", "sunrise", "bat", "bats", "dorak",
          "crimson", "hunter", "hunters", "harvest", "drained", "drain", "blink", "charm", "allure",
          "swiftness", "constitution", "strength", "iron skin", "market", "fangs", "lunge",
          "wailing", "blackmere", "harrow", "old coast", "gothic", "night closes"]
WORD = re.compile(r"\b(" + "|".join(re.escape(w) for w in BANNED) + r")\b", re.I)
LIT = re.compile(r'"((?:[^"\\\n]|\\.)*)"|\'((?:[^\'\\\n]|\\.)*)\'')


def visible(s):
    if not s or "/" in s or s.startswith("#") or s.startswith("cw_") or s.startswith("audio"):
        return False
    return " " in s.strip() or s[:1].isupper()


def scan(game_dir):
    leaks = []
    fonts = []
    for root, _dirs, files in os.walk(game_dir):
        if os.sep + "cache" in root or os.sep + "tl" in root or os.sep + "saves" in root:
            continue
        for fn in files:
            if not fn.endswith(".rpy"):
                continue
            path = os.path.join(root, fn)
            for ln, line in enumerate(io.open(path, encoding="utf-8-sig"), 1):
                code = line.split("#", 1)[0] if line.lstrip().startswith("#") else line
                if line.lstrip().startswith("#") or line.lstrip().startswith('"""'):
                    continue                          # comments and docstrings never reach the screen
                for m in LIT.finditer(code):
                    s = m.group(1) if m.group(1) is not None else m.group(2)
                    if s.startswith("fonts/"):
                        fonts.append((path, ln, s))
                    if visible(s) and WORD.search(s):
                        leaks.append((os.path.relpath(path, game_dir), ln, s))
    missing = [(p, ln, f) for p, ln, f in fonts if not os.path.exists(os.path.join(game_dir, f))]
    return leaks, missing


def level_names_themed(game_dir):
    """Every engine level key must have a name in theme.rpy (the engine's own names are the old skin's)."""
    core = os.path.join(game_dir, "python-packages", "hunt_core.py")
    theme = os.path.join(game_dir, "theme.rpy")
    if not (os.path.exists(core) and os.path.exists(theme)):
        return ["no theme.rpy"]
    keys = re.findall(r'"key":\s*"([a-z_]+)"', io.open(core, encoding="utf-8").read())
    th = io.open(theme, encoding="utf-8").read()
    block = th[th.index("TH_LEVEL_NAMES"):]
    block = block[:block.index("}") + 1]
    named = ast.literal_eval(block.split("=", 1)[1].strip())
    return [k for k in keys if k not in named]


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    game_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "..", "game")
    leaks, missing = scan(game_dir)
    unnamed = level_names_themed(game_dir)
    for p, ln, s in leaks:
        print("LEAK  %s:%d  %r" % (p, ln, s))
    for p, ln, f in missing:
        print("MISSING FONT  %s:%d  %s" % (os.path.relpath(p, game_dir), ln, f))
    if unnamed:
        print("LEVELS WITHOUT A THEMED NAME: %s" % unnamed)
    n = len(leaks) + len(missing) + len(unnamed)
    print("%d problems (%d leaks, %d missing fonts, %d unnamed levels)" % (n, len(leaks), len(missing), len(unnamed)))
    sys.exit(1 if n else 0)


if __name__ == "__main__":
    main()
