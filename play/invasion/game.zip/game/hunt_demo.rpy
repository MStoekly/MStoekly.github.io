# A throwaway wrapper so the minigame is reachable before it has a real home in
# the story. Delete this file once hunt_run is called from the actual script.

label hunt_demo:
    scene black
    "The porch lights are still on along Route 9. Somewhere ahead, a radio plays."
    call hunt_lobby
    "The beam takes you home before the sun is up. [cw_blood] biomass, and counting."
    return
