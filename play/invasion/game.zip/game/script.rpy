# The script of the game goes in this file.

init -1 python:
    # The typing blip gets its own channel, so it never cuts a game sound.
    renpy.music.register_channel("dev_blip", "sfx", False)

    def dev_blip_cb(event, interact=True, **kwargs):
        """Loops a short blip while the dev note types, and stops it when the line is complete."""
        if not interact:
            return
        if event == "show_done":
            renpy.music.play("audio/sfx_dev_blip.wav", channel="dev_blip", loop=True)
        elif event in ("slow_done", "end"):
            renpy.music.stop(channel="dev_blip")

define narrator_k = Character(None, what_italic=True)
define dev_note = Character("Dev note", color="#8dff5a", callback=dev_blip_cb, what_slow_cps=45)


# The game starts here.

label start:

    # a run that left the arcade section by the main menu must not start without rollback
    $ config.rollback_enabled = True

    scene black

    dev_note "Not a finished game. This is a prototype of a currency-acquisition engine: the loop that earns the money in an incremental game."

    dev_note "It is built to be reused. Invasion is a reskin of Crimson Wake: same rules, new art and sound. I worked on the engine, not the polish."

    dev_note "You are Kreel, an alien. Humans are currency, soldiers are the cost. Move with WASD or the arrow keys and absorb humans. Every feeding draws more soldiers."

    dev_note "A run is one short night. Survive until extraction for a bonus, then spend your biomass in the Mutation Lab to grow stronger and unlock powers."

    narrator_k "The saucer came down in the woods behind Hollister Farm and did not get up again."

    narrator_k "Something crawled out of it. It is small, and it is hungry, and every meal teaches it something new."

    # Hunt entry point. Replace with the real story when it exists.
    call hunt_demo

    # This ends the game.

    return
