# Where the currency (theme.rpy: TH["currency"]) turns into permanent upgrades. Reads and writes cw_blood and
# cw_upgrades, both declared in hunt.rpy.

init python:
    import store

    CW_MAX_LEVEL = 5

    CW_UPGRADES = [(k, TH_STAT[k][0], TH_STAT[k][1]) for k in ("speed", "constitution", "allure", "strength")]

    # Powers are not extra upgrades. When a stat reaches 5 / 5 the MAXED mark on
    # its card turns into the power's card (icon, name, an unlock button). Costs
    # are deliberately steep.
    CW_POWER_OF = {"speed": "blink", "allure": "charm", "strength": "bloodlust", "constitution": "drain"}
    CW_POWER_COST = {"blink": 2500, "charm": 3000, "bloodlust": 3500, "drain": 3200}
    CW_POWER_TEXT = TH_POWER_TEXT

    def cw_power_owned(key):
        p = CW_POWER_OF.get(key)
        return bool(p) and store.cw_upgrades.get(p, 0) >= 1

    def cw_power_offer(key):
        """True while the stat is maxed and its power is not bought yet."""
        p = CW_POWER_OF.get(key)
        return (bool(p) and store.cw_upgrades.get(key, 0) >= CW_MAX_LEVEL
                and store.cw_upgrades.get(p, 0) < 1)

    def cw_blurb(key, blurb):
        if cw_power_offer(key):
            return CW_POWER_TEXT[CW_POWER_OF[key]][0]
        if cw_power_owned(key):
            return CW_POWER_TEXT[CW_POWER_OF[key]][1]
        return blurb

    # The ultimate hangs off the end of all four lines: it opens once every line is
    # complete (stat 5/5 and its power bought). CW_ULTIMATE_BUILT guards the node so it
    # can be switched off if the ultimate is ever withdrawn.
    CW_ULTIMATE_COST = 12000
    CW_ULTIMATE_BUILT = True

    def cw_line_done(key):
        p = CW_POWER_OF.get(key)
        return (store.cw_upgrades.get(key, 0) >= CW_MAX_LEVEL
                and (not p or store.cw_upgrades.get(p, 0) >= 1))

    def cw_lines_done():
        return sum(1 for k, _t, _b in CW_UPGRADES if cw_line_done(k))

    def cw_ultimate_open():
        return cw_lines_done() == len(CW_UPGRADES)

    def cw_ultimate_owned():
        return store.cw_upgrades.get("ultimate", 0) >= 1

    def cw_buy_ultimate():
        if (not CW_ULTIMATE_BUILT or not cw_ultimate_open() or cw_ultimate_owned()
                or store.cw_blood < CW_ULTIMATE_COST):
            return
        store.cw_blood -= CW_ULTIMATE_COST
        store.cw_upgrades["ultimate"] = 1
        renpy.restart_interaction()

    def cw_cost(level):
        """Blood for the next level, or None if already maxed."""
        if level >= CW_MAX_LEVEL:
            return None
        return int(round(100 * (1.9 ** level) / 10.0) * 10)

    def cw_buy(key):
        level = store.cw_upgrades.get(key, 0)
        cost = cw_cost(level)
        if cost is None or store.cw_blood < cost:
            return
        store.cw_blood -= cost
        store.cw_upgrades[key] = level + 1
        renpy.restart_interaction()

    def cw_buy_power(power):
        """Buy a power (its key is set on the Controls screen, see cw_key in hunt.rpy)."""
        stat = [k for k, v in CW_POWER_OF.items() if v == power][0]
        cost = CW_POWER_COST[power]
        if not cw_power_offer(stat) or store.cw_blood < cost:
            return
        store.cw_blood -= cost
        store.cw_upgrades[power] = 1
        renpy.restart_interaction()


screen blood_shop():
    add CheatListener()
    modal True
    add cw_backdrop()

    frame:
        background cw_panel("stone")
        align (0.5, 0.5)
        padding (64, 44, 64, 52)

        vbox:
            spacing 14

            hbox:
                xsize 1600
                text TH["shop"] style "cw_title" yalign 0.5
                hbox:
                    xalign 1.0
                    yalign 0.5
                    spacing 14
                    add cw_drop(True) yalign 0.5
                    text ("%d" % cw_blood) style "cw_label" size 52 color CW_GOLD yalign 0.5

            add cw_divider(110) xalign 0.5
            null height 4

            hbox:
                spacing 32

                # Character preview: the hero at his current mutation stage, with
                # the lure aura growing with Pheromones (allure).
                frame:
                    background cw_card("dim")
                    xsize 400
                    ysize 632
                    padding (15, 15)

                    add cw_backdrop()
                    fixed:
                        xalign 0.5
                        yalign 0.46
                        xysize (340, 340)

                        if cw_upgrades["allure"] > 0:
                            add cw_ring(14 + 3 * cw_upgrades["allure"]) at cw_aura_glow:
                                xalign 0.5
                                yalign 0.5
                        add cw_vampire(10, cw_mutation_stage(cw_upgrades)):
                            xalign 0.5
                            yalign 0.5

                    text TH["hero"] style "cw_h2" xalign 0.5 yalign 1.0 yoffset -92
                    text (TH["stage"] % (cw_mutation_stage(cw_upgrades), 4)) style "cw_dim" xalign 0.5 yalign 1.0 yoffset -48

                vbox:
                    spacing 8

                    # One line per skill: the stat's five levels, then its power at the end.
                    for key, title, blurb in CW_UPGRADES:
                        $ level = cw_upgrades.get(key, 0)
                        $ cost = cw_cost(level)
                        $ power = CW_POWER_OF.get(key)
                        $ offer = cw_power_offer(key)
                        $ owned = cw_power_owned(key)
                        $ done = cw_line_done(key)

                        frame:
                            background cw_card("gold" if done else ("blood" if offer else "stone"))
                            xsize 1150
                            ysize 120
                            padding (28, 6, 28, 6)

                            hbox:
                                spacing 20
                                yalign 0.5

                                frame:
                                    background cw_card("dim")
                                    xysize (84, 84)
                                    padding (15, 15)
                                    yalign 0.5
                                    add cw_icon(key, 3) align (0.5, 0.5)

                                vbox:
                                    xsize 460
                                    yalign 0.5
                                    text title style "cw_label" size 30
                                    text cw_blurb(key, blurb) style "cw_dim" size 19 color (CW_TEXT if offer else CW_DIM)

                                vbox:
                                    xsize 185
                                    yalign 0.5
                                    spacing 4
                                    hbox:
                                        xalign 0.5
                                        yalign 0.5
                                        for n in range(CW_MAX_LEVEL):
                                            add cw_pip(n < level, 3) yalign 0.5
                                            if n < CW_MAX_LEVEL - 1:
                                                add Solid("#a8323f" if n + 1 < level else "#3a3040") xsize 12 ysize 3 yalign 0.5
                                    text ("Level %d / %d" % (level, CW_MAX_LEVEL)) style "cw_dim" size 20 xalign 0.5

                                # the power at the end of the line
                                frame:
                                    background cw_card("gold" if owned else ("blood" if offer else "dim"))
                                    xysize (72, 72)
                                    padding (12, 12)
                                    yalign 0.5
                                    if owned:
                                        add cw_icon(power, 2) align (0.5, 0.5)
                                    elif offer:
                                        add cw_icon(power, 2) align (0.5, 0.5) at cw_aura_glow
                                    else:
                                        add cw_lock(2) align (0.5, 0.5)

                                if cost is not None:
                                    button:
                                        style "cw_button"
                                        xsize 210
                                        yalign 0.5
                                        padding (20, 14, 20, 20)
                                        action Function(cw_buy, key)
                                        sensitive (cw_blood >= cost)
                                        hbox:
                                            xalign 0.5
                                            spacing 10
                                            add cw_drop(cw_blood >= cost, 2) yalign 0.5
                                            text ("%d" % cost) style "cw_button_text" yalign 0.5
                                elif offer:
                                    button:
                                        style "cw_button"
                                        xsize 210
                                        yalign 0.5
                                        padding (20, 14, 20, 20)
                                        action Function(cw_buy_power, power)
                                        sensitive (cw_blood >= CW_POWER_COST[power])
                                        hbox:
                                            xalign 0.5
                                            spacing 10
                                            add cw_drop(cw_blood >= CW_POWER_COST[power], 2) yalign 0.5
                                            text ("%d" % CW_POWER_COST[power]) style "cw_button_text" yalign 0.5
                                else:
                                    vbox:
                                        xsize 210
                                        yalign 0.5
                                        spacing 4
                                        text "COMPLETE" style "cw_label" size 30 color CW_GOLD xalign 0.5
                                        if power in CW_POWERS:
                                            text ("Press %s" % cw_key_label(cw_key(power))) style "cw_dim" size 22 xalign 0.5
                                        else:
                                            text "Passive" style "cw_dim" size 22 xalign 0.5

                    # the ultimate: the four lines meet here
                    $ u_open = cw_ultimate_open()
                    $ u_owned = cw_ultimate_owned()
                    frame:
                        background cw_card("gold" if u_owned else ("blood" if u_open else "dim"))
                        xsize 1150
                        ysize 120
                        padding (28, 6, 28, 6)

                        hbox:
                            spacing 20
                            yalign 0.5

                            frame:
                                background cw_card("dim")
                                xysize (84, 84)
                                padding (15, 15)
                                yalign 0.5
                                if u_open:
                                    add cw_icon("ultimate", 3) align (0.5, 0.5)
                                else:
                                    add cw_lock(2) align (0.5, 0.5)

                            vbox:
                                xsize 460
                                yalign 0.5
                                text TH_POWER["ultimate"] style "cw_label" size 30 color (CW_TEXT if u_open else CW_LOCKED)
                                if u_owned:
                                    text TH["ultimate_owned"] style "cw_dim" size 19
                                elif u_open:
                                    text TH["ultimate_owned"] style "cw_dim" size 19 color CW_TEXT
                                else:
                                    text TH["ultimate_locked"] style "cw_dim" size 19 color CW_LOCKED

                            vbox:
                                xsize 185
                                yalign 0.5
                                spacing 4
                                hbox:
                                    xalign 0.5
                                    spacing 12
                                    for n in range(len(CW_UPGRADES)):
                                        add cw_pip(n < cw_lines_done(), 3) yalign 0.5
                                text ("Lines  %d / %d" % (cw_lines_done(), len(CW_UPGRADES))) style "cw_dim" size 20 xalign 0.5

                            null width 72

                            if u_owned:
                                vbox:
                                    xsize 210
                                    yalign 0.5
                                    spacing 4
                                    text "UNLOCKED" style "cw_label" size 30 color CW_GOLD xalign 0.5
                                    text ("Press %s" % cw_key_label(cw_key("ultimate"))) style "cw_dim" size 22 xalign 0.5
                            elif u_open and CW_ULTIMATE_BUILT:
                                button:
                                    style "cw_button"
                                    xsize 210
                                    yalign 0.5
                                    padding (20, 14, 20, 20)
                                    action Function(cw_buy_ultimate)
                                    sensitive (cw_blood >= CW_ULTIMATE_COST)
                                    hbox:
                                        xalign 0.5
                                        spacing 10
                                        add cw_drop(cw_blood >= CW_ULTIMATE_COST, 2) yalign 0.5
                                        text ("%d" % CW_ULTIMATE_COST) style "cw_button_text" yalign 0.5
                            elif u_open:
                                text "Coming soon" style "cw_label" size 28 color CW_GOLD xsize 210 text_align 0.5 yalign 0.5
                            else:
                                fixed:
                                    xysize (210, 60)
                                    yalign 0.5
                                    add cw_lock(3) align (0.5, 0.5)

            null height 10
            hbox:
                xalign 0.5
                spacing 30
                textbutton TH["ground_button"] style "cw_button" action Return(True)
                textbutton "Controls" style "cw_button" action Show("cw_controls")
