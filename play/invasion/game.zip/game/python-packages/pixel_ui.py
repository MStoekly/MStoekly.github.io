"""Pixel-art UI pieces for the hunt screens, drawn in code like everything else.

Theme: 1950s atomic age, chrome-and-enamel (diner, jukebox, car dashboard):
glossy deep-teal enamel fields with a cream pinstripe, polished chrome bezels
with a bright highlight edge, starburst corner accents; turquoise, cream and
cherry accents, neon green for ready/highlighted states.

No Ren'Py imports: every function returns a Canvas (or PNG bytes via *_png at
a given integer scale). ui_hunt.rpy wraps them as im.Data / Frame. Nine-slice
pieces are small and tile-friendly: the corners keep their pixels, the edges
and the middle repeat (use Frame(..., tile=True)).

    panel(kind)    24x24, border 8     enamel field, chrome bezel, pinstripe, starbursts
    card(kind)     16x16, border 5     slimmer chrome + pinstripe row/card frame
    button(state)  16x16, border 4     idle / hover / insensitive (jukebox button)
    slot()         12x12, border 3     dark inset (bars, counters)
    heart(full, fill)  round life cell  drop(full)  green biomass blob
    lock(), icon(name), pip(filled), divider(w), bg_tile() (formica pattern)

Kinds keep their historical names: "stone" = teal enamel, "gold" = neon-green
highlighted, "blood" = cherry highlighted, "dim" = dark/disabled.
"""

import math
import random

import pixel_art as pa
from pixel_art import Canvas, _rgb, _B4


# -- palette (shared UI tokens; pixel_art.C is left alone) --------------------

UI = dict((k, _rgb(v)) for k, v in {
    "ink": "#060e13", "ink2": "#0b171e",
    # panel fields
    "field": "#10202a", "field2": "#16303a", "grid": "#13283a",
    "gfield": "#0e2620", "gfield2": "#14362a", "ggrid": "#123026",
    "rfield": "#26121a", "rfield2": "#381822", "rgrid": "#2e1520",
    # metal / chrome ramp
    "m0": "#17282f", "m1": "#243d47", "m2": "#3a5560", "m3": "#5f7c86", "m4": "#9fb4bc", "m5": "#dbe8eb",
    # accent neon green
    "neon_dd": "#18401e", "neon_d": "#3a9a30", "neon": "#8dff5a", "neon_l": "#d4ffbc",
    # danger cherry
    "cherry_dd": "#4a0f1e", "cherry_d": "#b02238", "cherry": "#ff4f5e", "cherry_l": "#ffa8b0",
    # text
    "cream": "#f4ecd8", "dim": "#8aa3a6", "locked": "#55666b",
    # extras
    "cyan_d": "#1d6a80", "cyan": "#5fd8f0", "cyan_l": "#c8f6ff",
    "violet_d": "#3a1d5c", "violet": "#8a5ad0", "violet_l": "#c9a8ff",
    "amber": "#ffc65a", "amber_d": "#b07a2a",
    "white": "#fbfff4",
    # atomic-age chrome (bright highlight -> deep reflection)
    "c0": "#24363c", "c1": "#566e75", "c2": "#8ea5ab", "c3": "#c6d5d9", "c4": "#f6fcfc",
    "dc0": "#16262a", "dc1": "#2e444a", "dc2": "#475f66", "dc3": "#5f777e",           # dulled chrome (dim)
    # enamel fields (panel, card, gloss)
    "en": "#0f3b40", "en2": "#14494f", "eng": "#1b5b61",
    "gen": "#0f3a26", "gen2": "#154a30", "geng": "#1d5e3c",
    "ren": "#3a1222", "ren2": "#4a182c", "reng": "#5e2236",
    "den": "#0a2225", "den2": "#0d292d", "deng": "#11333a",
    "btn": "#17575c", "btn_d": "#10454a",
    # accents
    "turq_dd": "#0f3f42", "turq_d": "#1f8a86", "turq": "#3fc7c0", "turq_l": "#a8f0ea",
    # life cell
    "pink_l": "#ffd8dc", "pink": "#ff7d8a", "nuc": "#8e2a5c", "nuc_d": "#5a1640",
}.items())


def _u(name):
    return UI[name]


def _bayer(x, y):
    return (_B4[y & 3][x & 3] + 0.5) / 16.0


def _speckle(c, x0, y0, x1, y1, base, speck, rate, seed):
    rnd = random.Random(seed)
    for y in range(y0, y1):
        for x in range(x0, x1):
            c.px(x, y, speck if rnd.random() < rate else base)


def _ring(c, i, w, h, col):
    c.rect(i, i, w - i, i + 1, col)
    c.rect(i, h - 1 - i, w - i, h - i, col)
    c.rect(i, i, i + 1, h - i, col)
    c.rect(w - 1 - i, i, w - i, h - i, col)


def _bevel(c, i, w, h, light, dark):
    """Ring i: light on top/left, dark on bottom/right."""
    c.rect(i, i, w - i, i + 1, light)
    c.rect(i, i, i + 1, h - i, light)
    c.rect(i + 1, h - 1 - i, w - i, h - i, dark)
    c.rect(w - 1 - i, i + 1, w - i, h - i, dark)


def _chamfer(c, w, h):
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        c.p[y][x] = None


# -- nine-slice frames --------------------------------------------------------

_PANEL_KINDS = {
    #         pinstripe   field / gloss        corner star (arm, centre)   chrome ramp (bright .. deep)
    "stone": ("cream",    ("en", "eng"),       ("turq", "cream"),          ("c4", "c3", "c2", "c1", "c0")),
    "blood": ("cherry",   ("ren", "reng"),     ("cherry", "cream"),        ("c4", "c3", "c2", "c1", "c0")),
    "gold":  ("neon",     ("gen", "geng"),     ("neon", "neon_l"),         ("c4", "c3", "c2", "c1", "c0")),
    "dim":   ("locked",   ("den", "deng"),     ("dc3", "dim"),             ("dc3", "dc2", "dc2", "dc1", "dc0")),
}


def _star(c, cx, cy, arm, centre, size=2):
    """Atomic-age starburst: a plus with long arms, short diagonals, bright centre."""
    for k in range(1, size + 1):
        for dx, dy in ((k, 0), (-k, 0), (0, k), (0, -k)):
            c.px(cx + dx, cy + dy, arm)
    for dx, dy in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
        c.px(cx + dx, cy + dy, arm)                         # diagonals make it an 8-point burst
    for dx, dy in ((size, 0), (-size, 0), (0, size), (0, -size)):
        c.px(cx + dx, cy + dy, centre)                      # bright ray tips
    c.px(cx, cy, centre)


def _chrome(c, n, ch, start=1):
    """Polished chrome bezel, rings start..start+3: bright highlight edge, then a dark reflection band."""
    c4, c3, c2, c1, c0 = [_u(k) for k in ch]
    _bevel(c, start, n, n, c4, c2)            # bright highlight edge
    _bevel(c, start + 1, n, n, c3, c1)
    _bevel(c, start + 2, n, n, c1, c0)        # reflection band
    _bevel(c, start + 3, n, n, c2, c3)        # rolled inner lip (light from below)


def panel(kind="stone"):
    pin, fld, star, ch = _PANEL_KINDS[kind]
    n = 24
    c = Canvas(n, n)
    c.rect(0, 0, n, n, _u(fld[0]))                          # glossy enamel field
    _ring(c, 0, n, n, _u("ink"))
    _chrome(c, n, ch, 1)                                    # rings 1..4
    _ring(c, 5, n, n, _u("ink"))
    _ring(c, 6, n, n, _u(fld[0]))
    c.rect(6, 6, n - 6, 7, _u(fld[1]))                      # enamel gloss under the bezel
    _ring(c, 7, n, n, _u(pin))                              # inner pinstripe
    arm, tip = _u(star[0]), _u(star[1])
    for cx, cy in ((4, 4), (n - 5, 4), (4, n - 5), (n - 5, n - 5)):
        # enamel starburst badge on each chrome corner (inside the 8x8 corners, so the edges tile)
        pts = {(cx, cy): _u("white") if kind != "dim" else tip}
        for k in (1, 2, 3):
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                pts[(cx + dx * k, cy + dy * k)] = tip if k == 3 else arm
        for k in (1, 2):
            for dx, dy in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
                pts[(cx + dx * k, cy + dy * k)] = arm if k == 1 else tip
        for (x, y) in list(pts):
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                q = (x + dx, y + dy)
                if q not in pts and 0 < q[0] < n - 1 and 0 < q[1] < n - 1 and \
                        (q[0] < 8 or q[0] >= n - 8) and (q[1] < 8 or q[1] >= n - 8):
                    c.px(q[0], q[1], _u("ink"))
        for (x, y), col in pts.items():
            c.px(x, y, col)
    _chamfer(c, n, n)
    return c


PANEL_BORDER = 8


_CARD_KINDS = {
    #         pinstripe   field / gloss          star (arm, centre)    chrome
    "stone": ("turq",     ("en2", "eng"),        ("turq", "cream"),    ("c4", "c3", "c2", "c1", "c0")),
    "gold":  ("neon",     ("gen2", "geng"),      ("neon", "neon_l"),   ("c4", "c3", "c2", "c1", "c0")),
    "blood": ("cherry",   ("ren2", "reng"),      ("cherry", "cream"),  ("c4", "c3", "c2", "c1", "c0")),
    "dim":   ("dc2",      ("den2", "den2"),      ("dc2", "dc3"),       ("dc3", "dc2", "dc2", "dc1", "dc0")),
}


def card(kind="stone"):
    """Lighter frame for rows inside a panel: slim chrome, enamel, pinstripe."""
    pin, fld, star, ch = _CARD_KINDS[kind]
    n = 16
    c = Canvas(n, n)
    c.rect(0, 0, n, n, _u(fld[0]))
    c4, c3, c2, c1, c0 = [_u(k) for k in ch]
    _ring(c, 0, n, n, _u("ink"))
    _bevel(c, 1, n, n, c4, c1)
    _bevel(c, 2, n, n, c2, c0)
    c.rect(3, 3, n - 3, 4, _u(fld[1]))                      # gloss
    _ring(c, 4, n, n, _u(pin))                              # pinstripe
    for cx, cy in ((2, 2), (n - 3, 2), (2, n - 3), (n - 3, n - 3)):  # corner studs in the accent colour
        c.px(cx, cy, _u(star[0]))
    c.px(2, 2, _u(star[1]))
    _chamfer(c, n, n)
    return c


CARD_BORDER = 5


def button(state="idle"):
    """Jukebox push-button: chrome rim, enamel face with a gloss line."""
    n = 16
    c = Canvas(n, n)
    if state == "insensitive":
        face, low, gloss, inner, ch = "den2", "den", "deng", None, ("dc3", "dc2", "dc2", "dc1", "dc0")
    elif state in ("hover", "selected"):
        face, low, gloss, inner, ch = "gen2", "gen", "neon_l", "neon", ("c4", "c3", "c2", "c1", "c0")
    else:
        face, low, gloss, inner, ch = "btn", "btn_d", "turq", None, ("c4", "c3", "c2", "c1", "c0")
    c4, c3, c2, c1, c0 = [_u(k) for k in ch]
    c.rect(0, 0, n, n, _u(face))                            # flat face: the centre tiles without bands
    _ring(c, 0, n, n, _u("ink"))
    _bevel(c, 1, n, n, c4, c1)
    _bevel(c, 2, n, n, c2, c0)
    if inner:
        _ring(c, 3, n, n, _u(inner))                        # lit inner ring (ready / highlighted)
    c.rect(3, 3, n - 3, 4, _u(gloss))                       # gloss line
    c.rect(4, n - 4, n - 4, n - 3, _u(low) if not inner else _u("neon_d"))
    _chamfer(c, n, n)
    for x, y in ((1, 1), (n - 2, 1), (1, n - 2), (n - 2, n - 2)):
        c.p[y][x] = _u("ink")
    return c


BUTTON_BORDER = 4


def slot():
    n = 12
    c = Canvas(n, n)
    c.rect(0, 0, n, n, _u("ink"))
    _bevel(c, 1, n, n, _u("c1"), _u("c3"))                  # inset chrome: dark top, light bottom
    c.rect(2, 2, n - 2, n - 2, _u("ink"))
    c.rect(3, 3, n - 3, n - 3, (7, 28, 31, 255))
    _chamfer(c, n, n)
    return c


SLOT_BORDER = 3


# -- small icons -------------------------------------------------------------

_CELL = ["....XXXXX....",
         "..XXXXXXXXX..",
         ".XXXXXXXXXXX.",
         ".XXXXXXXXXXX.",
         "XXXXXXXXXXXXX",
         "XXXXXXXXXXXXX",
         "XXXXXXXXXXXXX",
         ".XXXXXXXXXXX.",
         ".XXXXXXXXXXX.",
         "..XXXXXXXXX..",
         "....XXXXX...."]


def _inside(rows, x, y):
    return 0 <= y < len(rows) and 0 <= x < len(rows[0]) and rows[y][x] != "."


def heart(full=True, fill=1.0):
    """A round life cell: membrane ring, pink cytoplasm, darker nucleus.
    fill < 1 draws a part-filled cell: the left `fill` of its width is alive, the rest an empty husk;
    the live edge of a partial cell is drawn as a bright meniscus so 0.75 never reads as full."""
    rows = _CELL
    wcell = len(rows[0])
    cut = int(round(fill * wcell))
    c = Canvas(wcell + 2, len(rows) + 2)
    partial = full and 0 < cut < wcell
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch != "X":
                continue
            edge = not all(_inside(rows, x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
            inner_edge = not edge and not all(_inside(rows, x + dx, y + dy) for dx, dy in
                                              ((2, 0), (-2, 0), (0, 2), (0, -2), (1, 1), (-1, -1), (1, -1), (-1, 1)))
            nucleus = (x - 7.5) ** 2 + (y - 5.5) ** 2 <= 4.6
            if full and x < cut:
                if edge:                                              # membrane: pale pink ring
                    col = "pink_l" if (x - 6) * -0.6 + (y - 5) * -0.8 > -2.5 else "pink"
                elif inner_edge:
                    col = "cherry"                                    # inner wall of the membrane
                else:
                    col = "pink"
                    if (x - 6) * 0.6 + (y - 5) * 0.8 > 2.0:
                        col = "cherry"
                    if nucleus:
                        col = "nuc_d" if (x - 7.5) + (y - 5.5) > 0.8 else "nuc"
                if partial and x == cut - 1 and not edge:
                    col = "pink_l"                                    # meniscus at the live edge
            else:
                if edge:
                    col = "locked"
                elif nucleus:
                    col = "den2" if (x + y) % 2 else "dc1"
                else:
                    col = "ink"
            c.px(x + 1, y + 1, _u(col))
    if full and cut > 4:
        c.px(4, 4, _u("white"))                                       # highlight
        c.px(5, 4, _u("white"))
        c.px(4, 5, _u("pink_l"))
    if full and cut > 8:
        c.px(7, 6, _u("pink_l"))                                      # nucleus glint
    if full and cut > 10:
        c.px(11, 9, _u("pink_l"))                                     # organelle
    c.outline(_u("ink"))
    return c


_BLOB = [".........",
         "...XXX...",
         "..XXXXX..",
         ".XXXXXXX.",
         "XXXXXXXXX",
         "XXXXXXXXX",
         "XXXXXXXXX",
         "XXXXXXXXX",
         ".XXXXXXXX",
         ".XXXXXXX.",
         "..X.XXX.."]


def drop(full=True):
    """The currency: a glowing blob of green biomass (dim and grey when not affordable)."""
    c = Canvas(len(_BLOB[0]) + 2, len(_BLOB) + 2)
    for y, row in enumerate(_BLOB):
        for x, ch in enumerate(row):
            if ch != "X":
                continue
            if full:
                col = "neon"
                if x + y > 13 or y >= 9:
                    col = "neon_d"
                elif y <= 4 and x <= 4:
                    col = "neon_l"
            else:
                col = "m2"
                if x + y > 13 or y >= 9:
                    col = "m1"
                elif y <= 4 and x <= 4:
                    col = "m3"
            c.px(x + 1, y + 1, _u(col))
    if full:
        c.px(3, 4, _u("white"))
        c.px(7, 7, _u("neon_l"))                                     # suspended bubbles
        c.px(5, 9, _u("neon_l"))
        c.px(8, 5, _u("neon_l"))
    c.outline(_u("neon_dd") if full else _u("ink"))
    return c


def lock():
    c = Canvas(13, 15)
    for x, y in ((4, 1), (5, 0), (6, 0), (7, 0), (8, 1), (9, 2), (9, 3), (9, 4), (3, 2), (3, 3), (3, 4)):
        c.px(x, y + 1, _u("c3"))
    c.px(5, 1, _u("c4"))
    c.rect(2, 6, 11, 14, _u("c2"))
    c.rect(2, 6, 11, 7, _u("c4"))
    c.rect(2, 7, 3, 13, _u("c3"))
    c.rect(2, 12, 11, 14, _u("c1"))
    c.rect(6, 8, 7, 12, _u("ink"))
    c.px(9, 8, _u("cherry"))                                         # status lamp
    c.outline(_u("ink"))
    return c


def pip(filled=True):
    c = Canvas(9, 9)
    ramp = ("neon_dd", "neon_d", "neon", "neon_l") if filled else ("ink2", "m0", "m1", "m1")
    c.shade_ellipse(4.5, 4.5, 3.6, 3.6, [_u(n) for n in ramp], light=(-0.6, -0.7), dither=0.6)
    c.px(3, 3, _u("white") if filled else _u("m2"))
    c.outline(_u("ink"))
    return c


def _thick_line(c, pts, col, w0=2, w1=1):
    """Polyline whose width tapers from w0 to w1."""
    segs = len(pts) - 1
    for i in range(segs):
        (x0, y0), (x1, y1) = pts[i], pts[i + 1]
        steps = max(abs(x1 - x0), abs(y1 - y0)) * 2 + 1
        for s in range(int(steps) + 1):
            t = s / float(steps)
            g = (i + t) / segs
            w = w0 + (w1 - w0) * g
            x = x0 + (x1 - x0) * t
            y = y0 + (y1 - y0) * t
            c.rect(int(x), int(y), int(x) + max(1, int(round(w))), int(y) + max(1, int(round(w))), col)


def _alien(c, cx, col, dark):
    """Tiny grey-alien silhouette, ~8 wide, standing at y 16."""
    c.ellipse(cx, 5.0, 3.3, 3.6, col)
    c.rect(int(cx) - 1, 8, int(cx) + 1, 10, col)
    c.rect(int(cx) - 2, 10, int(cx) + 2, 14, col)
    c.line(int(cx) - 3, 10, int(cx) - 4, 13, col)
    c.line(int(cx) + 2, 10, int(cx) + 3, 13, col)
    c.rect(int(cx) - 2, 14, int(cx) - 1, 17, col)
    c.rect(int(cx) + 1, 14, int(cx) + 2, 17, col)
    if dark is not None:
        c.px(int(cx) - 2, 5, dark)
        c.px(int(cx) - 1, 6, dark)
        c.px(int(cx) + 1, 5, dark)
        c.px(int(cx), 6, dark)


def _spiral(c, cx, cy, r, a, b, turns=1.6, phase=0.0):
    for y in range(int(cy - r) - 1, int(cy + r) + 2):
        for x in range(int(cx - r) - 1, int(cx + r) + 2):
            dx, dy = x + 0.5 - cx, y + 0.5 - cy
            d = math.hypot(dx, dy)
            if d <= r:
                v = (math.atan2(dy, dx) / (2 * math.pi) + d / r * turns + phase) % 1.0
                c.px(x, y, a if v < 0.5 else b)


def icon(name):
    c = Canvas(18, 18)
    after = None
    if name == "speed":                                   # alien tendrils running, motion lines
        for pts, col in ((((10, 9), (7, 11), (5, 14), (2, 15)), "neon_d"),
                         (((11, 10), (10, 13), (8, 16)), "neon_d"),
                         (((13, 10), (14, 13), (16, 14)), "neon"),
                         (((12, 10), (11, 14), (12, 16)), "neon")):
            _thick_line(c, pts, _u(col), 2, 1)
        c.shade_ellipse(11.5, 6.5, 4.6, 4.0, [_u("neon_dd"), _u("neon_d"), _u("neon"), _u("neon_l")])
        c.px(11, 6, _u("ink"))
        c.px(13, 6, _u("ink"))
        c.px(11, 5, _u("white"))
        c.px(13, 5, _u("white"))
        for y, x0, x1 in ((4, 1, 6), (7, 0, 5), (10, 1, 5)):
            c.rect(x0, y, x1, y + 1, _u("m4"))
            c.px(x0, y, _u("m2"))
    elif name == "constitution":                           # cell membrane + nucleus
        c.ellipse(9, 9, 7.6, 7.6, _u("neon"))
        c.ellipse(9, 9, 6.4, 6.4, _u("neon_d"))
        for y in range(18):
            for x in range(18):
                if math.hypot(x + 0.5 - 9, y + 0.5 - 9) <= 5.6:
                    c.px(x, y, _u("neon_dd") if _bayer(x, y) > 0.3 else _u("neon_d"))
        for x, y in ((5, 6), (12, 13), (6, 12), (13, 6)):        # organelles
            c.px(x, y, _u("neon_l"))
        c.shade_ellipse(10, 9.5, 3.2, 3.0, [_u("violet_d"), _u("violet"), _u("violet_l")])
        c.px(9, 8, _u("white"))
        for x, y in ((4, 3), (5, 2), (6, 2), (3, 4)):              # membrane shine
            c.px(x, y, _u("neon_l"))
    elif name == "allure":                                 # hypnotic spiral eye
        for x in range(1, 17):
            h = int(5.0 * (1.0 - (abs(x - 8.5) / 8.0) ** 1.6) + 0.5)
            for y in range(9 - h, 9 + h):
                c.px(x, y, _u("cream") if y < 9 + h - 2 else _u("dim"))
        _spiral(c, 9, 9, 4.6, _u("neon"), _u("neon_dd"), 1.4)
        c.px(8, 8, _u("ink"))
        c.px(9, 8, _u("ink"))
        c.px(8, 9, _u("ink"))
        c.px(9, 9, _u("ink"))
        c.px(7, 6, _u("white"))
        for x in range(2, 16):                              # upper lid line
            h = int(5.0 * (1.0 - (abs(x - 8.5) / 8.0) ** 1.6) + 0.5)
            c.px(x, 9 - h - 1, _u("violet"))
        for x in (3, 8, 14):                                # lure waves
            c.px(x, 1, _u("violet_l"))
    elif name == "strength":                               # Carapace: armoured beetle shell from above
        shell = [_u("turq_dd"), _u("turq_d"), _u("turq"), _u("turq_l")]
        c.shade_ellipse(9, 4.2, 4.4, 2.8, [_u("c0"), _u("c1"), _u("c2"), _u("c3")], dither=0.4)   # head plate
        c.shade_ellipse(9, 10.8, 7.0, 6.6, shell, light=(-0.7, -0.5), dither=0.5)                 # wing cases
        for y in range(6, 18):                                  # the split between the two cases
            if c.get(9, y) is not None:
                c.px(9, y, _u("ink"))
        for y in range(7, 17):                                  # chrome ridge highlight on each case
            for x0 in (5, 12):
                if c.get(x0, y) is not None and y < 15 - abs(x0 - 9) // 3:
                    c.px(x0, y, _u("c4") if y < 10 else _u("turq_l"))
        for x in range(3, 16):                                  # collar line between head and shell
            if c.get(x, 6) is not None:
                c.px(x, 6, _u("ink"))
                if c.get(x, 7) is not None and x != 9:
                    c.px(x, 7, _u("c3"))
        for y in (10, 13):                                      # armour bands
            for x in range(2, 17):
                if c.get(x, y) not in (None, _u("ink")) and x != 9:
                    c.px(x, y, _u("turq_dd"))
        for x, y in ((7, 3), (11, 3)):                          # head studs
            c.px(x, y, _u("neon"))
    elif name == "blink":                                  # Phase: solid alien + dotted ghost
        _alien(c, 12.0, _u("neon"), _u("ink"))

        def after(c):
            ghost = Canvas(18, 18)
            _alien(ghost, 5.0, _u("neon_d"), None)
            for y in range(18):
                for x in range(18):
                    if ghost.p[y][x] is not None and c.p[y][x] is None and (x + y) % 2 == 0:
                        c.px(x, y, _u("neon_d") if x < 4 else _u("neon"))
    elif name == "charm":                                  # Thrall: spiral-eyed head, mind waves
        c.shade_ellipse(9, 12, 5.0, 5.2, [_u("m3"), _u("dim"), _u("cream")], dither=0.5)
        for ex in (7, 11):
            for dx, dy in ((-1, -1), (0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0)):
                c.px(ex + dx, 11 + dy, _u("neon_d"))
            c.px(ex, 11, _u("neon"))
            c.px(ex - 1, 10, _u("neon"))
        c.rect(8, 15, 11, 16, _u("m2"))
        for r, col in ((6.6, "neon"), (8.6, "violet_l")):
            for a in range(200, 341, 4):
                t = math.radians(a)
                c.px(int(9 + r * math.cos(t)), int(12 + r * math.sin(t)), _u(col))
    elif name == "bloodlust":                              # Frenzy: radiation burst
        for k in range(8):                                     # eight neon rays
            a = k * math.pi / 4 + math.pi / 8
            for r10 in range(58, 88):
                r = r10 / 10.0
                x, y = int(9 + r * math.cos(a)), int(9 + r * math.sin(a))
                c.px(x, y, _u("neon_l") if r > 7.4 else _u("neon"))
        c.ellipse(9, 9, 6.0, 6.0, _u("amber"))
        c.ellipse(9, 9, 6.0, 6.0, _u("amber")) 
        for y in range(18):
            for x in range(18):
                dx, dy = x + 0.5 - 9, y + 0.5 - 9
                d = math.hypot(dx, dy)
                ang = (math.degrees(math.atan2(dy, dx)) + 360 + 90) % 120     # one blade points up
                if 1.9 < d <= 5.0 and 30 <= ang <= 90:
                    c.px(x, y, _u("ink"))
                elif d <= 1.2:
                    c.px(x, y, _u("ink"))
                elif d > 5.0 and d <= 6.0 and dx + dy < -2:
                    c.px(x, y, _u("cream"))                    # rim highlight
    elif name == "drain":                                  # Regenerate: DNA double helix
        pts = []
        for y in range(1, 17):
            ph = (y - 1) * 0.5
            pts.append((y, 9 + 5.2 * math.sin(ph), 9 - 5.2 * math.sin(ph), math.cos(ph) > 0))
        for y, xa, xb, fa in pts:                           # base-pair rungs
            if y % 2 == 0:
                lo, hi = sorted((xa, xb))
                for x in range(int(lo) + 2, int(hi)):
                    c.px(x, y, _u("cream") if (x - int(lo)) % 3 else _u("amber"))
        for front in (False, True):                         # back strand first, then front strand
            for y, xa, xb, fa in pts:
                if front:
                    x, col = (xa, "neon") if fa else (xb, "turq")
                else:
                    x, col = (xb, "turq_d") if fa else (xa, "neon_d")
                c.rect(int(x), y, int(x) + 2, y + 1, _u(col))
                if front:
                    c.px(int(x), y, _u("neon_l") if col == "neon" else _u("turq_l"))
    elif name == "ultimate":                               # Stasis: frozen clock in a field
        c.ellipse(9, 9, 7.6, 7.6, _u("cyan_l"))
        c.ellipse(9, 9, 6.6, 6.6, _u("m3"))
        for y in range(18):
            for x in range(18):
                if math.hypot(x + 0.5 - 9, y + 0.5 - 9) <= 5.6:
                    c.px(x, y, _u("cyan_d") if _bayer(x, y) < 0.55 else _u("m0"))
        for x, y in ((8, 3), (9, 3), (14, 8), (14, 9), (8, 14), (9, 14), (3, 8), (3, 9)):
            c.px(x, y, _u("cyan_l"))
        c.rect(8, 5, 10, 10, _u("cream"))                  # hands, stopped
        c.line(9, 9, 12, 11, _u("cream"))
        c.line(9, 10, 12, 12, _u("cream"))
        c.px(9, 9, _u("cherry"))
        for x, y in ((2, 2), (15, 2), (2, 15), (15, 15)):   # ice glints / field corners
            c.px(x, y, _u("cyan_l"))
            c.px(x + (1 if x < 9 else -1), y, _u("cyan"))
            c.px(x, y + (1 if y < 9 else -1), _u("cyan"))
    else:
        raise KeyError(name)
    c.outline(_u("ink"))
    if after:
        after(c)
    return c


def divider(w):
    """Horizontal ornament, w native px wide: a chrome rail, ink shadow, centre atom."""
    h = 9
    c = Canvas(w, h)
    mid = w // 2
    for x in range(2, w - 2):
        if abs(x - mid) > 8:
            c.px(x, 4, _u("c3"))
            c.px(x, 5, _u("c1"))
    for x in (1, w - 2):
        c.px(x, 4, _u("neon"))
        c.px(x, 5, _u("neon_d"))
    for y in range(h):                                     # orbit ring
        for x in range(mid - 9, mid + 10):
            dx, dy = (x + 0.5 - (mid + 0.5)) / 7.5, (y + 0.5 - 4.5) / 3.6
            d = dx * dx + dy * dy
            if 0.55 < d <= 1.05:
                c.px(x, y, _u("c4") if dy < 0 else _u("c2"))
    c.rect(mid - 1, 3, mid + 2, 6, _u("neon"))
    c.px(mid - 1, 3, _u("neon_l"))
    c.px(mid + 1, 5, _u("neon_d"))
    c.px(mid - 7, 4, _u("neon"))                           # electrons
    c.px(mid + 7, 4, _u("neon"))
    for k in (-12, 12):
        c.px(mid + k, 4, _u("neon"))
        c.px(mid + k, 5, _u("neon_d"))
    c.outline(_u("ink"))
    return c


def bg_tile():
    """32x32 tileable 1950s formica backdrop: dark teal enamel with faint boomerangs, starbursts and dots."""
    n = 32
    c = Canvas(n, n)
    base = (10, 38, 42, 255)
    for y in range(n):
        for x in range(n):
            c.p[y][x] = base

    def put(x, y, col):
        c.p[y % n][x % n] = col

    def boomerang(cx, cy, flip, col, lite):
        for i in range(-6, 7):
            t = i / 6.0
            x = cx + i
            y = cy + int(round(flip * (t * t * 4 - 2)))
            w = 2 if abs(i) < 5 else 1
            for k in range(w):
                put(x, y + k * flip, col)
            put(x, y - flip, lite if abs(i) < 4 else col)

    def star(cx, cy, col, centre):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, -1), (1, -1), (-1, 1),
                       (2, 0), (-2, 0), (0, 2), (0, -2), (2, 2), (-2, -2), (2, -2), (-2, 2)):
            put(cx + dx, cy + dy, col)                       # 8-ray starburst (not a plus)
        put(cx, cy, centre)

    boomerang(9, 9, 1, (16, 52, 57, 255), (21, 64, 69, 255))
    boomerang(25, 25, -1, (13, 46, 50, 255), (18, 58, 62, 255))
    star(25, 7, (22, 66, 70, 255), (34, 92, 94, 255))
    star(7, 23, (19, 60, 64, 255), (30, 84, 86, 255))
    for x, y in ((17, 16), (30, 15), (14, 29), (2, 13), (20, 2)):
        put(x, y, (24, 70, 74, 255))
    return c

# -- cache + PNG ---------------------------------------------------------------

def png(canvas, scale):
    return canvas.png(scale)


def self_check():
    """Headless sanity checks (python game/python-packages/pixel_ui.py)."""
    ok = True

    def check(label, cond):
        print("%-60s %s" % (label, "PASS" if cond else "FAIL"))
        return cond

    for kind in _PANEL_KINDS:
        p = panel(kind)
        ok &= check("panel(%s): 24x24, solid centre, corners chamfered" % kind,
                    (p.w, p.h) == (24, 24) and p.get(12, 12) is not None and p.get(0, 0) is None)
        # edges must tile: rows of the left/right edge strips repeat down the middle third
        ok &= check("panel(%s): edge strips tile (rows/cols 8..15 repeat)" % kind,
                    len(set(tuple(p.p[y][0:8]) for y in range(8, 16))) == 1
                    and len(set(tuple(p.p[y][x] for y in range(0, 8)) for x in range(8, 16))) == 1)
    for kind in _CARD_KINDS:
        cd = card(kind)
        ok &= check("card(%s): 16x16, opaque centre" % kind, (cd.w, cd.h) == (16, 16) and cd.get(8, 8) is not None)
    for state in ("idle", "hover", "insensitive", "selected"):
        b = button(state)
        ok &= check("button(%s): 16x16, opaque centre" % state, (b.w, b.h) == (16, 16) and b.get(8, 8) is not None)
    ok &= check("hover differs from idle", button("hover").p != button("idle").p)
    ok &= check("slot: 12x12", (slot().w, slot().h) == (12, 12))
    for name in ("speed", "constitution", "allure", "strength", "blink", "charm", "bloodlust", "drain", "ultimate"):
        ic = icon(name)
        n = sum(1 for row in ic.p for px in row if px is not None)
        ok &= check("icon(%s): 18x18, drawn (%d px)" % (name, n), (ic.w, ic.h) == (18, 18) and n > 40)
    ok &= check("hearts: full and empty are 15x13", (heart(True).w, heart(True).h) == (15, 13) == (heart(False).w, heart(False).h))
    q = [heart(True, f).p for f in (0.25, 0.5, 0.75, 1.0)]
    ok &= check("hearts: partial fills differ and are 15x13",
                len(set(str(p) for p in q)) == 4 and all((heart(True, f).w, heart(True, f).h) == (15, 13) for f in (0.25, 0.5, 0.75)))
    ok &= check("drop: 11x13 full/empty", (drop(True).w, drop(True).h) == (11, 13) == (drop(False).w, drop(False).h))
    ok &= check("lock 13x15, pip 9x9", (lock().w, lock().h, pip().w, pip().h) == (13, 15, 9, 9))
    ok &= check("deterministic", panel("stone").p == panel("stone").p and card().p == card().p and icon("blink").p == icon("blink").p)
    ok &= check("divider width", divider(120).w == 120 and divider(60).w == 60)
    t = bg_tile()
    ok &= check("bg_tile: 32x32, fully opaque", (t.w, t.h) == (32, 32) and all(px is not None for row in t.p for px in row))
    print("\n%s" % ("ALL PASS" if ok else "FAILURES ABOVE"))
    return ok


if __name__ == "__main__":
    import sys
    sys.exit(0 if self_check() else 1)
