"""1950s rural-America buildings for pixel_art.building() (the game "Invasion").

Drop-in replacement for pixel_medieval: the same build(kind, variant) API and
exactly the same canvas size per kind, so collisions (the footprint rectangle,
see hunt_mapgen) still match the art.

Same conventions as pixel_medieval: oblique view facing south, a roof block
over a front wall; the sprite is `rise` px taller than the footprint (roof
overhang to the north). Dimensions come from pixel_art.BUILDINGS (w, d in
tiles, 16 native px each; fences use fractional tiles). The visible base
spans the full footprint width and sits on the sprite's bottom row.

Look: Kodachrome under moonlight -- pastel clapboard, dark shingle, cherry
red, chrome, warm amber windows; the alien neon green is kept for a couple of
accents (the diner sign; a strange window on house_l variant 7 only).

Kinds: house_s/m/l (ranch houses), shed (garage / tool shed), tavern (roadside
diner), stable (red gambrel barn), church (white chapel with steeple and
clock), windmill (farm water tower), tower (military guard tower), wall_h /
wall_v (concrete barrier with concertina wire), fence_h / fence_v (white
picket fence). Python 2/3, no PIL, deterministic per (kind, variant).
"""

import math
import random

import pixel_art as pa
from pixel_art import Canvas, C

# ---------------------------------------------------------------------------
# local palette (pixel_art.C is shared; extra colours live here)
# ---------------------------------------------------------------------------

_HEX = {
    # siding: dark lap, board, lit board
    "mint_d": "#3d6f66", "mint": "#5b968a", "mint_l": "#7cb8a8",
    "cream_d": "#8e8470", "cream": "#c2b79a", "cream_l": "#ddd3b6",
    "yel_d": "#94834a", "yel": "#c4af6a", "yel_l": "#ddcb8e",
    "blue_d": "#506a88", "blue": "#7590b0", "blue_l": "#98b2ce",
    "salm_d": "#8c5248", "salm": "#bb7564", "salm_l": "#d6977f",
    "trim": "#e6e2d6", "trim_d": "#aaa597", "trim_dd": "#76736c",
    # roofs
    "char_d": "#1f222a", "char": "#2f343f", "char_l": "#454c5a",
    "teal_d": "#1b2c30", "teal": "#2a4244", "teal_l": "#3f5c58",
    "maro_d": "#2f1e25", "maro": "#472a33", "maro_l": "#623b43",
    "brn_d": "#29221c", "brn": "#3e3226", "brn_l": "#574634",
    # accents
    "cherry_d": "#7a1424", "cherry": "#bc1e38", "cherry_l": "#f05468",
    "chrome_d": "#3a414e", "chrome": "#69737f", "chrome_m": "#97a1ad", "chrome_l": "#d4dce4",
    "turq_d": "#1d7069", "turq": "#2ea79b", "turq_l": "#79d8cc",
    "neon_d": "#2f8f26", "neon": "#7cff4f", "neon_l": "#d6ffc4",
    "mustard": "#d8a83a", "mustard_d": "#94701e",
    "tv": "#5d8ccc", "tv_l": "#bcdcff",
    "nglass": "#18233a", "nglass_l": "#34507a",
    "shade": "#121824", "shade_l": "#1c2433",
    # materials
    "barn_d": "#561a1f", "barn": "#86262c", "barn_l": "#a7393a",
    "brick_d": "#43261f", "brick": "#69362b", "brick_l": "#86483a",
    "conc0": "#30343b", "conc1": "#474b53", "conc2": "#62666e", "conc3": "#7f838b", "conc4": "#9ea2a8",
    "olive_d": "#29311f", "olive": "#3e4a2c", "olive_l": "#566540",
    "bag_d": "#4e4633", "bag": "#6f6548", "bag_l": "#8d8361",
    "wire": "#9aa2ae", "wire_l": "#cfd6de",
    "lamp": "#fff6d0",
}
K = dict((n, pa._rgb(h)) for n, h in _HEX.items())


def k(name):
    """Colour tuple by name: local palette first, then pixel_art.C."""
    return K[name] if name in K else C[name]


def rp(*names):
    return [k(n) for n in names]


SIDINGS = [rp("mint_d", "mint", "mint_l"), rp("cream_d", "cream", "cream_l"), rp("yel_d", "yel", "yel_l"),
           rp("blue_d", "blue", "blue_l"), rp("salm_d", "salm", "salm_l")]
ROOFS = [rp("char_d", "char", "char_l"), rp("teal_d", "teal", "teal_l"), rp("maro_d", "maro", "maro_l"),
         rp("brn_d", "brn", "brn_l")]
DOORS = [rp("cherry_d", "cherry", "cherry_l"), rp("turq_d", "turq", "turq_l"), rp("mustard_d", "mustard", "yel_l")]


def _dims(kind):
    spec = pa.BUILDINGS[kind]
    return int(round(spec["w"] * 16)), int(round(spec["d"] * 16)), spec["rise"]


def _wrap(body):
    c = Canvas(body.w + 2, body.h + 2)
    c.blit(body, 1, 1)
    c.outline("ink")
    return c


def _b4(x, y):
    return (pa._B4[y & 3][x & 3] + 0.5) / 16.0


# ---------------------------------------------------------------------------
# pieces
# ---------------------------------------------------------------------------

def _shingles(b, x0, y0, x1, y1, cols, seed=0, period=3):
    """Shingle courses: a shadow line every `period` rows, staggered seams,
    a few lighter tabs so the field is not flat."""
    d, m, l = cols
    for y in range(y0, y1):
        r = (y - y0) % period
        course = (y - y0) // period
        for x in range(x0, x1):
            if r == period - 1:
                col = d
            elif (x + course * 5 + seed) % 11 == 0 or (r == 0 and pa._hash(x, course, seed + 9) > 0.93):
                col = d
            elif r == 0 and pa._hash(x // 7, course, seed) > 0.62:
                col = l
            else:
                col = m
            b.px(x, y, col)


def _roof_gable(b, x0, y0, x1, y1, cols, seed=0):
    """Gable roof, ridge running east-west: thin back slope, ridge cap, the
    big front slope, a cream fascia at the eave and barge boards at the ends."""
    d, m, l = cols
    ry = y0 + max(4, (y1 - y0) // 5)
    for y in range(y0, ry):
        for x in range(x0, x1):
            b.px(x, y, d if (y - y0) % 2 or (x + seed) % 5 == 0 else m)
    b.rect(x0, ry, x1, ry + 1, l)
    b.rect(x0, ry + 1, x1, ry + 2, d)
    _shingles(b, x0, ry + 2, x1, y1 - 2, cols, seed)
    b.rect(x0, y1 - 2, x1, y1 - 1, d)
    b.rect(x0, y1 - 1, x1, y1, k("trim_d"))
    b.rect(x0, ry, x0 + 1, y1, k("trim"))                    # barge boards
    b.rect(x1 - 1, ry, x1, y1, k("trim_d"))


def _roof_hip(b, x0, y0, x1, y1, cols, seed=0):
    """Hip roof: back slope, short ridge, moonlit west facet, shaded east
    facet, front slope; fascia at the eave."""
    d, m, l = cols
    ry = y0 + max(4, (y1 - y0) // 4)
    inset = min((x1 - x0) // 4, 16)
    _shingles(b, x0, ry + 1, x1, y1 - 2, cols, seed)
    for y in range(y0, y1 - 2):
        if y <= ry:
            f = inset * (y - y0 + 1) / float(ry - y0 + 1)
        else:
            f = inset * (y1 - 2 - y) / float(y1 - 2 - ry)
        for x in range(x0, x1):
            lx, rx = x - x0, x1 - 1 - x
            if lx < f:
                col = l if (y + lx) % 3 else m                    # west facet catches the moon
                if lx >= f - 1:
                    col = l
            elif rx < f:
                col = d if (y + rx) % 3 else m
                if rx >= f - 1:
                    col = m
            elif y < ry:
                col = d if (y - y0) % 2 or (x + seed) % 5 == 0 else m
            elif y == ry:
                col = l
            else:
                continue
            b.px(x, y, col)
    b.rect(x0, y1 - 2, x1, y1 - 1, d)
    b.rect(x0, y1 - 1, x1, y1, k("trim_d"))


def _clapboard(b, x0, y0, x1, y1, sid):
    """Lap siding: 3px boards with a shadowed lap, moonlit west end."""
    d, m, l = sid
    for y in range(y0, y1):
        r = (y - y0) % 3
        for x in range(x0, x1):
            if r == 2:
                col = d
            elif r == 0 and (x - x0 < 5 or pa._hash(x // 9, (y - y0) // 3, 5) > 0.8):
                col = l
            else:
                col = m
            b.px(x, y, col)


def _foundation(b, x0, x1, y):
    b.rect(x0, y, x1, y + 1, k("conc3"))
    b.rect(x0, y + 1, x1, y + 2, k("conc1"))


def _window(b, x, y, w, h, state, shutters=None, frame="trim"):
    """state: lit / dark / tv / alien. A 1px frame, a sill, optional shutters."""
    b.rect(x - 1, y - 1, x + w + 1, y + h + 1, k(frame))
    if state == "lit":
        b.rect(x, y, x + w, y + h, k("lit"))
        b.rect(x, y, x + w, y + 1, k("lit_l"))
        b.rect(x, y, x + 1, y + h, k("lit_l"))
        b.rect(x, y + h - 1, x + w, y + h, k("lit_d"))
    elif state == "tv":
        b.rect(x, y, x + w, y + h, k("tv"))
        b.rect(x + 1, y + 1, x + max(2, w // 2), y + h - 1, k("tv_l"))
    elif state == "alien":
        b.rect(x, y, x + w, y + h, k("neon_d"))
        b.rect(x + 1, y + 1, x + w - 1, y + h - 1, k("neon"))
        b.px(x + w // 2, y + h // 2, k("neon_l"))
    else:
        b.rect(x, y, x + w, y + h, k("nglass"))
        for i in range(min(w, h)):
            if i < 3:
                b.px(x + w - 2 - i, y + 1 + i, k("nglass_l"))
    b.rect(x, y + h // 2, x + w, y + h // 2 + 1, k(frame))     # sash bar
    b.rect(x - 2, y + h + 1, x + w + 2, y + h + 2, k("trim_d"))  # sill
    if shutters:
        for sx in (x - 3, x + w + 1):
            b.rect(sx, y - 1, sx + 2, y + h + 1, shutters[1])
            for yy in range(y, y + h, 2):
                b.px(sx, yy, shutters[0])


def _picture_window(b, x, y, w, h, state, curtain):
    """Big ranch picture window with drapes drawn to the sides."""
    _window(b, x, y, w, h, state)
    b.rect(x, y, x + 2, y + h, curtain[1])
    b.rect(x + w - 2, y, x + w, y + h, curtain[1])
    b.rect(x + 1, y, x + 2, y + h, curtain[0])
    b.rect(x + w - 2, y, x + w - 1, y + h, curtain[2])
    b.rect(x + 2, y + h // 2, x + w - 2, y + h // 2 + 1, k("trim"))
    if state == "lit":                                          # a lamp shade silhouette
        b.rect(x + w - 6, y + h - 4, x + w - 3, y + h - 2, k("lit_d"))


def _door(b, x, ybot, cols, w=6, h=12):
    """Front door with the three stepped lights, chrome knob, concrete step."""
    d, m, l = cols
    b.rect(x - 1, ybot - h - 1, x + w + 1, ybot, k("trim"))
    b.rect(x, ybot - h, x + w, ybot, m)
    b.rect(x, ybot - h, x + 1, ybot, l)
    b.rect(x + w - 1, ybot - h, x + w, ybot, d)
    for i in range(3):
        b.px(x + 1 + i, ybot - h + 2 + i * 2, k("lit_l"))
        b.px(x + 2 + i, ybot - h + 2 + i * 2, k("lit"))
    b.px(x + w - 2, ybot - h // 2, k("chrome_l"))
    b.rect(x - 2, ybot, x + w + 2, ybot + 1, k("conc4"))


def _antenna(b, x, ybase, ytop):
    """Rooftop TV antenna: mast and three crossbars."""
    b.rect(x - 1, ybase - 1, x + 2, ybase + 1, k("chrome_d"))
    b.rect(x, ytop, x + 1, ybase, k("chrome_m"))
    for i, hw in enumerate((5, 4, 3)):
        yy = ytop + 1 + i * 3
        b.rect(x - hw, yy, x + hw + 1, yy + 1, k("chrome_l"))
        b.px(x - hw, yy + 1, k("chrome_d"))
        b.px(x + hw, yy + 1, k("chrome_d"))
    b.px(x, ytop, k("chrome_l"))


def _chimney(b, x, y0, y1, w=6):
    for y in range(y0, y1):
        for xx in range(x, x + w):
            col = k("brick")
            if (y - y0) % 3 == 2 or (xx + ((y - y0) // 3) * 2) % 4 == 0 and (y - y0) % 3 == 0:
                col = k("brick_d")
            if xx == x:
                col = k("brick_l")
            elif xx == x + w - 1:
                col = k("brick_d")
            b.px(xx, y, col)
    b.rect(x - 1, y0, x + w + 1, y0 + 2, k("conc3"))
    b.rect(x + 1, y0, x + w - 1, y0 + 1, k("ink2"))


def _car(b, x, ybot, cols):
    """Rear view of a finned sedan (16 px): fins, tail lights, chrome bumper."""
    d, m, l = cols
    b.rect(x + 4, ybot - 9, x + 12, ybot - 6, l)               # roof + rear window
    b.rect(x + 5, ybot - 8, x + 11, ybot - 6, k("nglass_l"))
    b.rect(x + 1, ybot - 6, x + 15, ybot - 2, m)
    b.rect(x + 1, ybot - 6, x + 15, ybot - 5, l)
    b.rect(x, ybot - 7, x + 2, ybot - 2, m)                    # fins
    b.rect(x + 14, ybot - 7, x + 16, ybot - 2, d)
    b.rect(x, ybot - 5, x + 2, ybot - 3, k("red_l"))
    b.rect(x + 14, ybot - 5, x + 16, ybot - 3, k("red"))
    b.rect(x + 6, ybot - 4, x + 10, ybot - 3, k("chrome_m"))   # plate
    b.rect(x, ybot - 2, x + 16, ybot - 1, k("chrome_l"))       # bumper
    b.rect(x + 2, ybot - 1, x + 5, ybot, k("ink"))
    b.rect(x + 11, ybot - 1, x + 14, ybot, k("ink"))


def _awning(b, x0, x1, y, cols, stripe=True):
    """Porch awning (4 rows, scalloped hem) on two slim posts to the ground."""
    for yy in range(y, y + 4):
        for x in range(x0, x1):
            if stripe:
                col = cols[1] if (x - x0) % 6 < 3 else k("trim")
                if yy == y:
                    col = cols[2] if (x - x0) % 6 < 3 else k("lamp")
            else:
                col = cols[1] if yy > y else cols[2]
            b.px(x, yy, col)
    for x in range(x0, x1):
        if (x - x0) % 3 != 1:
            b.px(x, y + 4, cols[0] if stripe else cols[1])
    for x in range(x0 + 1, x1 - 1):
        b.px(x, y + 5, k("shade_l"))


def _porch_posts(b, x0, x1, ytop, ybot):
    for px_ in (x0, x1 - 2):
        b.rect(px_, ytop, px_ + 2, ybot, k("trim"))
        b.rect(px_ + 1, ytop, px_ + 2, ybot, k("trim_d"))


def _rollup(b, x0, y0, x1, y1, cols=None):
    """Roll-up garage door: ribbed panels, a row of little lights."""
    lo, hi = (k("chrome"), k("chrome_l")) if cols is None else (cols[1], cols[2])
    b.rect(x0 - 1, y0 - 1, x1 + 1, y1, k("trim"))
    for y in range(y0, y1):
        r = (y - y0) % 4
        for x in range(x0, x1):
            col = hi if r == 0 else (lo if r < 3 else k("chrome_d"))
            if x == x0:
                col = hi
            b.px(x, y, col)
    wy = y0 + 4 + 1
    for x in range(x0 + 2, x1 - 2, 5):
        b.rect(x, wy, x + 3, wy + 2, k("nglass"))
    b.rect((x0 + x1) // 2 - 1, y1 - 3, (x0 + x1) // 2 + 2, y1 - 2, k("chrome_d"))


def _front_gable(b, cx, eave, half, apex_h, sid, rcols):
    """Front-facing cross gable over part of the facade, with a vent."""
    top = eave - apex_h
    for y in range(top, eave):
        t = (y - top + 1) / float(apex_h)
        hw = int(half * t)
        b.rect(cx - hw - 2, y, cx + hw + 3, y + 1, rcols[0])
        b.rect(cx - hw - 1, y, cx + hw + 2, y + 1, k("trim"))
        if hw > 0:
            for x in range(cx - hw + 1, cx + hw):
                b.px(x, y, sid[2] if (x - cx) % 3 == 0 else (sid[1] if x < cx + hw // 2 else sid[0]))
    b.rect(cx - half - 2, eave, cx + half + 3, eave + 1, rcols[0])
    vy = top + apex_h // 2
    b.rect(cx - 2, vy, cx + 3, vy + 3, k("shade"))
    b.rect(cx - 2, vy + 1, cx + 3, vy + 2, k("trim_d"))


def _wall_lamp(b, x, y):
    b.rect(x, y, x + 2, y + 3, k("lit"))
    b.px(x, y, k("lit_l"))
    b.px(x + 1, y + 3, k("chrome_d"))


# ---------------------------------------------------------------------------
# houses
# ---------------------------------------------------------------------------

def _house(kind, variant):
    W, fd, rise = _dims(kind)
    H = fd + rise
    v = variant
    koff = {"house_s": 0, "house_m": 2, "house_l": 4}[kind]
    rnd = random.Random(sum(ord(ch) for ch in kind) * 31 + v)
    b = Canvas(W, H)
    sid = SIDINGS[(v + koff) % 5]
    rcols = ROOFS[(v + koff // 2 + v // 4) % 4]
    hip = (v + koff // 2) % 2 == 1
    mirror = (v // 2) % 2 == 1
    door_c = DOORS[(v + koff) % 3]
    if door_c[1] == sid[1]:
        door_c = DOORS[(v + koff + 1) % 3]
    shut = None if v % 3 == 0 else rp(("teal_d", "char_d", "maro_d")[v % 3], ("teal", "char", "maro")[v % 3])
    wall_top = H - 22
    eave = wall_top + 2
    gy = H - 2                                                  # ground line (top of foundation)

    def X(x, w=0):
        return W - x - w if mirror else x

    # --- layout (x, width) before mirroring
    carport = garage = None
    porch = None
    smalls = []
    if kind == "house_s":
        pic, door = (5, 16), 29
        smalls = [(42, 6), (53, 6)]
        porch = (25, 39) if v % 2 == 0 else None
    elif kind == "house_m":
        if v % 2:
            carport = (54, 26)
            pic, door = (5, 18), 31
            smalls = [(42, 6)]
        else:
            pic, door = (6, 18), 35
            smalls = [(49, 6), (62, 6)]
            porch = (31, 45)
    else:
        if v % 2 == 0:
            garage = (64, 26)
            pic, door = (6, 20), 35
            smalls = [(48, 6)]
            porch = (31, 45) if v % 4 == 0 else None
        else:
            carport = (70, 26)
            pic, door = (7, 20), 36
            smalls = [(49, 6), (60, 6)]
            porch = (32, 46)

    # --- walls
    _clapboard(b, 0, wall_top, W, gy, sid)
    b.rect(0, wall_top, 2, gy, k("trim"))                       # corner boards
    b.rect(W - 2, wall_top, W, gy, k("trim_d"))
    _foundation(b, 0, W, gy)
    if carport:
        cx0 = X(carport[0], carport[1])
        cw = carport[1]
        b.rect(cx0, eave, cx0 + cw, gy, k("shade"))
        b.rect(cx0, gy - 9, cx0 + cw, gy, k("shade_l"))             # back wall of the carport
        b.rect(cx0 + 3, gy - 14, cx0 + 8, gy - 10, k("chrome_d"))    # tool shelf
        b.rect(cx0, gy, cx0 + cw, H, k("conc2"))
        b.rect(cx0, eave, cx0 + cw, eave + 2, k("trim"))             # beam
        b.rect(cx0, eave + 1, cx0 + cw, eave + 2, k("trim_d"))
        post = cx0 + cw - 2 if not mirror else cx0
        b.rect(post, eave, post + 2, gy, k("trim"))
        b.rect(post + 1, eave, post + 2, gy, k("trim_d"))
        _car(b, cx0 + (cw - 16) // 2, gy + 1, DOORS[(v + 1) % 2] if v % 4 != 3 else SIDINGS[0])
    if garage:
        g0 = X(garage[0], garage[1])
        _rollup(b, g0 + 2, eave + 5, g0 + garage[1] - 2, gy, sid if v % 4 == 2 else None)
        b.rect(g0, gy, g0 + garage[1], H, k("conc2"))
    lit_p = 0.75
    pstate = "lit" if rnd.random() < lit_p else ("tv" if v % 2 else "dark")
    curtain = rp("cherry_d", "cherry", "cherry_l") if v % 2 == 0 else rp("turq_d", "turq", "turq_l")
    _picture_window(b, X(pic[0], pic[1]), eave + 4, pic[1], 9, pstate, curtain)
    for i, (sx, sw) in enumerate(smalls):
        st = "lit" if rnd.random() < 0.5 else "dark"
        if kind == "house_l" and v % 4 == 3 and i == len(smalls) - 1:
            st = "alien" if v >= 4 else "tv"                     # something is in the back bedroom
        _window(b, X(sx, sw), eave + 4, sw, 7, st, shutters=shut)
    dx = X(door, 6)
    _door(b, dx, gy, door_c)
    if porch:
        a0, a1 = X(porch[0], porch[1] - porch[0]), X(porch[0], porch[1] - porch[0]) + porch[1] - porch[0]
        _porch_posts(b, a0, a1, eave + 3, gy)
        awn = DOORS[(v + 2) % 3] if v % 4 < 2 else rcols
        _awning(b, a0 - 1, a1 + 1, eave + 1, awn, stripe=v % 4 < 2)
    else:
        _wall_lamp(b, dx + 8 if not mirror else dx - 4, gy - 10)

    # --- roof
    if hip:
        _roof_hip(b, 0, 0, W, eave, rcols, seed=v)
    else:
        _roof_gable(b, 0, 0, W, eave, rcols, seed=v)
        if kind != "house_s":
            pc = X(pic[0], pic[1]) + pic[1] // 2
            _front_gable(b, pc, eave, pic[1] // 2 + 4, 12, sid, rcols)
    # --- antenna / chimney
    topper = (v + koff) % 3
    if topper != 1:
        ax = int(W * (0.72 if not mirror else 0.28))
        _antenna(b, ax, eave - 10, 1)
    if topper != 0:
        chx = int(W * (0.18 if not mirror else 0.74))
        _chimney(b, chx, 2, eave - 12)
    return _wrap(b)


# ---------------------------------------------------------------------------
# shed: garage with a roll-up door / tool shed with double doors
# ---------------------------------------------------------------------------

def _shed(variant):
    W, fd, rise = _dims("shed")
    H = fd + rise
    v = variant
    b = Canvas(W, H)
    wall_top = H - 20
    eave = wall_top + 2
    gy = H - 1
    if v % 2 == 0:
        sid = SIDINGS[(1, 4, 3, 0)[(v // 2) % 4]]
        _clapboard(b, 0, wall_top, W, gy, sid)
        b.rect(0, wall_top, 2, gy, k("trim"))
        b.rect(W - 2, wall_top, W, gy, k("trim_d"))
        _rollup(b, 6, eave + 4, W - 6, gy)
        b.rect(0, gy, W, H, k("conc2"))
        _wall_lamp(b, W // 2 - 1, eave + 1)
        _roof_gable(b, 0, 0, W, eave, ROOFS[(v // 2) % 4], seed=v)
    else:
        boards = rp("barn_d", "barn", "barn_l") if (v // 2) % 2 == 0 else rp("teal_d", "turq_d", "teal_l")
        for y in range(wall_top, gy):
            for x in range(W):
                col = boards[1 + (1 if x % 4 == 1 else 0)]
                if x % 4 == 3:
                    col = boards[0]
                b.px(x, y, col)
        b.rect(0, gy, W, H, k("conc1"))
        d0, d1 = 12, W - 12                                        # double doors
        b.rect(d0 - 2, eave + 3, d1 + 2, gy, k("trim"))
        b.rect(d0, eave + 5, d1, gy, boards[1])
        b.rect((d0 + d1) // 2, eave + 5, (d0 + d1) // 2 + 1, gy, k("trim"))
        for a, z in ((d0, (d0 + d1) // 2), ((d0 + d1) // 2 + 1, d1)):
            b.line(a, gy - 1, z - 1, eave + 5, k("trim"))
            b.rect(a, eave + 5, z, eave + 6, k("trim"))
            b.rect(a, gy - 1, z, gy, k("trim"))
        b.px((d0 + d1) // 2 - 2, gy - 7, k("chrome_l"))
        b.px((d0 + d1) // 2 + 2, gy - 7, k("chrome_l"))
        _window(b, 3, eave + 5, 4, 5, "dark" if v % 4 == 1 else "lit")
        # corrugated metal roof with a little rust
        for y in range(0, eave):
            for x in range(W):
                r = x % 3
                col = (k("chrome_m"), k("chrome"), k("chrome_d"))[r]
                if y < 3:
                    col = k("chrome_l") if r == 0 else k("chrome_m")
                if pa._hash(x // 2, y // 3, 40 + v) > 0.9 and y > 3:
                    col = k("brick_l") if r == 0 else k("brick")
                if y >= eave - 2:
                    col = k("chrome_d") if y == eave - 2 else k("ink2")
                b.px(x, y, col)
        b.rect(0, 0, W, 1, k("chrome_l"))
    return _wrap(b)


# ---------------------------------------------------------------------------
# diner (tavern)
# ---------------------------------------------------------------------------

def _diner(variant):
    W, fd, rise = _dims("tavern")
    H = fd + rise
    v = variant
    b = Canvas(W, H)
    wall_top = H - 30
    gy = H - 2
    cx = W // 2
    stripe = rp("cherry_d", "cherry", "cherry_l") if v % 2 == 0 else rp("turq_d", "turq", "turq_l")
    # --- barrel roof, rounded at the ends
    ry0, ry1 = 18, wall_top + 2
    ramp_ = rp("chrome_d", "chrome", "chrome_m", "chrome_l")
    rad = 8
    for y in range(ry0, ry1):
        t = (y - ry0) / float(ry1 - ry0)
        level = 1.2 + 2.0 * (t / 0.3) if t < 0.3 else 3.2 - 3.0 * (t - 0.3) / 0.7
        for x in range(2, W - 2):
            dxe = min(x - 2, W - 3 - x)
            if dxe < rad:                                          # round the four corners
                dy = min(y - ry0, ry1 - 1 - y)
                if dy < rad and (rad - dxe) ** 2 + (rad - dy) ** 2 > rad * rad:
                    continue
            lv = level - (0.9 if dxe < 5 else 0.0) * (1 - dxe / 5.0)
            i = int(lv + _b4(x, y) - 0.5)
            col = ramp_[max(0, min(3, i))]
            if (x - 2) % 10 == 9 and 0.1 < t < 0.95:
                col = ramp_[max(0, min(3, i - 1))]                 # standing seams
            b.px(x, y, col)
    # roof vent hoods
    for vx in (14, W - 22):
        b.rect(vx, ry0 + 6, vx + 8, ry0 + 11, k("chrome_d"))
        b.rect(vx, ry0 + 6, vx + 8, ry0 + 7, k("chrome_m"))
        b.rect(vx + 1, ry0 + 9, vx + 7, ry0 + 10, k("ink2"))
    # --- front wall
    y = wall_top
    b.rect(2, y, W - 2, y + 3, k("trim"))                          # enamel cornice
    b.rect(2, y + 2, W - 2, y + 3, k("trim_d"))
    wy0, wy1 = y + 4, y + 15
    b.rect(2, y + 3, W - 2, wy1 + 2, k("chrome_m"))
    rnd = random.Random(1950 + v)
    for x in range(4, W - 4):
        pane = (x - 4) % 10
        if pane < 2:
            b.rect(x, wy0, x + 1, wy1, k("chrome_l") if pane == 0 else k("chrome"))
            continue
        for yy in range(wy0, wy1):
            col = k("lit") if yy > wy0 + 1 else k("lit_l")
            if yy == wy1 - 1:
                col = k("lit_d")
            if yy == wy0 + 7 and x % 2:
                col = k("lit_d")                                   # counter line
            b.px(x, yy, col)
    for i in range(0, (W - 8) // 10):                              # customers on stools
        px0 = 4 + i * 10 + 2
        if abs(px0 + 4 - cx) < 12 or rnd.random() < 0.45:
            continue
        hx = px0 + 2 + rnd.randint(0, 3)
        b.rect(hx, wy0 + 3, hx + 3, wy0 + 6, k("brick_d"))
        b.rect(hx - 1, wy0 + 6, hx + 4, wy0 + 9, k("brick_d"))
    b.rect(2, wy1, W - 2, wy1 + 2, k("chrome_l"))                  # sill
    b.rect(2, wy1 + 1, W - 2, wy1 + 2, k("chrome"))
    sy = wy1 + 2
    b.rect(2, sy, W - 2, sy + 4, stripe[1])                        # the coloured stripe
    b.rect(2, sy, W - 2, sy + 1, stripe[2])
    b.rect(2, sy + 3, W - 2, sy + 4, stripe[0])
    for yy in range(sy + 4, gy):                                   # fluted stainless skirt
        for x in range(2, W - 2):
            b.px(x, yy, (k("chrome_l"), k("chrome_m"), k("chrome"))[x % 3])
    b.rect(2, gy, W - 2, H, k("ink2"))
    # rounded ends of the car body
    for x in range(0, 6):
        sh = (6 - x) / 6.0
        for yy in range(wall_top, H):
            for xx in (2 + x, W - 3 - x):
                p = b.get(xx, yy)
                if p is not None and sh > 0.5 and (xx + yy) % 2 == 0:
                    b.px(xx, yy, k("chrome_d"))
    for xx, yy in ((2, wall_top), (3, wall_top), (2, wall_top + 1), (W - 3, wall_top), (W - 4, wall_top),
                   (W - 3, wall_top + 1), (2, H - 1), (W - 3, H - 1)):
        b.p[yy][xx] = None
    # --- entrance vestibule
    vx0, vx1 = cx - 10, cx + 10
    b.rect(vx0, wall_top - 4, vx1, gy, k("chrome_m"))
    b.rect(vx0, wall_top - 4, vx0 + 2, gy, k("chrome_l"))
    b.rect(vx1 - 2, wall_top - 4, vx1, gy, k("chrome"))
    b.rect(vx0 - 2, wall_top - 7, vx1 + 2, wall_top - 3, stripe[1])  # vestibule roof slab
    b.rect(vx0 - 2, wall_top - 7, vx1 + 2, wall_top - 6, stripe[2])
    b.rect(vx0 - 2, wall_top - 3, vx1 + 2, wall_top - 2, k("chrome_l"))
    b.rect(cx - 5, wall_top + 2, cx + 5, gy, k("chrome_d"))
    b.rect(cx - 4, wall_top + 3, cx + 4, gy, k("lit"))
    b.rect(cx - 4, wall_top + 3, cx + 4, wall_top + 4, k("lit_l"))
    b.rect(cx, wall_top + 3, cx + 1, gy, k("chrome_d"))
    b.rect(cx - 3, wall_top + 12, cx + 4, wall_top + 13, k("chrome_l"))  # push bars
    b.rect(cx - 13, gy, cx + 13, H, k("conc4"))                    # step
    b.rect(cx - 13, H - 1, cx + 13, H, k("conc2"))
    # --- rooftop sign: a boomerang board edged in neon, an atomic star
    scx, scy = cx - 10, 14
    for p in range(2, 9):
        b.rect(scx - 12 + p * 3, scy + 8, scx - 11 + p * 3, ry0 + 4, k("chrome_d"))  # sign legs
    b.ellipse(scx, scy, 25, 9, k("neon"))
    b.ellipse(scx, scy, 24, 8, k("neon_d"))
    b.ellipse(scx, scy, 23, 7, stripe[1])
    b.ellipse(scx - 1, scy - 1, 21, 5, stripe[2] if v % 2 else stripe[1])
    for x in range(scx - 17, scx + 18):                            # a wave of tube light (no letters)
        yy = scy + int(round(2.2 * math.sin((x - scx) / 3.0)))
        b.px(x, yy, k("neon_l") if x % 4 else k("neon"))
    sx_, sy_ = scx + 30, 10                                        # atomic starburst
    for ax, ay in ((1, 0), (0, 1), (1, 1), (1, -1)):
        for t in range(-6, 7):
            b.px(sx_ + ax * t, sy_ + ay * t, k("neon") if abs(t) > 2 else k("neon_l"))
    for ax, ay in ((6, 0), (-6, 0), (0, 6), (0, -6)):
        b.px(sx_ + ax, sy_ + ay, k("lamp"))
    b.rect(sx_ - 1, sy_ - 1, sx_ + 2, sy_ + 2, k("lamp"))
    b.rect(sx_, sy_ + 7, sx_ + 1, ry0 + 3, k("chrome_d"))
    return _wrap(b)


# ---------------------------------------------------------------------------
# barn (stable)
# ---------------------------------------------------------------------------

def _firehouse(variant):
    """Main Street fire station: flat tar roof with a siren, brick front, three red
    engine doors. Used for the 'stable' slot inside town and village (even variants)."""
    W, fd, rise = _dims("stable")
    H = fd + rise
    b = Canvas(W, H)
    gy = H - 1
    front = H - 26                                                   # top of the brick facade
    # flat roof seen from above: tar and gravel, brick parapet
    for y in range(0, front):
        for x in range(W):
            col = k("char")
            h_ = pa._hash(x, y, 51)
            if h_ > 0.86:
                col = k("char_l")
            elif h_ < 0.10:
                col = k("char_d")
            b.px(x, y, col)
    b.rect(0, 0, W, 2, k("brick_l"))
    b.rect(0, 0, 2, front, k("brick_l"))
    b.rect(W - 2, 0, W, front, k("brick_d"))
    b.rect(12, 6, 26, 14, k("chrome"))                               # vent box
    b.rect(12, 6, 26, 7, k("chrome_l"))
    b.rect(W - 30, 5, W - 22, 13, k("chrome_d"))                     # siren on a post
    b.ellipse(W - 26, 6, 4.5, 3.2, k("chrome_m"))
    b.ellipse(W - 26, 6, 2.0, 1.5, k("cherry_l"))
    # brick facade
    for y in range(front, gy):
        r = (y - front) // 3
        for x in range(W):
            col = k("brick")
            if (y - front) % 3 == 2:
                col = k("brick_d")
            elif (x + (r % 2) * 4) % 8 == 0:
                col = k("brick_d")
            elif pa._hash(x // 8, r, 9) > 0.8:
                col = k("brick_l")
            b.px(x, y, col)
    b.rect(0, front, W, front + 3, k("trim"))                        # cornice
    b.rect(0, front + 2, W, front + 3, k("trim_d"))
    b.rect(W // 2 - 14, front + 4, W // 2 + 14, front + 7, k("cream"))   # name plate, no letters
    b.rect(W // 2 - 14, front + 6, W // 2 + 14, front + 7, k("cream_d"))
    # three engine doors
    dw, dh = 26, 16
    xs = [10, (W - dw) // 2, W - 10 - dw]
    for i, x0 in enumerate(xs):
        _rollup(b, x0, gy - dh, x0 + dw, gy, rp("cherry_d", "cherry", "cherry_l"))
        _wall_lamp(b, x0 + dw // 2 - 1, gy - dh - 3)
    for wx in (xs[0] + dw + 6, xs[1] + dw + 6):                     # small windows between doors
        _window(b, wx, front + 9, 6, 7, "lit")
    b.rect(0, gy, W, H, k("conc2"))                                  # apron
    return _wrap(b)


def _barn(variant):
    W, fd, rise = _dims("stable")
    H = fd + rise
    v = variant
    b = Canvas(W, H)
    red = rp("barn_d", "barn", "barn_l") if v % 2 == 0 else rp("maro_d", "barn_d", "barn")
    if v % 2 == 0:
        rcols = rp("char_d", "char", "char_l")
    else:
        rcols = rp("chrome_d", "chrome", "chrome_m")
    wall_top = H - 24
    eave = wall_top + 2
    gy = H - 1
    cx = W // 2

    def boards(x0, y0, x1, y1):
        for y in range(y0, y1):
            for x in range(x0, x1):
                col = red[1]
                if x % 4 == 3:
                    col = red[0]
                elif x % 4 == 0 and pa._hash(x, y // 6, 3) > 0.5:
                    col = red[2]
                b.px(x, y, col)

    # wings: board walls, gambrel roof seen from the front (two pitches)
    boards(0, wall_top, W, gy)
    b.rect(0, gy, W, H, k("conc1"))
    knee = eave // 2
    for y in range(0, eave):
        for x in range(W):
            if y < knee:
                col = rcols[2] if (y % 3 == 0 and pa._hash(x // 5, y, 2) > 0.5) else rcols[1]
                if y % 3 == 2:
                    col = rcols[0]
            elif y == knee:
                col = rcols[2]
            else:
                col = rcols[1] if (y - knee) % 3 else rcols[0]
                if (x + (y - knee) // 3 * 3) % 7 == 0:
                    col = rcols[0]
            if y >= eave - 2:
                col = k("trim") if y == eave - 1 else rcols[0]
            b.px(x, y, col)
    b.rect(0, 0, 1, eave, k("trim"))
    b.rect(W - 1, 0, W, eave, k("trim_d"))
    b.rect(0, wall_top, 2, gy, k("trim"))                            # white corner trim
    b.rect(W - 2, wall_top, W, gy, k("trim_d"))
    for wx in (10, 24, W - 30, W - 16):                                # stall windows
        _window(b, wx, wall_top + 6, 5, 5, "lit" if wx == 24 and v % 2 == 0 else "dark")
    # central gambrel gable end
    half, wall_y = 32, wall_top
    k1y, k1h = 18, 21                                                  # knee: height, half-width
    peak = 3

    def hw_at(y):
        if y >= wall_y:
            return half
        if y >= k1y:
            return k1h + (half - k1h) * (y - k1y) / float(wall_y - k1y)
        return k1h * (y - peak) / float(k1y - peak)

    for y in range(peak, gy):
        hw = int(hw_at(y))
        b.rect(cx - hw - 3, y, cx + hw + 3, y + 1, rcols[0] if y < wall_y else k("trim"))
        b.rect(cx - hw - 2, y, cx + hw + 2, y + 1, k("trim"))
        if y >= wall_y:
            b.rect(cx - hw - 3, y, cx - hw - 1, y + 1, k("trim"))
        for x in range(cx - hw, cx + hw):
            col = red[1]
            if x % 4 == 3:
                col = red[0]
            elif x % 4 == 0 and pa._hash(x, y // 6, 3) > 0.5:
                col = red[2]
            b.px(x, y, col)
    b.rect(cx - half - 3, gy, cx + half + 3, H, k("conc1"))
    # hayloft door with the hay hood
    b.rect(cx - 1, peak + 2, cx + 1, peak + 6, k("wood_d"))            # hood beam
    b.rect(cx - 7, peak + 7, cx + 7, peak + 22, k("trim"))
    b.rect(cx - 6, peak + 8, cx + 6, peak + 21, k("shade"))
    for i in range(10):
        b.px(cx - 5 + i, peak + 20 - (i % 3), k("hay"))
        b.px(cx - 5 + i, peak + 19 - (i % 2), k("hay_d"))
    b.rect(cx - 6, peak + 8, cx + 6, peak + 9, k("shade_l"))
    # big doors: white frame, X braces
    d0, d1, dt = cx - 16, cx + 16, wall_top + 3
    b.rect(d0 - 1, dt - 1, d1 + 1, gy, k("trim"))
    b.rect(d0, dt, d1, gy, red[1])
    for x in range(d0, d1):
        if x % 4 == 3:
            b.rect(x, dt, x + 1, gy, red[0])
    for a, z in ((d0, cx), (cx, d1)):
        b.rect(a, dt, z, dt + 2, k("trim"))
        b.rect(a, gy - 2, z, gy, k("trim"))
        b.rect(a, dt, a + 2, gy, k("trim"))
        b.rect(z - 2, dt, z, gy, k("trim"))
        b.line(a + 1, dt + 1, z - 2, gy - 2, k("trim"))
        b.line(a + 2, dt + 1, z - 1, gy - 2, k("trim_d"))
        b.line(z - 2, dt + 1, a + 1, gy - 2, k("trim"))
    b.rect(cx - 1, dt, cx + 1, gy, k("trim_d"))
    # a barn lamp over the doors
    _wall_lamp(b, cx - 1, dt - 6)
    # cupola on the west wing
    cu = 18
    b.rect(cu, 1, cu + 10, 9, k("trim"))
    b.rect(cu + 1, 3, cu + 9, 8, k("shade"))
    for yy in (4, 6):
        b.rect(cu + 1, yy, cu + 9, yy + 1, k("trim_d"))
    b.rect(cu - 1, 0, cu + 11, 2, rcols[2])
    return _wrap(b)


# ---------------------------------------------------------------------------
# church: white chapel with a steeple and a clock
# ---------------------------------------------------------------------------

def _church(variant):
    W, fd, rise = _dims("church")
    H = fd + rise
    b = Canvas(W, H)
    white = rp("trim_dd", "trim_d", "trim")
    sid = rp("trim_dd", "cream_l", "trim")
    rc = rp("char_d", "char", "char_l")
    cx = W // 2
    gy = H - 2
    # side wings (meeting rooms): hip roofs, clapboard
    wt = H - 28
    for x0, x1 in ((2, 40), (W - 40, W - 2)):
        _clapboard(b, x0, wt, x1, gy, sid)
        _roof_hip(b, x0 - 2, H - fd - 1, x1 + 2, wt + 2, rc, seed=x0)   # deep wings: cover the whole footprint
        for wx in (x0 + 7, x1 - 13):
            _window(b, wx, wt + 7, 6, 11, "lit" if (wx // 7) % 3 else "dark")
        b.rect(x0, wt, x0 + 2, gy, k("trim"))
        b.rect(x1 - 2, wt, x1, gy, k("trim_d"))
    _foundation(b, 0, W, gy)
    # nave: ridge running north-south, so the roof shows two slopes
    n0, n1 = 30, W - 30
    ft = H - 50                                                     # facade wall top
    for y in range(40, ft):
        for x in range(n0, n1):
            west = x < cx
            col = rc[2] if west else rc[1]
            if (y - 40) % 4 == 3:
                col = rc[1] if west else rc[0]
            elif (x + ((y - 40) // 4) * 3) % 8 == 0:
                col = rc[1] if west else rc[0]
            b.px(x, y, col)
    b.rect(cx - 1, 40, cx + 1, ft, rc[2])                          # ridge
    _clapboard(b, n0, ft, n1, gy, sid)
    b.rect(n0, ft, n0 + 3, gy, k("trim"))
    b.rect(n1 - 3, ft, n1, gy, k("trim_d"))
    # pediment
    ph = 26
    for y in range(ft - ph, ft):
        hw = int((n1 - n0) / 2.0 * (y - (ft - ph) + 1) / ph)
        b.rect(cx - hw - 1, y, cx + hw + 1, y + 1, k("trim"))
        for x in range(cx - hw + 2, cx + hw - 2):
            b.px(x, y, sid[1] if (y % 3) else sid[0])
    b.rect(n0 - 1, ft - 1, n1 + 1, ft + 2, k("trim"))
    b.rect(n0 - 1, ft + 1, n1 + 1, ft + 2, k("trim_d"))
    # tall sash windows either side of the tower
    for wx in (n0 + 9, n1 - 17):
        _window(b, wx, ft + 9, 8, 26, "lit")
        b.rect(wx - 2, ft + 6, wx + 10, ft + 8, k("trim"))            # flat pediment cap
        b.rect(wx + 3, ft + 9, wx + 5, ft + 35, k("trim"))            # muntin
    # steeple tower
    t0, t1 = cx - 13, cx + 13
    tt = 58
    for y in range(tt, gy):
        for x in range(t0, t1):
            col = sid[1] if (y - tt) % 3 != 2 else sid[0]
            if x < t0 + 3:
                col = k("trim")
            elif x >= t1 - 3:
                col = k("trim_dd")
            b.px(x, y, col)
    b.rect(t0 - 2, tt - 2, t1 + 2, tt + 2, k("trim"))               # cornice
    b.rect(t0 - 2, tt + 1, t1 + 2, tt + 2, k("trim_dd"))
    # clock face (no numerals: tick marks only)
    ccy = tt + 15
    b.ellipse(cx, ccy, 10, 10, k("trim_dd"))
    b.ellipse(cx, ccy, 8.6, 8.6, k("lamp"))
    for ax, ay in ((0, -7), (0, 7), (-7, 0), (7, 0)):
        b.px(cx + ax, ccy + ay, k("ink2"))
        b.px(cx + ax - (1 if ax > 0 else 0), ccy + ay - (1 if ay > 0 else 0), k("ink2"))
    b.line(cx, ccy, cx, ccy - 6, k("ink2"))                           # nearly midnight
    b.line(cx, ccy, cx - 3, ccy - 4, k("ink2"))
    b.px(cx, ccy, k("cherry"))
    # belfry with louvres
    bt = 34
    b.rect(t0 + 2, bt, t1 - 2, tt - 2, k("trim"))
    b.rect(t1 - 4, bt, t1 - 2, tt - 2, k("trim_dd"))
    b.rect(cx - 7, bt + 4, cx + 7, tt - 4, k("shade"))
    for yy in range(bt + 5, tt - 4, 3):
        b.rect(cx - 7, yy, cx + 7, yy + 1, k("trim_dd"))
    b.rect(t0, bt - 2, t1, bt + 1, k("trim"))
    b.rect(t0, bt, t1, bt + 1, k("trim_dd"))
    # spire
    b.triangle(cx, 3, bt - 1, 11, rp("trim_dd", "trim_d", "trim", "lamp"))
    b.rect(cx, 0, cx + 1, 6, k("chrome_m"))                          # lightning rod / vane
    b.rect(cx - 2, 2, cx + 3, 3, k("chrome_l"))
    # entrance: double red doors under a flat pediment, steps
    dw = 14
    d0 = cx - dw // 2
    dtop = gy - 22
    b.triangle(cx, dtop - 8, dtop - 1, 11, rp("trim_dd", "trim_d", "trim", "trim"))
    b.rect(d0 - 3, dtop - 2, d0 + dw + 3, dtop, k("trim"))
    b.rect(d0 - 1, dtop, d0 + dw + 1, gy, k("trim"))
    b.rect(d0, dtop + 1, d0 + dw, gy, k("cherry"))
    b.rect(d0, dtop + 1, d0 + 1, gy, k("cherry_l"))
    b.rect(cx, dtop + 1, cx + 1, gy, k("cherry_d"))
    for yy in (dtop + 4, dtop + 12):
        b.rect(d0 + 2, yy, cx - 1, yy + 6, k("cherry_d"))
        b.rect(cx + 2, yy, d0 + dw - 2, yy + 6, k("cherry_d"))
    b.px(cx - 2, dtop + 11, k("chrome_l"))
    b.px(cx + 2, dtop + 11, k("chrome_l"))
    _wall_lamp(b, d0 - 5, dtop + 2)
    _wall_lamp(b, d0 + dw + 3, dtop + 2)
    for i in range(2):                                               # steps
        b.rect(d0 - 6 - 2 * i, gy - 1 + i, d0 + dw + 6 + 2 * i, gy + i, k("conc4") if i == 0 else k("conc3"))
    return _wrap(b)


# ---------------------------------------------------------------------------
# farm water tower (windmill)
# ---------------------------------------------------------------------------

def _water_tower(variant):
    W, fd, rise = _dims("windmill")
    H = fd + rise
    v = variant
    b = Canvas(W, H)
    cx = W // 2
    t0, t1 = 13, W - 13                                               # tank
    ty0, ty1 = 30, 62
    leg = rp("chrome_d", "chrome", "chrome_m")
    # concrete pad over the WHOLE footprint: the slab is exactly what you collide
    # with, and everything above it (legs, tank) is scenery you can pass behind
    pad = H - fd + 1
    b.rect(2, pad, W - 2, H - 4, k("conc2"))                  # slab top, seen from above
    for y in range(pad, H - 4):
        for x in range(2, W - 2):
            if pa._hash(x // 3, y // 2, 77) > 0.85:
                b.px(x, y, k("conc1"))
    b.rect(2, pad, W - 2, pad + 1, k("conc3"))
    b.rect(2, H - 4, W - 2, H - 3, k("conc3"))
    b.rect(2, H - 3, W - 2, H, k("conc1"))
    b.rect(10, H - 18, 22, H - 9, k("conc0"))                 # well head / pump box
    b.rect(10, H - 18, 22, H - 17, k("conc3"))
    b.rect(12, H - 15, 20, H - 14, k("chrome"))
    # back legs (darker, shorter), then braces, then front legs
    foot = H - 6
    for (xa, xb, yb, cols) in ((28, 24, H - 20, (leg[0], leg[0])), (W - 29, W - 25, H - 20, (leg[0], leg[0]))):
        b.line(xa, ty1, xb, yb, cols[0])
        b.line(xa + 1, ty1, xb + 1, yb, cols[1])
        b.rect(xb - 1, yb, xb + 3, yb + 2, k("conc1"))
    fl = (18, 7)
    fr = (W - 19, W - 8)

    def lx(p, y):
        return int(round(p[0] + (p[1] - p[0]) * (y - ty1) / float(foot - ty1)))

    for ya, yb in ((ty1 + 2, ty1 + 18), (ty1 + 18, foot - 2)):         # X bracing
        b.line(lx(fl, ya) + 2, ya, lx(fr, yb), yb, k("chrome_d"))
        b.line(lx(fr, ya), ya, lx(fl, yb) + 2, yb, k("chrome_d"))
        b.rect(lx(fl, yb), yb, lx(fr, yb) + 2, yb + 1, k("chrome"))
    for p in (fl, fr):
        for y in range(ty1, foot):
            x = lx(p, y)
            b.px(x, y, leg[2])
            b.px(x + 1, y, leg[1])
            b.px(x + 2, y, leg[0])
        b.rect(lx(p, foot) - 1, foot, lx(p, foot) + 4, foot + 2, k("conc4"))
    # ladder up the middle
    for y in range(ty1, foot):
        b.px(cx - 3, y, k("chrome_m"))
        b.px(cx + 2, y, k("chrome"))
        if y % 3 == 0:
            b.rect(cx - 2, y, cx + 2, y + 1, k("chrome"))
    # the tank: cylinder lit from the west, seams, a coloured band
    band = rp("cherry_d", "cherry", "cherry_l") if v % 2 == 0 else rp("turq_d", "turq", "turq_l")
    tank = rp("chrome_d", "chrome", "chrome_m", "chrome_l")
    for y in range(ty0, ty1 + 3):
        for x in range(t0, t1):
            u = (x - t0 + 0.5) / float(t1 - t0)
            if y >= ty1:                                              # rounded bottom
                if abs(u - 0.5) > 0.5 - (y - ty1 + 1) * 0.12:
                    continue
            lvl = 3.4 - abs(u - 0.28) * 6.0
            i = int(lvl + _b4(x, y) - 0.5)
            col = tank[max(0, min(3, i))]
            if ty0 + 12 <= y < ty0 + 18:
                col = band[max(0, min(2, i - 1))]
            elif (y - ty0) % 8 == 7:
                col = tank[max(0, min(3, i - 1))]
            b.px(x, y, col)
    # catwalk with railing round the tank
    cy_ = ty1 - 4
    b.rect(t0 - 4, cy_, t1 + 4, cy_ + 2, k("chrome_d"))
    b.rect(t0 - 4, cy_, t1 + 4, cy_ + 1, k("chrome"))
    b.rect(t0 - 4, cy_ - 6, t1 + 4, cy_ - 5, k("chrome_m"))
    for x in range(t0 - 4, t1 + 5, 5):
        b.rect(x, cy_ - 6, x + 1, cy_, k("chrome_m"))
    # conical roof, finial and a red beacon
    b.triangle(cx, 8, ty0 + 2, (t1 - t0) // 2 + 3, rp("chrome_d", "chrome", "chrome_m", "chrome_l"))
    for x in range(t0 - 3, t1 + 3):
        b.px(x, ty0 + 1, k("chrome_d"))
    b.rect(cx - 1, 3, cx + 1, 9, k("chrome_m"))
    b.rect(cx - 2, 1, cx + 2, 4, k("cherry"))
    b.px(cx - 1, 1, k("cherry_l"))
    return _wrap(b)


# ---------------------------------------------------------------------------
# military guard tower
# ---------------------------------------------------------------------------

def _guard_tower(variant):
    W, fd, rise = _dims("tower")
    H = fd + rise
    b = Canvas(W, H)
    cx = W // 2
    wood = rp("wood_d", "wood", "wood_l")
    gy = H - 1
    # gravel pad under the whole footprint (the part you collide with), legs on top
    for y in range(H - fd + 2, gy):
        for x in range(2, W - 2):
            b.px(x, y, k("conc1") if pa._hash(x // 2, y // 2, 61) > 0.7 else k("conc0"))
    b.rect(2, H - fd + 2, W - 2, H - fd + 3, k("conc2"))
    # back legs, bracing, front legs
    leg_top = 44
    for x in (11, W - 14):
        b.rect(x, leg_top, x + 3, H - 22, wood[0])
    for x0 in (4, W - 8):
        b.rect(x0, leg_top, x0 + 4, gy, wood[1])
        b.rect(x0, leg_top, x0 + 1, gy, wood[2])
        b.rect(x0 + 3, leg_top, x0 + 4, gy, wood[0])
    for ya, yb in ((leg_top + 2, leg_top + 18), (leg_top + 18, H - 12)):
        b.line(8, ya, W - 9, yb, wood[0])
        b.line(W - 9, ya, 8, yb, wood[0])
        b.line(8, ya + 1, W - 9, yb + 1, wood[1])
        b.rect(8, yb, W - 8, yb + 1, wood[1])
    # ladder
    for y in range(leg_top, gy):
        b.px(cx - 3, y, wood[2])
        b.px(cx + 2, y, wood[1])
        if y % 3 == 1:
            b.rect(cx - 2, y, cx + 2, y + 1, wood[2])
    # sandbag nest round the foot
    bag = rp("bag_d", "bag", "bag_l")
    sb_top = H - 12
    for row in range(4):
        y = sb_top + row * 3
        off = 3 if row % 2 else 0
        for x0 in range(-3 + off, W, 7):
            if row == 0 and abs(x0 + 3 - cx) < 6:
                continue                                          # gap at the ladder
            for x in range(max(0, x0), min(W, x0 + 6)):
                col = bag[1]
                if y == sb_top + row * 3:
                    col = bag[2]
                if x in (x0, x0 + 5):
                    col = bag[0]
                b.px(x, y, col)
                b.px(x, y + 1, bag[1] if x not in (x0, x0 + 5) else bag[0])
                b.px(x, y + 2, bag[0])
    # cabin: platform, olive half-wall, open window band, tin roof
    b.rect(0, 40, W, 45, wood[1])                                  # platform
    b.rect(0, 40, W, 41, wood[2])
    b.rect(0, 44, W, 45, wood[0])
    ol = rp("olive_d", "olive", "olive_l")
    b.rect(2, 30, W - 2, 40, ol[1])
    for x in range(2, W - 2, 4):
        b.rect(x, 30, x + 1, 40, ol[0])
    b.rect(2, 30, 3, 40, ol[2])
    b.rect(2, 18, W - 2, 30, k("shade"))
    b.rect(2, 18, 4, 30, ol[2])
    b.rect(W - 4, 18, W - 2, 30, ol[0])
    b.rect(cx - 1, 18, cx + 1, 30, ol[1])                          # corner post seen through
    b.rect(10, 22, 15, 30, k("olive_d"))                           # a sentry: helmet + shoulders
    b.rect(9, 25, 16, 30, k("olive_d"))
    b.rect(10, 21, 15, 23, k("olive"))
    b.px(14, 24, k("lit_d"))                                       # cigarette
    b.rect(2, 29, W - 2, 30, ol[2])                                # sill
    # tin roof (corrugated) with overhang
    for y in range(6, 19):
        for x in range(0, W):
            r = x % 3
            col = (k("chrome_m"), k("chrome"), k("chrome_d"))[r]
            if y < 9:
                col = k("chrome_l") if r == 0 else k("chrome_m")
            if y >= 17:
                col = k("chrome_d") if y == 17 else k("ink2")
            b.px(x, y, col)
    # searchlight on the roof, glowing
    sx = W - 14
    b.rect(sx - 1, 4, sx + 9, 10, k("chrome_d"))
    b.rect(sx, 3, sx + 8, 9, k("chrome"))
    b.rect(sx, 3, sx + 8, 4, k("chrome_m"))
    b.ellipse(sx + 3.5, 6, 3.4, 2.9, k("lamp"))
    b.ellipse(sx + 3.0, 5.5, 1.6, 1.4, k("white"))
    b.rect(sx + 3, 9, sx + 5, 12, k("chrome_d"))
    for gx, gy_ in ((sx - 2, 5), (sx - 2, 7), (sx + 3, 2), (sx - 3, 6)):   # glow spill on the tin
        b.px(gx, gy_, k("lit_l"))
    return _wrap(b)


# ---------------------------------------------------------------------------
# walls and fences
# ---------------------------------------------------------------------------

def _coil_h(b, x0, x1, cy, ry, period=6):
    """Concertina wire seen from the front: overlapping loops."""
    for lx in range(x0 - period, x1 + period, period):
        for t in range(24):
            a = t * 2 * math.pi / 24.0
            x = int(round(lx + period / 2.0 + math.cos(a) * (period * 0.85)))
            y = int(round(cy + math.sin(a) * ry))
            if x0 <= x < x1:
                b.px(x, y, k("wire_l") if math.sin(a) < 0 else k("wire"))


def _wall_h(variant):
    W, fd, rise = _dims("wall_h")
    H = fd + rise
    b = Canvas(W, H)
    v = variant
    top, face = 9, 14
    for y in range(top, face):                                     # top of the barrier
        for x in range(W):
            b.px(x, y, k("conc4") if y == top else k("conc3"))
    for y in range(face, H):
        for x in range(W):
            col = k("conc2")
            if x % 16 == 15:
                col = k("conc0")
            elif x % 16 == 0:
                col = k("conc3")
            elif pa._hash(x, y // 3, 60 + v) > 0.88:
                col = k("conc1")
            if y == face:
                col = k("conc1")
            if y >= H - 2:
                col = k("conc1") if y == H - 2 else k("conc0")
            b.px(x, y, col)
    for x in (3 + 7 * (v % 2), 22 - 5 * (v % 3)):                   # rust/water streaks
        for y in range(face + 1, face + 6 + (x % 4)):
            b.px(x, y, k("brick_d") if y < face + 3 else k("conc1"))
    for x in (3, 19):                                               # wire stakes
        b.rect(x, 1, x + 1, top + 1, k("chrome_d"))
    _coil_h(b, 0, W, 5, 3.6, period=8)
    return _wrap(b)


def _wall_v(variant):
    """North-south barrier seen from the south: the top face with the wire
    coil running along it. Seamless along its length (period 16 px)."""
    W, fd, rise = _dims("wall_v")
    H = fd + rise
    b = Canvas(W, H)
    for y in range(H):
        for x in range(W):
            if x < 2:
                col = k("conc3")
            elif x >= W - 2:
                col = k("conc1")
            else:
                col = k("conc4") if x < 5 else k("conc3")
                if y % 16 == 15:
                    col = k("conc1")
            b.px(x, y, col)
    for y in range(H):                                              # coil from above
        for s in (1, -1):
            x = int(round(W / 2.0 - 0.5 + s * 4.3 * math.cos(y * 2 * math.pi / 8.0)))
            b.px(x, y, k("wire_l") if s > 0 else k("wire"))
        if y % 8 == 0:
            b.rect(W // 2 - 4, y, W // 2 + 4, y + 1, k("chrome_d"))
    for y in range(0, H, 16):                                       # stakes
        b.rect(W // 2 - 1, y + 7, W // 2 + 1, y + 9, k("ink2"))
    return _wrap(b)


def _fence_h(variant):
    """White picket fence; seamless in 4 px."""
    W, fd, rise = _dims("fence_h")
    H = fd + rise
    b = Canvas(W, H)
    for yy in (H - 10, H - 5):                                      # rails behind
        b.rect(0, yy, W, yy + 2, k("trim_d"))
        b.rect(0, yy + 1, W, yy + 2, k("trim_dd"))
    for x0 in range(0, W, 4):
        b.px(x0 + 1, 0, k("trim"))
        b.rect(x0 + 1, 1, x0 + 3, H, k("trim"))
        b.rect(x0 + 2, 1, x0 + 3, H, k("trim_d"))
    for x in range(W):
        if b.get(x, H - 1) is not None:
            b.px(x, H - 1, k("trim_dd"))
    return _wrap(b)


def _fence_v(variant):
    """Picket fence running north-south, seen from above-south."""
    W, fd, rise = _dims("fence_v")
    H = fd + rise
    b = Canvas(W, H)
    b.rect(1, 0, W - 1, H, k("trim_d"))
    b.rect(W - 2, 0, W - 1, H, k("trim_dd"))
    for y in range(0, H, 4):
        b.rect(0, y, W, y + 2, k("trim"))
        b.rect(W - 1, y, W, y + 2, k("trim_d"))
        b.rect(0, y + 2, W, y + 3, k("trim_dd"))
    return _wrap(b)


def build(kind, variant=0):
    if kind in ("house_s", "house_m", "house_l"):
        return _house(kind, variant)
    if kind == "stable" and variant % 2 == 0:
        return _firehouse(variant)                                   # in town: no barns on Main Street
    return {"shed": _shed, "tavern": _diner, "stable": _barn, "church": _church,
            "windmill": _water_tower, "tower": _guard_tower, "wall_h": _wall_h, "wall_v": _wall_v,
            "fence_h": _fence_h, "fence_v": _fence_v}[kind](variant)
