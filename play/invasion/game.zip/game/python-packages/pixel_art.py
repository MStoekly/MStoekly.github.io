"""Pixel art for the Crimson Wake hunt minigame, drawn entirely in code.

No Ren'Py imports and no image libraries: sprites are painted onto a tiny
Canvas of palette colours, and a ~15-line PNG encoder turns them into bytes
that hunt.rpy hands to im.Data. That means:

  * every sprite is exactly the pixels written here (no resampling),
  * integer upscaling is baked into the PNG (nearest-neighbour by
    construction), so crispness never depends on an engine setting,
  * it all runs headless -- tools/make_pixel_sheet.py renders a contact sheet.

Native resolution: one map tile = TILE_PX (16) pixels. The simulation still
works in "world" pixels (hunt_mapgen.TILE = 70 world px per tile).

Compatible with Python 2 (Ren'Py 7) and 3 (Ren'Py 8): no f-strings, no
bytes([...]) tricks.
"""

import math
import random
import struct
import zlib

import hunt_mapgen

TILE_PX = 16


# ---------------------------------------------------------------------------
# palette -- one shared, hand-picked set so everything looks like one game
# ---------------------------------------------------------------------------

def _rgb(h):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), 255)


C = dict((k, _rgb(v)) for k, v in {
    "ink": "#120e18", "ink2": "#1c1424",
    # skin
    "skin_pale": "#e4d6d8", "skin_pale_d": "#b9a3b0",
    "skin": "#d9a98a", "skin_d": "#b07f66",
    # vampire cloak
    "cloak_d": "#2a0d1d", "cloak": "#4a1430", "cloak_l": "#6e2043",
    "red": "#c81428", "red_l": "#ff5f6e",
    "hair": "#1a1424",
    "white": "#f2ece6", "bone": "#d9ccb8", "silver": "#c8ccd8", "silver_d": "#8a8fa0",
    # leather / wood
    "wood_d": "#2e1c14", "wood": "#5a3a24", "wood_l": "#8a5c38",
    "tan": "#b88a58", "tan_l": "#d9b27c",
    # cloth
    "slate_d": "#262c3c", "slate": "#3b4458", "slate_l": "#566280",
    "purple_d": "#321a4a", "purple": "#4a2a6a", "purple_l": "#6e44a0",
    "green_c_d": "#24402e", "green_c": "#3a6a4a",
    "rag_d": "#4a4038", "rag": "#6e6050", "rag_l": "#8c7c68",
    "gold": "#e8c04a", "gold_d": "#a8832a",
    "hay": "#c9a23c", "hay_d": "#8e6e22", "hay_l": "#e6c660",
    # foliage
    "leaf0": "#102a1c", "leaf1": "#1a3d27", "leaf2": "#27552f", "leaf3": "#3a7038", "leaf4": "#58914a",
    "pine0": "#0e2426", "pine1": "#17383a", "pine2": "#234f48", "pine3": "#336a58", "pine4": "#4c8468",
    "berry": "#c81e3a",
    # stone
    "stone0": "#22222c", "stone1": "#363642", "stone2": "#4e4e5c", "stone3": "#6a6a7a", "stone4": "#8a8a98",
    "moss": "#3f6a3a",
    # ground
    "grass0": "#14241d", "grass1": "#1b3125", "grass2": "#233e2e", "grass3": "#2c4c37", "grass4": "#3a6042",
    "mead0": "#243a22", "mead1": "#2e4a2a", "mead2": "#3a5a32", "mead3": "#486c3a", "mead4": "#5a8044",
    "dirt0": "#2e2118", "dirt1": "#40301f", "dirt2": "#54402a", "dirt3": "#6c5334", "dirt4": "#826440",
    "cob0": "#24222a", "cob1": "#34323e", "cob2": "#46444f", "cob3": "#5a5864", "cob4": "#6e6c78",
    "leafy": "#4a3a1c", "water": "#10202c",
    "roof_red_d": "#4a1a20", "roof_red": "#7a2a2a", "roof_red_l": "#a63f38",
    "plaster_d": "#9c8e7a", "plaster": "#cdbfa8", "plaster_l": "#e8ddc8",
    "thatch0": "#5e4c24", "thatch1": "#80672c", "thatch2": "#a58a3c",
    "glass": "#4f6a8a", "glass_l": "#8fb0cc", "flower_y": "#e8c04a", "flower_p": "#c864b4",
    # medieval roofs, lit windows, shutters
    "tile_d": "#3c1f1d", "tile": "#6a3028", "tile_l": "#93483a",
    "mslate_d": "#26322f", "mslate": "#3d524c", "mslate_l": "#5a7568",
    "shingle_d": "#2a2018", "shingle": "#4a3828", "shingle_l": "#6a5238",
    "lit_d": "#a8632a", "lit": "#f0b44a", "lit_l": "#ffe08a",
    "shutter": "#3a5a40", "shutter_d": "#27402c", "shutter_r": "#7a2a2a",
    # ---- Invasion (1950s B-movie night) -- added keys, prefix f_ ----------
    # the alien Kreel
    "f_alien_d": "#5f9e78", "f_alien": "#a6dcae", "f_alien_l": "#e2ffdc",
    "f_eye": "#04060a", "f_eye_l": "#d8f4ff", "f_glow": "#8dff5a",
    "f_neon": "#7cff4f", "f_neon_d": "#2fbf5a", "f_neon_l": "#d4ffb0",
    # soldiers
    "f_olive_d": "#323a20", "f_olive": "#556236", "f_olive_l": "#7c8c4c",
    "f_helmet_d": "#4a4a2c", "f_helmet": "#7a7448", "f_helmet_l": "#a8a070",
    "f_steel": "#30343c", "f_steel_l": "#7a828e",
    "f_khaki_d": "#5e5034", "f_khaki": "#9a8656", "f_khaki_l": "#c9b582",
    # people + cow
    "f_cow_k": "#17171c", "f_cow_d": "#a6a49c", "f_cow_w": "#ece8dc",
    "f_pink": "#ec96a4", "f_pink_d": "#b5606e",
    "f_denim_d": "#1c2e58", "f_denim": "#2c4f94", "f_denim_l": "#5a86d0",
    "f_cherry_d": "#86121e", "f_cherry": "#d02a3a", "f_cherry_l": "#f05a62",
    "f_mint_d": "#1f7a70", "f_mint": "#3fb8a6", "f_mint_l": "#86e0cc",
    "f_cream": "#f4ecd2",
    "f_leather_d": "#0e0e12", "f_leather": "#1f1f27", "f_leather_l": "#3c3c4a",
    "f_chrome": "#a8b8cc", "f_hair_l": "#5a6070",
    "f_lab_d": "#9aa2ac", "f_lab": "#d6dce2", "f_lens": "#bfe6ff",
    # night foliage, bark, stone
    "f_leaf0": "#071418", "f_leaf1": "#0d2226", "f_leaf2": "#14322f", "f_leaf3": "#1e4537", "f_leaf4": "#2d5c45",
    "f_moonleaf": "#5e8c80",
    "f_pine0": "#061217", "f_pine1": "#0b1e24", "f_pine2": "#122d33", "f_pine3": "#1b3e40", "f_pine4": "#285350",
    "f_bark_d": "#16121a", "f_bark": "#2c2428", "f_bark_l": "#45393a",
    "f_char0": "#09080a", "f_char1": "#171416", "f_char2": "#272121", "f_char3": "#3a302b",
    "f_ember": "#ff6a24", "f_ember_l": "#ffc060",
    "f_dead0": "#121218", "f_dead1": "#25252d", "f_dead2": "#383842", "f_dead3": "#50505a",
    "f_stone0": "#141820", "f_stone1": "#212833", "f_stone2": "#303946", "f_stone3": "#45505d", "f_stone4": "#606c79",
    "f_moss": "#284636",
    "f_hay_d": "#6a5628", "f_hay": "#977c36", "f_hay_l": "#c2a34c",
    "f_wood_d": "#2a1d16", "f_wood": "#4f3826", "f_wood_l": "#765536",
    # props
    "f_drum_r_d": "#6a1018", "f_drum_r": "#b8202e", "f_drum_r_l": "#e45058",
    "f_drum_y_d": "#8a6410", "f_drum_y": "#d8a820", "f_drum_y_l": "#f6d860",
    "f_bench_d": "#1c4a44", "f_bench": "#2e6e64", "f_bench_l": "#4a988a",
    "f_iron": "#1a1c22",
    # ground
    "f_grass0": "#0a1719", "f_grass1": "#0f2023", "f_grass2": "#152a2a", "f_grass3": "#1c3531", "f_grass4": "#29473d",
    "f_mead0": "#0e1d1d", "f_mead1": "#132724", "f_mead2": "#19312b", "f_mead3": "#213c33", "f_mead4": "#2e4d3d",
    "f_lawn0": "#0f2420", "f_lawn1": "#142e27", "f_lawn2": "#1a382d", "f_lawn3": "#224434", "f_lawn4": "#2f563f",
    "f_litter": "#262520",
    "f_dirt0": "#1d1918", "f_dirt1": "#29231f", "f_dirt2": "#362e28", "f_dirt3": "#463c33", "f_dirt4": "#5a4e42",
    "f_asph0": "#121419", "f_asph1": "#191c22", "f_asph2": "#20242b", "f_asph3": "#282d35", "f_asph4": "#333943",
    "f_conc0": "#262b32", "f_conc1": "#3a4048", "f_conc2": "#4c535c", "f_conc3": "#5f6770", "f_conc4": "#7a838c",
    "f_line": "#d8b440", "f_line_d": "#8c7630",
    "f_corn0": "#132a1a", "f_corn1": "#1f4024", "f_corn2": "#2e5a2a", "f_corn3": "#4c7432", "f_corn4": "#8c9a46",
}.items())


def ramp(*names):
    return [C[n] for n in names]


_B4 = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]


def _hash(x, y, seed=0):
    """Small deterministic integer hash -> float in [0, 1)."""
    h = (x * 374761393 + y * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h ^= h >> 16
    return (h & 0xFFFF) / 65536.0


# ---------------------------------------------------------------------------
# canvas
# ---------------------------------------------------------------------------

class Canvas(object):
    """A w x h grid of RGBA tuples; None = transparent."""

    def __init__(self, w, h):
        self.w = w
        self.h = h
        self.p = [[None] * w for _ in range(h)]

    # -- primitives ------------------------------------------------------

    def px(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.p[y][x] = C[c] if isinstance(c, str) else c

    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return self.p[y][x]
        return None

    def rect(self, x0, y0, x1, y1, c):
        """Filled, x1/y1 exclusive."""
        for y in range(y0, y1):
            for x in range(x0, x1):
                self.px(x, y, c)

    def ellipse(self, cx, cy, rx, ry, c):
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                nx = (x + 0.5 - cx) / rx
                ny = (y + 0.5 - cy) / ry
                if nx * nx + ny * ny <= 1.0:
                    self.px(x, y, c)

    def shade_ellipse(self, cx, cy, rx, ry, colors, light=(-0.55, -0.75), dither=0.8):
        """Ellipse lit from the upper left, banded through `colors`
        (dark -> light) with a Bayer dither between bands."""
        n = len(colors)
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                nx = (x + 0.5 - cx) / rx
                ny = (y + 0.5 - cy) / ry
                if nx * nx + ny * ny <= 1.0:
                    b = nx * light[0] + ny * light[1]
                    t = (b + 1.0) / 2.0 * (n - 1)
                    t += ((_B4[y & 3][x & 3] + 0.5) / 16.0 - 0.5) * dither
                    i = max(0, min(n - 1, int(t + 0.5)))
                    self.px(x, y, colors[i])

    def line(self, x0, y0, x1, y1, c):
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        while True:
            self.px(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy

    def triangle(self, cx, top, bottom, half_w, colors):
        """Isoceles triangle, lit from the left, for pine tiers."""
        n = len(colors)
        for y in range(top, bottom):
            w = half_w * (y - top + 0.5) / float(bottom - top)
            for x in range(int(cx - w), int(cx + w) + 1):
                if abs(x + 0.5 - cx) <= w:
                    side = (x + 0.5 - cx) / max(w, 0.5)       # -1 left .. 1 right
                    t = (1.0 - side) / 2.0 * (n - 1) - 0.4 + (y - top) * 0.02
                    t += ((_B4[y & 3][x & 3] + 0.5) / 16.0 - 0.5) * 0.8
                    self.px(x, y, colors[max(0, min(n - 1, int(t + 0.5)))])

    # -- whole-canvas passes ---------------------------------------------

    def outline(self, c):
        """1px outline in colour c, drawn around every opaque pixel (into
        the transparent margin, so leave 1px of empty border)."""
        col = C[c] if isinstance(c, str) else c
        marks = []
        for y in range(self.h):
            for x in range(self.w):
                if self.p[y][x] is None:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        if self.get(x + dx, y + dy) is not None:
                            marks.append((x, y))
                            break
        for x, y in marks:
            self.p[y][x] = col

    def flipped(self):
        o = Canvas(self.w, self.h)
        o.p = [list(reversed(row)) for row in self.p]
        return o

    def blit(self, other, x0, y0):
        for y in range(other.h):
            for x in range(other.w):
                c = other.p[y][x]
                if c is not None:
                    self.px(x0 + x, y0 + y, c)

    # -- output ----------------------------------------------------------

    def rgba(self, scale=1):
        """Raw RGBA rows, each pixel repeated `scale` times both ways."""
        clear = (0, 0, 0, 0)
        table = {}
        for row in self.p:
            for c in set(row):
                if c not in table:
                    table[c] = bytes(bytearray(c if c is not None else clear)) * scale
        get = table.__getitem__
        rows = []
        for row in self.p:
            r = b"".join(map(get, row))
            rows.extend([r] * scale)
        return rows

    def png(self, scale=1):
        return encode_png(self.w * scale, self.h * scale, self.rgba(scale))


def encode_png(w, h, rows):
    def chunk(tag, data):
        body = tag + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"".join([b"\x00" + r for r in rows]), 3))
            + chunk(b"IEND", b""))


# ---------------------------------------------------------------------------
# characters (16x16, facing "down" / "up" / "side" = right; flip for left)
# ---------------------------------------------------------------------------

def _alien_eye(c, x, y, mirror):
    """A big glossy black almond eye, slanting down towards the nose; (x, y)
    is the outer top corner, mirror=True for the right eye."""
    d = -1 if mirror else 1
    for ex, ey in ((0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (1, 2), (2, 2)):
        c.px(x + ex * d, y + ey, "f_eye")
    c.px(x if not mirror else x - 2, y, "f_eye_l")             # gloss, lit from the upper left


def _ink_edge(c, col="ink"):
    """Turn the silhouette's own outermost pixels dark (an ink edge INSIDE the
    shape), so a bright outline drawn around it afterwards reads crisply."""
    marks = []
    for y in range(c.h):
        for x in range(c.w):
            if c.p[y][x] is not None:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    if c.get(x + dx, y + dy) is None:
                        marks.append((x, y))
                        break
    k = C[col]
    for x, y in marks:
        c.p[y][x] = k


def _aura(c, stage):
    """Sparse bright pixels just outside the outline (stage 4 glow)."""
    marks = []
    for y in range(c.h):
        for x in range(c.w):
            if c.p[y][x] is None:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    if c.get(x + dx, y + dy) is not None:
                        if _hash(x, y, 91 + stage) > 0.80:
                            marks.append((x, y))
                        break
    for x, y in marks:
        c.p[y][x] = C["f_neon_l"]


def vampire(facing="down", stage=0):
    """The hero (internal kind "vampire"): Kreel, a pale grey-green alien with
    big glossy black eyes, an ink edge and a bright neon-green outline (so it
    pops off the dark ground). `stage` 0..4 is its mutation stage: 0 big-eyed
    blob, 1 antennae, 2 bigger with spikes, 3 extra eyes + glowing veins,
    4 a crown of tentacles and an aura. Feet stay on rows 13-14."""
    s = max(0, min(4, int(stage or 0)))
    c = Canvas(16, 16)
    skin = ramp("f_alien_d", "f_alien", "f_alien_l")
    big = s >= 2
    hx = 5.6 + (1.0 if big else 0.0)          # head radii
    hy = 3.9 + (0.4 if big else 0.0)
    hcy = 7.0 - (0.4 if big else 0.0)          # head centre y
    bx = 3.8 + (1.0 if big else 0.0)           # body radii
    by = 2.6 + (0.4 if big else 0.0)
    bcy = 11.6
    top = int(hcy - hy + 0.5)                  # first head row
    ey = int(hcy) - 1                          # eye row
    side = facing == "side"
    hcx, bcx = (8.6, 7.6) if side else (8.0, 8.0)
    # -- mass: feet, body, head; then the ink edge on that mass
    if side:
        c.rect(5, 13, 7, 15, "f_alien_d")
        c.rect(8, 13, 10, 15, "f_alien_d")
    else:
        c.rect(5, 13, 7, 15, "f_alien_d")
        c.rect(9, 13, 11, 15, "f_alien_d")
    c.shade_ellipse(bcx, bcy, bx, by, skin)
    c.shade_ellipse(hcx, hcy, hx, hy, skin if facing != "up" else ramp("f_alien_d", "f_alien", "f_alien"))
    _ink_edge(c)
    # -- appendages (ink, outlined in neon below)
    tipc = "f_neon_l"
    if s >= 2:                                                  # spikes
        if side:
            for sx, sy in ((3, 5), (2, 9), (2, 12)):
                c.px(sx, sy, "ink")
                c.px(sx - 1, sy - 1, "ink")
        else:
            for sx, d in ((2, -1), (13, 1)):
                c.px(sx, 10, "ink")
                c.px(sx, 9, "ink")
                c.px(sx + d, 8, "ink")
        if facing == "up":                                      # ridge down the back
            for y in range(top + 2, 13, 2):
                c.px(8, y, "f_neon" if s >= 3 else "f_alien_d")
                c.px(7, y + 1, "f_alien_d")
                c.px(9, y + 1, "f_alien_d")
    if 1 <= s < 4:                                              # antennae
        tt = max(1, top - 2)
        if side:
            c.line(7, top, 6, tt, "ink")
            c.px(5, tt - 1 if tt > 1 else tt, tipc)
            c.line(10, top, 10, tt, "ink")
            c.px(11, tt - 1 if tt > 1 else tt, tipc)
        else:
            c.line(6, top, 5, tt, "ink")
            c.px(4, max(0, tt - 1), tipc)
            c.line(10, top, 11, tt, "ink")
            c.px(12, max(0, tt - 1), tipc)
    if s >= 4:                                                  # tentacle crown
        crown = (((4, 0), (3, -1), (2, -2)), ((6, 0), (6, -1), (5, -2)), ((8, 0), (8, -1), (9, -2)),
                 ((10, 0), (10, -1), (11, -2)), ((12, 0), (13, -1), (14, -2)))
        if side:
            crown = (((5, 0), (4, -1), (3, -2)), ((7, 0), (7, -1), (6, -2)), ((9, 0), (9, -1), (10, -2)),
                     ((11, 0), (12, -1), (13, -2)))
        for pts in crown:
            for i, (x, y) in enumerate(pts):
                if top + y >= 0:
                    c.px(x, top + y, tipc if i == len(pts) - 1 else "ink")
    # -- face
    if side:
        ex = int(hcx) + 2
        for px_, py_ in ((ex - 1, ey), (ex, ey), (ex + 1, ey), (ex, ey + 1), (ex + 1, ey + 1), (ex + 2, ey + 1), (ex + 2, ey + 2)):
            c.px(px_, py_, "f_eye")
        c.px(ex, ey, "f_eye_l")
        c.px(int(hcx) + 3, ey + 4, "f_alien_d")                # mouth slit
        if s >= 3:
            c.px(ex - 2, ey - 2, "f_eye")                      # extra eyes
            c.px(ex + 1, ey - 2, "f_eye")
            c.px(ex + 1, ey - 3, "f_neon")
            for vx, vy in ((6, 11), (7, 12), (8, 11), (9, 12)):
                c.px(vx, vy, "f_neon")
    elif facing == "up":
        if s >= 3:
            for vx, vy in ((5, 11), (6, 12), (11, 11), (10, 12), (5, 6), (11, 6)):
                c.px(vx, vy, "f_neon")
    else:
        _alien_eye(c, 4, ey, False)
        _alien_eye(c, 11, ey, True)
        c.px(8, ey + 4, "f_alien_d")                           # mouth slit
        if s >= 3:
            c.px(7, ey - 2, "f_eye")                           # third + fourth eye
            c.px(8, ey - 2, "f_eye")
            c.px(7, ey - 2, "f_neon")
            c.px(8, ey - 3, "f_alien_d")
            for vx, vy in ((6, 11), (7, 12), (10, 11), (9, 12), (3, 8), (12, 8)):
                c.px(vx, vy, "f_neon")
    c.outline("f_neon_l" if s >= 4 else "f_glow")
    if s >= 4:
        _aura(c, s)
    return c


def hunter(facing="down"):
    """1950s soldier: olive drab helmet and uniform, rifle."""
    c = Canvas(16, 16)
    uni = ramp("f_khaki_d", "f_khaki", "f_khaki_l")
    helm = ramp("f_helmet_d", "f_helmet", "f_helmet_l")
    skin = ramp("skin_d", "skin")
    if facing == "side":
        c.rect(5, 13, 7, 15, "f_khaki_d")
        c.rect(8, 13, 10, 15, "f_khaki_d")
        c.px(5, 14, "ink2")
        c.px(8, 14, "ink2")
        c.shade_ellipse(7.4, 10.8, 3.8, 3.2, uni)
        c.shade_ellipse(9.0, 7.2, 2.4, 2.0, skin)
        c.px(10, 7, "ink")
        c.shade_ellipse(8.4, 4.8, 3.8, 2.6, helm)
        c.px(7, 3, "white")                                 # helmet shine
        c.px(8, 3, "white")
        c.rect(5, 6, 13, 7, "f_helmet_d")                      # brim
        c.line(5, 10, 14, 10, "wood_l")                        # rifle, held forward
        c.line(10, 10, 14, 10, "f_steel_l")
        c.px(14, 9, "f_steel_l")
        c.px(5, 11, "f_wood")
        c.px(9, 11, "skin")                                    # hand
    elif facing == "up":
        c.rect(5, 13, 7, 15, "f_khaki_d")
        c.rect(9, 13, 11, 15, "f_khaki_d")
        c.shade_ellipse(8, 10.8, 4.4, 3.4, uni)
        c.rect(6, 9, 11, 13, "f_khaki_d")                      # pack
        c.rect(6, 9, 11, 10, "f_olive")
        c.line(3, 13, 12, 6, "wood_l")                         # rifle slung across the back
        c.line(10, 8, 13, 5, "f_steel_l")
        c.shade_ellipse(8, 5.4, 4.2, 3.0, helm)
        c.px(6, 4, "white")                                 # helmet shine
        c.px(7, 3, "white")
        c.rect(4, 7, 13, 8, "f_helmet_d")
    else:
        c.rect(5, 13, 7, 15, "f_khaki_d")
        c.rect(9, 13, 11, 15, "f_khaki_d")
        c.px(5, 14, "ink2")
        c.px(10, 14, "ink2")
        c.shade_ellipse(8, 10.8, 4.4, 3.4, uni)
        c.rect(5, 12, 12, 13, "f_khaki_d")                     # belt
        c.px(8, 12, "f_steel_l")
        c.shade_ellipse(8, 7.4, 2.4, 1.9, skin)
        c.px(7, 7, "ink")
        c.px(9, 7, "ink")
        c.shade_ellipse(8, 4.6, 4.2, 2.6, helm)
        c.px(6, 3, "white")                                 # helmet shine
        c.px(7, 3, "white")
        c.rect(4, 6, 13, 7, "f_helmet_d")                      # brim shadow
        c.line(3, 13, 11, 9, "wood_l")                         # rifle across the chest
        c.line(11, 9, 14, 7, "f_steel_l")
        c.px(14, 6, "f_steel_l")
        c.px(10, 10, "skin")
        c.px(5, 12, "skin")
    c.outline("ink")
    return c


def prey(tier):
    """Five victims, poorest -> richest (= more blood): cow, farmer, housewife,
    greaser, scientist."""
    c = Canvas(16, 16)
    skin = ramp("skin_d", "skin")
    if tier == 0:                                  # cow: bulky, black and white
        c.rect(3, 13, 5, 15, "f_cow_k")
        c.rect(11, 13, 13, 15, "f_cow_k")
        c.shade_ellipse(8, 10.6, 6.0, 3.9, ramp("f_cow_d", "f_cow_w", "f_cow_w"))
        c.ellipse(4.2, 11.4, 1.9, 1.6, "f_cow_k")
        c.ellipse(12.0, 9.6, 1.7, 1.3, "f_cow_k")
        c.ellipse(9.6, 13.0, 1.6, 1.0, "f_cow_k")
        c.px(7, 14, "f_pink")                      # udder
        c.px(8, 14, "f_pink")
        c.rect(2, 5, 5, 7, "f_cow_k")              # ears
        c.rect(11, 5, 14, 7, "f_cow_k")
        c.px(4, 3, "bone")                         # horns
        c.px(4, 4, "bone")
        c.px(11, 3, "bone")
        c.px(11, 4, "bone")
        c.shade_ellipse(8, 6.2, 3.0, 2.8, ramp("f_cow_d", "f_cow_w", "f_cow_w"))
        c.rect(5, 4, 8, 6, "f_cow_k")              # patch over one eye
        c.ellipse(8, 8.3, 2.4, 1.3, "f_pink")      # muzzle
        c.px(7, 8, "f_pink_d")
        c.px(9, 8, "f_pink_d")
        c.px(6, 5, "f_eye")
        c.px(10, 5, "f_eye")
    elif tier == 1:                                # farmer: overalls, straw hat
        c.rect(5, 13, 7, 15, "f_denim_d")
        c.rect(9, 13, 11, 15, "f_denim_d")
        c.px(5, 14, "wood_d")
        c.px(6, 14, "wood_d")
        c.px(9, 14, "wood_d")
        c.px(10, 14, "wood_d")
        c.shade_ellipse(8, 10.8, 4.4, 3.2, ramp("f_cherry_d", "f_cherry", "f_cherry_l"))
        for x, y in ((5, 9), (11, 10), (4, 11), (12, 9)):
            c.px(x, y, "f_cherry_d")               # plaid flecks
        c.rect(6, 9, 11, 14, "f_denim")            # bib + trousers
        c.rect(6, 9, 11, 10, "f_denim_l")
        c.px(6, 8, "f_denim")                      # straps
        c.px(10, 8, "f_denim")
        c.px(6, 9, "gold")
        c.px(10, 9, "gold")
        c.shade_ellipse(8, 6.6, 2.6, 2.2, skin)
        c.px(7, 7, "ink")
        c.px(9, 7, "ink")
        c.ellipse(8, 4.6, 5.6, 1.6, "f_hay")       # hat brim
        c.ellipse(8, 3.4, 2.8, 1.7, "f_hay_l")
        c.rect(6, 4, 11, 5, "f_cherry_d")          # hat band
    elif tier == 2:                                # housewife: polka-dot dress, headscarf
        c.shade_ellipse(8, 12.0, 5.2, 2.9, ramp("f_mint_d", "f_mint", "f_mint_l"))
        c.shade_ellipse(8, 9.4, 2.8, 1.9, ramp("f_mint_d", "f_mint", "f_mint_l"))
        for x, y in ((5, 12), (8, 11), (11, 12), (6, 14), (10, 14), (7, 9), (4, 13), (12, 13)):
            c.px(x, y, "f_cream")
        c.rect(6, 10, 11, 11, "f_cherry")          # belt
        c.px(4, 9, "skin")                         # arms
        c.px(12, 9, "skin")
        c.shade_ellipse(8, 6.4, 2.6, 2.3, skin)
        c.px(7, 6, "ink")
        c.px(9, 6, "ink")
        c.px(8, 7, "f_cherry")                     # lipstick
        c.shade_ellipse(8, 4.2, 3.2, 1.9, ramp("f_cherry_d", "f_cherry", "f_cherry_l"))
        c.px(5, 5, "hay_l")                        # curls
        c.px(11, 5, "hay_l")
        c.px(5, 6, "hay")
        c.px(11, 6, "hay")
        c.px(4, 6, "f_cherry")                     # scarf knot ends
        c.px(12, 6, "f_cherry")
    elif tier == 3:                                # greaser: leather jacket, quiff
        c.rect(5, 13, 7, 15, "f_denim_d")
        c.rect(9, 13, 11, 15, "f_denim_d")
        c.px(5, 14, "f_denim_l")                   # rolled cuffs
        c.px(6, 14, "f_denim_l")
        c.px(9, 14, "f_denim_l")
        c.px(10, 14, "f_denim_l")
        c.shade_ellipse(8, 10.8, 4.6, 3.3, ramp("f_leather_d", "f_leather", "f_leather_l"))
        c.rect(7, 8, 10, 13, "white")              # tee
        c.px(6, 8, "f_leather_l")                  # collar
        c.px(10, 8, "f_leather_l")
        c.px(6, 11, "f_chrome")                    # zip
        c.px(4, 10, "f_chrome")
        c.shade_ellipse(8, 6.6, 2.5, 2.2, skin)
        c.px(7, 7, "ink")
        c.px(9, 7, "ink")
        c.ellipse(8, 4.4, 3.0, 1.8, "f_leather")   # slick hair
        c.rect(5, 5, 6, 7, "f_leather")            # sideburns
        c.rect(10, 5, 11, 7, "f_leather")
        c.ellipse(8.6, 2.6, 2.4, 1.6, "f_leather") # the quiff
        c.px(10, 1, "f_leather")
        c.px(11, 1, "f_leather")
        c.px(7, 2, "f_hair_l")
        c.px(8, 2, "f_hair_l")
        c.px(9, 1, "f_hair_l")
    else:                                          # scientist: lab coat, glasses
        c.shade_ellipse(8, 10.9, 4.4, 3.9, ramp("f_lab_d", "f_lab", "white"))
        c.line(8, 10, 8, 14, "f_lab_d")            # coat opening
        c.px(8, 8, "f_denim_d")                    # tie
        c.px(8, 9, "f_denim_d")
        c.px(10, 10, "gold")                       # pens
        c.px(11, 10, "f_cherry")
        c.rect(12, 10, 15, 14, "f_wood")           # clipboard
        c.rect(12, 11, 14, 14, "f_cream")
        c.px(5, 14, "ink2")                        # shoes
        c.px(10, 14, "ink2")
        c.shade_ellipse(8, 6.0, 2.8, 2.6, skin)
        c.rect(4, 5, 6, 8, "f_lab_d")              # grey tufts, bald on top
        c.rect(10, 5, 12, 8, "f_lab_d")
        c.px(4, 4, "f_lab")
        c.px(11, 4, "f_lab")
        c.px(6, 6, "f_lens")                       # glasses
        c.px(7, 6, "f_lens")
        c.px(8, 6, "ink")
        c.px(9, 6, "f_lens")
        c.px(10, 6, "f_lens")
        c.px(6, 7, "ink")
        c.px(10, 7, "ink")
        c.px(8, 4, "skin")                         # shine on the bald dome
    c.outline("ink")
    return c


def lunge_ring(radius_native):
    """Dotted pixel circle, 1px thick; radius in native pixels."""
    r = max(3, int(radius_native))
    size = r * 2 + 3
    c = Canvas(size, size)
    cx = cy = size / 2.0
    steps = int(r * 8)
    for i in range(steps):
        if (i // 2) % 2:
            continue
        a = i * 2.0 * math.pi / steps
        c.px(int(cx + math.cos(a) * r), int(cy + math.sin(a) * r), "red_l")
    return c


# ---------------------------------------------------------------------------
# map objects. A tree is TWO sprites: a trunk (drawn under the entities) and
# a crown (drawn over them), so you run under the branches but are stopped by
# the trunk. (Placement and collision both come from the art: see footprint().)
# ---------------------------------------------------------------------------

def _trunk(seed, w=10, h=14, dark=False):
    rnd = random.Random(seed)
    c = Canvas(w, h)
    cols = ramp("f_bark_d", "f_bark", "f_bark", "f_bark_l") if not dark else ramp("ink2", "f_bark_d", "f_bark_d", "f_bark")
    mid = w // 2
    for y in range(h):
        flare = 1 if y >= h - 3 else 0
        half = 3 + flare
        for x in range(mid - half, mid + half):
            t = (x - (mid - half)) / float(2 * half - 1)       # 0 left .. 1 right
            idx = 3 - int(t * 3.99)                            # left = light
            c.px(x, y, cols[max(0, min(3, idx))])
    for _ in range(h // 2):                                    # bark marks
        c.px(mid - 2 + rnd.randint(0, 3), rnd.randint(1, h - 4), cols[0])
    c.outline("ink")
    return c


def oak_trunk(variant=0):
    return _trunk(100 + variant)


def oak_crown(variant=0):
    rnd = random.Random(7 + variant * 31)
    c = Canvas(34, 28)
    colors = ramp("f_leaf0", "f_leaf1", "f_leaf2", "f_leaf3", "f_leaf4")
    blobs = [(17, 17, 12, 8)]
    for _ in range(5):
        blobs.append((rnd.uniform(9, 25), rnd.uniform(9, 19), rnd.uniform(5, 8), rnd.uniform(4, 7)))
    blobs.sort(key=lambda b: -b[1])                            # lower blobs first, upper blobs on top
    for cx, cy, rx, ry in blobs:
        c.shade_ellipse(cx, cy + 1, rx, ry, colors)
    for _ in range(26):                                        # leaf specks: moonlit on top
        x, y = rnd.randint(4, 29), rnd.randint(3, 22)
        cur = c.get(x, y)
        if cur is not None:
            c.px(x, y, "f_moonleaf" if y < 12 else colors[0])
    c.outline("f_leaf0")
    return c


def pine_trunk(variant=0):
    return _trunk(200 + variant, w=8, h=12, dark=True)


def pine_crown(variant=0):
    c = Canvas(28, 38)
    colors = ramp("f_pine0", "f_pine1", "f_pine2", "f_pine3", "f_pine4")
    tiers = [(1, 14, 7), (8, 22, 10), (16, 32, 13)] if variant == 0 else [(2, 12, 6), (7, 19, 9), (13, 27, 11), (19, 36, 13)]
    for top, bottom, half in tiers:
        c.triangle(14, top, bottom, half, colors)
    for top, bottom, half in tiers:                            # moonlight catching the tier tips
        for y in range(top + 2, bottom, 3):
            x = int(14 - half * (y - top + 0.5) / float(bottom - top)) + 1
            if c.get(x, y) is not None:
                c.px(x, y, "f_moonleaf")
    c.outline("f_pine0")
    return c


def dead_tree(variant=0):
    """A scorched, burnt tree: charred black limbs with a few live embers."""
    rnd = random.Random(300 + variant)
    c = Canvas(24, 32)
    cols = ramp("f_char0", "f_char1", "f_char2", "f_char3")
    for y in range(8, 30):
        flare = 1 if y >= 27 else 0
        for x in range(10 - flare, 14 + flare):
            c.px(x, y, cols[3 if x == 10 else (2 if x < 12 else 1)])
    c.line(12, 14, 5, 6, cols[2])
    c.line(12, 12, 19, 4, cols[2])
    c.line(12, 18, 20, 13, cols[1])
    c.line(5, 6, 3, 2, cols[1])
    c.line(19, 4, 21, 1, cols[1])
    c.line(5, 6, 7, 3, cols[1])
    for _ in range(4):                                         # charcoal cracks
        c.px(10 + rnd.randint(0, 3), rnd.randint(10, 26), cols[0])
    for x, y in ((3, 2), (21, 1), (20, 13)):                   # smouldering tips
        c.px(x, y, "f_ember")
    for _ in range(3):                                         # embers in the bark
        y = rnd.randint(12, 26)
        c.px(11 + rnd.randint(0, 1), y, "f_ember")
        c.px(11 + rnd.randint(0, 1), y + 1, "f_ember_l" if rnd.random() < 0.5 else "f_ember")
    c.outline("ink")
    return c


def rock(variant=0):
    rnd = random.Random(400 + variant)
    big = variant % 2 == 1
    w, h = (24, 18) if big else (16, 12)
    c = Canvas(w, h)
    colors = ramp("f_stone0", "f_stone1", "f_stone2", "f_stone3", "f_stone4")
    c.shade_ellipse(w * 0.5, h * 0.62, w * 0.44, h * 0.36, colors)
    c.shade_ellipse(w * 0.36, h * 0.5, w * 0.26, h * 0.3, colors)
    for _ in range(3 if big else 1):
        x, y = rnd.randint(4, w - 6), rnd.randint(4, h - 5)
        c.line(x, y, x + rnd.randint(1, 3), y + rnd.randint(1, 3), "f_stone0")
    for _ in range(4 if big else 2):
        x, y = rnd.randint(3, w - 4), rnd.randint(2, h - 4)
        if c.get(x, y) is not None:
            c.px(x, y, "f_moss")
    c.outline("ink")
    return c


def bush(variant=0):
    rnd = random.Random(500 + variant)
    c = Canvas(14, 11)
    colors = ramp("f_leaf0", "f_leaf1", "f_leaf2", "f_leaf3", "f_leaf4")
    c.shade_ellipse(5, 6.5, 4.2, 3.6, colors)
    c.shade_ellipse(9, 6, 4.2, 3.8, colors)
    c.px(6, 3, "f_moonleaf")
    if variant % 2:
        for _ in range(4):
            x, y = rnd.randint(3, 10), rnd.randint(3, 8)
            if c.get(x, y) is not None:
                c.px(x, y, "f_cherry")
    c.outline("f_leaf0")
    return c


def gravestone(variant=0):
    """(Kept under its old name, map key "grave".) Crash debris: a twisted,
    torn fragment of silver saucer hull half buried in scorched earth, its torn
    edge still glowing faintly green."""
    c = Canvas(11, 14)
    c.ellipse(5.5, 11.5, 4.6, 1.6, "f_char1")                 # scorched mound
    c.px(2, 11, "f_char2")
    c.px(8, 12, "f_char2")
    rows = {2: (6, 8), 3: (5, 9), 4: (4, 9), 5: (4, 9), 6: (3, 9), 7: (3, 9),
            8: (2, 9), 9: (2, 8), 10: (2, 7), 11: (2, 6)}
    for y, (x0, x1) in rows.items():
        for x in range(x0, x1 + 1):
            t = (x - x0) / float(max(1, x1 - x0))
            col = "f_chrome" if t < 0.2 else ("silver" if t < 0.6 else "silver_d")
            c.px(x, y, col)
        c.px(x0, y, "white" if y in (4, 5, 8) else "f_chrome")  # moonlit curl
    c.line(4, 4, 2, 9, "silver_d")                            # bent rim
    for x, y in ((3, 10), (8, 3), (8, 9)):                    # rivets
        c.px(x, y, "f_steel")
    c.rect(5, 5, 8, 8, C["f_steel"])                          # cracked porthole, still lit
    c.px(6, 6, "f_neon")
    c.px(7, 6, "f_neon_d")
    c.px(6, 7, "f_neon_d")
    c.rect(7, 10, 10, 12, C["silver_d"])                      # a smaller shard
    c.px(7, 10, "f_chrome")
    for x, y in ((9, 4), (9, 6), (9, 3), (9, 8)):             # glowing torn edge
        c.px(x, y, "f_neon")
    c.px(9, 11, "f_neon_d")
    c.outline("ink")
    for x, y in ((10, 4), (10, 5), (9, 2), (9, 7), (10, 10)):   # faint green glow
        if c.get(x, y) is None:
            c.px(x, y, (124, 255, 79, 90))
    return c


def crate(variant=0):
    """Wooden supply crate: lighter lid, planked front, iron corners, rope
    handle."""
    c = Canvas(14, 14)
    c.rect(1, 1, 13, 13, C["f_wood"])
    c.rect(1, 1, 13, 4, C["f_wood_l"])                 # lid
    c.rect(1, 1, 13, 2, C["tan"])
    c.rect(1, 4, 13, 5, C["f_wood_d"])                 # lid shadow
    for y in (7, 10):                                  # plank seams
        c.rect(2, y, 12, y + 1, C["f_wood_d"])
    c.rect(1, 4, 2, 13, C["f_wood_d"])                 # frame
    c.rect(12, 4, 13, 13, C["f_wood_d"])
    c.rect(1, 12, 13, 13, C["f_wood_d"])
    for x, y in ((1, 4), (12, 4), (1, 12), (12, 12), (1, 1), (12, 1)):
        c.px(x, y, "f_steel_l")
    c.rect(4, 8, 10, 9, C["f_wood_l"])                 # rope handle
    c.px(4, 9, "f_wood_l")
    c.px(9, 9, "f_wood_l")
    c.outline("ink")
    return c


def barrel(variant=0):
    """Oil drum with rolled rims; variant 0 cherry red, 1 yellow."""
    c = Canvas(12, 14)
    k = "y" if variant % 2 else "r"
    d, m, l = C["f_drum_%s_d" % k], C["f_drum_%s" % k], C["f_drum_%s_l" % k]
    cols = [l, l, m, m, m, m, m, d, d, d]              # x = 1..10, lit from the left
    for y in range(3, 13):
        for i, col in enumerate(cols):
            c.px(1 + i, y, col)
    for y in (6, 9):                                   # rolled ribs
        for i in range(10):
            c.px(1 + i, y, C["f_steel_l"] if i < 3 else (l if i < 7 else m))
            c.px(1 + i, y + 1, d)
    c.rect(1, 12, 11, 13, C["f_steel"])                # bottom chime
    c.ellipse(6, 2.6, 5.0, 1.8, "f_steel_l")           # top rim
    c.ellipse(6, 2.6, 4.0, 1.1, d)
    c.px(4, 2, "f_steel")                              # bung
    c.px(8, 3, "f_steel")
    c.outline("ink")
    return c


def haybale(variant=0):
    c = Canvas(18, 13)
    c.rect(1, 2, 17, 12, C["f_hay"])
    c.rect(1, 2, 17, 4, C["f_hay_l"])
    c.rect(1, 10, 17, 12, C["f_hay_d"])
    for x in (5, 11):
        c.rect(x, 2, x + 1, 12, C["f_wood_d"])
    for i in range(6):
        c.px(2 + i * 3, 6 + (i % 2) * 2, "f_hay_d")
    c.outline("ink")
    return c


def well(variant=0):
    """(Kept under its old name.) A 1950s gas pump on a concrete island:
    rounded cherry-red body, glowing globe on top, dial window, chrome hose."""
    c = Canvas(24, 22)
    # island: top face then front face
    c.rect(2, 13, 22, 18, C["f_conc3"])
    c.rect(2, 13, 22, 14, C["f_conc4"])
    c.rect(2, 18, 22, 20, C["f_conc1"])
    c.rect(2, 17, 22, 18, C["f_line"])                 # painted kerb edge
    for x in range(3, 22, 4):
        c.px(x, 17, "f_line_d")
    # pump body
    body = [C["f_drum_r_l"], C["f_drum_r"], C["f_drum_r"], C["f_drum_r"], C["f_drum_r"], C["f_drum_r"], C["f_drum_r_d"], C["f_drum_r_d"]]
    for y in range(6, 17):
        for i, col in enumerate(body):
            c.px(8 + i, y, col)
    for i in range(1, 7):                              # rounded shoulders
        c.px(8 + i, 5, body[i])
    c.rect(8, 15, 16, 17, C["f_cherry_d"])             # plinth
    c.rect(10, 7, 14, 10, C["f_cream"])                # dial window
    c.px(12, 8, "ink")
    c.px(11, 9, "ink")
    c.rect(9, 11, 15, 12, C["f_chrome"])               # chrome band
    c.rect(11, 13, 13, 14, C["f_cream"])               # badge
    # globe
    c.ellipse(12, 3.2, 2.6, 2.0, "f_cream")
    c.px(11, 2, "lit_l")
    c.px(12, 2, "white")
    c.rect(11, 5, 13, 6, C["f_steel"])
    # hose hanging down the right side + nozzle in its holster
    c.px(16, 8, "f_steel_l")
    c.px(17, 9, "f_iron")
    c.px(17, 10, "f_iron")
    c.px(18, 11, "f_iron")
    c.px(18, 12, "f_iron")
    c.px(17, 13, "f_iron")
    c.px(16, 9, "f_chrome")
    c.outline("ink")
    for x, y in ((11, 0), (12, 0), (9, 2), (15, 3)):   # faint glow round the globe
        if c.get(x, y) is None:
            c.px(x, y, (255, 224, 138, 90))
    return c


def lamp(variant=0):
    """Street lamp: steel pole, curved arm, a cobra head throwing warm light."""
    c = Canvas(12, 26)
    c.rect(2, 5, 4, 25, C["f_steel"])
    c.rect(2, 5, 3, 25, C["f_steel_l"])
    c.rect(1, 22, 6, 26, C["f_steel"])                 # base
    c.rect(1, 22, 2, 26, C["f_steel_l"])
    c.rect(1, 22, 6, 23, C["f_chrome"])
    c.px(3, 4, "f_steel")                              # arm curving over
    c.px(4, 3, "f_steel")
    c.rect(5, 2, 8, 3, C["f_steel"])
    c.rect(6, 3, 11, 5, C["f_iron"])                   # lamp head
    c.rect(6, 3, 10, 4, C["f_steel_l"])
    c.rect(7, 5, 11, 6, C["lit_l"])                    # lens
    c.px(10, 5, "lit")
    c.outline("ink")
    for x, y in ((6, 7), (7, 7), (8, 7), (9, 7), (10, 7), (7, 8), (8, 8), (9, 8), (8, 9), (6, 6), (11, 6)):
        if c.get(x, y) is None or c.get(x, y) == C["ink"]:
            c.px(x, y, (255, 214, 120, 110 if y < 8 else 60))
    return c


def scarecrow(variant=0):
    c = Canvas(18, 22)
    c.rect(8, 6, 10, 21, C["f_wood"])                 # post
    c.rect(1, 8, 17, 10, C["f_wood_l"])               # arms
    c.rect(3, 10, 15, 16, C["f_cherry_d"])            # flannel shirt
    c.rect(3, 10, 15, 11, C["f_cherry"])
    for x in range(4, 15, 3):
        c.rect(x, 10, x + 1, 16, C["f_cherry"])
    c.rect(3, 15, 15, 16, C["f_denim_d"])
    c.ellipse(9, 5, 3.4, 3.4, "f_hay")                # head: a sack
    c.px(8, 4, "ink")
    c.px(10, 4, "ink")
    c.rect(5, 2, 13, 3, C["f_wood_d"])                # hat brim
    c.rect(7, 0, 11, 3, C["f_wood_d"])
    for x in (2, 15):
        c.px(x, 10, "f_hay_l")
        c.px(x, 11, "f_hay")
    c.outline("ink")
    return c


def haystack(variant=0):
    c = Canvas(22, 24)
    c.shade_ellipse(11, 14.5, 9.5, 9.0, ramp("f_hay_d", "f_hay", "f_hay_l"))
    c.triangle(11, 1, 14, 6, [C["f_hay_d"], C["f_hay"], C["f_hay_l"], C["f_hay_l"]])
    for i in range(7):
        c.px(5 + i * 2, 10 + (i % 3) * 3, "f_hay_d")
    c.rect(4, 19, 18, 23, C["f_hay_d"])
    c.ellipse(11, 21, 7.5, 2.5, "f_hay")
    c.outline("ink")
    return c


def grave_cross(variant=0):
    """(Kept under its old name, map key "cross".) A red fire hydrant."""
    c = Canvas(12, 18)
    c.rect(3, 15, 9, 17, C["f_cherry_d"])                     # base flange
    c.rect(3, 15, 9, 16, C["f_cherry"])
    body = ["f_cherry_l", "f_cherry", "f_cherry", "f_cherry_d"]
    for y in range(7, 15):
        for i, col in enumerate(body):
            c.px(4 + i, y, col)
    for x in (2, 3, 8, 9):                                    # side nozzles
        c.px(x, 9, "f_cherry_d")
        c.px(x, 10, "f_cherry_d")
    c.px(2, 9, "f_chrome")
    c.px(9, 9, "f_chrome")
    c.rect(5, 10, 7, 12, C["f_chrome"])                       # pumper cap
    c.px(5, 10, "white")
    c.rect(3, 6, 9, 7, C["f_cherry_d"])                       # bonnet rim
    c.rect(4, 5, 8, 6, C["f_cherry"])
    c.px(4, 5, "f_cherry_l")
    c.rect(5, 4, 7, 5, C["f_chrome"])                         # operating nut
    c.px(5, 4, "white")
    c.outline("ink")
    return c


# ---------------------------------------------------------------------------
# buildings. Oblique view, always facing south: a roof block over a front wall.
# A building's footprint is `d` tiles deep and its sprite is `rise` px taller
# than that; the rise is the roof overhanging northwards, so the vampire can
# stand behind a house and be hidden by it. Collision is the footprint
# rectangle (hunt_mapgen), not a circle.
# ---------------------------------------------------------------------------

BUILDINGS = {
    "house_s": {"w": 4, "d": 3, "rise": 10, "style": "house"},
    "house_m": {"w": 5, "d": 3, "rise": 10, "style": "house"},
    "house_l": {"w": 6, "d": 3, "rise": 10, "style": "house"},
    "shed":    {"w": 3, "d": 2, "rise": 8, "style": "shed"},
    "tavern":  {"w": 7, "d": 4, "rise": 12, "style": "tavern"},
    "stable":  {"w": 8, "d": 3, "rise": 10, "style": "stable"},
    "church":  {"w": 9, "d": 6, "rise": 56, "style": "church"},
    "windmill": {"w": 5, "d": 3, "rise": 64, "style": "windmill"},
    "tower":   {"w": 3, "d": 3, "rise": 40, "style": "tower"},
    "wall_h":  {"w": 2, "d": 1, "rise": 14, "style": "wall"},
    "wall_v":  {"w": 1, "d": 2, "rise": 0, "style": "wall"},
    "fence_h": {"w": 2, "d": 0.375, "rise": 8, "style": "fence"},
    "fence_v": {"w": 0.375, "d": 2, "rise": 4, "style": "fence"},
}


def building(kind, variant=0):
    """Sprite for a BUILDINGS kind; drawn in pixel_fifties (the theme's building set)."""
    import pixel_fifties
    return pixel_fifties.build(kind, variant)


def _bld(kind):
    return lambda v=0: building(kind, v)


def bench(variant=0):
    """Park bench: teal slats on cast-iron ends."""
    c = Canvas(16, 9)
    c.rect(1, 0, 15, 2, C["f_bench"])                 # backrest
    c.rect(1, 0, 15, 1, C["f_bench_l"])
    c.rect(1, 3, 15, 6, C["f_bench"])                 # seat
    c.rect(1, 3, 15, 4, C["f_bench_l"])
    c.rect(1, 5, 15, 6, C["f_bench_d"])
    c.rect(1, 6, 15, 7, C["f_iron"])
    for x in (2, 12):                                 # iron legs + arm ends
        c.rect(x, 7, x + 2, 9, C["f_iron"])
        c.rect(x, 0, x + 1, 6, C["f_iron"])
    c.outline("ink")
    return c


def flowers(variant=0):
    """Flower bed: leafy mound in a low brick edging, Kodachrome blooms."""
    rnd = random.Random(700 + variant)
    c = Canvas(14, 9)
    colors = ramp("f_leaf1", "f_leaf2", "f_leaf3", "f_leaf4")
    c.shade_ellipse(7, 4.6, 5.5, 3.0, colors)
    for x in range(2, 12):
        c.px(x, 7, "roof_red" if x % 3 else "roof_red_d")
    blooms = [["f_cherry", "f_cream", "lit"], ["f_pink", "f_cream", "f_mint_l"], ["lit_l", "f_cherry_l", "f_cream"]][variant % 3]
    for _ in range(8):
        x, y = rnd.randint(3, 10), rnd.randint(2, 6)
        c.px(x, y, rnd.choice(blooms))
    c.outline("f_leaf0")
    return c


# kind -> sprite builders.
#   solid      has a collision circle (decor like bushes does not)
#   fp_rows    how many of the sprite's lowest opaque rows define its footprint
#              (3 = a trunk's base; half the sprite for a wide prop like a rock)
#   crown_rise how many native px the crown's bottom edge sits above the
#              trunk's bottom edge
OBJECTS = {
    "oak":   {"base": oak_trunk,  "crown": oak_crown,  "variants": 3, "solid": True, "fp_rows": 3, "crown_rise": 8},
    "pine":  {"base": pine_trunk, "crown": pine_crown, "variants": 2, "solid": True, "fp_rows": 3, "crown_rise": 7},
    "dead":  {"base": dead_tree,  "crown": None,       "variants": 2, "solid": True, "fp_rows": 3},
    "rock":  {"base": rock,       "crown": None,       "variants": 2, "solid": True, "fp_rows": 6},
    "bush":  {"base": bush,       "crown": None,       "variants": 4, "solid": False, "fp_rows": 3},
    "grave": {"base": gravestone, "crown": None,       "variants": 1, "solid": True, "fp_rows": 4},
    "crate": {"base": crate,      "crown": None,       "variants": 1, "solid": True, "fp_rows": 7},
    "barrel": {"base": barrel,    "crown": None,       "variants": 2, "solid": True, "fp_rows": 6},
    "hay":   {"base": haybale,    "crown": None,       "variants": 1, "solid": True, "fp_rows": 6},
    "well":  {"base": well,       "crown": None,       "variants": 1, "solid": True, "fp_rows": 9},
    "lamp":  {"base": lamp,       "crown": None,       "variants": 1, "solid": True, "fp_rows": 2},
    "scarecrow": {"base": scarecrow, "crown": None,    "variants": 1, "solid": True, "fp_rows": 3},
    "haystack": {"base": haystack, "crown": None,      "variants": 1, "solid": True, "fp_rows": 5},
    "cross": {"base": grave_cross, "crown": None,      "variants": 1, "solid": True, "fp_rows": 4},
    "bench": {"base": bench,      "crown": None,       "variants": 1, "solid": True, "fp_rows": 6},
    "flowers": {"base": flowers,  "crown": None,       "variants": 3, "solid": False, "fp_rows": 3},
}
# buildings: footprint is a rectangle of `tiles` (see BUILDINGS), not a circle
for _k, _b in BUILDINGS.items():
    OBJECTS[_k] = {"base": _bld(_k), "crown": None, "variants": 4, "solid": False,
                   "building": True, "tiles": (_b["w"], _b["d"])}


def _bounds(c):
    """(top, bottom, left, right) of the opaque pixels, bottom/right exclusive."""
    rows = [y for y in range(c.h) if any(p is not None for p in c.p[y])]
    cols = [x for x in range(c.w) if any(c.p[y][x] is not None for y in range(c.h))]
    return rows[0], rows[-1] + 1, cols[0], cols[-1] + 1


def footprint(kind, variant):
    """Collision circle measured from the art itself: the opaque width of the
    base sprite's lowest rows (minus the 1px outline on each side) is the
    circle's diameter, and the circle's bottom touches the sprite's bottom
    edge. Returns radius in native px, and the centre's x within the sprite."""
    spec = OBJECTS[kind]
    v = variant % spec["variants"]

    def build():
        c = spec["base"](v)
        top, bottom, _l, _r = _bounds(c)
        xs = []
        for y in range(max(top, bottom - spec["fp_rows"]), bottom):
            xs += [x for x in range(c.w) if c.p[y][x] is not None]
        left, right = min(xs), max(xs) + 1
        return {"r": max(2.0, (right - left - 2) / 2.0), "cx": (left + right) / 2.0}
    return _cached(("fp", kind, v), build)


# ---------------------------------------------------------------------------
# ground
# ---------------------------------------------------------------------------

_BIOME_STYLE = {
    "forest":    {"base": ("f_grass0", "f_grass1", "f_grass2", "f_grass3", "f_grass4"), "tuft": "f_grass4", "fleck": "f_litter"},
    "road":      {"base": ("f_mead0", "f_mead1", "f_mead2", "f_mead3", "f_mead4"), "tuft": "f_mead4", "fleck": "f_dirt3"},
    "outskirts": {"base": ("f_mead0", "f_mead1", "f_mead2", "f_mead3", "f_mead4"), "tuft": "f_mead4", "fleck": "f_hay_d"},
    "village":   {"base": ("f_mead0", "f_mead1", "f_mead2", "f_mead3", "f_mead4"), "tuft": "f_lawn4", "fleck": "f_dirt3"},
    "town":      {"base": ("f_asph0", "f_asph1", "f_asph2", "f_asph3", "f_asph4"), "tuft": "f_asph4", "fleck": "f_asph0"},
}

# ground ramps (dark -> light)
_ASPH = ramp("f_asph0", "f_asph1", "f_asph2", "f_asph3", "f_asph4")
_CONC = ramp("f_conc0", "f_conc1", "f_conc2", "f_conc3", "f_conc4")
_LAWN = ramp("f_lawn0", "f_lawn1", "f_lawn2", "f_lawn3", "f_lawn4")
_CORN = ramp("f_corn0", "f_corn1", "f_corn2", "f_corn3", "f_corn4")


class _Noise(object):
    """Smooth value noise on a lattice, seeded."""

    def __init__(self, seed, cell, gw, gh):
        rnd = random.Random(seed)
        self.cell = float(cell)
        self.g = [[rnd.random() for _ in range(gw + 2)] for _ in range(gh + 2)]
        self._w = None

    def at(self, x, y):
        fx, fy = x / self.cell, y / self.cell
        ix, iy = int(fx), int(fy)
        tx, ty = fx - ix, fy - iy
        tx = tx * tx * (3 - 2 * tx)
        ty = ty * ty * (3 - 2 * ty)
        g = self.g
        a = g[iy][ix] * (1 - tx) + g[iy][ix + 1] * tx
        b = g[iy + 1][ix] * (1 - tx) + g[iy + 1][ix + 1] * tx
        return a * (1 - ty) + b * ty

    def row(self, y, x0, n):
        """at(x, y) for x in x0 .. x0+n-1, as a list (the same values, much
        faster: the lattice is blended in y once per row, then each lattice
        cell is a straight ramp whose smoothstep weights are precomputed)."""
        cell = int(self.cell)
        w = self._w
        if w is None:
            w = self._w = [(i / float(cell)) ** 2 * (3.0 - 2.0 * i / float(cell)) for i in range(cell)]
        fy = y / self.cell
        iy = int(fy)
        ty = fy - iy
        ty = ty * ty * (3 - 2 * ty)
        a = [p * (1.0 - ty) + q * ty for p, q in zip(self.g[iy], self.g[iy + 1])]
        c0, c1 = x0 // cell, (x0 + n - 1) // cell
        out = []
        for ci in range(c0, c1 + 1):
            lo = a[ci]
            d = a[ci + 1] - lo
            out += [lo + d * t for t in w]
        k = x0 - c0 * cell
        return out[k:k + n]


def _zone_color(code, x, y, v, seed, rand, mead, dirt, cob):
    """Colour of one pixel in a structured-map zone (see hunt_mapgen layouts):
    g grass, d gravel/dirt path, y mowed lawn, s asphalt street, p concrete
    slabs, f ploughed furrows, w corn rows. `cob` is the asphalt ramp."""
    if code == "g":
        return mead[max(0, min(4, int(v * 5.0)))]
    if code == "d":
        col = dirt[max(1, min(4, int(v * 5.0) + 1))]
        r = rand()
        return C["f_stone3"] if r > 0.975 else (C["f_stone2"] if r > 0.95 else col)
    if code == "f":                                    # ploughed: dark furrows, lit ridges
        band = y % 4
        if band == 0:
            col = dirt[3] if v > 0.5 else dirt[2]
            if x % 3 == 0 and _hash(x, y, seed + 5) > 0.7:
                return C["f_corn1"]
            return col
        if band == 3:
            return dirt[0]
        return dirt[2] if (band == 1 and v > 0.55) else dirt[1]
    if code == "w":                                    # corn: vertical rows of green-gold plants
        ph = x % 5
        h = _hash(x, y, seed + 6)
        if ph == 4:
            return C["f_dirt0"] if h > 0.25 else _CORN[1]
        if ph == 3:
            return _CORN[1] if h > 0.45 else C["f_dirt1"]
        if v < 0.28 and h < 0.5:
            return C["f_dirt2"]
        i = 3 - ph                                     # lit from the left
        if (y + x // 5 * 3) % 4 == 0:
            i += 1                                     # leaf highlights
        if h > 0.95 and ph < 2:
            i = 4                                      # golden tassels / husks
        return _CORN[max(0, min(4, i))]
    if code == "y":
        return _LAWN[max(0, min(3, int(v * 4.0)))]
    if code == "p":                                    # concrete slabs with joints
        if x % 16 == 15 or y % 16 == 15:
            return _CONC[1]
        shade = _hash(x // 16, y // 16, seed + 33)
        i = 2 + (1 if shade > 0.55 else 0)
        h = _hash(x, y, seed + 34)
        if h > 0.93:
            i += 1 if shade > 0.3 else -1
        if x % 16 == 0 or y % 16 == 0:
            i = min(4, i + 1)
        return _CONC[max(0, min(4, i))]
    return _cobble(x, y, seed, cob, v)


_HARD_VARIANTS = 24


def _hard_tiles(seed, cob):
    """Pre-drawn 16x16 tiles of asphalt ('s', with hairline cracks, oil stains
    and repair patches on some variants) and concrete slabs ('p'); whole tiles
    are copied into the map."""
    out = {"s": [], "p": []}
    for k in range(_HARD_VARIANTS):
        sd = seed + 977 * k
        rnd = random.Random(sd)
        t = [[_cobble(x, y, sd, cob, 0.5) for x in range(16)] for y in range(16)]
        if k % 4 == 1:                                 # repair patch
            x0, y0 = rnd.randint(1, 7), rnd.randint(1, 7)
            w, h = rnd.randint(4, 8), rnd.randint(3, 7)
            for y in range(y0, min(16, y0 + h)):
                for x in range(x0, min(16, x0 + w)):
                    t[y][x] = cob[3] if _hash(x, y, sd) > 0.3 else cob[2]
        if k % 3 == 0:                                 # hairline crack
            x, y = rnd.randint(2, 13), rnd.randint(2, 13)
            dx, dy = rnd.choice((-1, 1)), rnd.choice((-1, 1))
            for _ in range(rnd.randint(5, 11)):
                if 0 <= x < 16 and 0 <= y < 16:
                    t[y][x] = cob[0]
                if rnd.random() < 0.5:
                    x += dx
                else:
                    y += dy
        if k % 5 == 2:                                 # oil stain
            cx, cy = rnd.uniform(4, 12), rnd.uniform(4, 12)
            for y in range(16):
                for x in range(16):
                    dd = ((x + 0.5 - cx) / 2.6) ** 2 + ((y + 0.5 - cy) / 1.8) ** 2
                    if dd < 1.0 and _hash(x, y, sd + 1) > 0.25:
                        t[y][x] = cob[0] if dd < 0.45 else cob[1]
        out["s"].append(t)
        out["p"].append([[_zone_color("p", x, y, 0.5, sd, None, None, None, cob) for x in range(16)] for y in range(16)])
    return out


def _lut(colors, scale, lo):
    """Colour lookup for int(v * 5 + 5): v in [-1, 2) -> colour index
    clamp(int(v * scale) + lo, 0, len(colors) - 1)."""
    n = len(colors)
    out = []
    for j in range(15):
        v = (j - 5) / 5.0
        out.append(colors[max(0, min(n - 1, int(v * scale) + lo))])
    return out


def _render_zones(game_map):
    """Ground for the structured biomes: a tile grid of zone codes (see
    hunt_mapgen) painted with per-zone texture, concrete curbs where asphalt or
    slabs meet soft ground, and a ragged blend where soft zones meet.

    Fast path: each 16x16 tile is filled in one go (asphalt/slab tiles are
    copied from pre-drawn variants; grass/dirt/lawn rows come from a colour
    lookup over the noise, lawn alternating light/dark mowing stripes per
    tile column), then only the 2px border bands that face a different zone
    get the per-pixel curb / ragged-edge treatment."""
    grid = game_map["grid"]
    if game_map.get("biome") in ("village", "town"):
        # Main Street / Fort Dalton: paths are paved -- 'd' renders as asphalt
        # with concrete curbs (gravel/dirt stays in the other biomes)
        grid = [row.replace("d", "s") for row in grid]
    tw, th = game_map["tiles_w"], game_map["tiles_h"]
    W, H = tw * TILE_PX, th * TILE_PX
    seed = game_map["seed"]
    c = Canvas(W, H)
    big = _Noise(seed, 40, W // 40 + 2, H // 40 + 2)
    small = _Noise(seed + 1, 9, W // 9 + 2, H // 9 + 2)
    mead = ramp("f_mead0", "f_mead1", "f_mead2", "f_mead3", "f_mead4")
    dirt = ramp("f_dirt0", "f_dirt1", "f_dirt2", "f_dirt3", "f_dirt4")
    cob = _ASPH
    conc = _CONC
    rnd = random.Random(seed + 4)
    rand = rnd.random
    hard = "sp"
    tiles = _hard_tiles(seed, cob)
    # per-code lookups: ((lut for even tile columns, lut for odd), speckle probability, speckle colour)
    g_lut = _lut(mead, 5.0, 0)
    d_lut = _lut(dirt, 5.0, 1)
    fast = {"g": ((g_lut, g_lut), 0.0, None),
            "d": ((d_lut, d_lut), 0.04, C["f_stone2"]),
            "y": ((_lut(_LAWN[:4], 4.0, 0), _lut(_LAWN[1:], 4.0, 0)), 0.01, C["f_lawn4"])}
    # ordered dither + white noise (centred), as 16 prebuilt rows per y&3 phase:
    # a row's pattern is picked by y, so no per-pixel random calls in the hot loop
    grain = [[((_B4[k & 3][x & 3] + 0.5) / 16.0 - 0.5) * 0.16 + rand() * 0.1 - 0.05 for x in range(W)]
             for k in range(64)]

    def neighbours(tx, ty):
        row = grid[ty]
        z = row[tx]
        return (row[tx - 1] if tx > 0 else z, row[tx + 1] if tx < tw - 1 else z,
                grid[ty - 1][tx] if ty > 0 else z, grid[ty + 1][tx] if ty < th - 1 else z)

    for ty in range(th):
        row = grid[ty]
        for gy in range(16):
            y = ty * 16 + gy
            prow = c.p[y]
            tx = 0
            while tx < tw:
                z = row[tx]
                if z in hard:
                    prow[tx * 16:tx * 16 + 16] = tiles[z][int(_hash(tx, ty, seed + 55) * _HARD_VARIANTS)][gy]
                    tx += 1
                    continue
                # a run of soft tiles: one noise row for the lot
                t1 = tx
                while t1 < tw and row[t1] not in hard:
                    t1 += 1
                x0, n = tx * 16, (t1 - tx) * 16
                b = big.row(y, x0, n)
                sm = small.row(y, x0, n)
                d = grain[(y & 3) + 4 * ((y * 7 >> 2) % 16)][x0:x0 + n]
                v = [0.55 * p_ + 0.45 * q_ + e_ for p_, q_, e_ in zip(b, sm, d)]
                for t in range(tx, t1):
                    z = row[t]
                    seg = v[(t - tx) * 16:(t - tx) * 16 + 16]
                    if z in fast:
                        luts, prob, spec = fast[z]
                        lut = luts[t & 1]
                        if prob:
                            prow[t * 16:t * 16 + 16] = [spec if rand() < prob else lut[int(vv * 5.0 + 5.0)] for vv in seg]
                        else:
                            prow[t * 16:t * 16 + 16] = [lut[int(vv * 5.0 + 5.0)] for vv in seg]
                    else:
                        for i in range(16):
                            prow[t * 16 + i] = _zone_color(z, t * 16 + i, y, seg[i], seed, rand, mead, dirt, cob)
                tx = t1

    # borders facing a different zone: curbs on hard zones, ragged blend on soft ones
    curb_hi, curb_lo = conc[4], conc[2]
    for ty in range(th):
        row = grid[ty]
        for tx in range(tw):
            z = row[tx]
            left, right, up, down = neighbours(tx, ty)
            if left == z and right == z and up == z and down == z:
                continue
            x0, y0 = tx * 16, ty * 16
            for gy in range(16):
                for gx in range(16):
                    if 2 <= gx <= 13 and 2 <= gy <= 13:
                        continue
                    nz = z
                    if gx < 2:
                        nz = left
                    elif gx > 13:
                        nz = right
                    if nz == z:
                        if gy < 2:
                            nz = up
                        elif gy > 13:
                            nz = down
                    if nz == z:
                        continue
                    x, y = x0 + gx, y0 + gy
                    if z in hard and nz not in hard:
                        c.p[y][x] = curb_hi if (gx == 0 or gx == 15 or gy == 0 or gy == 15) else curb_lo
                    elif z not in hard and nz not in hard and rand() < 0.4:
                        v = 0.55 * big.at(x, y) + 0.45 * small.at(x, y) + grain[y & 3][x]
                        c.p[y][x] = _zone_color(nz, x, y, v, seed, rand, mead, dirt, cob)

    rnd = random.Random(seed + 3)
    tuft = C["f_mead4"]
    lawn_t = C["f_lawn4"]
    for _ in range((W * H) // 140):
        x, y = rnd.randint(1, W - 3), rnd.randint(1, H - 3)
        z = grid[y >> 4][x >> 4]
        if z == "g" or z == "y":
            t_ = tuft if z == "g" else lawn_t
            c.px(x, y, t_)
            c.px(x - 1, y - 1, t_)
            c.px(x + 1, y - 1, t_)
        elif z in hard and rnd.random() < 0.4:
            c.px(x, y, cob[0] if z == "s" else conc[1])
    _light_pools(c, game_map)
    return c


def render_ground(game_map):
    """Paint the whole arena floor. Deterministic for a given map dict.
    Free-scatter biomes: night woods grass (forest); night meadow with a
    cracked asphalt road, gravel shoulders and a dashed yellow centre line
    (road). Structured biomes go through _render_zones."""
    if game_map.get("grid"):
        return _render_zones(game_map)
    biome = game_map["biome"]
    style = _BIOME_STYLE[biome]
    base = ramp(*style["base"])
    tw, th = game_map["tiles_w"], game_map["tiles_h"]
    W, H = tw * TILE_PX, th * TILE_PX
    seed = game_map["seed"]
    road = game_map.get("road")
    c = Canvas(W, H)
    # lattices cover the arena plus the 70px offset the road sampling uses
    big = _Noise(seed, 40, (W + 80) // 40 + 1, (H + 80) // 40 + 1)
    small = _Noise(seed + 1, 9, (W + 80) // 9 + 1, (H + 80) // 9 + 1)
    field = _Noise(seed + 2, 90, W // 90 + 1, H // 90 + 1)
    dirt = ramp("f_dirt1", "f_dirt2", "f_dirt3", "f_dirt3", "f_dirt4")
    asph = _ASPH
    world_per_px = hunt_mapgen.TILE / float(TILE_PX)

    rnd_px = random.Random(seed + 4)        # per-pixel grain (deterministic per map)
    rand = rnd_px.random
    road_y = None
    if road is not None:
        road_y = [hunt_mapgen.road_center(road, x * world_per_px) for x in range(W)]
        road_half = road["half"]
        asph_half = road_half - 12.0
        line_half = 3.0                                     # world px either side of the centreline
        # perpendicular-distance factor and arc length per column, for an even
        # road width and evenly spaced dashes on the curves
        road_k, dash = [], []
        arc = 0.0
        for x in range(W):
            s = (road_y[min(W - 1, x + 1)] - road_y[max(0, x - 1)]) / (2.0 * world_per_px) if W > 1 else 0.0
            k = 1.0 / math.sqrt(1.0 + s * s)
            road_k.append(k)
            arc += 1.0 / k
            dash.append(int(arc / 6.0) % 2 == 0)
        line_c, line_d = C["f_line"], C["f_line_d"]
        pebble = C["f_stone2"]
        # rows each column's road band can touch, so the road pass below only
        # visits pixels near the road
        road_rows = [[] for _ in range(H)]
        for x in range(W):
            reach = (road_half + 16.0) / road_k[x] / world_per_px
            cy = road_y[x] / world_per_px
            for y in range(max(0, int(cy - reach)), min(H, int(cy + reach) + 2)):
                road_rows[y].append(x)
    for y in range(H):
        bigrow = big.row(y, 0, W)
        smallrow = small.row(y, 0, W)
        fieldrow = field.row(y, 0, W) if biome in ("outskirts", "village") else None
        if road is not None:
            dirt_big = big.row(y, 70, W)               # offset samples for the road surface
            dirt_small = small.row(y + 70, 0, W)
        brow = _B4[y & 3]
        prow = c.p[y]
        wy = y * world_per_px
        for x in range(W):
            v = 0.55 * bigrow[x] + 0.45 * smallrow[x]
            v += ((brow[x & 3] + 0.5) / 16.0 - 0.5) * 0.16 + (rand() - 0.5) * 0.10
            col = base[max(0, min(4, int(v * 5.0)))]

            if fieldrow is not None and biome == "outskirts" and fieldrow[x] > 0.58:
                col = _zone_color("f", x, y, v, seed, rand, base, ramp("f_dirt0", "f_dirt1", "f_dirt2", "f_dirt3", "f_dirt4"), asph)
            elif fieldrow is not None and biome == "village" and fieldrow[x] > 0.60:
                col = _zone_color("p", x, y, v, seed, rand, base, dirt, asph)
            elif biome == "town":
                col = _cobble(x, y, seed, asph, v)
            prow[x] = col

        if road_y is not None:
            for x in road_rows[y]:
                d = abs(wy - road_y[x]) * road_k[x]
                if d < asph_half:
                    ds = dirt_small[x]
                    if -0.012 < ds - 0.5 < 0.012 or -0.008 < dirt_big[x] - 0.62 < 0.008:
                        prow[x] = asph[0]              # hairline cracks
                    elif d < line_half and dash[x]:
                        prow[x] = line_d if rand() < 0.12 else line_c
                    else:
                        dv = 0.5 * dirt_big[x] + 0.5 * ds + (rand() - 0.5) * 0.25
                        prow[x] = asph[max(1, min(3, int(dv * 4.0)))]
                elif d < road_half + (rand() - 0.5) * 30.0:
                    dv = 0.5 * dirt_big[x] + 0.5 * dirt_small[x] + (rand() - 0.5) * 0.3
                    prow[x] = pebble if rand() > 0.94 else dirt[max(0, min(3, int(dv * 4.0)))]

    # tufts and flecks scattered on top (not on the asphalt)
    rnd = random.Random(seed + 3)
    tuft = C[style["tuft"]]
    fleck = C[style["fleck"]]
    count = (W * H) // 120
    for _ in range(count):
        x, y = rnd.randint(1, W - 3), rnd.randint(1, H - 3)
        if biome == "town":
            if rnd.random() < 0.5:
                c.px(x, y, fleck)
            continue
        if road_y is not None and abs(y * world_per_px - road_y[x]) * road_k[x] < road_half + 6.0:
            rnd.random()
            continue
        if rnd.random() < 0.6:
            c.px(x, y, tuft)
            c.px(x - 1, y - 1, tuft)
            c.px(x + 1, y - 1, tuft)
        else:
            c.px(x, y, fleck)
    _light_pools(c, game_map)
    return c


_POOL_RGB = (255, 196, 110)


def _light_pools(c, game_map):
    """Warm amber pools of light on the ground under every street lamp (drawn
    into the ground, not the lamp sprite, so collision footprints are not
    touched). Banded with a Bayer dither so it stays pixel art."""
    k = TILE_PX / float(hunt_mapgen.TILE)
    ar, ag, ab = _POOL_RGB
    rx, ry = 16.0, 8.5
    mixed = {}
    for o in game_map.get("objects", ()):
        if o.get("kind") != "lamp":
            continue
        cx = o["x"] * k + 5.0                 # under the lamp head (arm reaches right)
        cy = o["y"] * k + 1.5
        for y in range(int(cy - ry), int(cy + ry) + 2):
            if not 0 <= y < c.h:
                continue
            row = c.p[y]
            b = _B4[y & 3]
            ny = (y + 0.5 - cy) / ry
            for x in range(int(cx - rx), int(cx + rx) + 2):
                if not 0 <= x < c.w:
                    continue
                nx = (x + 0.5 - cx) / rx
                d2 = nx * nx + ny * ny
                if d2 >= 1.0:
                    continue
                s = 0.50 * (1.0 - d2) + ((b[x & 3] + 0.5) / 16.0 - 0.5) * 0.10
                q = int(s / 0.07)                 # quantised -> visible bands
                if q <= 0 or row[x] is None:
                    continue
                key = (row[x], q)
                col = mixed.get(key)
                if col is None:
                    f = q * 0.07
                    p0 = row[x]
                    col = (int(p0[0] + (ar - p0[0]) * f), int(p0[1] + (ag - p0[1]) * f),
                           int(p0[2] + (ab - p0[2]) * f), 255)
                    mixed[key] = col
                row[x] = col


def _cobble(x, y, seed, cob, v):
    """(Legacy name.) Asphalt grain over the ramp `cob`: mostly mid tones with
    darker pores and the odd bright aggregate chip."""
    h = _hash(x, y, seed + 21)
    if h > 0.975:
        return cob[4]
    i = 2
    if h < 0.22:
        i = 1
    elif h > 0.8:
        i = 3
    if v < 0.35 and h < 0.5:
        i -= 1
    return cob[max(0, i)]


# ---------------------------------------------------------------------------
# cache: (name, variant, scale, flip) -> png bytes
# ---------------------------------------------------------------------------

_cache = {}


def _cached(key, build):
    v = _cache.get(key)
    if v is None:
        v = build()
        _cache[key] = v
    return v


def character_canvas(kind, facing, tier=0):
    flip = facing == "left"
    face = "side" if facing in ("left", "right") else facing
    if kind == "vampire":
        c = vampire(face, tier)
    elif kind == "hunter":
        c = hunter(face)
    else:
        c = prey(tier)
    return c.flipped() if flip else c


def character_png(kind, facing, scale, tier=0, flash=False):
    """flash=True gives a solid-white silhouette (hit/feed flash frame)."""
    def build():
        c = character_canvas(kind, facing, tier)
        if flash:
            for row in c.p:
                for x, px in enumerate(row):
                    if px is not None:
                        row[x] = (255, 255, 255, px[3] if len(px) > 3 else 255)
        return c.png(scale)
    return _cached(("char", kind, facing, tier, scale, flash), build)


def object_canvas(kind, variant, layer):
    spec = OBJECTS[kind]
    fn = spec[layer]
    if fn is None:
        return None
    return fn(variant % spec["variants"])


def object_layout(kind, variant, layer):
    """(canvas, off_x, off_y, foot) or None when this kind has no sprite on
    that layer. off_x/off_y are native px from the object's collision-circle
    centre to the sprite's top-left corner; foot is the native y of the
    trunk's bottom edge relative to that centre (the depth-sort line)."""
    spec = OBJECTS[kind]
    v = variant % spec["variants"]

    def build():
        c = object_canvas(kind, v, layer)
        if c is None:
            return None
        if spec.get("building"):
            fd = spec["tiles"][1] * TILE_PX
            return (c, -c.w / 2.0, fd / 2.0 - (c.h - 1), fd / 2.0)
        fp = footprint(kind, v)
        foot = fp["r"]                 # circle bottom == trunk bottom edge
        top, bottom, left, right = _bounds(c)
        if layer == "base":
            return (c, -fp["cx"], foot - bottom, foot)
        return (c, -(left + right) / 2.0, foot - spec["crown_rise"] - bottom, foot)
    return _cached(("layout", kind, v, layer), build)


def object_sprite(kind, variant, layer, scale):
    """(png bytes, off_x, off_y, w, h, foot): object_layout plus the PNG
    baked at `scale` (native px * scale = screen px)."""
    lay = object_layout(kind, variant, layer)
    if lay is None:
        return None
    c, ox, oy, foot = lay
    spec = OBJECTS[kind]
    return _cached(("objpng", kind, variant % spec["variants"], layer, scale),
                   lambda: (c.png(scale), ox, oy, c.w, c.h, foot))


ARROW_BUCKETS = 16
_ARROW_COLORS = {"hunter": "red_l", 0: "f_cow_w", 1: "f_denim_l", 2: "f_mint", 3: "f_chrome", 4: "gold"}


def arrow(bucket, color):
    """9x9 pixel arrow pointing at angle bucket/16 of a turn (0 = east,
    clockwise, y down), for off-screen hunters and prey."""
    c = Canvas(11, 11)
    a = bucket * 2.0 * math.pi / ARROW_BUCKETS
    fx, fy = math.cos(a), math.sin(a)
    sx, sy = -fy, fx
    tip = (5.5 + fx * 4.2, 5.5 + fy * 4.2)
    b1 = (5.5 - fx * 2.6 + sx * 3.0, 5.5 - fy * 2.6 + sy * 3.0)
    b2 = (5.5 - fx * 2.6 - sx * 3.0, 5.5 - fy * 2.6 - sy * 3.0)

    def side(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])

    for y in range(11):
        for x in range(11):
            pt = (x + 0.5, y + 0.5)
            d1, d2, d3 = side(tip, b1, pt), side(b1, b2, pt), side(b2, tip, pt)
            if (d1 >= 0 and d2 >= 0 and d3 >= 0) or (d1 <= 0 and d2 <= 0 and d3 <= 0):
                c.px(x, y, color)
    c.outline("ink")
    return c


def arrow_png(bucket, who, scale):
    """who = "hunter" or a prey tier 0-4."""
    return _cached(("arrow", bucket, who, scale),
                   lambda: arrow(bucket, _ARROW_COLORS[who]).png(scale))


def ring_png(radius_native, scale):
    return _cached(("ring", int(radius_native), scale), lambda: lunge_ring(radius_native).png(scale))


def ground_png(game_map, scale):
    return render_ground(game_map).png(scale)
