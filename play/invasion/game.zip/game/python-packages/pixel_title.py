"""Full-screen pixel scenes for the menus: a 1950s B-movie night over a farm
for the main menu and a chrome-and-enamel diner wall for the game menu.
Both are 640x360 native pixels (scaled 3x to 1920x1080 by the caller).
No Ren'Py imports; deterministic.

    title_scene()   moon, stars, flying saucer with a green tractor beam over
                    a cornfield with a crop circle; barn, silo, water tower and
                    a farmhouse with lit windows on the horizon
    brick_wall()    (name kept for callers) a 1950s diner wall: formica
                    pattern, chrome rail, ribbed teal enamel wainscot
"""

import math
import random

from pixel_art import Canvas, _B4, _rgb
import pixel_ui

W, H = 640, 360


def _c(h):
    return _rgb(h)


SKY = ["#03050c", "#050912", "#070d19", "#0a1221", "#0d1829", "#111f31", "#152839", "#1b3341", "#22404a"]
HORIZON = 246
SIL = _c("#050a10")                     # silhouette
NEON = _c("#8dff5a")
SAUCER = (350, 112)


class _Cv(Canvas):
    """Canvas that also takes "#rrggbb" strings, so the scene can use colours
    outside the shared palette."""

    def px(self, x, y, c):
        if isinstance(c, str) and c.startswith("#"):
            c = _rgb(c)
        Canvas.px(self, x, y, c)


def _bayer(x, y):
    return (_B4[y & 3][x & 3] + 0.5) / 16.0


def _mix(a, b, t):
    return (int(a[0] + (b[0] - a[0]) * t), int(a[1] + (b[1] - a[1]) * t), int(a[2] + (b[2] - a[2]) * t), 255)


def _blend(c, x, y, col, t, steps=5):
    """Posterised, Bayer-dithered blend of col over the pixel (keeps the pixel-art feel)."""
    if not (0 <= x < W and 0 <= y < H) or t <= 0:
        return
    t = min(1.0, t)
    lv = t * steps
    i = int(lv)
    if lv - i > _bayer(x, y):
        i += 1
    if i:
        c.p[y][x] = _mix(c.p[y][x], col, i / float(steps))


def _sky(c):
    n = len(SKY) - 1
    for y in range(HORIZON + 1):
        t = (y / float(HORIZON)) ** 1.3 * n
        i = int(t)
        f = t - i
        for x in range(W):
            idx = i + (1 if (i < n and f > _bayer(x, y)) else 0)
            c.p[y][x] = _c(SKY[idx])


def _moon(c, cx, cy, r):
    halo = r * 2.6
    for y in range(int(cy - halo), int(cy + halo) + 1):
        for x in range(int(cx - halo), int(cx + halo) + 1):
            d = math.hypot(x - cx, y - cy)
            if r < d < halo and 0 <= y <= HORIZON:
                p = (1.0 - (d - r) / (halo - r)) ** 2 * 0.9
                if p > _bayer(x, y):
                    c.px(x, y, "#1f3a4c" if d < r * 1.45 else "#152a3a")
    disc = [_c(h) for h in ("#a9b49e", "#cfd3bc", "#e9e6d0", "#f8f4e4")]
    c.shade_ellipse(cx, cy, r, r, disc, light=(-0.5, -0.6), dither=0.7)
    for ox, oy, rr in ((-8, -5, 5), (7, 8, 6), (-3, 13, 3.5), (12, -11, 3), (-14, 8, 3), (2, -2, 2.5)):
        c.ellipse(cx + ox, cy + oy, rr, rr * 0.85, "#bcc2aa")
        c.ellipse(cx + ox - 1, cy + oy - 1, rr * 0.7, rr * 0.6, "#d6d8c2")


def _stars(c, rnd, moon):
    for _ in range(230):
        x, y = rnd.randrange(W), rnd.randrange(int(HORIZON * 0.8))
        if math.hypot(x - moon[0], y - moon[1]) < moon[2] * 2.4:
            continue
        c.px(x, y, rnd.choice(("#e8f0e6", "#9fb4bc", "#5f7c86", "#e8f0e6", "#5f7c86")))
    for _ in range(11):
        x, y = rnd.randrange(170, W - 8), rnd.randrange(6, int(HORIZON * 0.55))
        if math.hypot(x - moon[0], y - moon[1]) < moon[2] * 2.4 or abs(x - SAUCER[0]) < 70 and abs(y - SAUCER[1]) < 30:
            continue
        for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
            c.px(x + dx, y + dy, "#f4f8ec" if (dx, dy) == (0, 0) else "#5f7c86")


def _ridge(c, fn, col, bottom=H, x0=0, x1=W):
    colour = _c(col) if isinstance(col, str) else col
    for x in range(x0, x1):
        for y in range(max(0, int(fn(x))), bottom):
            c.p[y][x] = colour


def _ground_y(x):
    return HORIZON + 2 + 1.5 * math.sin(x * 0.02)


def _field(c):
    """Cornfield rows converging on a vanishing point under the saucer."""
    vx, vy = 350.0, HORIZON - 8.0
    corn = [_c(h) for h in ("#0a1a12", "#0f2618", "#15331f", "#1c4127")]
    soil = _c("#070d0b")
    for y in range(HORIZON, H):
        depth = (y - HORIZON) / float(H - HORIZON)                # 0 far .. 1 near
        for x in range(W):
            if y < _ground_y(x):
                continue
            period = (y - vy) / 3.2                                # row spacing in px at this depth
            u = (x - vx) / period
            f = u - math.floor(u)
            row = f < 0.62
            if period < 6.0:                                       # too fine to resolve: dithered flat field
                k = depth * 2.6 + (_bayer(x, y) - 0.5) * 1.2
                c.p[y][x] = corn[max(0, min(3, int(k)))] if _bayer(x + 1, y) < 0.7 else soil
            elif row:
                k = depth * 2.6 + (0.6 if f < 0.18 else 0.0)             # moonlit side of each row
                k += (_bayer(x, y) - 0.5) * 0.9
                c.p[y][x] = corn[max(0, min(3, int(k)))]
            else:
                c.p[y][x] = soil
        if depth < 0.12:                                           # haze at the horizon
            for x in range(W):
                _blend(c, x, y, _c("#1b3341"), (0.12 - depth) / 0.12 * 0.7)


def _crop_circle(c, cx, cy, rx, ry):
    flat = _c("#3c5a33")
    flat_d = _c("#2a4426")
    for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
        for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
            d = math.hypot((x - cx) / rx, (y - cy) / ry)
            if d > 1.0:
                continue
            if d < 0.28 or 0.46 < d < 0.62 or 0.86 < d <= 1.0:
                c.px(x, y, flat if (x + y * 3) % 7 else flat_d)
    for a in (0.6, 2.4, 4.0):                                      # satellite circles
        sx, sy = cx + math.cos(a) * rx * 1.35, cy + math.sin(a) * ry * 1.35
        c.ellipse(sx, sy, rx * 0.13, ry * 0.13, flat)


def _farmhouse(c, cx, base):
    w, h = 34, 16
    x0 = cx - w // 2
    c.rect(x0, base - h, x0 + w, base + 1, SIL)
    for i in range(13):                                            # gabled roof
        half = (w / 2.0 + 2) * (1.0 - i / 13.0)
        c.rect(int(cx - half), base - h - i - 1, int(cx + half) + 1, base - h - i, SIL)
    c.rect(cx + 7, base - h - 14, cx + 10, base - h - 4, SIL)      # chimney
    c.rect(x0 - 14, base - 8, x0, base + 1, SIL)                   # porch
    for i in range(5):
        c.rect(x0 - 16 + i, base - 9 - i, x0, base - 8 - i, SIL)
    lit = _c("#ffc65a")
    for wx, wy, on in ((x0 + 4, base - 12, True), (x0 + 13, base - 12, False), (x0 + 24, base - 12, True),
                       (x0 + 4, base - 5, True), (x0 + 24, base - 5, False), (cx - 1, base - h - 7, True)):
        if on:
            c.rect(wx, wy, wx + 4, wy + 4, lit)
            c.px(wx + 1, wy, "#fff0b0")
            c.rect(wx + 2, wy, wx + 3, wy + 4, _c("#b07a2a"))
            for gy in range(wy - 2, wy + 7):                       # window glow
                for gx in range(wx - 3, wx + 8):
                    if c.get(gx, gy) is not None and c.p[gy][gx] != lit:
                        _blend(c, gx, gy, lit, 0.12 * (1 - abs(gx - wx - 2) / 6.0))
        else:
            c.rect(wx, wy, wx + 4, wy + 4, _c("#3a2a18"))


def _barn(c, cx, base):
    w, wall_h = 46, 20
    x0 = cx - w // 2
    red, red_d, red_l = _c("#6e1c24"), _c("#4a1018"), _c("#8e2a30")
    roof = _c("#0b1218")
    for y in range(base - wall_h, base + 1):
        for x in range(x0, x0 + w):
            c.px(x, y, red_l if x < x0 + 3 else (red if (x - x0) % 4 else red_d))
    # gambrel roof
    for i in range(18):
        if i < 8:
            half = w / 2.0 + 2 - i * 0.4
        else:
            half = (w / 2.0 - 1.2) * (1.0 - (i - 8) / 10.0) + 3
        c.rect(int(cx - half), base - wall_h - i - 1, int(cx + half) + 1, base - wall_h - i, roof)
    for i in range(18):                                            # moonlit roof edge
        half = (w / 2.0 + 2 - i * 0.4) if i < 8 else ((w / 2.0 - 1.2) * (1.0 - (i - 8) / 10.0) + 3)
        c.px(int(cx + half), base - wall_h - i - 1, _c("#2a3c46"))
    trim = _c("#c9c0a8")
    dx0, dx1 = cx - 9, cx + 9                                      # big door with an X brace
    c.rect(dx0, base - 15, dx1, base + 1, red_d)
    for x in range(dx0, dx1):
        c.px(x, base - 15, trim)
    for y in range(base - 15, base + 1):
        c.px(dx0, y, trim)
        c.px(dx1 - 1, y, trim)
        c.px(cx, y, trim)
    for i in range(15):
        c.px(dx0 + int(i * 9 / 15.0), base - 15 + i, trim)
        c.px(cx - 1 - int(i * 9 / 15.0), base - 15 + i, trim)
        c.px(cx + int(i * 9 / 15.0), base - 15 + i, trim)
        c.px(dx1 - 1 - int(i * 9 / 15.0), base - 15 + i, trim)
    c.rect(cx - 3, base - wall_h - 12, cx + 3, base - wall_h - 5, _c("#2a0a10"))  # hayloft door
    for x in range(cx - 3, cx + 3):
        c.px(x, base - wall_h - 12, trim)
    # silo
    sx = x0 + w + 4
    c.rect(sx, base - 34, sx + 12, base + 1, _c("#1d2a30"))
    c.rect(sx, base - 34, sx + 2, base + 1, _c("#3a5560"))
    for yy in range(base - 30, base, 5):
        c.rect(sx, yy, sx + 12, yy + 1, _c("#141e24"))
    c.ellipse(sx + 6, base - 34, 6.5, 5, _c("#2a3c46"))
    c.ellipse(sx + 5, base - 36, 3, 2, _c("#5f7c86"))


def _water_tower(c, cx, base):
    leg = _c("#0a1218")
    top = base - 58
    for lx, tilt in ((-11, -3), (-4, -1), (4, 1), (11, 3)):
        for y in range(top + 14, base + 1):
            t = (y - top - 14) / float(base - top - 14)
            c.px(int(cx + lx * 0.8 + tilt * t * 2), y, leg)
    for yy in (top + 26, top + 40):                                # cross braces
        c.rect(cx - 12, yy, cx + 13, yy + 1, leg)
    c.rect(cx - 14, top, cx + 15, top + 15, _c("#1d2a30"))        # tank
    c.rect(cx - 14, top, cx - 11, top + 15, _c("#3a5560"))
    c.rect(cx - 11, top, cx - 10, top + 15, _c("#2a3c46"))
    for i in range(7):                                             # conical cap
        c.rect(cx - 15 + i * 2, top - i - 1, cx + 16 - i * 2, top - i, _c("#141e24"))
    c.px(cx, top - 8, "#ff4f5e")                                   # aircraft warning lamp
    c.px(cx, top - 9, "#ffa8b0")
    c.rect(cx - 14, top + 13, cx + 15, top + 15, leg)             # catwalk


def _poles(c, xs, base_fn):
    pole = _c("#081016")
    tops = []
    for x in xs:
        b = int(base_fn(x))
        top = b - 30
        c.rect(x, top, x + 1, b + 1, pole)
        c.rect(x - 4, top + 2, x + 5, top + 3, pole)
        tops.append((x, top + 2))
    for (x0, y0), (x1, y1) in zip(tops, tops[1:]):                 # sagging wires
        for x in range(x0, x1 + 1):
            t = (x - x0) / float(max(1, x1 - x0))
            y = y0 + (y1 - y0) * t + 5 * math.sin(math.pi * t)
            c.px(x, int(y), pole)
            c.px(x, int(y) + 2, pole)


def _treeline(c, rnd, x0, x1, base):
    x = x0
    while x < x1:
        w = rnd.randrange(8, 18)
        h = rnd.randrange(6, 14)
        c.ellipse(x + w / 2.0, base - h * 0.6, w / 2.0, h * 0.7, SIL)
        x += int(w * 0.7)


def _saucer(c, cx, cy):
    # faint glow behind
    for y in range(cy - 28, cy + 20):
        for x in range(cx - 80, cx + 81):
            d = math.hypot((x - cx) / 80.0, (y - cy) / 26.0)
            if d < 1.0:
                _blend(c, x, y, _c("#2f6a3a"), (1 - d) ** 2 * 0.35)
    # dome
    glass = [_c(h) for h in ("#123a46", "#1f6a78", "#4fb8c8", "#bff4ff")]
    for y in range(cy - 20, cy - 2):
        for x in range(cx - 20, cx + 21):
            nx, ny = (x + 0.5 - cx) / 19.0, (y + 0.5 - (cy - 4)) / 15.0
            if nx * nx + ny * ny <= 1.0:
                b = nx * -0.6 + ny * -0.7
                t = (b + 1) / 2.0 * 3 + (_bayer(x, y) - 0.5) * 0.8
                c.px(x, y, glass[max(0, min(3, int(t + 0.5)))])
    for x, y in ((cx - 9, cy - 15), (cx - 10, cy - 14), (cx - 11, cy - 12), (cx - 8, cy - 16)):
        c.px(x, y, "#f4fff8")
    c.ellipse(cx + 2, cy - 8, 2.4, 3.2, _c("#2a5a3a"))             # a shape at the controls
    c.ellipse(cx + 2, cy - 10, 3.0, 2.4, _c("#3f8a4a"))
    c.px(cx + 1, cy - 10, "#060e13")
    c.px(cx + 3, cy - 10, "#060e13")
    # hull
    hull = [_c(h) for h in ("#22343c", "#4a6670", "#8ea6ae", "#c8d8dc", "#eef6f6")]
    c.shade_ellipse(cx, cy, 56, 9, hull, light=(-0.2, -0.95), dither=0.6)
    for x in range(cx - 54, cx + 55):                              # rim seam
        dy = 9 * math.sqrt(max(0.0, 1 - ((x - cx) / 56.0) ** 2))
        c.px(x, int(cy + dy * 0.15), "#22343c")
    c.shade_ellipse(cx, cy + 6, 34, 5, [_c("#0e181e"), _c("#1d2a30"), _c("#3a5560")], light=(0, -1), dither=0.5)
    c.ellipse(cx, cy + 8, 13, 3.2, _c("#3a9a30"))                  # emitter
    c.ellipse(cx, cy + 8, 9, 2.2, NEON)
    c.ellipse(cx, cy + 8, 4, 1.2, _c("#e8ffd8"))
    lights = ("#8dff5a", "#ff4f5e", "#ffc65a")
    for i, lx in enumerate(range(cx - 48, cx + 49, 8)):            # rim lights
        dy = 9 * math.sqrt(max(0.0, 1 - ((lx - cx) / 56.0) ** 2))
        ly = int(cy + dy * 0.15) + 1
        col = lights[i % 3]
        c.rect(lx, ly, lx + 2, ly + 2, _c(col))
        c.px(lx, ly, "#ffffff")


def _beam(c, cx, top, bottom, rnd):
    w0, w1 = 12.0, 64.0
    for y in range(top, bottom + 1):
        t = (y - top) / float(bottom - top)
        half = w0 + (w1 - w0) * t
        for x in range(int(cx - half) - 1, int(cx + half) + 2):
            e = abs(x + 0.5 - cx) / half
            if e > 1.0:
                continue
            a = 0.22 + 0.32 * e ** 6 + 0.14 * (1 - t)
            if e > 0.94:
                a = 0.8
            _blend(c, x, y, NEON, a)
    for k in range(5):                                             # energy rings sliding down the beam
        yy = top + 18 + k * 34
        t = (yy - top) / float(bottom - top)
        half = w0 + (w1 - w0) * t
        for x in range(int(cx - half), int(cx + half) + 1):
            dy = 2.5 * math.sqrt(max(0.0, 1 - ((x - cx) / half) ** 2))
            _blend(c, x, int(yy + dy), _c("#d4ffbc"), 0.7)
    for _ in range(70):                                            # rising motes
        t = rnd.random()
        y = int(top + 8 + t * (bottom - top - 10))
        half = w0 + (w1 - w0) * (y - top) / float(bottom - top)
        x = int(cx + rnd.uniform(-0.85, 0.85) * half)
        c.px(x, y, "#d4ffbc" if rnd.random() < 0.6 else "#ffffff")
    for y in range(bottom - 16, min(H, bottom + 22)):              # glow pooled on the field
        for x in range(int(cx - 110), int(cx + 111)):
            d = math.hypot((x - cx) / 105.0, (y - bottom) / 20.0)
            if d < 1.0:
                _blend(c, x, y, NEON, (1 - d) ** 1.5 * 0.55)


def _cow(c, x, y):
    rows = ["....XX.........",
            "XXXXXXXXXXXXX.X",
            "XWWWXXXWWXXXXX.",
            "XXWWWXXXWWWXXX.",
            ".XXXXXXXXXXXX..",
            ".X.X......X.X..",
            ".X.X......X.X.."]
    pal = {"X": _c("#0c1410"), "W": _c("#c8d6c0")}
    cv = Canvas(len(rows[0]) + 2, len(rows) + 2)
    for yy, row in enumerate(rows):
        for xx, ch in enumerate(row):
            if ch in pal:
                cv.px(xx + 1, yy + 1, pal[ch])
    cv.outline(_c("#d4ffbc"))
    for yy in range(cv.h):                                         # tilted: shear as it is lifted
        for xx in range(cv.w):
            p = cv.p[yy][xx]
            if p is not None:
                c.px(x + xx, y + yy + xx // 5, p)


def _foreground_corn(c, rnd):
    base = H
    dark, lit = _c("#04080a"), _c("#17331f")
    glow = _c("#3fa24a")
    x = -4
    while x < W + 4:
        h = rnd.randrange(26, 52)
        top = base - h
        near_beam = abs(x - SAUCER[0]) < 120
        for y in range(top, base):
            c.px(x, y, dark)
            c.px(x + 1, y, dark)
        c.px(x, top, lit)
        for k in range(rnd.randrange(3, 6)):                       # leaves
            ly = top + 4 + k * rnd.randrange(5, 9)
            if ly >= base:
                break
            d = rnd.choice((-1, 1))
            ln = rnd.randrange(6, 13)
            for i in range(ln):
                lx = x + d * (i + 1)
                yy = ly + int((i * i) / 14.0) - (2 if i < 3 else 0)
                c.px(lx, yy, dark)
                c.px(lx, yy + 1, dark)
                if i < ln - 2:
                    c.px(lx, yy - 1, glow if near_beam and d < 0 else lit)
        if near_beam:
            c.px(x, top + 1, glow)
        x += rnd.randrange(4, 8)


def _vignette(c, edge=0.70, strength=0.9):
    for y in range(H):
        for x in range(W):
            d = max(abs(x - W / 2.0) / (W / 2.0), abs(y - H / 2.0) / (H / 2.0))
            if d > edge:
                k = (d - edge) / (1.0 - edge) * strength
                if k > _bayer(x, y):
                    r, g, b, a = c.p[y][x]
                    c.p[y][x] = (int(r * 0.45), int(g * 0.5), int(b * 0.55), a)


def title_scene(seed=7):
    rnd = random.Random(seed)
    c = _Cv(W, H)
    _sky(c)
    moon = (548, 66, 30)
    _moon(c, *moon)
    _stars(c, rnd, moon)
    _ridge(c, lambda x: 222 + 10 * math.sin(x * 0.018 + 1.0) + 5 * math.sin(x * 0.061), "#0c1822")
    _ridge(c, lambda x: 236 + 6 * math.sin(x * 0.013 + 3.0) + 3 * math.sin(x * 0.08), "#08121a")
    _treeline(c, rnd, 140, 250, HORIZON + 2)
    _treeline(c, rnd, 610, 650, HORIZON + 2)
    _field(c)
    _crop_circle(c, 350, 304, 92, 17)
    _farmhouse(c, 222, HORIZON + 2)
    _barn(c, 478, HORIZON + 3)
    _water_tower(c, 566, HORIZON + 2)
    _poles(c, (176, 262, 300, 410, 452), lambda x: HORIZON + 2)
    cx, cy = SAUCER
    _beam(c, cx, cy + 10, 304, rnd)
    _cow(c, cx - 4, 196)
    _saucer(c, cx, cy)
    _foreground_corn(c, rnd)
    _vignette(c)
    return c


def brick_wall():
    """Game-menu backdrop (name kept for callers): a 1950s diner wall -- formica pattern above,
    a polished chrome rail, ribbed teal enamel wainscot below, soft vignette."""
    tile = pixel_ui.bg_tile()
    c = Canvas(W, H)
    rail = 286
    for y in range(H):
        for x in range(W):
            c.p[y][x] = tile.p[y % tile.h][x % tile.w]
    chrome = ["#060e13", "#f6fcfc", "#c6d5d9", "#8ea5ab", "#566e75", "#8ea5ab", "#c6d5d9", "#566e75", "#24363c", "#060e13"]
    for i, col in enumerate(chrome):
        c.rect(0, rail + i, W, rail + i + 1, _c(col))
    for x in range(16, W, 64):                                     # rail brackets
        c.rect(x, rail + 2, x + 3, rail + 8, _c("#24363c"))
        c.px(x, rail + 2, _c("#f6fcfc"))
    c.rect(0, rail + 10, W, rail + 11, _c("#f4ecd8"))              # cream pinstripe
    for y in range(rail + 11, H):                                  # ribbed enamel wainscot
        for x in range(W):
            m = x % 8
            col = "#134a50" if m in (0, 1) else ("#0a2a2e" if m == 7 else "#0f3b40")
            c.p[y][x] = _c(col)
    for y in range(H):                                             # smooth radial falloff
        for x in range(W):
            d = math.hypot((x - W / 2.0) / (W / 2.0), (y - H / 2.0) / (H / 2.0))
            k = 1.0 - 0.5 * min(1.0, max(0.0, (d - 0.35) / 1.0)) ** 1.2
            r, g, b, a = c.p[y][x]
            c.p[y][x] = (int(r * k), int(g * k), int(b * k), a)
    return c


if __name__ == "__main__":
    import sys
    import time
    t0 = time.time()
    s = title_scene()
    b = brick_wall()
    ok = (s.w, s.h, b.w, b.h) == (W, H, W, H) and all(px is not None for row in s.p for px in row) and all(px is not None for row in b.p for px in row)
    ok = ok and title_scene().p == s.p
    print("title_scene/brick_wall: 640x360, fully opaque, deterministic: %s (%.1fs)" % ("PASS" if ok else "FAIL", time.time() - t0))
    if len(sys.argv) > 1:
        import os
        out = sys.argv[1]
        with open(os.path.join(out, "title_scene.png"), "wb") as f:
            f.write(s.png(3))
        with open(os.path.join(out, "game_menu_bg.png"), "wb") as f:
            f.write(b.png(3))
    sys.exit(0 if ok else 1)
