﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

init -1 python:
    # The typing blip gets its own channel, so it never cuts a game sound.
    renpy.music.register_channel("dev_blip", "sfx", False)

    def dev_blip_cb(event, interact=True, **kwargs):
        """Loops a short blip while the dev note types, and stops it when the line is complete."""
        if not interact:
            return
        if event == "show_done":
            renpy.music.play("audio/sfx_dev_blip.wav", channel="dev_blip", loop=True)
        elif event in ("slow_done", "end"):
            renpy.music.stop(channel="dev_blip")

define dev_note = Character("Dev note", color="#c9a24a", callback=dev_blip_cb, what_slow_cps=45)


# The game starts here.

label start:

    # a run that left the arcade section by the main menu must not start without rollback
    $ config.rollback_enabled = True

    scene black

    dev_note "Not a finished game. This is a prototype of a currency-acquisition engine: the loop that earns the money in an incremental game."

    dev_note "It is built to be reused. Crimson Wake is one skin, and Invasion runs on the same rules with new art and sound. I worked on the engine, not the polish."

    dev_note "You are a vampire. Prey is currency, hunters are the cost. Move with WASD or the arrow keys and feed on prey. Every feeding draws more hunters."

    dev_note "A run is one short night. Survive until sunrise for a bonus, then spend your blood at the Blood Market to grow stronger and unlock powers."

    # Hunt prototype entry point. Delete these two lines once the minigame is
    # called from the real story instead.
    call hunt_demo

    # This ends the game.

    return
