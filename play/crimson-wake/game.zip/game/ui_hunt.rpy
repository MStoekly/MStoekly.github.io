# Gothic-pixel UI kit for the hunt + shop screens. The art is drawn in code
# (game/python-packages/pixel_ui.py) and wrapped here; the screens themselves
# live in hunt.rpy (level select, loading, results) and shop.rpy (Blood Market).
#
# One native UI pixel = CW_UI_ZOOM screen pixels, always a whole number so the
# pixels stay square. Fonts (both SIL OFL, see game/fonts/): Pixelify Sans for
# text, Pirata One (blackletter) for titles.

init -1 python:
    import pixel_ui
    import pixel_art

    CW_FONT = "fonts/PixelifySans-Regular.ttf"
    CW_FONT_BOLD = "fonts/PixelifySans-Bold.ttf"
    CW_TITLE_FONT = "fonts/PirataOne-Regular.ttf"

    CW_GOLD = "#e8c04a"
    CW_TEXT = "#e8dcd0"
    CW_DIM = "#9a8f88"
    CW_BLOOD = "#ff5f6e"
    CW_LOCKED = "#6a6470"

    CW_UI_ZOOM = 3

    _cw_ui = {}

    def _cw_cached(key, make):
        d = _cw_ui.get(key)
        if d is None:
            d = make()
            _cw_ui[key] = d
        return d

    def cw_px(key, make_canvas, z=CW_UI_ZOOM):
        """A pixel_ui Canvas as an image, z screen px per art px."""
        name = "cw_ui_%s_x%d.png" % ("_".join(str(k) for k in key), z)
        return _cw_cached(("px", key, z), lambda: im.Data(make_canvas().png(z), name))

    def _cw_frame(key, make_canvas, border, tile=True):
        z = CW_UI_ZOOM
        return _cw_cached(("frame", key), lambda: Frame(cw_px(key, make_canvas), border * z, border * z, tile=tile))

    def cw_panel(kind="stone"):
        return _cw_frame(("panel", kind), lambda: pixel_ui.panel(kind), pixel_ui.PANEL_BORDER)

    def cw_card(kind="stone"):
        return _cw_frame(("card", kind), lambda: pixel_ui.card(kind), pixel_ui.CARD_BORDER)

    def cw_button_bg(state="idle"):
        return _cw_frame(("button", state), lambda: pixel_ui.button(state), pixel_ui.BUTTON_BORDER)

    def cw_slot():
        return _cw_frame(("slot",), pixel_ui.slot, pixel_ui.SLOT_BORDER)

    def cw_heart(full=True, z=CW_UI_ZOOM, fill=1.0):
        return cw_px(("heart", full, fill), lambda: pixel_ui.heart(full, fill), z)

    def cw_drop(full=True, z=CW_UI_ZOOM):
        return cw_px(("drop", full), lambda: pixel_ui.drop(full), z)

    def cw_lock(z=CW_UI_ZOOM):
        return cw_px(("lock",), pixel_ui.lock, z)

    def cw_pip(filled=True, z=CW_UI_ZOOM):
        return cw_px(("pip", filled), lambda: pixel_ui.pip(filled), z)

    def cw_icon(name, z=CW_UI_ZOOM):
        return cw_px(("icon", name), lambda: pixel_ui.icon(name), z)

    def cw_divider(native_w=110):
        return cw_px(("divider", native_w), lambda: pixel_ui.divider(native_w))

    def cw_backdrop():
        return _cw_cached(("backdrop",), lambda: Tile(cw_px(("bg",), pixel_ui.bg_tile)))

    def cw_ring(radius_native, z=5):
        """Allure aura: the same ring sprite the lunge uses in the hunt."""
        key = ("ring", int(radius_native), z)
        return _cw_cached(key, lambda: im.Data(pixel_art.ring_png(radius_native, z), "cw_ui_ring_%d_x%d.png" % (radius_native, z)))

    def cw_vampire(z=10):
        key = ("vampire", z)
        return _cw_cached(key, lambda: im.Data(pixel_art.character_png("vampire", "down", z), "cw_ui_vampire_x%d.png" % z))
# ---- end helpers (tools/smoke_hunt_draw.py executes everything above this line)


style cw_text is text:
    font CW_FONT
    size 30
    color CW_TEXT

style cw_label is cw_text:
    font CW_FONT_BOLD
    size 36

style cw_dim is cw_text:
    size 24
    color CW_DIM

style cw_title is cw_text:
    font CW_TITLE_FONT
    size 88
    color CW_GOLD
    outlines [(4, "#120e18", 0, 4)]

style cw_h2 is cw_title:
    size 64

style cw_button is button:
    background cw_button_bg("idle")
    hover_background cw_button_bg("hover")
    selected_background cw_button_bg("hover")
    insensitive_background cw_button_bg("insensitive")
    padding (36, 14, 36, 20)
    xminimum 300

style cw_button_text is cw_text:
    font CW_FONT_BOLD
    size 32
    hover_color "#fff4d8"
    insensitive_color "#6e6a74"
    xalign 0.5
    text_align 0.5


# Three drops that pulse in turn: the loading indicator.
transform cw_blink(delay=0.0):
    alpha 0.25
    pause delay
    linear 0.45 alpha 1.0
    linear 0.45 alpha 0.25
    pause (0.9 - delay)
    repeat

# Allure aura in the shop.
transform cw_aura_glow:
    alpha 0.55
    linear 1.6 alpha 0.95
    linear 1.6 alpha 0.55
    repeat
