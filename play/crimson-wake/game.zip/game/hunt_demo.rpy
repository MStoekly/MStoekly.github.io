# A throwaway wrapper so the minigame is reachable before it has a real home in
# the story. Delete this file once hunt_run is called from the actual script.

label hunt_demo:
    scene black
    "The lamps are out on the lower streets. Somewhere ahead, a heartbeat."
    call hunt_lobby
    "Dawn is close. You have [cw_blood] blood to your name."
    return
