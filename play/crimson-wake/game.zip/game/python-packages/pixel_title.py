"""Full-screen pixel scenes for the menus: a gothic night skyline for the main
menu and a dark brick wall for the game menu. Both are 640x360 native pixels
(scaled 3x to 1920x1080 by the caller). No Ren'Py imports; deterministic.

    title_scene()   moon, stars, bats, hill town with a church, graveyard, mist
    brick_wall()    the pixel_ui brick tile, tiled and vignetted
"""

import math
import random

from pixel_art import Canvas, _B4, _rgb
import pixel_ui

W, H = 640, 360


def _c(h):
    return _rgb(h)


SKY = ["#0a0713", "#100b1c", "#170f26", "#201330", "#2d1737", "#411d3b", "#5a2641", "#7a3342"]
HORIZON = 238
NEAR_BLACK = _c("#07040c")
BAT = [".X.....X.",
       "XXX.X.XXX",
       "XXXXXXXXX",
       ".X.XXX.X."]


class _Cv(Canvas):
    """Canvas that also takes "#rrggbb" strings, so the scene can use colours
    outside the shared palette."""

    def px(self, x, y, c):
        if isinstance(c, str) and c.startswith("#"):
            c = _rgb(c)
        Canvas.px(self, x, y, c)


def _bayer(x, y):
    return (_B4[y & 3][x & 3] + 0.5) / 16.0


def _sky(c):
    n = len(SKY) - 1
    for y in range(HORIZON + 1):
        t = y / float(HORIZON) * n
        i = int(t)
        f = t - i
        for x in range(W):
            idx = i + (1 if (i < n and f > _bayer(x, y)) else 0)
            c.p[y][x] = _c(SKY[idx])


def _moon(c, cx, cy, r):
    halo = r * 2.3
    for y in range(int(cy - halo), int(cy + halo) + 1):
        for x in range(int(cx - halo), int(cx + halo) + 1):
            d = math.hypot(x - cx, y - cy)
            if r < d < halo and 0 <= y <= HORIZON:
                p = (1.0 - (d - r) / (halo - r)) ** 2 * 0.85
                if p > _bayer(x, y):
                    c.px(x, y, "#6a3a56" if d < r * 1.5 else "#4a2748")
    disc = [_c(h) for h in ("#b9a79c", "#d6c8ba", "#ece2d4", "#f8f2e8")]
    c.shade_ellipse(cx, cy, r, r, disc, light=(-0.45, -0.6), dither=0.7)
    for ox, oy, rr in ((-9, -6, 6), (8, 7, 7), (-4, 14, 4), (13, -12, 3), (-16, 9, 3)):
        c.ellipse(cx + ox, cy + oy, rr, rr * 0.85, "#c4b2a6")
        c.ellipse(cx + ox - 1, cy + oy - 1, rr * 0.7, rr * 0.6, "#d8cabc")


def _stars(c, rnd, moon):
    for _ in range(190):
        x, y = rnd.randrange(W), rnd.randrange(int(HORIZON * 0.72))
        if math.hypot(x - moon[0], y - moon[1]) < moon[2] * 2.1:
            continue
        c.px(x, y, rnd.choice(("#e8ddd0", "#bdb3c8", "#8a7fa0", "#e8ddd0")))
    for _ in range(9):
        x, y = rnd.randrange(8, W - 8), rnd.randrange(6, int(HORIZON * 0.55))
        if math.hypot(x - moon[0], y - moon[1]) < moon[2] * 2.1:
            continue
        for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
            c.px(x + dx, y + dy, "#f4ecde" if (dx, dy) == (0, 0) else "#8a7fa0")


def _ridge(c, fn, col, bottom=H):
    colour = _c(col)
    for x in range(W):
        for y in range(int(fn(x)), bottom):
            c.p[y][x] = colour


def _hill_y(x):
    return 270 - 52 * math.exp(-((x - 405) / 150.0) ** 2) + 3 * math.sin(x * 0.11)


def _house(c, cx, base, w, h, rnd, lit=0.55):
    x0 = int(cx - w / 2)
    c.rect(x0, base - h, x0 + w, base + 1, NEAR_BLACK)
    rh = int(w * 0.62)
    for i in range(rh):                                        # gabled roof
        half = (w / 2.0 + 2) * (1.0 - i / float(rh))
        c.rect(int(cx - half), base - h - i - 1, int(cx + half) + 1, base - h - i, NEAR_BLACK)
    if rnd.random() < 0.6:                                     # chimney
        c.rect(int(cx + w * 0.22), base - h - rh - 3, int(cx + w * 0.22) + 3, base - h - rh // 2, NEAR_BLACK)
    for wx in range(x0 + 3, x0 + w - 3, 6):
        for wy in range(base - h + 4, base - 3, 8):
            if rnd.random() < lit:
                c.rect(wx, wy, wx + 2, wy + 3, _c("#f0b44a"))
                c.px(wx, wy, "#ffe08a")
            elif rnd.random() < 0.3:
                c.rect(wx, wy, wx + 2, wy + 3, _c("#a8632a"))


def _church(c, cx, base):
    c.rect(cx - 34, base - 30, cx - 6, base + 1, NEAR_BLACK)                  # nave
    for i in range(14):
        c.rect(cx - 36 + i, base - 30 - (13 - i) // 2 * 0 - i // 1 * 0 - (i if i < 14 else 0) // 2 - 1,
               cx - 4 - i + 4, base - 30 - (i // 2), NEAR_BLACK)
    c.rect(cx - 6, base - 62, cx + 12, base + 1, NEAR_BLACK)                  # tower
    for i in range(46):                                                         # spire
        half = 10 * (1.0 - i / 46.0)
        c.rect(int(cx + 3 - half), base - 62 - i - 1, int(cx + 3 + half) + 1, base - 62 - i, NEAR_BLACK)
    c.rect(cx + 2, base - 62 - 46 - 7, cx + 4, base - 62 - 46 + 1, NEAR_BLACK)  # cross
    c.rect(cx, base - 62 - 46 - 5, cx + 6, base - 62 - 46 - 3, NEAR_BLACK)
    c.rect(cx - 1, base - 52, cx + 8, base - 40, _c("#f0b44a"))                 # belfry glow
    c.rect(cx + 2, base - 52, cx + 4, base - 40, NEAR_BLACK)
    c.px(cx, base - 52, "#ffe08a")
    c.ellipse(cx + 3, base - 24, 4.5, 4.5, _c("#c8452e"))                      # rose window
    c.ellipse(cx + 3, base - 24, 2.2, 2.2, _c("#f0b44a"))
    for wx in (cx - 30, cx - 22, cx - 14):                                      # nave windows
        c.rect(wx, base - 22, wx + 3, base - 12, _c("#f0b44a"))
        c.px(wx + 1, base - 23, "#f0b44a")


def _keep(c, cx, base):
    c.rect(cx - 12, base - 52, cx + 12, base + 1, NEAR_BLACK)
    for x in range(cx - 14, cx + 15, 6):                                        # battlements
        c.rect(x, base - 58, x + 4, base - 52, NEAR_BLACK)
    c.rect(cx - 14, base - 54, cx + 15, base - 51, NEAR_BLACK)
    c.rect(cx - 1, base - 76, cx + 1, base - 58, NEAR_BLACK)                    # flag pole
    c.rect(cx + 1, base - 76, cx + 9, base - 70, _c("#7a2a2a"))
    for wy in (base - 44, base - 30, base - 18):
        c.rect(cx - 2, wy, cx + 2, wy + 6, _c("#f0b44a" if wy != base - 30 else "#a8632a"))


def _tree(c, x, base, rnd):
    def branch(x0, y0, ang, length, thick):
        if length < 5:
            return
        x1 = x0 + math.cos(ang) * length
        y1 = y0 - math.sin(ang) * length
        steps = int(length)
        for i in range(steps):
            px = x0 + (x1 - x0) * i / steps
            py = y0 + (y1 - y0) * i / steps
            c.rect(int(px), int(py), int(px) + thick, int(py) + thick, NEAR_BLACK)
        branch(x1, y1, ang + rnd.uniform(0.3, 0.7), length * 0.72, max(1, thick - 1))
        branch(x1, y1, ang - rnd.uniform(0.3, 0.7), length * 0.72, max(1, thick - 1))
    c.rect(x - 2, base - 40, x + 3, base + 1, NEAR_BLACK)
    branch(x, base - 38, math.pi / 2 + 0.2, 34, 3)
    branch(x + 1, base - 24, math.pi / 2 - 0.9, 24, 2)


def _grave(c, x, base, kind):
    if kind == 0:                                                               # cross
        c.rect(x, base - 14, x + 2, base + 1, NEAR_BLACK)
        c.rect(x - 3, base - 10, x + 5, base - 8, NEAR_BLACK)
    elif kind == 1:                                                             # round headstone
        c.rect(x - 4, base - 9, x + 5, base + 1, NEAR_BLACK)
        c.ellipse(x + 0.5, base - 9, 4.5, 4, NEAR_BLACK)
    else:                                                                       # obelisk
        c.rect(x - 2, base - 16, x + 3, base + 1, NEAR_BLACK)
        c.rect(x - 1, base - 19, x + 2, base - 16, NEAR_BLACK)


def _fence(c, x0, x1, base):
    for x in range(x0, x1, 7):
        c.rect(x, base - 17, x + 2, base + 1, NEAR_BLACK)
        c.px(x, base - 19, NEAR_BLACK)
        c.px(x + 1, base - 19, NEAR_BLACK)
        c.px(x, base - 18, NEAR_BLACK)
        c.px(x + 1, base - 18, NEAR_BLACK)
    c.rect(x0, base - 12, x1 + 1, base - 10, NEAR_BLACK)


def _bat(c, x, y):
    for yy, row in enumerate(BAT):
        for xx, ch in enumerate(row):
            if ch == "X":
                c.px(x + xx, y + yy, NEAR_BLACK)


def _mist(c, rnd):
    for y in range(270, 312):
        k = 1.0 - abs(y - 288) / 22.0
        if k <= 0:
            continue
        for x in range(W):
            if k * 0.5 > _bayer(x + (y // 3) * 5, y):
                old = c.p[y][x]
                if old is not None:
                    c.p[y][x] = (min(255, old[0] + 40), min(255, old[1] + 22), min(255, old[2] + 36), 255)


def _vignette(c, edge=0.70, strength=0.9):
    for y in range(H):
        for x in range(W):
            d = max(abs(x - W / 2.0) / (W / 2.0), abs(y - H / 2.0) / (H / 2.0))
            if d > edge:
                k = (d - edge) / (1.0 - edge) * strength
                if k > _bayer(x, y):
                    r, g, b, a = c.p[y][x]
                    c.p[y][x] = (int(r * 0.45), int(g * 0.45), int(b * 0.5), a)


def title_scene(seed=7):
    rnd = random.Random(seed)
    c = _Cv(W, H)
    _sky(c)
    moon = (462, 96, 34)
    _moon(c, *moon)
    _stars(c, rnd, moon)
    _ridge(c, lambda x: 206 + 14 * math.sin(x * 0.021 + 1.0) + 7 * math.sin(x * 0.067), "#2c1738")
    _ridge(c, lambda x: 230 + 11 * math.sin(x * 0.016 + 3.0) + 5 * math.sin(x * 0.09), "#1c0f27")
    _ridge(c, _hill_y, "#0d0715")
    _church(c, 400, int(_hill_y(400)) + 2)
    _keep(c, 566, int(_hill_y(566)) + 3)
    for cx, w, h in ((296, 20, 16), (322, 16, 14), (350, 22, 19), (432, 18, 15), (458, 22, 17), (490, 16, 13), (520, 20, 16), (270, 16, 11)):
        _house(c, cx, int(_hill_y(cx)) + 2, w, h, rnd)
    _ridge(c, lambda x: 318 + 3 * math.sin(x * 0.05), "#07040c")
    _mist(c, rnd)
    _tree(c, 604, 322, rnd)
    _tree(c, 214, 326, rnd)
    _fence(c, 250, 420, 322)
    for i, gx in enumerate(range(262, 560, 31)):
        if not (gx > 590):
            _grave(c, gx + rnd.randrange(-4, 5), 332 + rnd.randrange(-2, 3), i % 3)
    for bx, by in ((452, 86), (500, 62), (420, 54), (538, 118), (360, 120), (300, 70)):
        _bat(c, bx, by)
    _vignette(c)
    return c


def brick_wall():
    tile = pixel_ui.bg_tile()
    c = Canvas(W, H)
    for y in range(H):
        for x in range(W):
            c.p[y][x] = tile.p[y % tile.h][x % tile.w]
    _vignette(c, 0.45, 1.0)
    return c


if __name__ == "__main__":
    import sys
    import time
    t0 = time.time()
    s = title_scene()
    b = brick_wall()
    ok = (s.w, s.h, b.w, b.h) == (W, H, W, H) and all(px is not None for row in s.p for px in row) and all(px is not None for row in b.p for px in row)
    ok = ok and title_scene().p == s.p
    print("title_scene/brick_wall: 640x360, fully opaque, deterministic: %s (%.1fs)" % ("PASS" if ok else "FAIL", time.time() - t0))
    sys.exit(0 if ok else 1)
