"""Pixel-art UI pieces for the hunt screens, drawn in code like everything else.

No Ren'Py imports: every function returns a Canvas (or PNG bytes via *_png at
a given integer scale). hunt_ui.rpy wraps them as im.Data / Frame. Nine-slice
pieces are small and tile-friendly: the corners keep their pixels, the edges
and the middle repeat (use Frame(..., tile=True)).

    panel(kind)    24x24, border 8     stone frame with gold trim and rivets
    card(kind)     16x16, border 5     lighter row/card frame
    button(state)  16x16, border 4     idle / hover / insensitive
    slot()         12x8,  border 3     dark inset (bars, counters)
    heart(full), drop(), lock(), icon(name), pip(filled), divider(w)
"""

import random

import pixel_art as pa
from pixel_art import Canvas, C, ramp


def _dither_field(c, x0, y0, x1, y1, base, speck, rate, seed):
    rnd = random.Random(seed)
    for y in range(y0, y1):
        for x in range(x0, x1):
            c.px(x, y, speck if rnd.random() < rate else base)


# -- nine-slice frames --------------------------------------------------------

_PANEL_KINDS = {
    #          trim            band (light, mid, dark)             field
    "stone": ("gold_d", ("stone3", "stone2", "stone1"), "ink2"),
    "blood": ("red", ("cloak_l", "cloak", "cloak_d"), "ink2"),
    "gold":  ("gold", ("stone3", "stone2", "stone1"), "cloak_d"),
    "dim":   ("stone2", ("stone1", "stone1", "stone0"), "ink"),
}


def panel(kind="stone"):
    trim, band, field = _PANEL_KINDS[kind]
    n = 24
    c = Canvas(n, n)
    c.rect(0, 0, n, n, C[field])
    _dither_field(c, 0, 0, n, n, C[field], C["purple_d"], 0.07, 11)
    # concentric rings from the outside in (ring i is 1px wide)
    rings = ["ink", trim, "ink", band[0], band[1], band[2], "ink"]
    for i, name in enumerate(rings):
        col = C[name]
        c.rect(i, i, n - i, i + 1, col)                      # top
        c.rect(i, n - 1 - i, n - i, n - i, col)              # bottom
        c.rect(i, i, i + 1, n - i, col)                      # left
        c.rect(n - 1 - i, i, n - i, n - i, col)              # right
    # bevel: light top/left, dark bottom/right on the stone band
    for i in (3, 4):
        c.rect(i + 1, i, n - i - 1, i + 1, C[band[0]])
        c.rect(i, i + 1, i + 1, n - i - 1, C[band[0]])
        c.rect(i + 1, n - 1 - i, n - i - 1, n - i, C[band[2]])
        c.rect(n - 1 - i, i + 1, n - i, n - i - 1, C[band[2]])
    # gold trim catches the light on the top-left
    c.rect(2, 1, n - 2, 2, C["gold"] if trim == "gold_d" else C[trim])
    c.rect(1, 2, 2, n - 2, C["gold"] if trim == "gold_d" else C[trim])
    # corner rivets / studs (only in the 8x8 corners, so the edges tile cleanly)
    for cx, cy in ((3, 3), (n - 5, 3), (3, n - 5), (n - 5, n - 5)):
        c.rect(cx - 1, cy - 1, cx + 3, cy + 3, C["ink"])
        c.rect(cx, cy, cx + 2, cy + 2, C["gold"])
        c.px(cx, cy, "hay_l")
        c.px(cx + 1, cy + 1, "gold_d")
    # chamfer the outer corners
    for x, y in ((0, 0), (n - 1, 0), (0, n - 1), (n - 1, n - 1)):
        c.p[y][x] = None
    return c


PANEL_BORDER = 8


def card(kind="stone"):
    """Lighter frame for rows inside a panel."""
    trim = {"stone": "stone2", "gold": "gold_d", "blood": "red", "dim": "stone1"}[kind]
    n = 16
    c = Canvas(n, n)
    field = {"stone": "slate_d", "gold": "cloak_d", "blood": "cloak_d", "dim": "ink"}[kind]
    c.rect(0, 0, n, n, C[field])
    _dither_field(c, 0, 0, n, n, C[field], C["ink2"], 0.10, 23)
    for i, name in enumerate(("ink", trim, "ink")):
        col = C[name]
        c.rect(i, i, n - i, i + 1, col)
        c.rect(i, n - 1 - i, n - i, n - i, col)
        c.rect(i, i, i + 1, n - i, col)
        c.rect(n - 1 - i, i, n - i, n - i, col)
    c.rect(2, 3, n - 2, 4, C["slate_l"] if kind == "stone" else C[trim])      # top highlight under the trim
    for x, y in ((0, 0), (n - 1, 0), (0, n - 1), (n - 1, n - 1)):
        c.p[y][x] = None
    return c


CARD_BORDER = 5


def button(state="idle"):
    n = 16
    c = Canvas(n, n)
    if state == "insensitive":
        top, bot, trim, hi = "stone1", "stone0", "stone2", "stone2"
    elif state in ("hover", "selected"):
        top, bot, trim, hi = "red", "cloak", "gold", "hay_l"
    else:
        top, bot, trim, hi = "cloak", "cloak_d", "gold_d", "cloak_l"
    for y in range(n):
        t = y / float(n - 1)
        c.rect(0, y, n, y + 1, C[top] if t < 0.45 else C[bot])
    for i, name in enumerate(("ink", trim)):
        col = C[name]
        c.rect(i, i, n - i, i + 1, col)
        c.rect(i, n - 1 - i, n - i, n - i, col)
        c.rect(i, i, i + 1, n - i, col)
        c.rect(n - 1 - i, i, n - i, n - i, col)
    c.rect(2, 2, n - 2, 3, C[hi])                                 # top highlight
    c.rect(2, n - 3, n - 2, n - 2, C["ink"] if state != "insensitive" else C["stone0"])
    if state in ("hover", "selected"):
        c.rect(2, 3, n - 2, 4, C["red_l"])
    for x, y in ((0, 0), (n - 1, 0), (0, n - 1), (n - 1, n - 1)):
        c.p[y][x] = None
    for x, y in ((1, 1), (n - 2, 1), (1, n - 2), (n - 2, n - 2)):  # chamfer
        c.p[y][x] = C["ink"]
    return c


BUTTON_BORDER = 4


def slot():
    n = 12
    c = Canvas(n, n)
    c.rect(0, 0, n, n, C["ink"])
    c.rect(1, 1, n - 1, n - 1, C["gold_d"])
    c.rect(2, 2, n - 2, n - 2, C["ink"])
    c.rect(3, 3, n - 3, n - 3, C["stone0"])
    for x, y in ((0, 0), (n - 1, 0), (0, n - 1), (n - 1, n - 1)):
        c.p[y][x] = None
    return c


SLOT_BORDER = 3


# -- small icons -------------------------------------------------------------

def _from_rows(rows, legend):
    c = Canvas(len(rows[0]), len(rows))
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch != ".":
                c.px(x, y, legend[ch])
    return c


_HEART = ["..XXX...XXX..",
          ".XXXXX.XXXXX.",
          "XXXXXXXXXXXXX",
          "XXXXXXXXXXXXX",
          "XXXXXXXXXXXXX",
          ".XXXXXXXXXXX.",
          "..XXXXXXXXX..",
          "...XXXXXXX...",
          "....XXXXX....",
          ".....XXX.....",
          "......X......"]


def heart(full=True, fill=1.0):
    """fill < 1 draws a part-filled heart: the left `fill` of its width is red, the rest empty."""
    cut = int(round(fill * len(_HEART[0])))
    c = Canvas(len(_HEART[0]) + 2, len(_HEART) + 2)
    for y, row in enumerate(_HEART):
        for x, ch in enumerate(row):
            if ch == "X":
                if full and x < cut:
                    col = C["red"]
                    if y < 3 and x < 6:
                        col = C["red_l"]
                    elif y > 5 or x > 9:
                        col = C["roof_red"] if y > 7 else C["roof_red_l"]
                else:
                    col = C["ink2"] if (x + y) % 2 else C["slate_d"]
                c.px(x + 1, y + 1, col)
    if full and cut > 4:
        c.px(3, 3, "white")
        c.px(4, 3, "red_l")
    c.outline("ink" if full else "stone1")
    return c


_DROP = ["....X....",
         "....X....",
         "...XXX...",
         "...XXX...",
         "..XXXXX..",
         ".XXXXXXX.",
         "XXXXXXXXX",
         "XXXXXXXXX",
         "XXXXXXXXX",
         ".XXXXXXX.",
         "..XXXXX.."]


def drop(full=True):
    c = Canvas(len(_DROP[0]) + 2, len(_DROP) + 2)
    for y, row in enumerate(_DROP):
        for x, ch in enumerate(row):
            if ch == "X":
                col = C["red"] if full else C["stone1"]
                if full and x < 4 and 3 < y < 8:
                    col = C["red_l"]
                elif full and (x > 6 or y > 8):
                    col = C["roof_red_l"]
                c.px(x + 1, y + 1, col)
    if full:
        c.px(3, 8, "white")
        c.px(3, 9, "red_l")
    c.outline("ink")
    return c


def lock():
    c = Canvas(13, 15)
    for x, y in ((4, 1), (5, 0), (6, 0), (7, 0), (8, 1), (9, 2), (9, 3), (9, 4), (3, 2), (3, 3), (3, 4)):
        c.px(x + 0, y + 1, "stone3")
    c.rect(2, 6, 11, 14, C["gold_d"])
    c.rect(2, 6, 11, 7, C["gold"])
    c.rect(2, 13, 11, 14, C["wood_d"])
    c.rect(6, 8, 7, 11, C["ink"])
    c.px(6, 8, "ink")
    c.outline("ink")
    return c


def pip(filled=True):
    c = Canvas(9, 9)
    pat = ["....X....",
           "...XXX...",
           "..XXXXX..",
           ".XXXXXXX.",
           "XXXXXXXXX",
           ".XXXXXXX.",
           "..XXXXX..",
           "...XXX...",
           "....X...."]
    for y, row in enumerate(pat):
        for x, ch in enumerate(row):
            if ch == "X":
                if filled:
                    col = C["gold"] if (x + y) % 5 else C["hay_l"]
                    if x > 4 and y > 3:
                        col = C["gold_d"]
                else:
                    col = C["stone1"]
                c.px(x, y, col)
    c.outline("ink")
    return c


def icon(name):
    c = Canvas(18, 18)
    if name == "speed":                                   # bat
        for side in (-1, 1):
            for i in range(1, 8):
                x = 9 + side * (1 + i)
                ytop = int(9 - i * 0.75)
                ybot = 10 + (2 if i % 3 == 0 else 0) + (1 if i < 3 else 0)
                for y in range(ytop, ybot):
                    c.px(x, y, "purple" if y > ytop else "purple_l")
            c.px(9 + side * 2, 5, "ink2")
        c.ellipse(9, 10, 2.3, 3.4, "purple_d")
        c.ellipse(9, 7, 2.2, 2.0, "purple_d")
        c.px(7, 4, "purple_d")
        c.px(11, 4, "purple_d")
        c.px(8, 7, "red_l")
        c.px(10, 7, "red_l")
        c.px(8, 9, "white")
        c.px(10, 9, "white")
    elif name == "constitution":                           # shield + heart
        for y in range(2, 16):
            half = 6 if y < 9 else max(1, 6 - (y - 8))
            for x in range(9 - half, 9 + half):
                c.px(x, y, "stone3" if x < 9 else "stone2")
        c.rect(3, 2, 15, 4, C["gold"])
        for y in range(5, 12):
            for x in range(5, 13):
                pass
        c.ellipse(7.2, 7.2, 2.0, 1.8, "red")
        c.ellipse(10.8, 7.2, 2.0, 1.8, "red")
        for i in range(5):
            c.rect(5 + i, 8 + i, 13 - i, 9 + i, C["red"])
        c.px(6, 6, "red_l")
        c.px(7, 6, "red_l")
    elif name == "allure":                                 # eye
        for x in range(2, 16):
            h = int(3.2 * (1.0 - abs(x - 8.5) / 7.0)) + 1
            for y in range(9 - h, 9 + h):
                c.px(x, y, "white")
        c.ellipse(9, 9, 2.8, 2.8, "red")
        c.ellipse(9, 9, 1.4, 1.4, "ink")
        c.px(8, 8, "white")
        for x in range(2, 16, 2):
            h = int(3.2 * (1.0 - abs(x - 8.5) / 7.0)) + 1
            c.px(x, 9 - h - 1, "ink2")
        c.px(9, 4, "gold")
        c.px(9, 3, "gold")
    elif name == "strength":                               # fanged bite
        for x in range(1, 17):                              # upper lip arc
            top = 3 + int(2.2 * ((x - 8.5) / 7.5) ** 2)
            c.rect(x, top, x + 1, top + 3, C["red"])
            c.px(x, top, "red_l")
            c.px(x, top + 2, "roof_red")
        for fx in (3, 11):                                  # two tapering fangs
            for i in range(9):
                w = 4 - (i * 4) // 9
                x0 = fx + (4 - w) // 2
                for x in range(x0, x0 + max(w, 1)):
                    c.px(x, 8 + i, "white" if (x - x0) * 2 < max(w, 1) or w == 1 else "bone")
        c.px(4, 16, "red_l")
        c.px(12, 16, "red_l")
        c.px(4, 17, "red")
    elif name == "blink":                                  # a portal with speed streaks
        c.ellipse(12.5, 9, 3.8, 7.2, "purple")
        c.ellipse(12.5, 9, 2.6, 5.8, "purple_d")
        c.ellipse(13, 9, 1.3, 3.6, "red_l")
        c.ellipse(13, 9, 0.8, 2.0, "white")
        for y, x0, x1 in ((4, 3, 9), (8, 0, 10), (12, 2, 9), (15, 5, 9)):
            c.rect(x0, y, x1, y + 1, C["purple_l"])
            c.px(x1 - 1, y, "white")
    elif name == "charm":                                  # a heart under sparkles
        c.ellipse(6.6, 7.6, 3.4, 3.2, "red")
        c.ellipse(11.4, 7.6, 3.4, 3.2, "red")
        for i in range(7):
            c.rect(3 + i, 8 + i, 15 - i, 9 + i, C["red"])
        c.px(5, 6, "red_l")
        c.px(6, 5, "red_l")
        c.px(6, 6, "white")
        for x, y in ((14, 3), (3, 3), (15, 11)):            # little purple sparkles
            c.px(x, y, "purple_l")
            c.px(x - 1, y, "purple")
            c.px(x + 1, y, "purple")
            c.px(x, y - 1, "purple")
            c.px(x, y + 1, "purple")
            c.px(x, y, "white")
    elif name == "ultimate":                               # an hourglass with frozen sand
        c.rect(3, 1, 15, 3, C["gold"])
        c.rect(3, 15, 15, 17, C["gold"])
        c.rect(3, 1, 15, 2, C["gold_d"])
        for y in range(3, 15):
            half = 6 - (y - 3) if y < 9 else (y - 9) + 1
            half = max(half, 1)
            for x in range(9 - half, 9 + half):
                edge = x == 9 - half or x == 9 + half - 1
                sand = (4 < y < 9) or (y >= 12)
                c.px(x, y, "glass_l" if edge else ("white" if sand else "slate_d"))
        c.px(9, 9, "white")
        c.px(9, 10, "white")
    elif name == "drain":                                  # a blood drop falling into a heart
        for y in range(1, 6):
            half = (y - 1) // 2 + 1
            for x in range(9 - half, 9 + half):
                c.px(x, y, "red_l" if x < 9 else "red")
        c.ellipse(9, 6.4, 1.8, 1.7, "red")
        c.px(8, 5, "white")
        c.ellipse(6.4, 11.2, 3.2, 3.0, "red")
        c.ellipse(11.6, 11.2, 3.2, 3.0, "red")
        for i in range(6):
            c.rect(3 + i, 12 + i, 15 - i, 13 + i, C["red"])
        c.px(5, 9, "red_l")
        c.px(6, 9, "red_l")
        c.px(5, 10, "white")
    elif name == "bloodlust":                              # a furious blood drop with fangs
        for y in range(1, 9):                               # pointed top
            half = (y - 1) // 2 + 1
            for x in range(9 - half, 9 + half):
                c.px(x, y, "red")
        c.ellipse(9, 11, 5.6, 5.2, "red")
        c.ellipse(7, 9, 1.6, 2.2, "red_l")
        for x in (6, 7, 8):                                 # angry slit eyes
            c.px(x, 10, "ink")
            c.px(x + 4, 10, "ink")
        c.px(8, 9, "ink")
        c.px(11, 9, "ink")
        for fx in (6, 10):                                  # two fangs over the dark mouth
            c.rect(fx, 13, fx + 2, 14, C["ink"])
            c.px(fx, 14, "white")
            c.px(fx, 15, "white")
            c.px(fx + 1, 14, "white")
    else:
        raise KeyError(name)
    c.outline("ink")
    return c


def divider(w):
    """Horizontal ornament, w native px wide: a gold line, ink shadow, centre diamond."""
    h = 9
    c = Canvas(w, h)
    mid = w // 2
    for x in range(2, w - 2):
        if abs(x - mid) > 7:
            c.px(x, 4, "gold_d")
            c.px(x, 5, "ink")
    for x in (1, w - 2):
        c.px(x, 4, "gold")
    for i in range(4):
        for j in range(-i, i + 1):
            c.px(mid + j, 4 - i + 4, "gold" if j <= 0 else "gold_d")
            c.px(mid + j, 4 + i - 0, "gold" if j <= 0 else "gold_d")
    for k in (-9, 9):
        c.px(mid + k, 4, "red")
        c.px(mid + k, 3, "red_l")
    c.outline("ink")
    return c



def bg_tile():
    """32x32 tileable dark stone-brick wall for screen backdrops."""
    n = 32
    c = Canvas(n, n)
    rnd = random.Random(5)
    for row in range(4):
        y0 = row * 8
        shift = 0 if row % 2 == 0 else 8
        for x in range(n):
            c.px(x, y0, "ink")                                  # mortar, horizontal
        for bx in range(4):
            x = (bx * 16 + shift) % n
            for y in range(y0, y0 + 8):
                c.px(x, y, "ink")                               # mortar, vertical
        for y in range(y0 + 1, y0 + 8):
            for x in range(n):
                if c.p[y][x] is None:
                    r = rnd.random()
                    c.px(x, y, "purple_d" if r < 0.05 else ("slate_d" if r < 0.08 else "ink2"))
    return c

# -- cache + PNG ---------------------------------------------------------------

def png(canvas, scale):
    return canvas.png(scale)


def self_check():
    """Headless sanity checks (python game/python-packages/pixel_ui.py)."""
    ok = True

    def check(label, cond):
        print("%-60s %s" % (label, "PASS" if cond else "FAIL"))
        return cond

    for kind in _PANEL_KINDS:
        p = panel(kind)
        ok &= check("panel(%s): 24x24, solid centre, corners chamfered" % kind,
                    (p.w, p.h) == (24, 24) and p.get(12, 12) is not None and p.get(0, 0) is None)
        # edges must tile: the centre strip of each edge is uniform along its length
        ok &= check("panel(%s): edge strips tile (rows/cols 8..15 repeat)" % kind,
                    all(p.p[y][x] == p.p[y][x + 1 if False else x] for y in range(8, 16) for x in range(0, 8))
                    and len(set(tuple(p.p[y][0:8]) for y in range(9, 15))) <= 8)
    for state in ("idle", "hover", "insensitive"):
        b = button(state)
        ok &= check("button(%s): 16x16, opaque centre" % state, (b.w, b.h) == (16, 16) and b.get(8, 8) is not None)
    ok &= check("hover differs from idle", button("hover").p != button("idle").p)
    for name in ("speed", "constitution", "allure", "strength", "blink", "charm", "bloodlust"):
        ic = icon(name)
        n = sum(1 for row in ic.p for px in row if px is not None)
        ok &= check("icon(%s): drawn (%d px)" % (name, n), n > 40)
    ok &= check("hearts: full and empty are 15x13", (heart(True).w, heart(True).h) == (15, 13) == (heart(False).w, heart(False).h))
    ok &= check("deterministic", panel("stone").p == panel("stone").p and card().p == card().p)
    ok &= check("divider width", divider(120).w == 120)
    ok &= check("bg_tile: 32x32, fully opaque", all(px is not None for row in bg_tile().p for px in row))
    print("\n%s" % ("ALL PASS" if ok else "FAILURES ABOVE"))
    return ok


if __name__ == "__main__":
    import sys
    sys.exit(0 if self_check() else 1)
