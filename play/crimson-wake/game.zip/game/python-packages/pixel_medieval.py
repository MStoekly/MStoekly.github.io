"""Medieval / fantasy buildings for pixel_art.building().

Same conventions as pixel_art: oblique view facing south, a roof block over a
front wall; the sprite is `rise` px taller than the footprint (roof overhang
to the north), collision is the footprint rectangle (see hunt_mapgen).
Dimensions come from pixel_art.BUILDINGS (w, d in tiles, 16 native px each;
fences use fractional tiles).

Kinds: house_s/m/l, shed, tavern, stable (also the barn), church, windmill,
tower, wall_h, wall_v, fence_h, fence_v.
"""

import random

import pixel_art as pa
from pixel_art import Canvas, C, ramp

ROOFS = {
    "tile": ramp("tile_d", "tile", "tile_l"),
    "slate": ramp("mslate_d", "mslate", "mslate_l"),
    "shingle": ramp("shingle_d", "shingle", "shingle_l"),
    "church": ramp("slate_d", "slate", "slate_l"),
}


def _dims(kind):
    spec = pa.BUILDINGS[kind]
    return int(round(spec["w"] * 16)), int(round(spec["d"] * 16)), spec["rise"]


def _wrap(body):
    c = Canvas(body.w + 2, body.h + 2)
    c.blit(body, 1, 1)
    c.outline("ink")
    return c


# -- pieces -----------------------------------------------------------------

def _roof(b, x0, y0, x1, y1, cols, hip=4):
    """Hipped shingle roof: capped ridge, shingle courses with offset seams,
    shadowed eave. The top corners are cut so the silhouette is not a box."""
    d, m, l = cols
    for y in range(y0, y1):
        row = y - y0
        for x in range(x0, x1):
            cut = hip - row
            if cut > 0 and (x - x0 < cut or x1 - 1 - x < cut):
                continue
            if row < 2:
                col = l
            elif row == 2:
                col = d
            else:
                r = (row - 3) % 4
                if r == 3 or (x + ((row - 3) // 4) * 3) % 6 == 0:
                    col = d
                elif r == 0:
                    col = l if (x + row) % 3 else m
                else:
                    col = m
            if x >= x1 - 2 or y >= y1 - 2:
                col = d
            b.px(x, y, col)


def _thatch(b, x0, y0, x1, y1, hip=3):
    cols = [C["thatch0"], C["thatch1"], C["thatch2"], C["hay_l"]]
    for y in range(y0, y1):
        row = y - y0
        for x in range(x0, x1):
            cut = hip - row
            if cut > 0 and (x - x0 < cut or x1 - 1 - x < cut):
                continue
            n = pa._hash(x, row // 5, 7)
            col = cols[1 + int(n * 2.9)]
            if row % 5 == 4:
                col = cols[0]
            if row < 2:
                col = cols[3]
            if y >= y1 - 2:
                col = cols[0] if (x + y) % 2 else cols[1]
            if x >= x1 - 2:
                col = cols[0]
            b.px(x, y, col)
    for x in range(x0 + 2, x1 - 2, 3):                     # ragged hem
        if pa._hash(x, y1, 3) > 0.5:
            b.p[y1 - 1][x] = None


def _moss(b, rnd, n, palette):
    for _ in range(n):
        cx, cy = rnd.randint(4, b.w - 5), rnd.randint(6, b.h - 28)
        for dx in range(-2, 3):
            for dy in range(-1, 2):
                if rnd.random() < 0.65 and b.get(cx + dx, cy + dy) in palette:
                    b.px(cx + dx, cy + dy, C["moss"] if rnd.random() < 0.6 else C["leaf3"])


def _window(b, x, y, lit, shutter, w=4, h=5):
    b.rect(x - 2, y, x, y + h, C[shutter])                 # shutters
    b.rect(x + w, y, x + w + 2, y + h, C[shutter])
    b.rect(x - 1, y - 1, x + w + 1, y + h + 1, C["ink2"])
    if lit:
        b.rect(x, y, x + w, y + h, C["lit"])
        b.rect(x, y, x + 1, y + 2, C["lit_l"])
        b.rect(x, y + h - 1, x + w, y + h, C["lit_d"])
    else:
        b.rect(x, y, x + w, y + h, C["glass"])
        b.px(x, y, "glass_l")
    b.rect(x + w // 2, y, x + w // 2 + 1, y + h, C["ink2"])


def _arched_door(b, x, y_bot, w=6, h=10):
    b.rect(x - 1, y_bot - h, x + w + 1, y_bot, C["ink2"])
    b.rect(x, y_bot - h + 1, x + w, y_bot, C["wood"])
    b.rect(x, y_bot - h + 1, x + 1, y_bot, C["wood_l"])
    b.px(x, y_bot - h, "ink2")
    b.px(x + w - 1, y_bot - h, "ink2")
    b.rect(x + w // 2, y_bot - h + 1, x + w // 2 + 1, y_bot, C["wood_d"])
    b.px(x + w - 2, y_bot - 4, "gold")
    for yy in (y_bot - 7, y_bot - 3):                       # iron straps
        b.rect(x, yy, x + w, yy + 1, C["silver_d"])


def _stone_rows(b, x0, y0, x1, y1, cols, seed=0):
    """Brick-bonded stonework (cols dark -> light), bottom row shaded."""
    for y in range(y0, y1):
        row = (y - y0) // 4
        off = 4 if row % 2 else 0
        for x in range(x0, x1):
            if (y - y0) % 4 == 3 or (x - x0 + off) % 8 == 7:
                col = cols[0]
            else:
                col = cols[1 + int(pa._hash((x - x0 + off) // 8, row, seed) * 1.99)]
            if x - x0 < 2:
                col = cols[min(len(cols) - 1, 2)] if col != cols[0] else col
            if y == y1 - 1:
                col = cols[0]
            b.px(x, y, col)


def _timber_storey(b, x0, y0, x1, y1, plaster, rnd, windows, glow, shutter, braces=True, panel=14):
    """Plaster-and-beam storey. Returns the window/door-free panel centres."""
    b.rect(x0, y0, x1, y1, plaster[1])
    for y in range(y0 + 2, y1 - 2):                         # soft plaster speckle
        for x in range(x0, x1):
            if pa._hash(x, y, 9) > 0.93:
                b.px(x, y, plaster[0])
            elif x < x0 + 3:
                b.px(x, y, plaster[2])
    n = max(1, (x1 - x0) // panel)
    xs = [x0 + int(round(i * (x1 - x0 - 2) / float(n))) for i in range(n + 1)]
    for i in range(n):
        a, z = xs[i] + 2, xs[i + 1]
        if braces and z - a >= 8:
            if i % 2:
                b.line(a, y0 + 2, z - 1, y1 - 3, C["wood_d"])
            else:
                b.line(z - 1, y0 + 2, a, y1 - 3, C["wood_d"])
    for x in xs:
        b.rect(x, y0, x + 2, y1, C["wood_d"])               # posts
    b.rect(x0, y0, x1, y0 + 2, C["wood_d"])                 # top beam
    b.rect(x0, y1 - 2, x1, y1, C["wood"])                   # sill beam
    b.rect(x0, y1 - 2, x1, y1 - 1, C["wood_l"])
    centres = []
    for i in range(n):
        centres.append((xs[i] + 2 + xs[i + 1]) // 2)
    return centres


def _house(kind, variant):
    W, fd, rise = _dims(kind)
    H = fd + rise
    rnd = random.Random(sum(ord(ch) for ch in kind) * 31 + variant)
    b = Canvas(W, H)
    style = ("tile", "slate", "thatch", "shingle")[variant % 4]
    if kind == "tavern":
        style = "tile"
    elif kind == "shed":
        style = ("shingle", "thatch")[variant % 2]
    wall_h = 24
    eave = H - wall_h + 2                                    # bottom of the roof
    wall_top = H - wall_h
    up = 13
    plasters = {"tile": ramp("plaster_d", "plaster", "plaster_l"), "slate": ramp("rag_d", "rag", "rag_l"),
                "thatch": ramp("plaster_d", "plaster", "plaster_l"), "shingle": ramp("wood", "wood_l", "tan")}
    stones = ramp("cob0", "cob1", "cob2", "cob3")
    # --- walls
    glow = 0.55 if kind != "shed" else 0.3
    shut = {"tile": "shutter", "slate": "shutter_r", "thatch": "shutter", "shingle": "shutter_d"}[style]
    if style == "shingle":                                    # log cabin: horizontal planks
        for y in range(wall_top, H):
            for x in range(0, W):
                c = ramp("wood_d", "wood", "wood_l")[1 + (1 if (y - wall_top) % 4 == 1 else 0)]
                if (y - wall_top) % 4 == 3:
                    c = C["wood_d"]
                b.px(x, y, c)
        centres = [W // 4, W * 3 // 4] if W > 48 else [W // 2]
        for cxw in centres:
            _window(b, cxw - 2, wall_top + 6, rnd.random() < glow, shut)
        door_x = W // 2 - 3 + (rnd.randint(-1, 1) * 8 if W > 48 else 0)
        if W > 48 and abs(door_x - W // 2) < 5:
            door_x += 8
    else:
        centres = _timber_storey(b, 0, wall_top, W, wall_top + up, plasters[style], rnd, True, glow, shut,
                                 braces=(style != "slate"), panel=18)
        _stone_rows(b, 1, wall_top + up, W - 1, H, stones, seed=variant)
        b.rect(0, wall_top + up, W, wall_top + up + 1, C["stone0"])          # jetty shadow
        door_x = W // 2 - 3 + (rnd.randint(-1, 1) * 8 if W > 48 else 0)
        for i, cx_ in enumerate(centres):
            if len(centres) > 2 and i % 2 == (0 if kind == "tavern" else 1):
                continue                                      # every other panel keeps its braces
            _window(b, cx_ - 2, wall_top + 4, rnd.random() < glow, shut)
    if kind != "shed":
        _arched_door(b, door_x, H - 1, 6, 10)
        b.rect(door_x + 8, H - 12, door_x + 9, H - 8, C["wood_d"])            # lantern bracket
        b.rect(door_x + 9, H - 11, door_x + 11, H - 8, C["lit"])
    # --- roof
    if style == "thatch":
        _thatch(b, 0, 0, W, eave)
    else:
        key = {"tile": "tile", "slate": "slate", "shingle": "shingle"}[style]
        _roof(b, 0, 0, W, eave, ROOFS[key], hip=5)
        if style != "tile":
            _moss(b, rnd, 4 if style == "slate" else 2, set(ROOFS[key]))
    # --- dormers and chimney
    if kind in ("house_m", "house_l", "tavern") and style != "thatch":
        for cx_ in ([W // 3] if kind == "house_m" else [W // 4, W * 3 // 4]):
            if kind == "tavern":
                cx_ = [W // 4, W * 3 // 4][rnd.randint(0, 1)]
            yb = eave - 5
            b.rect(cx_ - 6, yb - 9, cx_ + 6, yb, C["plaster"])
            b.rect(cx_ - 6, yb - 9, cx_ - 5, yb, C["plaster_l"])
            b.rect(cx_ - 6, yb - 9, cx_ + 6, yb - 8, C["wood_d"])
            _window(b, cx_ - 2, yb - 7, rnd.random() < 0.7, shut, w=4, h=5)
            rc = ROOFS["tile" if style == "tile" else style]
            b.triangle(cx_, yb - 17, yb - 8, 8, [rc[0], rc[1], rc[2], rc[2]])
    chx = int(W * (0.7 if variant % 2 else 0.2))
    b.rect(chx, 2, chx + 7, 14, C["cob2"])
    b.rect(chx, 2, chx + 7, 4, C["cob4"])
    b.rect(chx + 5, 4, chx + 7, 14, C["cob1"])
    b.rect(chx - 1, 0, chx + 8, 2, C["cob3"])                                 # cap
    if kind == "tavern":
        sy = wall_top + 10
        b.rect(5, sy - 4, 6, sy + 12, C["wood_d"])                            # sign bracket + board
        b.rect(6, sy - 4, 20, sy - 3, C["wood_d"])
        b.rect(7, sy - 2, 19, sy + 10, C["gold_d"])
        b.rect(8, sy - 1, 18, sy + 9, C["wood"])
        b.rect(10, sy + 1, 16, sy + 5, C["hay_l"])                            # a mug
        b.rect(16, sy + 2, 17, sy + 4, C["hay_l"])
        b.rect(10, sy + 1, 16, sy + 2, C["white"])
        b.rect(W - 10, H - 11, W - 4, H, C["wood"])                           # barrel by the door
        b.rect(W - 10, H - 8, W - 4, H - 7, C["silver_d"])
    return _wrap(b)


def _stable(variant):
    W, fd, rise = _dims("stable")
    H = fd + rise
    rnd = random.Random(900 + variant)
    b = Canvas(W, H)
    wall_top = H - 24
    for y in range(wall_top, H):                              # vertical boards
        for x in range(W):
            col = ramp("wood_d", "wood", "wood_l")[1 + (1 if x % 5 == 1 else 0)]
            if x % 5 == 4:
                col = C["wood_d"]
            b.px(x, y, col)
    bay = 32
    cx = W // 2
    b.rect(cx - bay // 2 - 2, H - 21, cx + bay // 2 + 2, H, C["wood_d"])
    b.rect(cx - bay // 2, H - 19, cx + bay // 2, H, C["ink2"])
    for i in range(bay):
        if rnd.random() < 0.4:
            b.px(cx - bay // 2 + i, H - 1 - rnd.randint(0, 3), "hay")
    b.rect(cx - bay // 2, H - 21, cx + bay // 2, H - 19, C["wood"])
    b.line(cx - bay // 2, H - 19, cx, H - 3, C["wood_d"])                    # barn-door cross braces
    for xx in (6, W - 10):
        b.rect(xx, wall_top, xx + 3, H, C["wood"])
    loft = (cx - 5, wall_top + 3)                                             # hay loft hatch
    b.rect(loft[0] - 1, loft[1] - 1, loft[0] + 11, loft[1] + 8, C["ink2"])
    b.rect(loft[0], loft[1], loft[0] + 10, loft[1] + 7, C["hay_d"])
    for i in range(8):
        b.px(loft[0] + 1 + i, loft[1] + (i % 3), "hay_l")
    _thatch(b, 0, 0, W, H - 22, hip=6)
    b.rect(W - 18, H - 12, W - 10, H, C["wood"])                              # trough
    b.rect(W - 18, H - 12, W - 10, H - 10, C["wood_l"])
    return _wrap(b)


def _church():
    W, fd, rise = _dims("church")
    H = fd + rise
    b = Canvas(W, H)
    st = ramp("cob0", "cob1", "cob2", "cob3", "cob4")
    sl = ROOFS["church"]
    cx = W // 2
    # nave roof behind the facade
    _roof(b, 26, 26, W - 26, H - 60, sl, hip=6)
    # central gable (stone) with a rose window
    gb = H - 62
    b.triangle(cx, gb - 22, gb, 30, [st[1], st[2], st[3], st[3]])
    b.rect(30, gb, W - 30, H, st[2])
    for yy in range(gb, H - 4, 8):
        b.rect(30, yy + 7, W - 30, yy + 8, st[1])
    b.ellipse(cx, gb - 3, 9, 9, "ink2")
    b.ellipse(cx, gb - 3, 7.5, 7.5, "purple")
    for ax, ay in ((0, -7), (0, 7), (-7, 0), (7, 0), (5, 5), (-5, -5), (5, -5), (-5, 5)):
        b.line(cx, gb - 3, cx + ax, gb - 3 + ay, C["gold_d"])
    b.ellipse(cx, gb - 3, 2.2, 2.2, "gold")
    b.px(cx - 4, gb - 6, "glass_l")
    b.px(cx + 3, gb - 1, "red_l")
    b.rect(cx - 1, gb - 28, cx + 1, gb - 20, C["gold"])                       # gable cross
    b.rect(cx - 3, gb - 26, cx + 3, gb - 25, C["gold"])
    # twin towers with spires
    for tx in (4, W - 4 - 30):
        tcx = tx + 15
        for y in range(46, H):
            for x in range(tx, tx + 30):
                col = st[2]
                if (y - 46) % 7 == 6:
                    col = st[1]
                elif x - tx < 3:
                    col = st[3]
                elif x >= tx + 27:
                    col = st[1]
                b.px(x, y, col)
        b.rect(tx - 1, 44, tx + 31, 48, st[3])                                # cornice
        b.rect(tx - 1, 47, tx + 31, 48, st[1])
        b.triangle(tcx, 6, 44, 18, [sl[0], sl[1], sl[2], sl[2]])
        b.rect(tcx - 1, 0, tcx + 1, 9, C["gold"])
        b.rect(tcx - 3, 3, tcx + 3, 4, C["gold"])
        # pointed belfry opening and a lancet window
        for dy in range(10):
            hw = 4 if dy > 3 else dy // 1 + 1
            b.rect(tcx - min(4, hw), 56 + dy, tcx + min(4, hw), 57 + dy, C["ink2"])
        b.rect(tcx - 4, 62, tcx + 4, 68, C["ink2"])
        b.rect(tcx - 1, 56, tcx + 1, 68, C["slate_l"])
        for wy in (86, 108):
            b.rect(tcx - 2, wy, tcx + 2, wy + 12, C["ink2"])
            b.rect(tcx - 1, wy + 1, tcx + 1, wy + 11, C["glass"])
            b.px(tcx - 1, wy + 1, "glass_l")
        # buttress
        b.rect(tx + 28, H - 40, tx + 32 if tx < 20 else tx + 31, H, st[3])
    # pointed portal, archivolt, doors
    px_, ph = cx, H - 34
    for dy in range(34):
        hw = 11 if dy > 10 else int(11 * (dy + 2) / 12.0)
        b.rect(px_ - hw - 2, ph + dy, px_ + hw + 2, ph + dy + 1, st[4])
    for dy in range(30):
        hw = 9 if dy > 9 else int(9 * (dy + 2) / 11.0)
        b.rect(px_ - hw, ph + 4 + dy, px_ + hw, ph + 5 + dy, C["ink2"])
    for dy in range(26):
        hw = 7 if dy > 8 else int(7 * (dy + 2) / 10.0)
        b.rect(px_ - hw, ph + 8 + dy, px_ + hw, ph + 9 + dy, C["wood"])
    b.rect(px_, ph + 10, px_ + 1, H, C["wood_d"])
    for yy in (ph + 18, ph + 26):
        b.rect(px_ - 7, yy, px_ + 7, yy + 1, C["silver_d"])
    # nave lancets with stained glass either side of the portal
    for wx in (cx - 24, cx + 22):
        b.rect(wx - 1, H - 46, wx + 5, H - 12, C["ink2"])
        for dy in range(4):
            b.rect(wx + 2 - dy // 2 - 1, H - 49 + dy, wx + 2 + dy // 2 + 2, H - 48 + dy, C["ink2"])
        for i, col in enumerate(("purple_l", "red", "gold", "glass_l", "purple_l")):
            b.rect(wx, H - 44 + i * 6, wx + 4, H - 39 + i * 6, C[col])
        b.rect(wx + 2, H - 44, wx + 3, H - 12, C["ink2"])
    return _wrap(b)


def _windmill():
    W, fd, rise = _dims("windmill")
    H = fd + rise
    b = Canvas(W, H)
    cx = W // 2
    top, bot = 52, H - 12
    for y in range(top, bot):
        t = (y - top) / float(bot - top)
        half = int(15 + 8 * t)
        for x in range(cx - half, cx + half):
            lit = (x - (cx - half)) / float(2 * half)
            col = C["plaster_l"] if lit < 0.25 else (C["plaster"] if lit < 0.65 else C["plaster_d"])
            if (y - top) % 7 == 6:
                col = C["plaster_d"] if lit < 0.65 else C["rag_d"]
            b.px(x, y, col)
    # stone plinth across the footprint
    _stone_rows(b, 2, H - 14, W - 2, H, ramp("cob0", "cob1", "cob2", "cob3"), seed=4)
    b.rect(2, H - 15, W - 2, H - 14, C["cob4"])
    # door and windows
    _arched_door(b, cx - 3, H - 14, 6, 11)
    for wy, wx in ((top + 8, cx - 2), (top + 22, cx - 2)):
        b.rect(wx - 1, wy - 1, wx + 5, wy + 7, C["ink2"])
        b.rect(wx, wy, wx + 4, wy + 6, C["lit"])
        b.rect(wx, wy, wx + 1, wy + 2, C["lit_l"])
    b.rect(cx - 25, top + 34, cx + 25, top + 37, C["wood"])                   # gallery
    b.rect(cx - 25, top + 34, cx + 25, top + 35, C["wood_l"])
    # cap
    b.triangle(cx, 22, top + 2, 21, [C["shingle_d"], C["shingle"], C["shingle_l"], C["shingle_l"]])
    b.rect(cx - 21, top, cx + 21, top + 3, C["wood_d"])
    # sails in front
    hx, hy = cx, 44
    b.ellipse(hx, hy, 4, 4, "wood_l")
    for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        for t in range(7, 35):
            px0, py0 = hx + sx * t * 0.707, hy + sy * t * 0.707
            for s in range(-3, 4):
                ox, oy = int(round(px0 + sy * s * 0.707 * sx * -1)), int(round(py0 + sx * s * 0.707))
                ox2, oy2 = int(round(px0 - sx * sy * s * 0.707)), int(round(py0 + s * 0.707))
                col = C["bone"] if (t // 4) % 2 else C["plaster_l"]
                b.px(ox2, oy2, col)
        b.line(hx, hy, int(hx + sx * 36 * 0.707), int(hy + sy * 36 * 0.707), C["wood_d"])
        b.line(hx + 1, hy, int(hx + sx * 36 * 0.707) + 1, int(hy + sy * 36 * 0.707), C["wood"])
    b.ellipse(hx, hy, 2.5, 2.5, "gold_d")
    return _wrap(b)


def _tower():
    W, fd, rise = _dims("tower")
    H = fd + rise
    b = Canvas(W, H)
    st = ramp("cob0", "cob1", "cob2", "cob3", "cob4")
    cx = W // 2
    for y in range(34, H):
        for x in range(2, W - 2):
            col = st[2]
            if (y - 34) % 6 == 5 or ((x + ((y - 34) // 6) * 5) % 10 == 9):
                col = st[1]
            elif x < 6:
                col = st[3]
            elif x >= W - 6:
                col = st[1]
            b.px(x, y, col)
    b.rect(0, 33, W, 38, st[3])                                               # corbelled ledge
    b.rect(0, 37, W, 38, st[1])
    for x in range(0, W, 8):
        b.rect(x, 33, x + 4, 31, st[4])                                       # little merlons under the cone
    for yy in (48, 66):
        b.rect(cx - 1, yy, cx + 1, yy + 8, C["ink2"])                          # arrow slits
    b.rect(cx - 3, 40, cx + 3, 43, C["wood_d"])
    b.triangle(cx, 4, 34, 24, [C["slate_d"], C["slate"], C["slate_l"], C["slate_l"]])
    b.rect(cx, 0, cx + 1, 8, C["wood"])                                       # pennant
    b.rect(cx + 1, 1, cx + 7, 5, C["red"])
    b.px(cx + 7, 3, "red_l")
    b.rect(2, H - 3, W - 2, H, st[0])
    return _wrap(b)


def _wall_h(variant):
    W, fd, rise = _dims("wall_h")
    H = fd + rise
    b = Canvas(W, H)
    st = ramp("cob0", "cob1", "cob2", "cob3", "cob4")
    for x in range(W):
        if x % 16 < 8:
            for y in range(0, 5):
                b.px(x, y, st[4] if y < 2 else (st[3] if x % 16 > 1 else st[4]))
            b.px(x, 4, st[1])
    for y in range(5, 12):
        for x in range(W):
            b.px(x, y, st[3] if y > 5 else st[4])
    _stone_rows(b, 0, 12, W, H, st[:4], seed=variant)
    for x in range(7, W, 16):
        b.rect(x, 17, x + 2, 23, C["ink2"])
    return _wrap(b)


def _wall_v(variant):
    """North-south wall seen from the south: the top face, with a crenellated
    parapet down each side. Seamless along its length (period 16 px)."""
    W, fd, rise = _dims("wall_v")
    H = fd + rise
    b = Canvas(W, H)
    st = ramp("cob0", "cob1", "cob2", "cob3", "cob4")
    for y in range(H):
        for x in range(W):
            if x < 4 or x >= W - 4:
                inner = y % 16 < 9                              # merlon block vs gap
                if inner:
                    col = st[4] if (x in (1, 2) or (x == W - 4 and False)) else st[3]
                    if y % 16 == 0:
                        col = st[4]
                    if x in (0, W - 1) or y % 16 == 8:
                        col = st[1]
                else:
                    col = st[2]                                 # gap: walkway shows
            else:
                col = st[3] if (x + (y // 4) * 3) % 8 else st[2]   # flagstone walkway
                if y % 8 == 7:
                    col = st[2]
            b.px(x, y, col)
    return _wrap(b)


def _fence_h(variant):
    W, fd, rise = _dims("fence_h")
    H = fd + rise
    b = Canvas(W, H)
    for yy, hh in ((H - 11, 2), (H - 6, 2)):                                  # rails
        b.rect(0, yy, W, yy + hh, C["wood_l"])
        b.rect(0, yy + hh, W, yy + hh + 1, C["wood_d"])
    for x in (6, W - 8):                                                      # posts
        b.rect(x, H - 14, x + 3, H, C["wood"])
        b.rect(x, H - 14, x + 1, H, C["wood_l"])
        b.rect(x + 2, H - 14, x + 3, H, C["wood_d"])
    return _wrap(b)


def _fence_v(variant):
    W, fd, rise = _dims("fence_v")
    H = fd + rise
    b = Canvas(W, H)
    b.rect(1, 0, W - 1, H, C["wood_l"])
    b.rect(W - 2, 0, W - 1, H, C["wood_d"])
    for y in (4, H // 2 + 3):
        b.rect(0, y, W, y + 5, C["wood"])
        b.rect(0, y, W, y + 1, C["wood_l"])
    return _wrap(b)


def build(kind, variant=0):
    if kind in ("house_s", "house_m", "house_l", "tavern", "shed"):
        return _house(kind, variant)
    return {"stable": _stable, "church": lambda v: _church(), "windmill": lambda v: _windmill(),
            "tower": lambda v: _tower(), "wall_h": _wall_h, "wall_v": _wall_v,
            "fence_h": _fence_h, "fence_v": _fence_v}[kind](variant)
