# Gothic-pixel theme for the whole game. The pictures live in game/gui/ (made by
# tools/make_gui_assets.py); the numbers (fonts, colours, borders, sizes) are in
# gui.rpy; this file only holds the style tweaks gui.rpy cannot express.
# It sits after screens.rpy in init order, so these override the stock styles.

init offset = 5

# Radio buttons and check boxes are text with a pixel glyph, not button plates.
style radio_button:
    background None
style check_button:
    background None

# The 9-slice art needs 12 px of border, so the text padding is set here.
style navigation_button:
    padding (24, 12, 24, 18)
style choice_button:
    padding (60, 14, 60, 20)
style confirm_button:
    padding (36, 12, 36, 18)
style page_button:
    padding (18, 10, 18, 16)
style slider_button:
    padding (18, 10, 18, 16)
style mute_all_button:
    background None

style confirm_frame:
    padding (66, 60, 66, 66)
style skip_frame:
    padding (33, 12, 45, 15)
style notify_frame:
    padding (36, 12, 45, 18)

# Titles in blackletter.
style game_menu_label_text:
    font "fonts/PirataOne-Regular.ttf"
    size 84
    outlines [(4, "#120e18", 0, 4)]
style main_menu_title:
    font "fonts/PirataOne-Regular.ttf"
    size 140
    outlines [(5, "#120e18", 0, 5)]
style main_menu_version:
    size 26
    color "#b8aca4"
style confirm_prompt_text:
    size 40
    color "#e8dcd0"
style say_label:
    outlines [(3, "#120e18", 0, 3)]

# Dialogue stays readable on the dark box.
style say_dialogue:
    color "#e8dcd0"
