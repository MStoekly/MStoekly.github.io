"""Generates placeholder sprites for the hunt minigame into game/images/hunt/.

Run:  python tools/make_hunt_sprites.py
Everything is drawn at 4x and downsampled, so edges are smooth.
Delete a PNG and re-run to regenerate just what is missing? No - it rewrites all.
"""

import os
import random
from PIL import Image, ImageDraw, ImageFilter

S = 4  # supersample factor
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "game", "images", "hunt")


def canvas(size):
    return Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))


def finish(img, size):
    return img.resize((size, size), Image.LANCZOS)


def ellipse(d, cx, cy, rx, ry, fill):
    d.ellipse([(cx - rx) * S, (cy - ry) * S, (cx + rx) * S, (cy + ry) * S], fill=fill)


def glow(size, cx, cy, radius, color, steps=26):
    """Soft radial glow on its own layer."""
    img = canvas(size)
    d = ImageDraw.Draw(img)
    for i in range(steps, 0, -1):
        f = i / float(steps)
        a = int(color[3] * (1.0 - f) ** 2)
        ellipse(d, cx, cy, radius * f, radius * f, color[:3] + (a,))
    return img


def figure(size, cloak, trim, skin, glow_color=None, glow_r=None):
    """Top-down cloaked figure: teardrop cloak + head."""
    base = canvas(size)
    c = size / 2.0
    if glow_color:
        base = Image.alpha_composite(base, glow(size, c, c, glow_r or size * 0.48, glow_color))
    layer = canvas(size)
    d = ImageDraw.Draw(layer)
    # cloak
    ellipse(d, c, c + size * 0.05, size * 0.34, size * 0.38, cloak)
    # shoulders
    ellipse(d, c - size * 0.22, c + size * 0.02, size * 0.14, size * 0.16, cloak)
    ellipse(d, c + size * 0.22, c + size * 0.02, size * 0.14, size * 0.16, cloak)
    # inner trim
    ellipse(d, c, c + size * 0.09, size * 0.22, size * 0.24, trim)
    # head
    ellipse(d, c, c - size * 0.12, size * 0.16, size * 0.16, skin)
    return Image.alpha_composite(base, layer)


def make_vampire(size=76):
    img = figure(size, (18, 9, 14, 255), (120, 14, 30, 255), (232, 220, 210, 255),
                 glow_color=(205, 20, 45, 155), glow_r=size * 0.56)
    d = ImageDraw.Draw(img)
    c = size / 2.0
    # eyes
    ellipse(d, c - size * 0.06, c - size * 0.13, size * 0.028, size * 0.028, (235, 40, 55, 255))
    ellipse(d, c + size * 0.06, c - size * 0.13, size * 0.028, size * 0.028, (235, 40, 55, 255))
    # collar points
    d.polygon([((c - 0.30 * size) * S, (c - 0.10 * size) * S),
               ((c - 0.10 * size) * S, (c - 0.24 * size) * S),
               ((c - 0.08 * size) * S, (c + 0.02 * size) * S)], fill=(140, 16, 32, 255))
    d.polygon([((c + 0.30 * size) * S, (c - 0.10 * size) * S),
               ((c + 0.10 * size) * S, (c - 0.24 * size) * S),
               ((c + 0.08 * size) * S, (c + 0.02 * size) * S)], fill=(140, 16, 32, 255))
    return finish(img, size)


def make_hunter(size=76):
    # Deliberately near-black with a hot orange rim: enemies must never read as prey.
    img = figure(size, (24, 18, 20, 255), (54, 38, 30, 255), (198, 166, 140, 255),
                 glow_color=(255, 120, 20, 165), glow_r=size * 0.58)
    c = size / 2.0
    ImageDraw.Draw(img).ellipse(
        [(c - size * 0.34) * S, (c - size * 0.33) * S,
         (c + size * 0.34) * S, (c + size * 0.43) * S],
        outline=(255, 146, 40, 210), width=2 * S)
    # torch flame, offset to one side
    fx, fy = c + size * 0.26, c - size * 0.24
    img = Image.alpha_composite(img, glow(size, fx, fy, size * 0.30, (255, 170, 40, 200)))
    d = ImageDraw.Draw(img)
    ellipse(d, fx, fy, size * 0.075, size * 0.11, (255, 190, 70, 255))
    ellipse(d, fx, fy - size * 0.02, size * 0.04, size * 0.06, (255, 246, 200, 255))
    return finish(img, size)


PREY_COLORS = [
    ((66, 62, 58, 255), (92, 86, 78, 255), (150, 150, 150, 90)),    # tier 1 peasant
    ((70, 58, 40, 255), (116, 92, 58, 255), (196, 150, 80, 100)),   # tier 2
    ((40, 66, 52, 255), (62, 108, 78, 255), (90, 210, 130, 110)),   # tier 3
    ((38, 50, 82, 255), (60, 84, 140, 255), (90, 150, 255, 120)),   # tier 4 noble
    ((70, 40, 82, 255), (150, 110, 40, 255), (255, 205, 90, 150)),  # tier 5 rare
]


def make_prey(tier, size=64):
    cloak, trim, gl = PREY_COLORS[tier]
    img = figure(size, cloak, trim, (222, 196, 172, 255), glow_color=gl, glow_r=size * 0.5)
    return finish(img, size)


def _soft_light(img, x, y, r, color, steps=14):
    """Alpha-blended glow dot for a torch/window, composited onto img in place."""
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for i in range(steps, 0, -1):
        f = i / float(steps)
        a = int(color[3] * (1.0 - f) ** 2)
        rr = r * f
        d.ellipse([x - rr, y - rr, x + rr, y + rr], fill=color[:3] + (a,))
    return Image.alpha_composite(img, layer)


def make_ground(w=1400, h=820, base=(11, 13, 19), gravel_v=(20, 44), fog=(34, 40, 54, 26),
                lights=0, light_color=(255, 170, 60, 150), light_r=(50, 90), seed=7):
    """One biome's ground texture. Higher `lights` = more torches/windows =
    a more built-up, more dangerous area (forest has none, town is full of them)."""
    img = Image.new("RGBA", (w, h), base + (255,))
    rnd = random.Random(seed)
    fog_layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    fd = ImageDraw.Draw(fog_layer)
    for _ in range(50):
        x, y = rnd.randrange(w), rnd.randrange(h)
        r = rnd.randrange(80, 260)
        fd.ellipse([x - r, y - r * 0.6, x + r, y + r * 0.6], fill=fog)
    fog_layer = fog_layer.filter(ImageFilter.GaussianBlur(45))
    img = Image.alpha_composite(img, fog_layer)

    d = ImageDraw.Draw(img)
    lo, hi = gravel_v
    for _ in range(900):
        x, y = rnd.randrange(w), rnd.randrange(h)
        r = rnd.randrange(1, 4)
        v = rnd.randrange(lo, hi)
        d.ellipse([x - r, y - r, x + r, y + r], fill=(v, v + 3, v + 9, 120))

    for _ in range(lights):
        x, y = rnd.randrange(60, w - 60), rnd.randrange(60, h - 60)
        r = rnd.uniform(*light_r)
        img = _soft_light(img, x, y, r, light_color)

    vg = Image.new("L", (140, 82), 0)
    vd = ImageDraw.Draw(vg)
    steps = 60
    for i in range(steps):
        f = 1.0 - i / float(steps)
        a = int(215 * (f ** 2.2))
        vd.ellipse([70 - 92 * f, 41 - 62 * f, 70 + 92 * f, 41 + 62 * f], fill=255 - a)
    vg = vg.resize((w, h), Image.BICUBIC).filter(ImageFilter.GaussianBlur(24))
    dark = Image.new("RGBA", (w, h), (0, 0, 0, 255))
    dark.putalpha(Image.eval(vg, lambda p: 255 - p))
    return Image.alpha_composite(img, dark)


# One texture per hunt level (see LEVELS in hunt_core.py), easy/quiet to
# hard/built-up: no lights in the forest, dense warm lights in town.
GROUNDS = {
    "ground_forest.png": dict(base=(8, 14, 11), gravel_v=(16, 34),
                              fog=(30, 48, 38, 30), lights=0, seed=101),
    "ground_road.png": dict(base=(14, 12, 10), gravel_v=(28, 50),
                            fog=(46, 40, 32, 24), lights=5,
                            light_color=(255, 168, 60, 130), light_r=(40, 70), seed=102),
    "ground_outskirts.png": dict(base=(11, 13, 19), gravel_v=(20, 44),
                                 fog=(34, 40, 54, 26), lights=9,
                                 light_color=(255, 190, 90, 120), light_r=(45, 80), seed=7),
    "ground_village.png": dict(base=(16, 12, 10), gravel_v=(34, 58),
                               fog=(58, 42, 30, 26), lights=20,
                               light_color=(255, 196, 110, 140), light_r=(45, 85), seed=103),
    "ground_town.png": dict(base=(18, 8, 9), gravel_v=(40, 66),
                            fog=(70, 30, 32, 30), lights=38,
                            light_color=(255, 120, 60, 150), light_r=(40, 80), seed=104),
}


def make_obstacle(size=140):
    """Placeholder obstacle sprite -- a plain grey boulder. Swap for real
    per-biome shapes (trees/rocks/fences/rubble) once the game has its
    visual theme; hunt_core just needs *some* circular image at 2x radius."""
    img = canvas(size)
    d = ImageDraw.Draw(img)
    c = size / 2.0
    ellipse(d, c, c + size * 0.05, size * 0.40, size * 0.34, (26, 24, 26, 130))  # ground shadow
    ellipse(d, c, c - size * 0.02, size * 0.36, size * 0.32, (74, 70, 68, 255))
    ellipse(d, c - size * 0.08, c - size * 0.10, size * 0.20, size * 0.17, (96, 92, 88, 255))
    return finish(img, size)


def make_lunge_ring(size=256):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = size / 2.0
    for i in range(18):
        f = 1.0 - i / 18.0
        r = c * (0.62 + 0.36 * f)
        a = int(200 * (1.0 - f))
        d.ellipse([c - r, c - r, c + r, c + r], outline=(220, 30, 50, a), width=3)
    return img.filter(ImageFilter.GaussianBlur(2))


def main():
    os.makedirs(OUT, exist_ok=True)
    made = []
    def save(img, name):
        p = os.path.join(OUT, name)
        img.save(p)
        made.append((name, img.size))
    save(make_vampire(), "vampire.png")
    save(make_hunter(), "hunter.png")
    for t in range(5):
        save(make_prey(t), "prey_%d.png" % (t + 1))
    for name, kwargs in GROUNDS.items():
        save(make_ground(**kwargs), name)
    save(make_obstacle(), "obstacle.png")
    save(make_lunge_ring(), "lunge_ring.png")
    for name, sz in made:
        print("%-16s %s" % (name, sz))


if __name__ == "__main__":
    main()
