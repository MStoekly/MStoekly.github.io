"""Converts DungeonDraft grid coordinates into the pixel-space obstacle list
hunt_core.py expects.

Read (column, row) straight off DungeonDraft's own coordinate readout while
you place trees/rocks/etc on the map (bottom status bar shows grid position
under the cursor) -- no need to eyeball pixels.

Edit TILE_SIZE and OBSTACLES below, then run:
    python tools/tiles_to_obstacles.py
and paste the printed list into that level's cfg in hunt_core.py, e.g.:
    "obstacles": [ ...paste here... ],

One thing to check in DungeonDraft before reading coordinates: Export ->
if "Add Border" (or similar padding) is on, the grid's (0,0) in the exported
PNG is NOT the same as the grid's (0,0) shown while editing -- turn border
off, or tell me its size in tiles and I'll add an offset.
"""

TILE_SIZE = 70  # px per tile -- DungeonDraft's default project grid size

# Each entry: (tile_col, tile_row, size_in_tiles)
#   tile_col, tile_row -- grid position under the object (can be fractional
#                         if you nudged it off-grid)
#   size_in_tiles       -- roughly how many tiles across the object is
#                         (1 = fits in one tile, 2 = a 2x2 footprint, etc;
#                         fractional is fine, e.g. 0.5 for something small)
OBSTACLES = [
    (4, 2, 1.0),
    (9, 6, 1.5),
    (15, 3, 0.75),
]


def main():
    print('    "obstacles": [')
    for col, row, size_tiles in OBSTACLES:
        px = (col + 0.5) * TILE_SIZE
        py = (row + 0.5) * TILE_SIZE
        radius = size_tiles * TILE_SIZE / 2.0
        print("        (%d, %d, %d)," % (round(px), round(py), round(radius)))
    print("    ],")


if __name__ == "__main__":
    main()
