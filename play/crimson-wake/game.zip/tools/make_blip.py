"""Typing blip for the dev-note intro. Synthesized from scratch, no samples.

    python tools/make_blip.py <out.wav> <tri|sq> <low_hz> <high_hz>

Writes a short loop of 20 blips, one every 45 ms (about one per two letters at
45 characters per second), each at a random pitch between low_hz and high_hz.
script.rpy loops it while the dev note types and stops it when the line is done.
"""
import math
import random
import struct
import sys
import wave

RATE = 22050


def make(out, shape, lo, hi, n=20, spacing=0.045, blip=0.030, amp=0.22, seed=7):
    rnd = random.Random(seed)
    total = int(RATE * spacing * n)
    buf = [0.0] * total
    for i in range(n):
        f = rnd.uniform(lo, hi)
        start = int(i * spacing * RATE)
        for k in range(int(blip * RATE)):
            t = k / RATE
            ph = (t * f) % 1.0
            w = (1.0 if ph < 0.25 else -1.0) if shape == "sq" else (4.0 * abs(ph - 0.5) - 1.0)
            env = math.exp(-t * 90.0) * min(1.0, k / (0.002 * RATE))
            buf[start + k] += w * env * amp
    with wave.open(out, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(b"".join(struct.pack("<h", int(max(-1.0, min(1.0, v)) * 32767)) for v in buf))


if __name__ == "__main__":
    make(sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4]))
