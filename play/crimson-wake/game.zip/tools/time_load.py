"""Time each stage of a level load (what hunt_run does behind the loading screen). python tools/time_load.py"""
import os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "game", "python-packages"))
import hunt_core, pixel_art
for i, lv in enumerate(hunt_core.LEVELS):
    t0 = time.time(); cfg = hunt_core.level_cfg(i); t1 = time.time()
    g = hunt_core.HuntGame(config=cfg, upgrades={"speed": 0, "constitution": 0, "allure": 0, "strength": 0}); t2 = time.time()
    png = pixel_art.ground_png(g.map, 3); t3 = time.time()
    print("%-9s mapgen %.2fs  HuntGame %.2fs  ground+png %.2fs  (%d KB png, %d objects)" % (lv["key"], t1 - t0, t2 - t1, t3 - t2, len(png) // 1024, len(g.map["objects"])))
