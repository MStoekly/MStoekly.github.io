# Where blood turns into permanent upgrades. Reads and writes cw_blood and
# cw_upgrades, both declared in hunt.rpy.

init python:
    import store

    CW_MAX_LEVEL = 5
    CW_BLINK_COST = 2500          # one level, only after Swiftness is maxed

    CW_UPGRADES = [
        ("speed", "Swiftness",
         "Move faster. The hunters keep pace with you, so this buys reach, not escape."),
        ("constitution", "Constitution",
         "One more touch before the night takes you."),
        ("allure", "Allure",
         "Feed from further away, and draw richer prey into the street."),
        ("strength", "Strength",
         "A wider lunge, more often. It staggers hunters; only they can kill each other."),
    ]

    # Blink is not a fifth upgrade. Once Swiftness is 5 / 5 the MAXED mark on its
    # card turns into a button that unlocks Blink.
    CW_BLINK_OFFER = "Swiftness is mastered. Unlock Blink: press F to pass through walls and buildings."
    CW_BLINK_OWNED = "Mastered. Blink unlocked: press F to pass through walls and buildings."

    def cw_blurb(key, blurb):
        if key == "speed":
            if cw_blink_offer():
                return CW_BLINK_OFFER
            if store.cw_upgrades.get("blink", 0) >= 1:
                return CW_BLINK_OWNED
        return blurb

    def cw_blink_offer():
        """True while Swiftness is maxed and Blink is not bought yet."""
        return (store.cw_upgrades.get("speed", 0) >= CW_MAX_LEVEL
                and store.cw_upgrades.get("blink", 0) < 1)

    def cw_max(key):
        return 1 if key == "blink" else CW_MAX_LEVEL

    def cw_cost(level, key=None):
        """Blood for the next level, or None if already maxed."""
        if level >= cw_max(key):
            return None
        if key == "blink":
            return CW_BLINK_COST
        return int(round(100 * (1.9 ** level) / 10.0) * 10)

    def cw_buy(key):
        level = store.cw_upgrades.get(key, 0)      # .get: saves from before Blink have no such key
        cost = cw_cost(level, key)
        if cost is None or store.cw_blood < cost or (key == "blink" and not cw_blink_offer()):
            return
        store.cw_blood -= cost
        store.cw_upgrades[key] = level + 1
        renpy.restart_interaction()


screen blood_shop():
    modal True
    add cw_backdrop()

    frame:
        background cw_panel("stone")
        align (0.5, 0.5)
        padding (64, 44, 64, 52)

        vbox:
            spacing 14

            hbox:
                xsize 1600
                text "Blood Market" style "cw_title" yalign 0.5
                hbox:
                    xalign 1.0
                    yalign 0.5
                    spacing 14
                    add cw_drop(True) yalign 0.5
                    text ("%d" % cw_blood) style "cw_label" size 52 color CW_GOLD yalign 0.5

            add cw_divider(110) xalign 0.5
            null height 4

            hbox:
                spacing 32

                # Character preview. Only Allure changes anything for now: a
                # red aura that grows with its level, so buying it pays off
                # immediately. Hook point for per-upgrade art later.
                frame:
                    background cw_card("dim")
                    xsize 400
                    ysize 584
                    padding (15, 15)

                    add cw_backdrop()
                    fixed:
                        xalign 0.5
                        yalign 0.46
                        xysize (340, 340)

                        if cw_upgrades["allure"] > 0:
                            add cw_ring(14 + 3 * cw_upgrades["allure"]) at cw_aura_glow:
                                xalign 0.5
                                yalign 0.5
                        add cw_vampire(10):
                            xalign 0.5
                            yalign 0.5

                    text "Dorak" style "cw_h2" xalign 0.5 yalign 1.0 yoffset -92
                    text ("Allure  %d / %d" % (cw_upgrades["allure"], CW_MAX_LEVEL)) style "cw_dim" xalign 0.5 yalign 1.0 yoffset -48

                vbox:
                    spacing 12

                    for key, title, blurb in CW_UPGRADES:
                        $ level = cw_upgrades.get(key, 0)
                        $ mx = cw_max(key)
                        $ cost = cw_cost(level, key)
                        $ offer = (key == "speed" and cw_blink_offer())

                        frame:
                            background cw_card("blood" if offer else ("gold" if cost is None else "stone"))
                            xsize 1150
                            ysize 140
                            padding (28, 10, 28, 12)

                            hbox:
                                spacing 24
                                yalign 0.5

                                frame:
                                    background cw_card("dim")
                                    xysize (96, 96)
                                    padding (15, 15)
                                    yalign 0.5
                                    add cw_icon(key, 3) align (0.5, 0.5)

                                vbox:
                                    xsize 500
                                    yalign 0.5
                                    text title style "cw_label" size 34
                                    text cw_blurb(key, blurb) style "cw_dim" size 22 color (CW_TEXT if offer else CW_DIM)

                                vbox:
                                    xsize 190
                                    yalign 0.5
                                    spacing 8
                                    text ("Level %d / %d" % (level, mx)) style "cw_text" size 26 xalign 0.5
                                    hbox:
                                        xalign 0.5
                                        spacing 4
                                        for n in range(mx):
                                            add cw_pip(n < level, 3)

                                if offer:
                                    button:
                                        style "cw_button"
                                        xsize 210
                                        yalign 0.5
                                        padding (20, 14, 20, 20)
                                        action Function(cw_buy, "blink")
                                        sensitive (cw_blood >= CW_BLINK_COST)
                                        hbox:
                                            xalign 0.5
                                            spacing 10
                                            add cw_drop(cw_blood >= CW_BLINK_COST, 2) yalign 0.5
                                            text ("%d" % CW_BLINK_COST) style "cw_button_text" yalign 0.5
                                elif cost is None:
                                    text "MAXED" style "cw_label" size 38 color CW_GOLD xsize 210 text_align 0.5 yalign 0.5
                                else:
                                    button:
                                        style "cw_button"
                                        xsize 210
                                        yalign 0.5
                                        padding (20, 14, 20, 20)
                                        action Function(cw_buy, key)
                                        sensitive (cw_blood >= cost)
                                        hbox:
                                            xalign 0.5
                                            spacing 10
                                            add cw_drop(cw_blood >= cost, 2) yalign 0.5
                                            text ("%d" % cost) style "cw_button_text" yalign 0.5

            null height 10
            textbutton "Back to the hunt" style "cw_button" xalign 0.5 action Return(True)
