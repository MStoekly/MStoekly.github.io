"""Random map generator for the Crimson Wake hunt minigame.

Pure data, no Ren'Py and no drawing: generate() returns a dict of objects
(trees, rocks, crates...) with a collision radius each, plus a road for the
road biome. pixel_art.py paints it; hunt_core.py turns the collision radii
into obstacles. Headless-testable:

    python game/python-packages/hunt_mapgen.py

Units: world pixels, 70 per tile (same convention as the rest of hunt_core).
Rules that keep the sim honest (the obstacle resolver has no pathfinding):
  * collision objects keep >= GAP px between their edges, so a 52px-wide
    entity (2x radius 26) can always slip between any two of them;
  * nothing collides within SPAWN_CLEAR of the spawn point;
  * collision objects stay >= EDGE_GAP from the arena border (no pockets
    between an object and the wall);
  * the road band stays free of objects.
"""

import math
import random

TILE = 70.0
GAP = 64.0
EDGE_GAP = 58.0
SPAWN_CLEAR = 170.0

# Collision radii come from the art (pixel_art.footprint): the opaque width
# of each sprite's base, so what you bump into is what you see. Decor kinds
# (bushes) have none.

# Minimum edge-to-edge distance between solids when placing. GAP below is the
# hard floor the passability tests assert; SPACING is the softer, roomier
# target so obstacles read as scattered rather than clumped.
SPACING = 110.0

# biome -> list of (kind, objects per 100 tiles)
BIOMES = {
    "forest":    [("pine", 2.6), ("oak", 2.6), ("dead", 0.4), ("rock", 0.9), ("grave", 0.5), ("bush", 7.0)],
    "road":      [("oak", 1.0), ("pine", 0.6), ("rock", 1.4), ("bush", 6.0), ("grave", 0.2)],
    "outskirts": [("oak", 0.8), ("hay", 1.8), ("crate", 0.8), ("barrel", 0.8), ("bush", 4.0), ("lamp", 0.4)],
    "village":   [("crate", 1.4), ("barrel", 1.4), ("lamp", 1.0), ("well", 0.25), ("oak", 0.4), ("bush", 2.0)],
    "town":      [("lamp", 1.4), ("crate", 1.4), ("barrel", 1.6), ("well", 0.2), ("grave", 0.3)],
}


def road_center(road, wx):
    """y of the road's centreline at world x."""
    return road["cy"] + road["amp"] * math.sin(wx * road["freq"] + road["phase"])


def _radius(kind, variant):
    import pixel_art      # local import: pixel_art imports this module
    if not pixel_art.OBJECTS[kind]["solid"]:
        return 0.0
    return pixel_art.footprint(kind, variant)["r"] * TILE / pixel_art.TILE_PX


def generate(biome, tiles_w, tiles_h, seed=None, spawn=None):
    if seed is None:
        seed = random.SystemRandom().randrange(1, 2 ** 31)
    rnd = random.Random(seed)
    W, H = tiles_w * TILE, tiles_h * TILE
    if spawn is None:
        spawn = (W / 2.0, H / 2.0)

    road = None
    if biome == "road":
        road = {"cy": H * rnd.uniform(0.40, 0.60), "amp": H * rnd.uniform(0.10, 0.20),
                "freq": rnd.uniform(1.2, 2.2) * math.pi / W, "phase": rnd.uniform(0, 2 * math.pi),
                "half": 78.0}

    objects = []        # dicts: kind, variant, x, y, r
    solid = []          # (x, y, r) of collision objects, for gap checks

    area = tiles_w * tiles_h / 100.0
    table = BIOMES[biome]
    # place big things first so small ones fit around them
    order = sorted(table, key=lambda t: -max(_radius(t[0], 0), _radius(t[0], 1)))
    for kind, per100 in order:
        n = int(round(per100 * area + rnd.uniform(-0.5, 0.5)))
        for _ in range(max(0, n)):
            for _try in range(40):
                variant = rnd.randint(0, 7)
                r = _radius(kind, variant)
                y = rnd.uniform(EDGE_GAP + r, H - EDGE_GAP - r) if r else rnd.uniform(20, H - 20)
                x = rnd.uniform(EDGE_GAP + r, W - EDGE_GAP - r) if r else rnd.uniform(20, W - 20)
                if road is not None and abs(y - road_center(road, x)) < road["half"] + r + 36.0:
                    continue
                if math.hypot(x - spawn[0], y - spawn[1]) < SPAWN_CLEAR + r:
                    continue
                if r > 0:
                    if any(math.hypot(x - sx, y - sy) < sr + r + SPACING for sx, sy, sr in solid):
                        continue
                    solid.append((x, y, r))
                else:
                    if any(math.hypot(x - sx, y - sy) < sr + 14.0 for sx, sy, sr in solid):
                        continue
                objects.append({"kind": kind, "variant": variant, "x": x, "y": y, "r": r})
                break

    objects.sort(key=lambda o: o["y"])
    return {"biome": biome, "seed": seed, "tiles_w": tiles_w, "tiles_h": tiles_h,
            "w": W, "h": H, "spawn": spawn, "road": road, "objects": objects}


def obstacles_of(game_map):
    """(x, y, r) collision circles for HuntGame."""
    return [(o["x"], o["y"], o["r"]) for o in game_map["objects"] if o["r"] > 0]


def _selftest():
    ok = True

    def check(label, cond):
        print("%-60s %s" % (label, "PASS" if cond else "FAIL"))
        return cond

    sizes = {"forest": (34, 22), "road": (40, 26), "outskirts": (48, 30), "village": (56, 34), "town": (64, 40)}
    for biome, (tw, th) in sorted(sizes.items()):
        bad_gap = bad_spawn = bad_edge = bad_road = 0
        counts = []
        for seed in range(40):
            m = generate(biome, tw, th, seed)
            sol = [o for o in m["objects"] if o["r"] > 0]
            counts.append(len(sol))
            for i, a in enumerate(sol):
                if a["x"] - a["r"] < EDGE_GAP - 1e-6 or a["y"] - a["r"] < EDGE_GAP - 1e-6 \
                        or a["x"] + a["r"] > m["w"] - EDGE_GAP + 1e-6 or a["y"] + a["r"] > m["h"] - EDGE_GAP + 1e-6:
                    bad_edge += 1
                if math.hypot(a["x"] - m["spawn"][0], a["y"] - m["spawn"][1]) < SPAWN_CLEAR + a["r"] - 1e-6:
                    bad_spawn += 1
                if m["road"] and abs(a["y"] - road_center(m["road"], a["x"])) < m["road"]["half"] + a["r"]:
                    bad_road += 1
                for b in sol[i + 1:]:
                    if math.hypot(a["x"] - b["x"], a["y"] - b["y"]) - a["r"] - b["r"] < GAP - 1e-6:
                        bad_gap += 1
        ok &= check("%s x40: gaps>=%d, edge, spawn, road all clean (avg %.1f solids)"
                    % (biome, GAP, sum(counts) / float(len(counts))),
                    bad_gap == bad_spawn == bad_edge == bad_road == 0 and min(counts) > 0)
    a, b = generate("forest", 30, 22, 5), generate("forest", 30, 22, 5)
    ok &= check("same seed -> identical map", a == b)
    ok &= check("different seed -> different map", generate("forest", 30, 22, 6)["objects"] != a["objects"])
    return ok


if __name__ == "__main__":
    import sys
    sys.exit(0 if _selftest() else 1)
