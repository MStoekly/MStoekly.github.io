# The hunt minigame: you are the vampire, prey is currency, hunters are the cost.
# Rules and tuning live in game/python-packages/hunt_core.py (restart the game
# after editing it -- Shift+R does not re-import python packages).

init python:
    import math
    import hunt_core
    import pygame_sdl2 as pygame

    # Where the arena sits inside the 1920x1080 window, and the box its
    # rendering is scaled to fit -- whatever the level's actual arena_w/h is,
    # the whole map is always visible, just smaller for a bigger map.
    HUNT_X = 260
    HUNT_Y = 170
    DISPLAY_W = 1400.0
    DISPLAY_H = 820.0

    # Per-level track, keyed by LEVELS[i]["key"] -- not derived from the
    # display name, since those don't always match the file (e.g. the
    # village level is named "Blackmere Village" but its track is
    # "Blackmere Gate.mp3"). Add new entries here as tracks arrive.
    HUNT_MUSIC = {
        "forest": "music/Wailing Wood.mp3",
        "road": "music/Old Coast Road.mp3",
        "outskirts": "music/Village Outskirts.mp3",
        "village": "music/Blackmere Gate.mp3",
        "town": "music/Harrow's Gate.mp3",
    }

    class HuntDisplayable(renpy.Displayable):

        MOVE = {
            pygame.K_LEFT: (-1, 0), pygame.K_a: (-1, 0),
            pygame.K_RIGHT: (1, 0), pygame.K_d: (1, 0),
            pygame.K_UP: (0, -1), pygame.K_w: (0, -1),
            pygame.K_DOWN: (0, 1), pygame.K_s: (0, 1),
        }

        DEATH_PAUSE = 1.1

        def __init__(self, game, level, **kwargs):
            super(HuntDisplayable, self).__init__(**kwargs)
            self.game = game
            self.held = set()
            self.lunge_queued = False
            self.last_st = None
            self.end_at = None
            self.result_ready = False
            self.vfx = []

            self.level_name = level["name"]
            self.scale = min(DISPLAY_W / game.w, DISPLAY_H / game.h)
            self.ox = HUNT_X + (DISPLAY_W - game.w * self.scale) / 2.0
            self.oy = HUNT_Y + (DISPLAY_H - game.h * self.scale) / 2.0
            self.ground = Image("images/hunt/%s" % level["ground"])
            # Optional canopy/overhang layer, drawn AFTER every entity so it
            # occludes them -- lets a tall tree's top visually cover the
            # vamp/hunters/prey while they're standing "under" it, instead
            # of everyone drawing on top of painted foliage. Silent no-op
            # (same pattern as music) until level["ground_top"] is set AND
            # that file actually exists.
            top_name = level.get("ground_top")
            self.ground_top = None
            if top_name and renpy.loadable("images/hunt/%s" % top_name):
                self.ground_top = Image("images/hunt/%s" % top_name)
            self.im_vamp = Image("images/hunt/vampire.png")
            self.im_hunter = Image("images/hunt/hunter.png")
            self.im_prey = [Image("images/hunt/prey_%d.png" % (i + 1)) for i in range(5)]
            self.im_ring = Image("images/hunt/lunge_ring.png")
            self.im_obstacle = Image("images/hunt/obstacle.png")
            self.obstacle_base_radius = 70.0  # obstacle.png is 140px across
            self.red = Solid("#c81428")
            self.bar_bg = Solid("#00000099")
            self.bar_fill = Solid("#c81428")
            self.bar_full = Solid("#e8c04a")
            self.heart_empty = Solid("#3a2a2e")
            self._text = {}

        # -- helpers -----------------------------------------------------

        def label(self, s, size=36, color="#e8dcd0"):
            key = (s, size, color)
            d = self._text.get(key)
            if d is None:
                if len(self._text) > 300:
                    self._text.clear()
                d = Text(s, size=size, color=color)
                self._text[key] = d
            return d

        def add_vfx(self, kind, x, y, life, extra=0):
            self.vfx.append({"kind": kind, "x": x, "y": y, "t": 0.0,
                             "life": life, "extra": extra})

        def on_event(self, e):
            kind, x, y, a, _b = e
            if kind == "feed":
                self.add_vfx("feed", x, y, 0.95, a)
            elif kind == "clash":
                self.add_vfx("clash", x, y, 0.35)
            elif kind == "lunge":
                self.add_vfx("lunge", x, y, 0.45, a)
            elif kind == "hurt":
                self.add_vfx("hurt", x, y, 0.55)

        # -- frame -------------------------------------------------------

        def render(self, width, height, st, at):
            g = self.game

            if self.last_st is None:
                self.last_st = st
            dt = st - self.last_st
            self.last_st = st
            if dt < 0.0:
                dt = 0.0
            elif dt > 0.05:      # a lag spike must not teleport anyone
                dt = 0.05

            if not g.over:
                mx = my = 0
                for k in self.held:
                    d = self.MOVE.get(k)
                    if d:
                        mx += d[0]
                        my += d[1]
                mx = max(-1, min(1, mx))
                my = max(-1, min(1, my))
                for e in g.update(dt, mx, my, self.lunge_queued):
                    self.on_event(e)
                self.lunge_queued = False
                if g.over:
                    self.end_at = st + self.DEATH_PAUSE
            elif self.end_at is not None and st >= self.end_at:
                self.result_ready = True
                renpy.timeout(0.0)

            for v in self.vfx:
                v["t"] += dt
            self.vfx = [v for v in self.vfx if v["t"] < v["life"]]

            return self.draw(width, height, st, at)

        def draw(self, width, height, st, at):
            g = self.game
            sc = self.scale
            r = renpy.Render(width, height)

            ox, oy = self.ox, self.oy

            def put(d, cx, cy):
                # cx/cy are world coordinates; d may already carry its own
                # zoom/rotate/alpha from the caller -- scale is applied on
                # top of that, uniformly, both to size and to position.
                rend = renpy.render(Transform(d, zoom=sc), width, height, st, at)
                w, h = rend.get_size()
                r.blit(rend, (int(ox + cx * sc - w / 2), int(oy + cy * sc - h / 2)))

            ground_rend = renpy.render(Transform(self.ground, zoom=sc), width, height, st, at)
            r.blit(ground_rend, (int(ox), int(oy)))

            for o in g.obstacles:
                if not o.visible:
                    continue   # collision-only, e.g. tree-trunk scatter -- art's already in the ground image
                z = o.radius / self.obstacle_base_radius
                put(Transform(self.im_obstacle, zoom=z), o.x, o.y)

            for p in g.prey:
                put(self.im_prey[p.tier], p.x, p.y)

            for h in g.hunters:
                d = self.im_hunter
                if h.stun > 0.0:
                    d = Transform(d, alpha=0.55)
                put(d, h.x, h.y)

            # blink while invulnerable so the player can read the i-frames;
            # rotate to face the last direction moved (sprite art faces up/north
            # at rotate=0, and Ren'Py rotate is clockwise degrees)
            if g.invuln <= 0.0 or int(g.invuln * 14) % 2 == 0:
                heading = math.degrees(g.facing) + 90.0
                put(Transform(self.im_vamp, rotate=heading, rotate_pad=False), g.x, g.y)

            for v in self.vfx:
                p = v["t"] / v["life"]
                a = max(0.0, 1.0 - p)
                k = v["kind"]
                if k == "lunge":
                    z = (v["extra"] * 2.0 / 256.0) * (0.55 + 0.45 * p)
                    put(Transform(self.im_ring, zoom=z, alpha=a), v["x"], v["y"])
                elif k == "clash":
                    z = (110.0 / 256.0) * (0.35 + 1.3 * p)
                    put(Transform(self.im_ring, zoom=z, alpha=a), v["x"], v["y"])
                elif k == "feed":
                    put(Transform(self.label("+%d" % v["extra"], 34, "#ff5f6e"), alpha=a),
                        v["x"], v["y"] - 70.0 * p)
                elif k == "hurt":
                    flash = Transform(self.red, alpha=0.45 * a)
                    r.blit(renpy.render(flash, int(g.w * sc), int(g.h * sc), st, at), (int(ox), int(oy)))

            if self.ground_top is not None:
                # last thing drawn over the whole world layer -- obstacles,
                # prey, hunters, vamp, and all vfx (lunge rings, feed text,
                # hurt flash) all sit "under" the canopy, matching real depth.
                # Only the persistent HUD (drawn next) stays above it.
                top_rend = renpy.render(Transform(self.ground_top, zoom=sc), width, height, st, at)
                r.blit(top_rend, (int(ox), int(oy)))

            self.draw_hud(r, width, height, st, at)
            renpy.redraw(self, 0)
            return r

        def draw_hud(self, r, width, height, st, at):
            g = self.game

            def blit(d, x, y, w=None, h=None):
                # w may legitimately be 0 (empty cooldown bar), so test for None.
                rw = width if w is None else max(0, int(w))
                rh = height if h is None else max(0, int(h))
                r.blit(renpy.render(d, rw, rh, st, at), (int(x), int(y)))

            blit(self.label(self.level_name, 26, "#8a7f78"), HUNT_X, 40)
            blit(self.label("BLOOD", 28, "#8a7f78"), HUNT_X, 74)
            blit(self.label("%d" % g.blood, 54, "#e8dcd0"), HUNT_X, 100)

            # hearts
            for i in range(g.max_hp):
                d = self.red if i < g.hp else self.heart_empty
                blit(d, HUNT_X + 240 + i * 40, 116, 28, 28)

            # lunge cooldown
            ready = g.lunge_cd <= 0.0
            frac = 1.0 if ready else 1.0 - (g.lunge_cd / max(g.lunge_cooldown, 0.001))
            blit(self.label("LUNGE", 24, "#8a7f78"), HUNT_X + 240 + g.max_hp * 40 + 60, 96)
            bx = HUNT_X + 240 + g.max_hp * 40 + 60
            blit(self.bar_bg, bx, 126, 220, 16)
            blit(self.bar_full if ready else self.bar_fill, bx, 126, int(220 * frac), 16)

            if g.time < 7.0:
                hint = "WASD / arrows to move    SPACE to lunge    Q to break off"
                blit(Transform(self.label(hint, 30, "#8a7f78"),
                               alpha=min(1.0, (7.0 - g.time) / 1.5)),
                     self.ox, self.oy + g.h * self.scale + 16)

            if g.over:
                blit(self.label("DRAINED", 72, "#c81428"),
                     self.ox + g.w * self.scale / 2 - 150, self.oy + g.h * self.scale / 2 - 40)

        # -- input -------------------------------------------------------

        def event(self, ev, x, y, st):
            if self.result_ready:
                # A tuple is always truthy, so a 0-blood run still ends cleanly.
                return ("hunt_done", self.game.blood)

            if ev.type == pygame.KEYDOWN:
                if ev.key in self.MOVE:
                    self.held.add(ev.key)
                    raise renpy.IgnoreEvent()
                if ev.key == pygame.K_SPACE:
                    self.lunge_queued = True
                    raise renpy.IgnoreEvent()
                if ev.key == pygame.K_q:
                    return ("hunt_done", self.game.blood)

            elif ev.type == pygame.KEYUP:
                if ev.key in self.MOVE:
                    self.held.discard(ev.key)
                    raise renpy.IgnoreEvent()

            return None


default cw_blood = 999999
default cw_upgrades = {"speed": 0, "constitution": 0, "allure": 0, "strength": 0}
default cw_level = 0

# DEBUG: testing cheats, applied on every launch. Comment out either line below independently to disable just that cheat (leave "init python:" and "pass" -- the block needs at least one line in it).
#init python:
#    cw_blood = 999999                                                           # unlimited blood
#    cw_upgrades = {"speed": 5, "constitution": 5, "allure": 5, "strength": 5}   # all upgrades maxed
#    pass


screen hunt_screen(hd):
    modal True
    add Solid("#05060a")
    add hd
    key "game_menu" action NullAction()
    key "rollback" action NullAction()


screen level_select():
    modal True
    add Solid("#07070c")

    $ power = sum(cw_upgrades.values())

    vbox:
        align (0.5, 0.5)
        spacing 16

        text "Choose your hunting ground" size 56 color "#c81428" xalign 0.5
        text ("Vampiric strength: %d" % power) size 28 color "#8a7f78" xalign 0.5
        null height 10

        for i, lv in enumerate(hunt_core.LEVELS):
            $ unlocked = power >= lv["unlock_power"]

            frame:
                xsize 900
                padding (30, 18)

                hbox:
                    xfill True
                    vbox:
                        xsize 620
                        yalign 0.5
                        text lv["name"] size 34 color ("#e8dcd0" if unlocked else "#4a4441")
                        if unlocked:
                            text ("payout x%.2f" % lv["cfg"].get("blood_mult", 1.0)) size 22 color "#8a7f78"
                        else:
                            text ("requires %d vampiric strength" % lv["unlock_power"]) size 22 color "#6a4a4a"

                    if unlocked:
                        textbutton "Hunt" action [SetVariable("cw_level", i), Return("hunt")] xalign 1.0
                    else:
                        text "LOCKED" size 28 color "#4a4441" xalign 1.0

        null height 10
        textbutton "Blood Market" action Return("shop") xalign 0.5


screen hunt_results(earned, fed, secs):
    modal True
    add Solid("#000000cc")

    frame:
        align (0.5, 0.5)
        padding (70, 50)
        has vbox
        spacing 18

        text "The night closes in" size 52 color "#c81428"
        null height 10
        text ("Blood taken     %d" % earned) size 38
        text ("Prey drained    %d" % fed) size 38
        text ("Survived        %d s" % secs) size 38
        null height 10
        text ("Blood on hand   %d" % cw_blood) size 34 color "#8a7f78"
        null height 20

        textbutton "Hunt again" action Return("again")
        textbutton "Choose another hunting ground" action Return("lobby")
        textbutton "Blood market" action Return("shop")
        textbutton "Leave the streets" action Return("leave")


label hunt_lobby:
    call screen level_select
    if _return == "shop":
        call screen blood_shop
        jump hunt_lobby
    else:
        jump hunt_run


label hunt_run:
    window hide
    $ _hunt_lv = hunt_core.LEVELS[cw_level]
    $ _hunt_game = hunt_core.HuntGame(config=hunt_core.level_cfg(cw_level), upgrades=cw_upgrades)
    # Per-level music, once it exists -- drop a file at the path below and it
    # starts playing automatically, no code change needed. Silent no-op
    # until then (renpy.loadable check), so this is safe to leave in.
    $ _hunt_track = HUNT_MUSIC.get(_hunt_lv["key"])
    if _hunt_track and renpy.loadable(_hunt_track):
        play music _hunt_track loop fadein 1.0
    call screen hunt_screen(HuntDisplayable(_hunt_game, _hunt_lv))
    $ _hunt_earned = _return[1]
    $ cw_blood += _hunt_earned
    $ _hunt_fed, _hunt_secs = _hunt_game.fed, int(_hunt_game.time)
    $ _hunt_game = None
    call screen hunt_results(_hunt_earned, _hunt_fed, _hunt_secs)
    if _return == "again":
        jump hunt_run
    elif _return == "shop":
        call screen blood_shop
        jump hunt_run
    elif _return == "lobby":
        stop music fadeout 1.0
        jump hunt_lobby
    stop music fadeout 1.0
    return
