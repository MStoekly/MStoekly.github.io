"""Simulation core for the Crimson Wake hunt minigame.

No Ren'Py imports on purpose: this module runs headless, so the game rules can
be tested without launching Ren'Py.

    python game/python-packages/hunt_core.py     # runs the self-test

Ren'Py adds game/python-packages to sys.path automatically, so hunt.rpy can
just `import hunt_core`. Note: editing this file needs a full game restart --
Shift+R does not re-import python packages.

All tuning lives in DEFAULT_CONFIG below.
"""

import math
import random

import hunt_mapgen

DEFAULT_CONFIG = {
    # arena, in pixels (must match the ground.png size used by hunt.rpy)
    "arena_w": 1400,
    "arena_h": 820,

    # radii used for collision, not for drawing
    "vamp_radius": 26.0,
    "hunter_radius": 26.0,

    # movement
    "vamp_speed": 380.0,          # px/sec at upgrade level 0
    "speed_per_level": 0.09,      # +9% per Speed level

    # hunters. Slower than you at rest so you can always shape the pack, but
    # they close hard once they are on top of you -- that is where the pressure
    # comes from now that movement is 8-way and instant-turn.
    "hunter_speed_frac": 0.62,    # fraction of your BASE speed (Speed upgrades don't buff this)
    "hunter_speed_ramp": 0.012,   # +per prey fed
    "hunter_speed_ramp_cap": 0.30,
    "hunter_boost_dist": 260.0,
    "hunter_boost_mult": 1.55,
    "hunter_merge_dist": 46.0,    # two hunters this close destroy each other
    "hunter_spawn_min_dist": 520.0,  # never spawn one on top of you
    "hunter_spawn_max_dist": 1100.0, # ...and not across a huge map either: spawns form a ring around
                                     # you, so pacing doesn't depend on how big the arena is
    "max_hunters": 11,

    # feeding
    "prey_on_map": 3,
    "feed_radius": 42.0,
    "feed_radius_per_allure": 5.0,
    "prey_spawn_min_dist": 340.0,        # from you
    "prey_spawn_max_dist": 900.0,        # from you (same ring idea as hunters)
    "prey_spawn_min_hunter_dist": 150.0, # from any hunter
    "tier_values": [5, 15, 40, 100, 250],
    "tier_weights": [46.0, 27.0, 16.0, 8.0, 3.0],
    "allure_tier_bias": 0.09,     # per level, multiplies weight by (1+bias)**tier
    "blood_mult": 1.0,            # flat payout scaler, used by LEVELS below

    # one night per run: midnight to sunrise in night_length seconds, and the
    # sun ends the run (you bank what you took). Short on purpose, runs are
    # meant to be quick, incremental-game style. 0 turns the cycle off.
    "night_length": 60.0,
    # Surviving to sunrise is hard, so it pays: on top of what you took, you bank
    # dawn_bonus_kills average prey (a flat sum, ~28 blood each at blood_mult 1) plus
    # dawn_bonus_frac of what you took. (Dying banks only what you took.)
    "dawn_bonus_kills": 10,
    "dawn_bonus_frac": 0.0618,

    # Blink (F): a teleport in your move direction that crosses walls and
    # buildings. It lands on the first free spot at blink_dist or beyond (up to
    # blink_reach further); if the far side is out of reach it falls back to the
    # last free spot short of it. Only exists once bought (upgrade "blink",
    # offered on the Swiftness card once that is 5/5).
    "blink_dist": 230.0,
    "blink_reach": 260.0,
    "blink_cd": 6.0,
    "blink_step": 10.0,
    "blink_min": 40.0,            # a blink that would carry you less than this is refused (no cooldown spent)

    # survival
    "hp_base": 2,
    "hp_per_con": 1,
    "invuln_time": 1.4,

    # Drain Life (bought on the Constitution card at 5/5, a passive with no key): a
    # streak of drain_streak kills (feeds, or hunters killed by Bloodlust) with no
    # hit in between heals drain_heal hearts (any multiple of 0.25). Then it rests
    # drain_cd seconds. Nothing is spent while you are at full health: the streak
    # and the timer wait until the heal can actually help.
    "drain_heal": 0.5,
    "drain_cd": 25.0,
    "drain_streak": 3,

    # Ultimate, Harvest (bought once all four skill lines are complete, key R, once per
    # night): time stops for harvest_time seconds. The night clock, the hunter clock,
    # hunters and prey all hold still; you are untouchable and a little faster.
    # Touching a hunter kills it (harvest_kill_blood), touching prey feeds on it
    # (no hunter is summoned). When it ends you get harvest_grace seconds of safety.
    "harvest_time": 5.0,
    "harvest_speed": 1.3,
    "harvest_reach": 14.0,
    "harvest_kill_blood": 60,
    "harvest_grace": 0.8,

    # Strength, levels 1-5: Blood Shock. When a hunter wounds you, the hunters
    # around you are thrown back and stunned (it never kills: killing is what
    # hunter-vs-hunter clashes and Bloodlust are for).
    # Iron Skin (Strength, every level): each level gives block_per_str to shrug off a
    # hunter's touch altogether. No heart is lost and the kill streak survives; the
    # hunter is thrown back and stunned by Blood Shock, which fires as usual.
    "block_per_str": 0.08,
    "block_grace": 0.3,
    "shock_radius": 90.0,
    "shock_radius_per_str": 30.0,
    "shock_knockback": 170.0,
    "shock_stun": 0.40,
    "shock_stun_per_str": 0.15,

    # Charm (unlocked on the Allure card at 5/5, key bound by the player): a pulse
    # around you charms the nearest few hunters/prey for a while. A charmed hunter
    # stops chasing and walks into another hunter (a clash kills both) and cannot
    # hurt you; charmed prey walk to you, and feeding on them does not summon a hunter.
    "charm_radius": 170.0,
    "charm_targets": 3,
    "charm_time": 4.0,
    "charm_cd": 15.0,
    "charm_speed": 1.1,           # charmed hunters walk at this x hunter speed

    # Bloodlust (unlocked on the Strength card at 5/5): feeding fills a meter;
    # when full you can trigger it. For bloodlust_time seconds hunters flee from
    # you, touching one kills it (and pays), you cannot be hurt and you are faster.
    "bloodlust_fill": [0.10, 0.14, 0.20, 0.30, 0.45],   # meter gained per feed, by prey tier
    "bloodlust_time": 5.0,
    "bloodlust_speed": 1.2,
    "bloodlust_kill_blood": 30,

    # prey run from you, but not fast; higher tiers are warier and quicker. Allure
    # calms them (smaller flee distance).
    "prey_radius": 20.0,
    "prey_flee_dist": 150.0,
    "prey_flee_dist_per_tier": 22.0,
    "prey_flee_speed": 0.30,      # x your base speed
    "prey_flee_speed_per_tier": 0.07,
    "prey_calm_per_allure": 0.08,

    # hunters arrive on the clock too (not only when you feed), faster as dawn
    # nears, and slightly quicker on their feet by sunrise.
    "hunter_clock": True,         # False: only feeding summons hunters (tests use this)
    "hunter_clock_start": 9.0,    # seconds between arrivals at midnight
    "hunter_clock_end": 3.5,      # ...and just before sunrise
    "hunter_clock_first": 4.5,    # first arrival this many seconds in
    "hunter_dawn_ramp": 0.06,     # added to hunter_speed_frac at sunrise (linear in the night)

    # static obstacles. Hunters have no pathfinding, so these are cover: a
    # hunter homing straight at you rams one and stalls, giving you room the
    # raw speed numbers don't. They do not stay stuck forever though: a hunter
    # that stops making progress follows the obstacle sideways until the
    # straight line to you is clear (wall-sliding, not path planning), then
    # heads for you again.
    "hunter_slide_time": 2.5,     # longest one slide may last, seconds; 0 turns the unstick steering off
    "hunter_slide_angle": 1.4,    # radians off the straight line to you while sliding (~80 deg)
    "hunter_lost_time": 3.0,      # a hunter that moved < hunter_lost_dist in this long is truly trapped
    "hunter_lost_dist": 80.0,     # (a dead-end pocket sliding can't fix): it relocates to a normal spawn point
    "map": None,         # generated by level_cfg(): hunt_mapgen dict (objects, road) the renderer draws
    "obstacles": None,   # hand-placed, explicit [(x, y, radius), ...] -- see
                         # tools/tiles_to_obstacles.py for converting
                         # DungeonDraft tile coordinates into this list
    "spawn": None,        # explicit (x, y) start position -- defaults to arena center
}


def _d2(ax, ay, bx, by):
    dx = ax - bx
    dy = ay - by
    return dx * dx + dy * dy


class Prey(object):
    __slots__ = ("x", "y", "tier", "age", "charm")

    def __init__(self, x, y, tier):
        self.x = x
        self.y = y
        self.tier = tier
        self.age = 0.0
        self.charm = 0.0


class Hunter(object):
    __slots__ = ("x", "y", "age", "stun", "stuck", "slide_t", "slide_age", "slide_dir", "ax", "ay", "at", "charm")

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.age = 0.0
        self.stun = 0.0
        self.charm = 0.0        # seconds of Charm left
        self.stuck = 0.0        # seconds spent making almost no progress
        self.slide_t = 0.0      # seconds of sideways steering left (0 = not sliding)
        self.slide_age = 0.0    # seconds since this slide began
        self.slide_dir = 1.0    # +1 / -1: which way round the obstacle
        self.ax = x             # anchor for the "truly trapped" check
        self.ay = y
        self.at = 0.0


class Obstacle(object):
    """A circle (x, y, radius) or an axis-aligned rectangle (rect=(x0, y0,
    x1, y1); x/y are then its centre and radius is 0) that entities cannot
    enter. Rectangles are for buildings."""
    __slots__ = ("x", "y", "radius", "visible", "rect")

    def __init__(self, x, y, radius, visible=True, rect=None):
        self.x = x
        self.y = y
        self.radius = radius
        # False for collision that shouldn't also draw the placeholder
        # boulder sprite -- e.g. a wall/tree that's already part of the
        # ground art and just needs something to stop you walking through it.
        self.visible = visible
        self.rect = rect

    def clearance(self, px, py):
        """Distance from a point to this obstacle's surface (negative inside)."""
        if self.rect is None:
            return math.hypot(px - self.x, py - self.y) - self.radius
        x0, y0, x1, y1 = self.rect
        cx = min(max(px, x0), x1)
        cy = min(max(py, y0), y1)
        d = math.hypot(px - cx, py - cy)
        if d > 0.0:
            return d
        return -min(px - x0, x1 - px, py - y0, y1 - py)

    def push(self, px, py, r):
        """Move a circle of radius r at (px, py) out of this obstacle.
        Returns (x, y, moved)."""
        if self.rect is None:
            dx = px - self.x
            dy = py - self.y
            d = math.hypot(dx, dy)
            min_d = self.radius + r
            if d >= min_d:
                return px, py, False
            if d < 1e-6:
                dx, dy, d = 1.0, 0.0, 1.0
            return self.x + dx / d * min_d, self.y + dy / d * min_d, True
        x0, y0, x1, y1 = self.rect
        cx = min(max(px, x0), x1)
        cy = min(max(py, y0), y1)
        dx = px - cx
        dy = py - cy
        d = math.hypot(dx, dy)
        if d >= r:
            return px, py, False
        if d > 1e-6:
            return cx + dx / d * r, cy + dy / d * r, True
        # centre is inside the rectangle: leave through the nearest edge
        edges = [(px - x0, x0 - r, py), (x1 - px, x1 + r, py), (py - y0, px, y0 - r), (y1 - py, px, y1 + r)]
        best = min(range(4), key=lambda i: edges[i][0])
        if best == 0:
            return x0 - r, py, True
        if best == 1:
            return x1 + r, py, True
        if best == 2:
            return px, y0 - r, True
        return px, y1 + r, True


class HuntGame(object):
    """One run. Feed until your HP is gone, then bank the blood."""

    def __init__(self, config=None, upgrades=None, seed=None):
        self.cfg = dict(DEFAULT_CONFIG)
        if config:
            self.cfg.update(config)
        self.up = dict(upgrades or {})
        self.rng = random.Random(seed)
        self.block_rng = random.Random(None if seed is None else seed + 4242)   # Iron Skin rolls, apart from spawns

        self.map = self.cfg.get("map")   # drawable map from hunt_mapgen, or None
        self.w = float(self.cfg["arena_w"])
        self.h = float(self.cfg["arena_h"])
        if self.cfg["spawn"]:
            self.x, self.y = float(self.cfg["spawn"][0]), float(self.cfg["spawn"][1])
        else:
            self.x = self.w * 0.5
            self.y = self.h * 0.5
        r = self.cfg["vamp_radius"]
        self.x = min(max(self.x, r), self.w - r)
        self.y = min(max(self.y, r), self.h - r)

        self.max_hp = int(self.cfg["hp_base"] + self.cfg["hp_per_con"] * self.lvl("constitution"))
        self.hp = float(self.max_hp)  # hearts; quarter steps are exact in floating point
        self.heal_cd = 0.0            # Drain Life cooldown
        self.kill_streak = 0          # kills since the last hit (Drain Life)
        self.harvest_t = 0.0          # seconds of Harvest left (0 = not active)
        self.harvest_used = False     # one Harvest per night
        self.harvest_kills = 0
        self.blood = 0
        self.fed = 0
        self.time = 0.0
        self.over = False
        self.dawn = False             # True when the run ended because the sun came up
        self.dawn_bonus = 0           # blood added for surviving the night (already in self.blood)
        self.invuln = 0.0
        self.blink_cd = 0.0
        self.charm_cd = 0.0
        self.frenzy = 0.0             # Bloodlust meter 0..1 (drains as it runs)
        self.frenzy_t = 0.0           # seconds of Bloodlust left (0 = not active)
        self.spawn_t = self.cfg["hunter_clock_start"] - self.cfg["hunter_clock_first"]

        self.facing = -math.pi / 2.0   # radians; starts facing "up" (north)

        # Each entry is (x, y, radius) or (x, y, radius, visible). Default
        # is invisible: every obstacle we actually have right now is
        # collision-only, matching art that's already painted into the
        # ground image (a real map's trees/cave/etc traced from its .dd2vtt
        # export) -- opt into visible=True only for something with no
        # matching art yet (a placeholder boulder sprite should draw).
        # A ("rect", x0, y0, x1, y1) entry is a building footprint.
        self.obstacles = []
        for o in (self.cfg["obstacles"] or []):
            if o[0] == "rect":
                x0, y0, x1, y1 = [float(v) for v in o[1:5]]
                self.obstacles.append(Obstacle((x0 + x1) / 2.0, (y0 + y1) / 2.0, 0.0, visible=False,
                                               rect=(x0, y0, x1, y1)))
            else:
                self.obstacles.append(Obstacle(float(o[0]), float(o[1]), float(o[2]),
                                               visible=bool(o[3]) if len(o) > 3 else False))

        self._build_obstacle_grid()

        self.hunters = []
        self.prey = []
        self.events = []
        for _ in range(int(self.cfg["prey_on_map"])):
            self.prey.append(self._new_prey())

    # -- derived stats ---------------------------------------------------

    def lvl(self, name):
        return int(self.up.get(name, 0))

    @property
    def speed(self):
        v = self.cfg["vamp_speed"] * (1.0 + self.cfg["speed_per_level"] * self.lvl("speed"))
        return v * self.cfg["bloodlust_speed"] if self.frenzy_t > 0.0 else v

    @property
    def feed_radius(self):
        return self.cfg["feed_radius"] + self.cfg["feed_radius_per_allure"] * self.lvl("allure")

    @property
    def hunter_speed(self):
        # Deliberately keyed to your BASE speed, not self.speed. Keying it to
        # self.speed made Speed upgrades pointless for survival -- hunters
        # scaled with you 1:1, so max Speed still meant hunters could be 43%
        # faster than you, same as level 0. This way Speed actually buys a
        # real margin.
        ramp = min(self.cfg["hunter_speed_ramp"] * self.fed, self.cfg["hunter_speed_ramp_cap"])
        ramp += self.cfg["hunter_dawn_ramp"] * self.night_phase()
        return (self.cfg["hunter_speed_frac"] + ramp) * self.cfg["vamp_speed"]

    # -- spawning --------------------------------------------------------

    def _far_point(self, min_from_vamp, min_from_hunters=0.0, obstacle_margin=40.0, tries=80,
                   max_from_vamp=None, zone=None):
        """A spawn point at least min_from_vamp from you (and, if given, at
        most max_from_vamp: sampled in a ring around you, clamped to the
        arena; samples falling off the map are redrawn), clear of hunters
        and obstacles. Falls back to the best candidate seen if nothing
        qualifies. `zone` (x0, y0, x1, y1) limits samples to a box -- used to
        keep hunters inside a city wall -- but only while you are in or near
        it; once you leave, spawns follow you."""
        pad = 60.0
        if zone and not (zone[0] - 300.0 <= self.x <= zone[2] + 300.0 and zone[1] - 300.0 <= self.y <= zone[3] + 300.0):
            zone = None
        best = None
        best_score = -1.0
        for _ in range(tries):
            if max_from_vamp:
                ang = self.rng.uniform(0.0, 2.0 * math.pi)
                dist = self.rng.uniform(min_from_vamp, max_from_vamp)
                px = self.x + math.cos(ang) * dist
                py = self.y + math.sin(ang) * dist
                if not (pad <= px <= self.w - pad and pad <= py <= self.h - pad):
                    continue      # off the map: resample (clamping would pile spawns against the walls)
            else:
                px = self.rng.uniform(pad, self.w - pad)
                py = self.rng.uniform(pad, self.h - pad)
            if zone and not (zone[0] <= px <= zone[2] and zone[1] <= py <= zone[3]):
                continue
            dv = math.sqrt(_d2(px, py, self.x, self.y))
            dh = min([math.sqrt(_d2(px, py, h.x, h.y)) for h in self.hunters] or [9e9])
            do = min([o.clearance(px, py) for o in self.obstacles] or [9e9])
            if dv >= min_from_vamp and dh >= min_from_hunters and do >= obstacle_margin:
                return px, py
            score = min(dv - min_from_vamp, dh - min_from_hunters, do - obstacle_margin)
            if score > best_score:
                best_score, best = score, (px, py)
        if best is None:          # every ring sample fell off the map
            best = (min(max(self.x, pad), self.w - pad), min(max(self.y, pad), self.h - pad))
        return best

    GRID_CELL = 210.0

    def _build_obstacle_grid(self):
        """Uniform grid of obstacle indices. The big maps have hundreds of
        obstacles (walls, fences, trees) and every entity is resolved against
        them every frame, so only the ones near an entity are looked at."""
        cs = self.GRID_CELL
        self._grid = {}
        self._cand = {}
        for i, o in enumerate(self.obstacles):
            if o.rect is None:
                x0, y0, x1, y1 = o.x - o.radius, o.y - o.radius, o.x + o.radius, o.y + o.radius
            else:
                x0, y0, x1, y1 = o.rect
            for gx in range(int(x0 // cs), int(x1 // cs) + 1):
                for gy in range(int(y0 // cs), int(y1 // cs) + 1):
                    self._grid.setdefault((gx, gy), []).append(i)

    def _resolve_obstacles(self, x, y, r):
        """Push (x, y) back outside every obstacle it overlaps. Iterated: a
        single pass can push you out of one obstacle straight into a
        neighbor when two are close together (hand-placed obstacles, e.g.
        a cluster of trees, aren't guaranteed the old random-gen's 150px
        gap), so re-check the nearby obstacles a few times until it settles."""
        cs = self.GRID_CELL
        m = 2.0 * r + 60.0               # a push never moves an entity farther than this
        key = (int((x - m) // cs), int((y - m) // cs), int((x + m) // cs), int((y + m) // cs))
        cand = self._cand.get(key)
        if cand is None:
            idx = set()
            for gx in range(key[0], key[2] + 1):
                for gy in range(key[1], key[3] + 1):
                    idx.update(self._grid.get((gx, gy), ()))
            cand = [self.obstacles[i] for i in sorted(idx)]
            self._cand[key] = cand
        for _pass in range(4):
            moved = False
            for o in cand:
                x, y, mv = o.push(x, y, r)
                moved = moved or mv
            if not moved:
                break
        return x, y

    def _pick_tier(self):
        bias = 1.0 + self.cfg["allure_tier_bias"] * self.lvl("allure")
        weights = [w * (bias ** i) for i, w in enumerate(self.cfg["tier_weights"])]
        roll = self.rng.uniform(0.0, sum(weights))
        acc = 0.0
        for i, w in enumerate(weights):
            acc += w
            if roll <= acc:
                return i
        return len(weights) - 1

    def _new_prey(self):
        px, py = self._far_point(self.cfg["prey_spawn_min_dist"],
                                 self.cfg["prey_spawn_min_hunter_dist"],
                                 max_from_vamp=self.cfg["prey_spawn_max_dist"])
        return Prey(px, py, self._pick_tier())

    def _spawn_hunter(self):
        if len(self.hunters) >= self.cfg["max_hunters"]:
            return
        hx, hy = self._far_point(self.cfg["hunter_spawn_min_dist"],
                                 max_from_vamp=self.cfg["hunter_spawn_max_dist"],
                                 zone=(self.map or {}).get("hunter_zone"))
        self.hunters.append(Hunter(hx, hy))

    # -- the loop --------------------------------------------------------

    def dawn_bonus_for(self, taken):
        """Flat part: dawn_bonus_kills x the average prey value (base tier odds, so Allure
        does not inflate it), scaled by the level's blood_mult. Plus a % of what you took."""
        c = self.cfg
        tw = c["tier_weights"]
        avg = sum(w * v for w, v in zip(tw, c["tier_values"])) / float(sum(tw))
        return int(round(c["dawn_bonus_kills"] * avg * c["blood_mult"])) + int(round(taken * c["dawn_bonus_frac"]))

    def night_phase(self):
        """0.0 at midnight .. 1.0 at sunrise (always 0 when the cycle is off)."""
        nl = self.cfg["night_length"]
        return min(1.0, self.time / nl) if nl > 0 else 0.0

    @property
    def has_drain(self):
        return self.lvl("drain") >= 1

    @property
    def has_ultimate(self):
        return self.lvl("ultimate") >= 1

    @property
    def harvest_on(self):
        return self.harvest_t > 0.0

    @property
    def has_blink(self):
        return self.lvl("blink") >= 1

    @property
    def has_charm(self):
        return self.lvl("charm") >= 1

    @property
    def has_bloodlust(self):
        return self.lvl("bloodlust") >= 1

    @property
    def bloodlust_on(self):
        return self.frenzy_t > 0.0

    def update(self, dt, move_x, move_y, use=()):
        """Advance one frame. move_x/move_y are -1..1; `use` holds the powers pressed
        this frame ("blink", "charm", "bloodlust"). Returns this frame's events."""
        self.events = []
        if self.over:
            return self.events
        if self.harvest_t > 0.0:                    # time is stopped: only you move
            return self._harvest_step(dt, move_x, move_y)

        self.time += dt
        nl = self.cfg["night_length"]
        if nl > 0 and self.time >= nl:
            self.time = nl
            self.over = True
            self.dawn = True
            taken = self.blood
            self.dawn_bonus = self.dawn_bonus_for(taken)
            self.blood += self.dawn_bonus
            self.events.append(("dawn", self.x, self.y, taken, self.dawn_bonus))
            return self.events
        if "ultimate" in use and self.has_ultimate and not self.harvest_used:
            self._harvest()
            return self.events
        self.invuln = max(0.0, self.invuln - dt)
        self.heal_cd = max(0.0, self.heal_cd - dt)
        self.blink_cd = max(0.0, self.blink_cd - dt)
        self.charm_cd = max(0.0, self.charm_cd - dt)
        if self.frenzy_t > 0.0:
            self.frenzy_t = max(0.0, self.frenzy_t - dt)
            self.frenzy = self.frenzy_t / self.cfg["bloodlust_time"]
            if self.frenzy_t == 0.0:
                self.frenzy = 0.0
                self.events.append(("bloodlust_end", self.x, self.y, 0, 0))

        if move_x or move_y:
            n = math.hypot(move_x, move_y)
            step = self.speed * dt
            self.x += move_x / n * step
            self.y += move_y / n * step
            self.facing = math.atan2(move_y, move_x)
        r = self.cfg["vamp_radius"]
        self.x = min(max(self.x, r), self.w - r)
        self.y = min(max(self.y, r), self.h - r)
        self.x, self.y = self._resolve_obstacles(self.x, self.y, r)
        if "blink" in use and self.has_blink and self.blink_cd <= 0.0:
            self._blink(move_x, move_y)
        if "charm" in use and self.has_charm and self.charm_cd <= 0.0:
            self._charm()
        if "bloodlust" in use and self.has_bloodlust and self.frenzy >= 1.0 and self.frenzy_t <= 0.0:
            self._bloodlust()

        self._feed()
        self._move_prey(dt)
        self._hunter_clock(dt)
        self._move_hunters(dt)
        self._clash()
        self._contact()
        return self.events

    def _blink(self, move_x, move_y):
        """Teleport along the move direction (or where you face), through walls.
        Lands on the first free spot from blink_dist outward (to blink_dist +
        blink_reach); failing that, on the last free spot short of blink_dist."""
        if move_x or move_y:
            n = math.hypot(move_x, move_y)
            ux, uy = move_x / n, move_y / n
        else:
            ux, uy = math.cos(self.facing), math.sin(self.facing)
        r = self.cfg["vamp_radius"]
        dist = self.cfg["blink_dist"]
        step = self.cfg["blink_step"]
        x0, y0 = self.x, self.y

        def ok(d):
            x, y = x0 + ux * d, y0 + uy * d
            if x < r or y < r or x > self.w - r or y > self.h - r:
                return None
            return (x, y) if self._resolve_obstacles(x, y, r) == (x, y) else None

        spot = None
        d = dist
        while d <= dist + self.cfg["blink_reach"] + 1e-6 and spot is None:
            spot = ok(d)
            d += step
        d = dist - step
        while spot is None and d >= self.cfg["blink_min"]:
            spot = ok(d)
            d -= step
        if spot is None or math.hypot(spot[0] - x0, spot[1] - y0) < self.cfg["blink_min"]:
            return False
        self.x, self.y = spot
        self.blink_cd = self.cfg["blink_cd"]
        self.events.append(("blink", spot[0], spot[1], x0, y0))
        return True

    def _charm(self):
        """Charm the nearest few hunters/prey inside charm_radius."""
        rad = self.cfg["charm_radius"]
        near = []
        for t in self.hunters + self.prey:
            d2 = _d2(self.x, self.y, t.x, t.y)
            if d2 <= rad * rad and t.charm <= 0.0:
                near.append((d2, t))
        if not near:
            self.events.append(("fizzle", self.x, self.y, rad, 0))
            return False
        near.sort(key=lambda it: it[0])
        picked = [t for _, t in near[:int(self.cfg["charm_targets"])]]
        self.charm_cd = self.cfg["charm_cd"]
        self.events.append(("charm", self.x, self.y, rad, len(picked)))
        for t in picked:
            t.charm = self.cfg["charm_time"]
            self.events.append(("charmed", t.x, t.y, 1 if isinstance(t, Hunter) else 0, 0))
        return True

    def _harvest(self):
        self.harvest_t = self.cfg["harvest_time"]
        self.harvest_used = True
        self.harvest_kills = 0
        self.events.append(("harvest", self.x, self.y, self.cfg["harvest_time"], 0))

    def _harvest_step(self, dt, move_x, move_y):
        c = self.cfg
        self.harvest_t = max(0.0, self.harvest_t - dt)
        if move_x or move_y:
            n = math.hypot(move_x, move_y)
            step = self.speed * c["harvest_speed"] * dt
            self.x += move_x / n * step
            self.y += move_y / n * step
            self.facing = math.atan2(move_y, move_x)
        r = c["vamp_radius"]
        self.x = min(max(self.x, r), self.w - r)
        self.y = min(max(self.y, r), self.h - r)
        self.x, self.y = self._resolve_obstacles(self.x, self.y, r)
        rr = c["vamp_radius"] + c["hunter_radius"] + c["harvest_reach"]
        for h in list(self.hunters):
            if _d2(self.x, self.y, h.x, h.y) <= rr * rr:
                self.hunters.remove(h)
                self.blood += c["harvest_kill_blood"]
                self.harvest_kills += 1
                self.events.append(("harvest_kill", h.x, h.y, c["harvest_kill_blood"], 0))
                self._count_kill()
        self._feed(spawn=False)
        if self.harvest_t <= 0.0:
            self.invuln = max(self.invuln, c["harvest_grace"])
            self.events.append(("harvest_end", self.x, self.y, self.harvest_kills, 0))
        return self.events

    def _bloodlust(self):
        self.frenzy_t = self.cfg["bloodlust_time"]
        self.frenzy = 1.0
        self.events.append(("bloodlust", self.x, self.y, 0, 0))

    def _move_prey(self, dt):
        c = self.cfg
        pr = c["prey_radius"]
        calm = max(0.2, 1.0 - c["prey_calm_per_allure"] * self.lvl("allure"))
        for p in self.prey:
            p.age += dt
            dx = self.x - p.x
            dy = self.y - p.y
            d = math.hypot(dx, dy)
            if d < 1e-6:
                continue
            if p.charm > 0.0:
                p.charm = max(0.0, p.charm - dt)
                if d > self.feed_radius * 0.6:
                    sp = 0.55 * c["vamp_speed"] * dt
                    p.x += dx / d * sp
                    p.y += dy / d * sp
            else:
                if d >= (c["prey_flee_dist"] + c["prey_flee_dist_per_tier"] * p.tier) * calm:
                    continue
                sp = (c["prey_flee_speed"] + c["prey_flee_speed_per_tier"] * p.tier) * c["vamp_speed"] * dt
                p.x -= dx / d * sp
                p.y -= dy / d * sp
            p.x = min(max(p.x, pr), self.w - pr)
            p.y = min(max(p.y, pr), self.h - pr)
            p.x, p.y = self._resolve_obstacles(p.x, p.y, pr)

    def _hunter_clock(self, dt):
        """A hunter arrives every few seconds regardless of feeding, quicker towards dawn."""
        c = self.cfg
        if not c["hunter_clock"]:
            return
        interval = c["hunter_clock_start"] + (c["hunter_clock_end"] - c["hunter_clock_start"]) * self.night_phase()
        self.spawn_t += dt
        if self.spawn_t >= interval:
            self.spawn_t = 0.0
            self._spawn_hunter()

    def _feed(self, spawn=True):
        fr = self.feed_radius
        for p in list(self.prey):
            if _d2(self.x, self.y, p.x, p.y) <= fr * fr:
                value = int(round(self.cfg["tier_values"][p.tier] * self.cfg["blood_mult"]))
                self.blood += value
                self.fed += 1
                self.events.append(("feed", p.x, p.y, value, p.tier))
                self._count_kill()
                self.prey.remove(p)
                if p.charm <= 0.0 and spawn:
                    self._spawn_hunter()      # a willing (charmed) victim makes no noise
                self.prey.append(self._new_prey())
                if self.has_bloodlust and self.frenzy_t <= 0.0 and self.frenzy < 1.0:
                    self.frenzy = min(1.0, self.frenzy + self.cfg["bloodlust_fill"][p.tier])
                    if self.frenzy >= 1.0:
                        self.events.append(("bloodlust_ready", self.x, self.y, 0, 0))

    def _count_kill(self):
        """Drain Life: every third kill in a row (no hit between) mends half a heart."""
        self.kill_streak += 1
        if (self.has_drain and self.kill_streak >= self.cfg["drain_streak"]
                and self.heal_cd <= 0.0 and self.hp < self.max_hp):
            amount = min(self.cfg["drain_heal"], self.max_hp - self.hp)
            self.hp += amount
            self.heal_cd = self.cfg["drain_cd"]
            self.kill_streak = 0
            self.events.append(("heal", self.x, self.y, amount, 0))

    def _relocate_hunter(self, h):
        """A hunter stuck for good (e.g. a dead-end pocket) walks back in from a normal spawn point."""
        h.x, h.y = self._far_point(self.cfg["hunter_spawn_min_dist"],
                                   max_from_vamp=self.cfg["hunter_spawn_max_dist"],
                                   zone=(self.map or {}).get("hunter_zone"))
        h.stuck = 0.0
        h.slide_t = 0.0
        h.slide_age = 0.0

    def _free_at(self, h, ux, uy, dist, ang=0.0):
        """Is a hunter-sized circle `dist` px from h, in direction (ux, uy) turned by ang, clear?"""
        c, sn = math.cos(ang), math.sin(ang)
        px = h.x + (ux * c - uy * sn) * dist
        py = h.y + (ux * sn + uy * c) * dist
        return self._resolve_obstacles(px, py, self.cfg["hunter_radius"]) == (px, py)

    def _slide_side(self, h, ux, uy):
        """Which way (+1/-1) to go round whatever blocks h: the side with free
        space ahead, else random."""
        ang = self.cfg["hunter_slide_angle"]
        free = [sgn for sgn in (1.0, -1.0) if self._free_at(h, ux, uy, 70.0, ang * sgn)]
        if len(free) == 1:
            return free[0]
        return self.rng.choice((1.0, -1.0))

    def _move_hunters(self, dt):
        hs = self.hunter_speed
        boost_d = self.cfg["hunter_boost_dist"]
        boost_m = self.cfg["hunter_boost_mult"]
        slide_time = self.cfg["hunter_slide_time"]
        slide_ang = self.cfg["hunter_slide_angle"]
        lost_time = self.cfg["hunter_lost_time"]
        lost_dist = self.cfg["hunter_lost_dist"]
        for h in self.hunters:
            h.age += dt
            if h.stun > 0.0:
                h.stun = max(0.0, h.stun - dt)
                continue
            if self.frenzy_t > 0.0 or h.charm > 0.0:
                self._move_special(h, dt, hs)
                continue
            dx = self.x - h.x
            dy = self.y - h.y
            d = math.hypot(dx, dy)
            if d < 1e-6:
                continue
            ux = dx / d
            uy = dy / d
            if h.slide_t > 0.0:
                h.slide_t -= dt
                h.slide_age += dt
                # done once the way to the vampire is open again
                if h.slide_age > 0.3 and self._free_at(h, ux, uy, 60.0):
                    h.slide_t = 0.0
            if h.slide_t > 0.0:
                c, sn = math.cos(slide_ang * h.slide_dir), math.sin(slide_ang * h.slide_dir)
                mx, my = ux * c - uy * sn, ux * sn + uy * c
            else:
                mx, my = ux, uy
            s = hs * (boost_m if d < boost_d else 1.0)
            ox, oy = h.x, h.y
            h.x += mx * s * dt
            h.y += my * s * dt
            h.x, h.y = self._resolve_obstacles(h.x, h.y, self.cfg["hunter_radius"])
            h.at += dt
            if h.at >= lost_time:
                if math.hypot(h.x - h.ax, h.y - h.ay) < lost_dist:
                    self._relocate_hunter(h)
                h.ax, h.ay, h.at = h.x, h.y, 0.0
            if slide_time <= 0.0:
                continue
            if math.hypot(h.x - ox, h.y - oy) < 0.45 * s * dt:
                h.stuck += dt
            else:
                h.stuck = max(0.0, h.stuck - 2.0 * dt)
            if h.stuck > 0.12:
                h.stuck = 0.0
                if h.slide_t > 0.0:
                    h.slide_dir = -h.slide_dir          # blocked while sliding: a corner, go back the other way
                else:
                    h.slide_dir = self._slide_side(h, ux, uy)
                h.slide_t = slide_time
                h.slide_age = 0.0

    def _move_special(self, h, dt, hs):
        """Bloodlust: flee from the vampire. Charm: walk into the nearest other hunter."""
        hr = self.cfg["hunter_radius"]
        h.slide_t = 0.0
        h.stuck = 0.0
        if self.frenzy_t > 0.0 and h.charm <= 0.0:
            tx, ty, sp = h.x - (self.x - h.x), h.y - (self.y - h.y), hs
        else:
            h.charm = max(0.0, h.charm - dt)
            others = [o for o in self.hunters if o is not h]
            if not others:
                return
            o = min(others, key=lambda q: _d2(h.x, h.y, q.x, q.y))
            tx, ty, sp = o.x, o.y, hs * self.cfg["charm_speed"]
        dx, dy = tx - h.x, ty - h.y
        d = math.hypot(dx, dy)
        if d < 1e-6:
            return
        h.x += dx / d * sp * dt
        h.y += dy / d * sp * dt
        h.x = min(max(h.x, hr), self.w - hr)
        h.y = min(max(h.y, hr), self.h - hr)
        h.x, h.y = self._resolve_obstacles(h.x, h.y, hr)
        h.ax, h.ay, h.at = h.x, h.y, 0.0        # being driven around is not being lost

    def _clash(self):
        md = self.cfg["hunter_merge_dist"]
        dead = set()
        n = len(self.hunters)
        for i in range(n):
            if i in dead:
                continue
            for j in range(i + 1, n):
                if j in dead:
                    continue
                a, b = self.hunters[i], self.hunters[j]
                if _d2(a.x, a.y, b.x, b.y) <= md * md:
                    dead.add(i)
                    dead.add(j)
                    self.events.append(("clash", (a.x + b.x) * 0.5, (a.y + b.y) * 0.5, 0, 0))
                    break
        if dead:
            self.hunters = [h for i, h in enumerate(self.hunters) if i not in dead]

    def _contact(self):
        rr = self.cfg["vamp_radius"] + self.cfg["hunter_radius"]
        if self.frenzy_t > 0.0:                     # Bloodlust: you kill what touches you
            for h in list(self.hunters):
                if _d2(self.x, self.y, h.x, h.y) <= rr * rr:
                    self.hunters.remove(h)
                    self.blood += self.cfg["bloodlust_kill_blood"]
                    self.events.append(("kill", h.x, h.y, self.cfg["bloodlust_kill_blood"], 0))
                    self._count_kill()
            return
        if self.invuln > 0.0:
            return
        for h in self.hunters:
            if h.charm > 0.0:
                continue                            # a charmed hunter cannot hurt you
            if _d2(self.x, self.y, h.x, h.y) <= rr * rr:
                st = self.lvl("strength")
                if st > 0 and self.block_rng.random() < min(0.9, self.cfg["block_per_str"] * st):
                    self.invuln = self.cfg["block_grace"]
                    self.events.append(("block", self.x, self.y, 0, 0))
                    self._shock()                   # throws this hunter (and the pack) back and stuns them
                    return
                self.hp -= 1
                self.kill_streak = 0
                self.invuln = self.cfg["invuln_time"]
                self.hunters.remove(h)
                self.events.append(("hurt", self.x, self.y, 0, 0))
                if self.hp <= 0:
                    self.hp = 0
                    self.over = True
                    self.events.append(("over", self.x, self.y, self.blood, 0))
                else:
                    self._shock()
                return

    def _shock(self):
        """Blood Shock (Strength): the pack around you is thrown back and stunned."""
        st = self.lvl("strength")
        if st <= 0:
            return
        rad = self.cfg["shock_radius"] + self.cfg["shock_radius_per_str"] * st
        stun = self.cfg["shock_stun"] + self.cfg["shock_stun_per_str"] * st
        self.events.append(("shock", self.x, self.y, rad, 0))
        for h in self.hunters:
            if _d2(self.x, self.y, h.x, h.y) > rad * rad:
                continue
            dx = h.x - self.x
            dy = h.y - self.y
            d = math.hypot(dx, dy) or 1.0
            h.x += dx / d * self.cfg["shock_knockback"]
            h.y += dy / d * self.cfg["shock_knockback"]
            h.x = min(max(h.x, 0.0), self.w)
            h.y = min(max(h.y, 0.0), self.h)
            h.x, h.y = self._resolve_obstacles(h.x, h.y, self.cfg["hunter_radius"])
            h.stun = stun
            self.events.append(("stagger", h.x, h.y, 0, 0))


# ---------------------------------------------------------------------------
# self-test
# ---------------------------------------------------------------------------

def _play(upgrades=None, seed=0, frames=20000, policy="greedy", config=None):
    """Headless run driven by a scripted policy. Returns the finished HuntGame.

    "greedy"   -- beelines at the nearest prey, ignores danger. A floor.
    "cautious" -- seeks prey but is repelled by nearby hunters and uses its powers when
                  cornered (charm/blink) or when the Bloodlust meter is full. A rough stand-in for a competent player.
    """
    g = HuntGame(config=config, upgrades=upgrades, seed=seed)
    rng = random.Random(seed + 999)
    dt = 1.0 / 60.0
    for _ in range(frames):
        if g.over:
            break
        mx = my = 0.0
        if g.prey:
            t = min(g.prey, key=lambda p: _d2(g.x, g.y, p.x, p.y))
            d = math.hypot(t.x - g.x, t.y - g.y) or 1.0
            mx, my = (t.x - g.x) / d, (t.y - g.y) / d
        use = ()
        if policy == "cautious":
            closest = 9e9
            for h in g.hunters:
                dx, dy = g.x - h.x, g.y - h.y
                d = math.hypot(dx, dy) or 1.0
                closest = min(closest, d)
                if d < 320.0:
                    w = (320.0 - d) / 320.0 * 3.0
                    mx += dx / d * w
                    my += dy / d * w
            use = ("charm", "blink") if closest < 110.0 else ()
            if g.frenzy >= 1.0:
                use = use + ("bloodlust",)
            # hug away from walls so we do not corner ourselves
            mx += (1.0 if g.x < 140 else 0.0) - (1.0 if g.x > g.w - 140 else 0.0)
            my += (1.0 if g.y < 140 else 0.0) - (1.0 if g.y > g.h - 140 else 0.0)
        else:
            use = ("charm", "blink", "bloodlust") if rng.random() < 0.004 else ()
        g.update(dt, mx, my, use)
    return g


def _selftest():
    ok = True

    def check(label, cond):
        print("%-52s %s" % (label, "PASS" if cond else "FAIL"))
        return cond

    # 0. a hunter behind a long wall gets round it (and the test only means
    #    something if the same hunter stays stuck with the steering off)
    def wall_run(slide, seconds=14.0):
        cfg = {"obstacles": [("rect", 600.0, 100.0, 640.0, 720.0)], "prey_on_map": 0, "hunter_clock": False,
               "hunter_lost_time": 1e9,         # no teleporting out: this tests the steering alone
               "hunter_slide_time": slide, "spawn": (1000.0, 410.0)}
        w = HuntGame(config=cfg, seed=3)
        w.hunters.append(Hunter(400.0, 410.0))
        for _ in range(int(seconds * 60)):
            w.update(1.0 / 60.0, 0, 0)
            if w.hp < w.max_hp or not w.hunters:
                return True                      # it reached the vampire
        return w.hunters[0].x > 650.0
    ok = check("hunter stays stuck behind a wall with slide off", not wall_run(0.0)) and ok
    ok = check("hunter gets round the wall with slide on", wall_run(2.5)) and ok

    def pocket_run(seconds=40.0):
        # a U-shaped pocket open to the left, the vampire behind its back wall
        cfg = {"obstacles": [("rect", 700.0, 300.0, 740.0, 520.0), ("rect", 520.0, 300.0, 740.0, 340.0),
                             ("rect", 520.0, 480.0, 740.0, 520.0)], "prey_on_map": 0, "hunter_clock": False, "spawn": (1100.0, 410.0)}
        w = HuntGame(config=cfg, seed=4)
        w.hunters.append(Hunter(620.0, 410.0))
        for _ in range(int(seconds * 60)):
            w.update(1.0 / 60.0, 0, 0)
            if w.hp < w.max_hp:
                return True
        return False
    ok = check("a hunter trapped in a dead-end pocket is freed", pocket_run()) and ok

    # night: the sun ends the run, exactly once, at night_length
    nt = HuntGame(config={"night_length": 30.0, "prey_on_map": 0, "hunter_clock": False, "hunter_slide_time": 0.0}, seed=1)
    evs = []
    for _ in range(40 * 60):
        evs.extend(nt.update(1.0 / 60.0, 0, 0))
        if nt.over:
            break
    ok = check("sunrise ends the run at night_length (dawn flag, one event)",
               nt.over and nt.dawn and abs(nt.time - 30.0) < 1e-6 and [e[0] for e in evs].count("dawn") == 1) and ok
    nb = HuntGame(config={"night_length": 5.0, "prey_on_map": 0, "hunter_clock": False}, seed=1)
    nb.blood = 100
    evb = []
    for _ in range(6 * 60):
        evb.extend(nb.update(1.0 / 60.0, 0, 0))
    flat = nb.dawn_bonus - 6                       # 6.18% of 100 taken
    ok = check("sunrise pays 10 average kills (~280) plus 6.18% of what you took",
               nb.dawn and 270 <= flat <= 290 and nb.blood == 100 + nb.dawn_bonus
               and [e for e in evb if e[0] == "dawn"][0][3:] == (100, nb.dawn_bonus)) and ok
    nd = HuntGame(config={"night_length": 5.0, "prey_on_map": 0, "hunter_clock": False}, seed=1)
    nd.blood = 100
    nd.hp = 1
    nd.hunters.append(Hunter(nd.x + 30, nd.y))
    nd.update(1.0 / 60.0, 0, 0)
    ok = check("dying banks only what you took (no bonus)", nd.over and not nd.dawn and nd.dawn_bonus == 0 and nd.blood == 100) and ok
    nt2 = HuntGame(config={"night_length": 0.0, "prey_on_map": 0, "hunter_clock": False}, seed=1)
    for _ in range(600):
        nt2.update(1.0 / 60.0, 0, 0)
    ok = check("night_length 0 disables the cycle", not nt2.over and nt2.night_phase() == 0.0) and ok
    ok = check("night_phase runs 0..1", abs(HuntGame(config={"night_length": 100.0}).night_phase()) < 1e-9
               and abs(nt.night_phase() - 1.0) < 1e-9) and ok

    # blink: needs the upgrade, jumps blink_dist, crosses walls, has a cooldown
    def bl(up, obstacles=None, mv=(1, 0), spawn=(300.0, 410.0)):
        w = HuntGame(config={"obstacles": obstacles, "prey_on_map": 0, "spawn": spawn, "night_length": 0.0, "hunter_clock": False},
                     upgrades=up, seed=2)
        x0 = w.x
        ev = w.update(1.0 / 60.0, mv[0], mv[1], ("blink",))
        return w, x0, ev
    w, x0, ev = bl({})
    ok = check("blink does nothing without the upgrade", not any(e[0] == "blink" for e in ev) and w.x - x0 < 10.0) and ok
    w, x0, ev = bl({"blink": 1})
    moved = w.x - x0
    ok = check("blink jumps ~blink_dist along the move direction",
               any(e[0] == "blink" for e in ev) and 220.0 <= moved <= 260.0 and abs(w.y - 410.0) < 1.0) and ok
    w.update(1.0 / 60.0, 1, 0, ("blink",))
    ok = check("blink is on cooldown right after", w.blink_cd > 5.0 and w.x - x0 < 260.0) and ok
    w, x0, ev = bl({"blink": 1}, obstacles=[("rect", 450.0, 100.0, 490.0, 720.0)])
    ok = check("blink crosses a thin wall", w.x > 490.0 and any(e[0] == "blink" for e in ev)) and ok
    w, x0, ev = bl({"blink": 1}, obstacles=[("rect", 340.0, 100.0, 380.0, 720.0)])
    ok = check("blink crosses a wall right in front of you", w.x > 380.0 and any(e[0] == "blink" for e in ev)) and ok
    w, x0, ev = bl({"blink": 1}, obstacles=[("rect", 440.0, 100.0, 1300.0, 720.0)])
    ok = check("a wall too thick to cross: lands short of it",
               any(e[0] == "blink" for e in ev) and w.x < 440.0 and w.x - x0 >= 40.0) and ok
    w, x0, ev = bl({"blink": 1}, obstacles=[("rect", 330.0, 100.0, 1300.0, 720.0)])
    ok = check("blink with nowhere to land is refused and costs no cooldown",
               not any(e[0] == "blink" for e in ev) and w.blink_cd == 0.0) and ok
    w, x0, ev = bl({"blink": 1}, mv=(0, 0))
    ok = check("blink with no input goes where you face", any(e[0] == "blink" for e in ev)) and ok

    # 1. it runs a long time without exploding, and invariants hold every frame
    g = HuntGame(upgrades={"blink": 1, "charm": 1, "bloodlust": 1, "strength": 3, "allure": 3}, seed=1)
    dt = 1.0 / 60.0
    rng = random.Random(2)
    last_blood = 0
    frames = 0
    while frames < 20000 and not g.over:
        g.update(dt, rng.uniform(-1, 1), rng.uniform(-1, 1), ("blink", "charm", "bloodlust") if rng.random() < 0.01 else ())
        frames += 1
        r = g.cfg["vamp_radius"]
        if not (r - 0.5 <= g.x <= g.w - r + 0.5 and r - 0.5 <= g.y <= g.h - r + 0.5):
            ok = check("vampire stays inside the arena", False)
            break
        if g.blood < last_blood:
            ok = check("blood never decreases", False)
            break
        last_blood = g.blood
        if len(g.hunters) > g.cfg["max_hunters"]:
            ok = check("hunter count respects the cap", False)
            break
        if len(g.prey) != g.cfg["prey_on_map"]:
            ok = check("prey count stays constant", False)
            break
    ok &= check("20k random frames, all invariants held", True)

    # 2. a run actually ends
    g = _play(seed=3, policy="greedy")
    ok &= check("a greedy run eventually dies", g.over)
    ok &= check("a greedy run earns blood", g.blood > 0)

    # 3. a hunter never spawns on top of you. Feeding is what spawns them, so
    #    this has to run a policy that actually eats, or it asserts nothing.
    worst = 9e9
    spawns = 0
    for seed in range(12):
        g = HuntGame(upgrades={"constitution": 6}, seed=seed)
        for _ in range(9000):
            if g.over:
                break
            t = min(g.prey, key=lambda p: _d2(g.x, g.y, p.x, p.y))
            before = len(g.hunters)
            g.update(dt, t.x - g.x, t.y - g.y)
            if len(g.hunters) > before:
                spawns += 1
                worst = min(worst, math.sqrt(_d2(g.x, g.y, g.hunters[-1].x, g.hunters[-1].y)))
    ok &= check("%d hunter spawns, closest was %.0f px away" % (spawns, worst),
                spawns > 50 and worst > g.cfg["vamp_radius"] + g.cfg["hunter_radius"] + 100)

    # 4. upgrades measurably help, averaged over seeds
    def avg(up, key):
        runs = [_play(upgrades=up, seed=s) for s in range(14)]
        return sum(getattr(r, key) for r in runs) / float(len(runs))

    base_t = avg({}, "time")
    con_t = avg({"constitution": 4}, "time")
    ok &= check("Constitution 4 survives longer (%.1fs vs %.1fs)" % (con_t, base_t),
                con_t > base_t)

    base_b = avg({}, "blood")
    all_b = avg({"speed": 4, "constitution": 4, "allure": 4, "strength": 4}, "blood")
    ok &= check("all upgrades at 4 earn more blood (%.0f vs %.0f)" % (all_b, base_b),
                all_b > base_b)

    # 5. Allure biases toward richer prey
    def tier_avg(up):
        g = HuntGame(upgrades=up, seed=11)
        return sum(g._pick_tier() for _ in range(20000)) / 20000.0

    t0, t5 = tier_avg({}), tier_avg({"allure": 5})
    ok &= check("Allure 5 raises mean prey tier (%.3f vs %.3f)" % (t5, t0), t5 > t0)

    # 6. two hunters converging on a still target destroy each other
    g = HuntGame(seed=5)
    g.hunters = [Hunter(g.x - 300, g.y), Hunter(g.x + 300, g.y)]
    g.invuln = 999.0
    for _ in range(600):
        g.update(dt, 0, 0)
        if not g.hunters:
            break
    ok &= check("two hunters closing head-on clash and die", not g.hunters)

    # 7. Blood Shock, prey that run, the hunter clock, Charm and Bloodlust
    quiet = {"prey_on_map": 0, "night_length": 0.0, "hunter_clock": False,
             "hunter_slide_time": 0.0}

    def qg(up=None, **extra):
        c = dict(quiet)
        c.update(extra)
        return HuntGame(config=c, upgrades=up or {}, seed=6)

    g = qg({"strength": 3})
    g.hunters = [Hunter(g.x + 50, g.y), Hunter(g.x - 90, g.y)]
    g.update(dt, 0, 0)
    ok &= check("a hit costs a heart and shocks the others away (stunned, alive)",
                g.hp == g.max_hp - 1 and len(g.hunters) == 1 and g.hunters[0].stun > 0
                and _d2(g.x, g.y, g.hunters[0].x, g.hunters[0].y) > 90 * 90)
    g = qg({})
    g.hunters = [Hunter(g.x + 50, g.y), Hunter(g.x - 90, g.y)]
    g.update(dt, 0, 0)
    ok &= check("no Strength, no shock", len(g.hunters) == 1 and g.hunters[0].stun == 0)

    g = qg({}, prey_on_map=0)
    p = Prey(g.x + 100, g.y, 0)
    g.prey = [p]
    x0 = p.x
    for _ in range(30):
        g.update(dt, 0, 0)
    ok &= check("prey run from you, slower than you", p.x - x0 > 20.0 and p.x - x0 < 0.35 * g.speed * 0.5 + 5.0)
    g = qg({"allure": 5})
    p = Prey(g.x + 140, g.y, 0)
    g.prey = [p]
    x0 = p.x
    for _ in range(30):
        g.update(dt, 0, 0)
    ok &= check("Allure calms prey (no flee at a distance that scares at Allure 0)", abs(p.x - x0) < 1e-6)

    g = qg({}, hunter_clock=True, hunter_clock_start=9.0, hunter_clock_end=3.5, hunter_clock_first=4.5, night_length=60.0)
    seen = []
    real_spawn = g._spawn_hunter

    def counted():
        seen.append(g.time)
        real_spawn()
    g._spawn_hunter = counted
    g.hp = g.max_hp = 10 ** 6
    for i in range(60 * 60):
        g.update(dt, 0, 0)
        if g.over:
            break
    ok &= check("hunters arrive on the clock even if you never feed (first near 4.5s)",
                len(seen) >= 2 and 4.0 < seen[0] < 5.0)
    gaps = [seen[i + 1] - seen[i] for i in range(len(seen) - 1)]
    ok &= check("...and the gaps shrink towards dawn", len(gaps) >= 3 and gaps[-1] < gaps[0])

    # Charm
    g = qg({"charm": 1}, max_hunters=20)
    g.hunters = [Hunter(g.x + 70 + 70 * i, g.y) for i in range(2)] + [Hunter(g.x + 70, g.y + 70 + 70 * i) for i in range(2)] + [Hunter(g.x + 500, g.y)]
    ev = g.update(dt, 0, 0, ("charm",))
    charmed = [h for h in g.hunters if h.charm > 0]
    ok &= check("charm takes the nearest 3 hunters in range, not the far one",
                len(charmed) == 3 and g.hunters[4].charm == 0 and g.charm_cd > 14.0
                and [e[0] for e in ev].count("charmed") == 3)
    g2 = qg({})
    g2.hunters = [Hunter(g2.x + 80, g2.y)]
    g2.update(dt, 0, 0, ("charm",))
    ok &= check("no charm without the upgrade", g2.hunters[0].charm == 0)
    g3 = qg({"charm": 1})
    ev = g3.update(dt, 0, 0, ("charm",))
    ok &= check("charm with nobody near fizzles without spending the cooldown",
                any(e[0] == "fizzle" for e in ev) and g3.charm_cd == 0.0)
    g = qg({"charm": 1})
    a, b = Hunter(g.x + 150, g.y), Hunter(g.x + 330, g.y)
    g.hunters = [a, b]
    g.update(dt, 0, 0, ("charm",))
    clashed = False
    for _ in range(240):
        g.update(dt, 0, 0)
        if not g.hunters:
            clashed = True
            break
    ok &= check("a charmed hunter walks into another and both die; you take no damage", clashed and g.hp == g.max_hp)
    g = qg({"charm": 1})
    a = Hunter(g.x + 60, g.y)
    g.hunters = [a]
    g.update(dt, 0, 0, ("charm",))
    for _ in range(30):
        g.update(dt, 0, 0)
    ok &= check("a charmed hunter cannot hurt you", g.hp == g.max_hp and a in g.hunters)
    g = qg({"charm": 1, "allure": 0}, prey_on_map=0)
    p = Prey(g.x + 140, g.y, 1)
    g.prey = [p]
    g.update(dt, 0, 0, ("charm",))
    fed = False
    for _ in range(120):
        g.update(dt, 0, 0)
        if g.fed:
            fed = True
            break
    ok &= check("charmed prey walk to you and feeding on them summons no hunter",
                fed and len(g.hunters) == 0)

    # Bloodlust
    g = qg({"bloodlust": 1}, prey_on_map=0)
    g.prey = [Prey(g.x + 10, g.y, 4)]
    g.update(dt, 0, 0)
    ok &= check("feeding fills the Bloodlust meter", 0.4 < g.frenzy < 0.5)
    ok &= check("not ready: pressing the key does nothing", not g.update(dt, 0, 0, ("bloodlust",)) or g.frenzy_t == 0.0)
    g.prey = [Prey(g.x + 10, g.y, 4)]
    ev = g.update(dt, 0, 0)
    g.prey = [Prey(g.x + 10, g.y, 4)]
    ev += g.update(dt, 0, 0)
    ok &= check("a full meter announces itself", g.frenzy >= 1.0 and any(e[0] == "bloodlust_ready" for e in ev))
    g.hunters = [Hunter(g.x + 300, g.y), Hunter(g.x - 200, g.y + 100)]
    g.update(dt, 0, 0, ("bloodlust",))
    ok &= check("trigger starts the mode", g.bloodlust_on and g.frenzy_t > 4.0)
    d0 = [math.hypot(h.x - g.x, h.y - g.y) for h in g.hunters]
    for _ in range(30):
        g.update(dt, 0, 0)
    d1 = [math.hypot(h.x - g.x, h.y - g.y) for h in g.hunters]
    ok &= check("hunters flee from you during Bloodlust", all(b > a for a, b in zip(d0, d1)))
    g.hunters = [Hunter(g.x + 30, g.y)]
    b0 = g.blood
    ev = g.update(dt, 0, 0)
    ok &= check("touching a hunter kills it, pays, and costs no heart",
                not g.hunters and g.hp == g.max_hp and g.blood == b0 + 30 and any(e[0] == "kill" for e in ev))
    for _ in range(int(5.2 * 60)):
        ev = g.update(dt, 0, 0)
    ok &= check("it ends after bloodlust_time and the meter is empty", not g.bloodlust_on and g.frenzy == 0.0)
    g = qg({}, prey_on_map=0)
    g.prey = [Prey(g.x + 10, g.y, 4)]
    g.update(dt, 0, 0)
    ok &= check("no Bloodlust without the upgrade: no meter", g.frenzy == 0.0)

    # 7a. Iron Skin: Strength lets you shrug off hunter touches
    def touches(up, n=600):
        m = qg(up)
        blocked = hurt_n = 0
        for _ in range(n):
            m.hp = m.max_hp
            m.invuln = 0.0
            m.kill_streak = 2
            m.hunters = [Hunter(m.x + 30, m.y)]
            ev = m.update(dt, 0, 0)
            if any(e[0] == "block" for e in ev):
                blocked += 1
                assert m.hp == m.max_hp and m.kill_streak == 2 and len(m.hunters) == 1 and m.hunters[0].stun > 0
                assert _d2(m.x, m.y, m.hunters[0].x, m.hunters[0].y) > 100 * 100
            elif m.hp < m.max_hp:
                hurt_n += 1
        return blocked / float(n), hurt_n / float(n)

    b5, h5 = touches({"strength": 5})
    b0, h0 = touches({})
    b1, _h1 = touches({"strength": 1})
    ok &= check("Iron Skin: Strength 5 blocks about 40%% of touches (%.2f), the rest wound (%.2f)" % (b5, h5),
                0.33 <= b5 <= 0.47 and abs(b5 + h5 - 1.0) < 1e-9)
    ok &= check("Iron Skin: Strength 1 blocks about 8%% (%.2f)" % b1, 0.04 <= b1 <= 0.12)
    ok &= check("Iron Skin control: Strength 0 never blocks (%.2f) and every touch wounds (%.2f)" % (b0, h0),
                b0 == 0.0 and h0 == 1.0)

    # 7b. Drain Life: every third kill in a row, no hit between, mends half a heart; 25s rest
    def drain_game(drain=1, hurt=1.0):
        m = qg({"constitution": 5, "drain": drain})
        m.hp = m.max_hp - hurt
        m.invuln = 9999.0                # hunters summoned by feeding must not interfere
        return m

    def feed_once(m):
        m.prey = [Prey(m.x + 10, m.y, 0)]
        return m.update(dt, 0, 0)

    def heals(ev):
        return [e[3] for e in ev if e[0] == "heal"]

    m = drain_game()
    got = [heals(feed_once(m)) for _ in range(3)]
    ok &= check("Drain: the 3rd kill in a row heals half a heart, the first two do not",
                got == [[], [], [0.5]] and m.hp == m.max_hp - 0.5)
    got = [heals(feed_once(m)) for _ in range(3)]
    ok &= check("Drain: 3 more kills inside the 25s rest heal nothing", got == [[], [], []] and m.hp == m.max_hp - 0.5)
    m.prey = []
    for _ in range(int(25.2 * 60)):
        m.update(dt, 0, 0)
    got = [heals(feed_once(m)) for _ in range(3)]
    ok &= check("Drain: after 25s a banked streak pays out on the next kill, once (hp %.2f/%d)" % (m.hp, m.max_hp),
                got == [[0.5], [], []] and m.hp == m.max_hp)
    m = drain_game(drain=0)              # control: same scenario without the skill
    got = [heals(feed_once(m)) for _ in range(6)]
    ok &= check("Drain control: without the skill, kills never heal", not any(got) and m.hp == m.max_hp - 1.0)
    m = drain_game()
    feed_once(m); feed_once(m)
    m.hunters = [Hunter(m.x + 30, m.y)]
    m.invuln = 0.0
    m.update(dt, 0, 0)
    m.invuln = 9999.0
    hp_hit = m.hp
    got = heals(feed_once(m))
    ok &= check("Drain: a hit breaks the streak (2 kills, hit, 1 kill = no heal)",
                hp_hit == m.max_hp - 2.0 and got == [] and m.kill_streak == 1)
    m = drain_game(hurt=0.0)
    got = [heals(feed_once(m)) for _ in range(4)]
    ok &= check("Drain at full health heals nothing and the rest is not spent",
                not any(got) and m.heal_cd == 0.0 and m.hp == m.max_hp)
    m = drain_game(hurt=0.25)
    for _ in range(3):
        feed_once(m)
    ok &= check("Drain heals only what is missing (quarter heart)", m.hp == m.max_hp)
    m = qg({"constitution": 5, "drain": 1, "bloodlust": 1})
    m.hp = m.max_hp - 1.0
    m.invuln = 9999.0
    m.frenzy_t = 5.0
    m.hunters = [Hunter(m.x + 30, m.y), Hunter(m.x - 30, m.y), Hunter(m.x, m.y + 30)]
    ev = m.update(dt, 0, 0)
    ok &= check("Drain: three Bloodlust kills count as a streak", heals(ev) == [0.5])

    # 7c. Harvest: R stops time for 5s. Everything but you holds still; touch to kill or feed.
    def hv(up=None, **extra):
        cfgx = {"night_length": 60.0, "hunter_clock": True, "hunter_slide_time": 0.0}
        cfgx.update(extra)
        u = {"ultimate": 1}
        u.update(up or {})
        return qg(u, **cfgx)

    def snap(m):
        return ([(h.x, h.y) for h in m.hunters], [(p.x, p.y) for p in m.prey])

    m = hv()
    m.hunters = [Hunter(m.x + 400, m.y), Hunter(m.x - 500, m.y + 100)]
    m.prey = [Prey(m.x, m.y + 300, 1)]
    ev = m.update(dt, 0, 0, ("ultimate",))
    ok &= check("Harvest: R starts it and says so", m.harvest_on and any(e[0] == "harvest" for e in ev))
    s0, t0, sp0, n0 = snap(m), m.time, m.spawn_t, len(m.hunters)
    for _ in range(int(4.5 * 60)):
        m.update(dt, 0, 0)
    ok &= check("Harvest: hunters, prey, the night clock and the hunter clock all stand still",
                snap(m) == s0 and m.time == t0 and m.spawn_t == sp0 and len(m.hunters) == n0 and m.harvest_on)
    for _ in range(int(0.7 * 60)):
        ev2 = m.update(dt, 0, 0)
    ok &= check("Harvest: it ends after harvest_time, then time runs again",
                not m.harvest_on and m.time > t0)
    m.update(dt, 0, 0, ("ultimate",))
    ok &= check("Harvest: only once per night", not m.harvest_on and m.harvest_used)
    m = hv(up={"ultimate": 0})
    m.update(dt, 0, 0, ("ultimate",))
    ok &= check("Harvest control: without the ultimate, R does nothing", not m.harvest_on and not m.harvest_used)

    m = hv()
    m.update(dt, 0, 0, ("ultimate",))
    m.hunters = [Hunter(m.x + 20, m.y), Hunter(m.x + 600, m.y)]
    far = (m.hunters[1].x, m.hunters[1].y)
    b0, hp0 = m.blood, m.hp
    ev = m.update(dt, 0, 0)
    ok &= check("Harvest: touching a hunter kills it for blood and costs no heart; others stay put",
                len(m.hunters) == 1 and (m.hunters[0].x, m.hunters[0].y) == far and m.hp == hp0
                and m.blood == b0 + m.cfg["harvest_kill_blood"] and any(e[0] == "harvest_kill" for e in ev))
    m.hunters = []
    m.prey = [Prey(m.x + 10, m.y, 2)]
    ev = m.update(dt, 0, 0)
    ok &= check("Harvest: touching prey feeds on it and summons no hunter",
                any(e[0] == "feed" for e in ev) and not m.hunters)
    x0 = m.x
    m.update(dt, 1, 0)
    mv = m.x - x0
    n = qg({})
    n.x = x0
    n.update(dt, 1, 0)
    ok &= check("Harvest: you move faster while it lasts (%.2f vs %.2f px a frame)" % (mv, n.x - x0), mv > (n.x - x0) * 1.2)

    m = hv()
    m.update(dt, 0, 0, ("ultimate",))
    m.hunters = [Hunter(m.x + 20, m.y)]
    m.hp = m.max_hp - 1.0
    m.kill_streak = 2
    m.up["drain"] = 1
    m.update(dt, 0, 0)
    ok &= check("Harvest kills count for Drain Life", m.hp == m.max_hp - 0.5)
    for _ in range(int(5.2 * 60)):
        ev = m.update(dt, 0, 0)
    ok &= check("Harvest grants a moment of safety when it ends", m.invuln > 0.0)
    m = hv()
    m.update(dt, 0, 0, ("ultimate",))
    ok &= check("Harvest cannot be cut short by dawn", m.harvest_on and m.time < m.cfg["night_length"])

    # 8. pacing: what a competent player gets out of a run, unupgraded vs maxed.
    def survey(up):
        runs = [_play(upgrades=up, seed=s, policy="cautious") for s in range(20)]
        return (sum(r.time for r in runs) / 20.0,
                sum(r.blood for r in runs) / 20.0,
                sum(r.fed for r in runs) / 20.0)

    t0, b0, f0 = survey({})
    t5, b5, f5 = survey({"speed": 5, "constitution": 5, "allure": 5, "strength": 5})
    print("\npacing (cautious policy, 20 seeds):")
    print("  level 0 : %5.1fs  %6.0f blood  %4.1f prey" % (t0, b0, f0))
    print("  level 5 : %5.1fs  %6.0f blood  %4.1f prey" % (t5, b5, f5))
    ok &= check("an unupgraded run lasts 5-120s (short on purpose: 60s night, no lunge)", 5.0 <= t0 <= 120.0)
    ok &= check("maxed run out-earns unupgraded by 2x or more", b5 >= b0 * 2.0)

    # per-level pacing at each level's own unlock power (upgrades spread evenly).
    # Informational numbers from a crude bot -- the assertion is only a broad
    # sanity band, NOT a balance target (big arenas gave the bot ~2x longer
    # survival than the old small ones; tune by feel, see the notes).
    print("\nper-level pacing (at unlock power, cautious policy, 10 seeds):")
    names = ["speed", "constitution", "strength", "allure"]
    for i, lv in enumerate(LEVELS):
        up = dict((n, 0) for n in names)
        for j in range(lv["unlock_power"]):
            up[names[j % 4]] += 1
        runs = [_play(seed=sd, policy="cautious", upgrades=up, config=level_cfg(i, sd)) for sd in range(10)]
        tt = sum(r.time for r in runs) / 10.0
        print("  %-10s %5.1fs  %6.0f blood  %4.1f prey" % (lv["key"], tt, sum(r.blood for r in runs) / 10.0,
                                                           sum(r.fed for r in runs) / 10.0))
        ok &= check("%s at unlock power lasts 20-400s" % lv["key"], 20.0 <= tt <= 400.0)

    # 9. obstacles: given a hand-placed list (the only way they exist now),
    # nothing ever ends a frame embedded in one.
    worst_overlap = 0.0
    for seed in range(10):
        # non-overlapping by construction -- a level designer hand-placing
        # obstacles wouldn't stack them either, and the resolver (like most
        # simple push-out resolvers) only guarantees a clean result when
        # obstacles don't overlap each other.
        # gap >= 2x the biggest entity radius (hunter/vamp both 26) so the
        # two obstacles' keep-out zones (obstacle.radius + entity.radius)
        # don't overlap each other -- when they do, no single point can
        # satisfy both circles' push-out at once and the iterative resolver
        # can only get close, not exact. Below that threshold is a real
        # geometric limit, not a bug; hand-placed obstacles should keep it
        # in mind for tight passages too.
        rng9 = random.Random(seed + 900)
        explicit9 = []
        for _ in range(10):
            for _try in range(20):
                ex, ey, er = rng9.uniform(100, 1300), rng9.uniform(100, 720), rng9.uniform(30, 60)
                if all(math.sqrt(_d2(ex, ey, ox, oy)) >= er + orad + 60.0
                       for ox, oy, orad in explicit9):
                    explicit9.append((ex, ey, er))
                    break
        g = HuntGame(config={"obstacles": explicit9}, seed=seed)
        rng = random.Random(seed + 500)
        for _ in range(3000):
            if g.over:
                break
            g.update(dt, rng.uniform(-1, 1), rng.uniform(-1, 1), ("blink",) if rng.random() < 0.01 else ())
            for o in g.obstacles:
                d = math.sqrt(_d2(g.x, g.y, o.x, o.y)) - (o.radius + g.cfg["vamp_radius"])
                if d < -0.5:
                    worst_overlap = max(worst_overlap, -d)
            for h in g.hunters:
                for o in g.obstacles:
                    d = math.sqrt(_d2(h.x, h.y, o.x, o.y)) - (o.radius + g.cfg["hunter_radius"])
                    if d < -0.5:
                        worst_overlap = max(worst_overlap, -d)
    ok &= check("obstacles: no embedding found (worst %.1fpx)" % worst_overlap, worst_overlap <= 0.5)

    # 10. an explicit obstacle list (hand-mapped from DungeonDraft) is used
    # verbatim, no random fallback, and still gets the same safety resolver.
    explicit = [(300, 300, 40), (900, 500, 55)]
    g = HuntGame(config={"obstacles": explicit}, seed=1)
    ok &= check("explicit obstacle list used verbatim",
                len(g.obstacles) == 2
                and (g.obstacles[0].x, g.obstacles[0].y, g.obstacles[0].radius) == (300.0, 300.0, 40.0))
    gx, gy = g._resolve_obstacles(300.0, 300.0, 26.0)
    ok &= check("hand-mapped obstacles still push the player out",
                math.hypot(gx - 300.0, gy - 300.0) >= 40.0 + 26.0 - 0.5)

    # 10a. the spatial grid resolves exactly like checking every obstacle
    gt = HuntGame(config=level_cfg(len(LEVELS) - 1, 7), seed=7)
    rr = gt.cfg["vamp_radius"]
    rnd_ = random.Random(5)
    same = True
    for _ in range(1500):
        px, py = rnd_.uniform(0, gt.w), rnd_.uniform(0, gt.h)
        bx, by = px, py
        for _pass in range(4):
            mv = False
            for o in gt.obstacles:
                bx, by, m_ = o.push(bx, by, rr)
                mv = mv or m_
            if not mv:
                break
        gx_, gy_ = gt._resolve_obstacles(px, py, rr)
        same &= abs(gx_ - bx) < 1e-6 and abs(gy_ - by) < 1e-6
    ok &= check("obstacle grid resolves identically to a full scan (%d obstacles)" % len(gt.obstacles), same)

    # 10b. building footprints are rectangles: an entity is pushed out of a
    # side, out of a corner (circle-shaped), and out from inside.
    g = HuntGame(config={"obstacles": [("rect", 100, 100, 300, 200)]}, seed=1)
    rr = g.cfg["vamp_radius"]
    px, py = g._resolve_obstacles(200.0, 210.0, rr)
    ok &= check("rect: pushed out of a side", abs(py - (200.0 + rr)) < 0.01 and px == 200.0)
    px, py = g._resolve_obstacles(310.0, 210.0, rr)
    ok &= check("rect: pushed out of a corner, circle-shaped",
                abs(math.hypot(px - 300.0, py - 200.0) - rr) < 0.01)
    px, py = g._resolve_obstacles(120.0, 150.0, rr)
    ok &= check("rect: pushed out from inside via the nearest edge", px == 100.0 - rr and py == 150.0)
    ok &= check("rect: clearance is distance to the surface",
                abs(g.obstacles[0].clearance(350.0, 150.0) - 50.0) < 1e-6)

    # 11. every level builds a random map; its collision circles become the
    # obstacles, nothing blocks the spawn, and a long random run never leaves
    # an entity embedded in an obstacle.
    for i in range(len(LEVELS)):
        worst = 0.0
        for seed in range(6):
            cfg = level_cfg(i, seed)
            g = HuntGame(config=cfg, seed=seed)
            ok &= check("%s seed %d: obstacle count matches its map" % (LEVELS[i]["key"], seed),
                        len(g.obstacles) == len(hunt_mapgen.obstacles_of(cfg["map"])))
            rng = random.Random(seed)
            for _ in range(4000):
                if g.over:
                    break
                g.update(1.0 / 60.0, rng.uniform(-1, 1), rng.uniform(-1, 1), ("blink",) if rng.random() < 0.01 else ())
                for o in g.obstacles:
                    worst = max(worst, g.cfg["vamp_radius"] - o.clearance(g.x, g.y))
        ok &= check("%s: vamp never embedded in a generated obstacle (worst %.1fpx)" % (LEVELS[i]["key"], worst),
                    worst <= 0.5)
    ok &= check("same seed -> same level map", level_cfg(0, 9)["map"] == level_cfg(0, 9)["map"])
    ok &= check("unseeded level_cfg gives different maps", level_cfg(0)["map"]["seed"] != level_cfg(0)["map"]["seed"])

    print("\n%s" % ("ALL PASS" if ok else "FAILURES ABOVE"))
    return ok


# ---------------------------------------------------------------------------
# levels: forest (easy/low-reward) up through town (hard/high-reward)
# ---------------------------------------------------------------------------
# Each entry overrides a few DEFAULT_CONFIG keys. unlock_power is the
# threshold on sum(cw_upgrades.values()) (0-20) that opens the level -- i.e.
# the vampire has to actually grow stronger to take the higher-risk hunts.

LEVELS = [
    {
        "key": "forest", "name": "Wailing Wood", "unlock_power": 0,
        "biome": "forest", "tiles": (34, 22),   # arena = tiles x 70 world px; map is random every run
        "cfg": {
            "hunter_speed_frac": 0.46, "hunter_boost_mult": 1.18,
            "hunter_boost_dist": 190, "max_hunters": 6, "prey_on_map": 4,
            "tier_weights": [60.0, 26.0, 10.0, 3.0, 1.0],
            "blood_mult": 0.85, "invuln_time": 1.8,
        },
    },
    {
        "key": "road", "name": "Old Coast Road", "unlock_power": 3,
        "biome": "road", "tiles": (40, 26),
        "cfg": {
            "hunter_speed_frac": 0.54, "hunter_boost_mult": 1.32,
            "hunter_boost_dist": 220, "max_hunters": 8,
            "tier_weights": [52.0, 28.0, 13.0, 5.0, 2.0],
            "blood_mult": 1.0,
        },
    },
    {
        "key": "outskirts", "name": "Village Outskirts", "unlock_power": 7,
        "biome": "outskirts", "tiles": (48, 30),
        "cfg": {},
    },
    {
        "key": "village", "name": "Blackmere Village", "unlock_power": 12,
        "biome": "village", "tiles": (56, 34),
        "cfg": {
            "hunter_speed_frac": 0.70,
            # boost_mult cut from an earlier 1.70: at max Speed, hunters could
            # still be 17% faster than you in the worst case (max ramp +
            # boosted), regardless of upgrades. 1.30 brings that to ~90%, a
            # real if tight margin. Steady chase speed (hunter_speed_frac)
            # left alone on purpose -- only the close-range spike was the
            # problem.
            "hunter_boost_mult": 1.30,
            "hunter_boost_dist": 280, "max_hunters": 12,
            "tier_weights": [34.0, 27.0, 20.0, 13.0, 6.0],
            "blood_mult": 1.35, "invuln_time": 1.3,
        },
    },
    {
        "key": "town", "name": "Harrow's Gate", "unlock_power": 17,
        "biome": "town", "tiles": (96, 64),   # walled city (64x40) plus countryside
        "cfg": {
            "hunter_speed_frac": 0.78,
            # same fix as village: boost_mult 1.85->1.45 and ramp cap
            # 0.30->0.20 bring the worst-case ratio from 138% down to ~98%
            # (still the tightest in the game, town is meant to be the hardest).
            "hunter_boost_mult": 1.45, "hunter_speed_ramp_cap": 0.20,
            "hunter_boost_dist": 300, "max_hunters": 13,
            "tier_weights": [22.0, 25.0, 23.0, 19.0, 11.0],
            "blood_mult": 1.75, "invuln_time": 1.1,
        },
    },
]


def level_cfg(index, seed=None):
    """DEFAULT_CONFIG with one level's overrides merged in, plus a freshly
    generated random map (hunt_mapgen) -- arena size, spawn, collision
    obstacles and the drawable "map" all come from it. Pass a seed to
    reproduce a map. Does not mutate DEFAULT_CONFIG."""
    lv = LEVELS[index]
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(lv["cfg"])
    m = hunt_mapgen.generate(lv["biome"], lv["tiles"][0], lv["tiles"][1], seed)
    cfg["arena_w"], cfg["arena_h"] = m["w"], m["h"]
    cfg["spawn"] = m["spawn"]
    cfg["obstacles"] = hunt_mapgen.obstacles_of(m)
    cfg["map"] = m
    return cfg


def unlocked_levels(upgrades):
    power = sum(int(v) for v in (upgrades or {}).values())
    return [i for i, lv in enumerate(LEVELS) if lv["unlock_power"] <= power]


if __name__ == "__main__":
    import sys
    sys.exit(0 if _selftest() else 1)
