# Where blood turns into permanent upgrades. Reads and writes cw_blood and
# cw_upgrades, both declared in hunt.rpy.

init python:
    import store

    CW_MAX_LEVEL = 5

    CW_UPGRADES = [
        ("speed", "Swiftness",
         "Move faster. The hunters keep pace with you, so this buys reach, not escape."),
        ("constitution", "Constitution",
         "One more touch before the night takes you."),
        ("allure", "Allure",
         "Feed from further away, draw richer prey, and calm it so it runs less."),
        ("strength", "Strength",
         "Blood Shock: when a hunter wounds you, the pack around you is hurled back and stunned."),
    ]

    # Powers are not extra upgrades. When a stat reaches 5 / 5 the MAXED mark on
    # its card turns into the power's card (icon, name, an unlock button). Costs
    # are deliberately steep.
    CW_POWER_OF = {"speed": "blink", "allure": "charm", "strength": "bloodlust"}
    CW_POWER_COST = {"blink": 2500, "charm": 3000, "bloodlust": 3500}
    CW_POWER_TEXT = {
        "blink": ("Swiftness is mastered. Unlock Blink: step through walls and buildings.",
                  "Mastered. Blink: step through walls and buildings."),
        "charm": ("Allure is mastered. Unlock Charm: bend the nearest few to your will.",
                  "Mastered. Charm: bends the nearest few to your will."),
        "bloodlust": ("Strength is mastered. Unlock Bloodlust: feed to fill it, then hunters flee and die at your touch.",
                      "Mastered. Bloodlust: feed to fill it, then hunters flee and die at your touch."),
    }

    def cw_power_owned(key):
        p = CW_POWER_OF.get(key)
        return bool(p) and store.cw_upgrades.get(p, 0) >= 1

    def cw_power_offer(key):
        """True while the stat is maxed and its power is not bought yet."""
        p = CW_POWER_OF.get(key)
        return (bool(p) and store.cw_upgrades.get(key, 0) >= CW_MAX_LEVEL
                and store.cw_upgrades.get(p, 0) < 1)

    def cw_blurb(key, blurb):
        if cw_power_offer(key):
            return CW_POWER_TEXT[CW_POWER_OF[key]][0]
        if cw_power_owned(key):
            return CW_POWER_TEXT[CW_POWER_OF[key]][1]
        return blurb

    def cw_cost(level):
        """Blood for the next level, or None if already maxed."""
        if level >= CW_MAX_LEVEL:
            return None
        return int(round(100 * (1.9 ** level) / 10.0) * 10)

    def cw_buy(key):
        level = store.cw_upgrades.get(key, 0)
        cost = cw_cost(level)
        if cost is None or store.cw_blood < cost:
            return
        store.cw_blood -= cost
        store.cw_upgrades[key] = level + 1
        renpy.restart_interaction()

    def cw_buy_power(power):
        """Buy a power (its key is fixed, see CW_KEYS in hunt.rpy)."""
        stat = [k for k, v in CW_POWER_OF.items() if v == power][0]
        cost = CW_POWER_COST[power]
        if not cw_power_offer(stat) or store.cw_blood < cost:
            return
        store.cw_blood -= cost
        store.cw_upgrades[power] = 1
        renpy.restart_interaction()


screen blood_shop():
    add CheatListener()
    modal True
    add cw_backdrop()

    frame:
        background cw_panel("stone")
        align (0.5, 0.5)
        padding (64, 44, 64, 52)

        vbox:
            spacing 14

            hbox:
                xsize 1600
                text "Blood Market" style "cw_title" yalign 0.5
                hbox:
                    xalign 1.0
                    yalign 0.5
                    spacing 14
                    add cw_drop(True) yalign 0.5
                    text ("%d" % cw_blood) style "cw_label" size 52 color CW_GOLD yalign 0.5

            add cw_divider(110) xalign 0.5
            null height 4

            hbox:
                spacing 32

                # Character preview. Only Allure changes anything for now: a
                # red aura that grows with its level, so buying it pays off
                # immediately. Hook point for per-upgrade art later.
                frame:
                    background cw_card("dim")
                    xsize 400
                    ysize 584
                    padding (15, 15)

                    add cw_backdrop()
                    fixed:
                        xalign 0.5
                        yalign 0.46
                        xysize (340, 340)

                        if cw_upgrades["allure"] > 0:
                            add cw_ring(14 + 3 * cw_upgrades["allure"]) at cw_aura_glow:
                                xalign 0.5
                                yalign 0.5
                        add cw_vampire(10):
                            xalign 0.5
                            yalign 0.5

                    text "Dorak" style "cw_h2" xalign 0.5 yalign 1.0 yoffset -92
                    text ("Allure  %d / %d" % (cw_upgrades["allure"], CW_MAX_LEVEL)) style "cw_dim" xalign 0.5 yalign 1.0 yoffset -48

                vbox:
                    spacing 12

                    for key, title, blurb in CW_UPGRADES:
                        $ level = cw_upgrades.get(key, 0)
                        $ mx = CW_MAX_LEVEL
                        $ cost = cw_cost(level)
                        $ power = CW_POWER_OF.get(key)
                        $ offer = cw_power_offer(key)
                        $ owned = cw_power_owned(key)
                        $ pcard = offer or owned
                        $ show_key = power if pcard else key
                        $ show_title = CW_POWER_TITLE[power] if pcard else title
                        $ show_level = cw_upgrades.get(power, 0) if pcard else level
                        $ show_max = 1 if pcard else mx

                        frame:
                            background cw_card("blood" if offer else ("gold" if cost is None else "stone"))
                            xsize 1150
                            ysize 140
                            padding (28, 10, 28, 12)

                            hbox:
                                spacing 24
                                yalign 0.5

                                frame:
                                    background cw_card("dim")
                                    xysize (96, 96)
                                    padding (15, 15)
                                    yalign 0.5
                                    add cw_icon(show_key, 3) align (0.5, 0.5)

                                vbox:
                                    xsize 500
                                    yalign 0.5
                                    text show_title style "cw_label" size 34
                                    text cw_blurb(key, blurb) style "cw_dim" size 22 color (CW_TEXT if offer else CW_DIM)

                                vbox:
                                    xsize 190
                                    yalign 0.5
                                    spacing 8
                                    text ("Level %d / %d" % (show_level, show_max)) style "cw_text" size 26 xalign 0.5
                                    hbox:
                                        xalign 0.5
                                        spacing 4
                                        for n in range(show_max):
                                            add cw_pip(n < show_level, 3)

                                if offer:
                                    button:
                                        style "cw_button"
                                        xsize 210
                                        yalign 0.5
                                        padding (20, 14, 20, 20)
                                        action Function(cw_buy_power, power)
                                        sensitive (cw_blood >= CW_POWER_COST[power])
                                        hbox:
                                            xalign 0.5
                                            spacing 10
                                            add cw_drop(cw_blood >= CW_POWER_COST[power], 2) yalign 0.5
                                            text ("%d" % CW_POWER_COST[power]) style "cw_button_text" yalign 0.5
                                elif owned:
                                    vbox:
                                        xsize 210
                                        yalign 0.5
                                        spacing 6
                                        text "UNLOCKED" style "cw_label" size 32 color CW_GOLD xalign 0.5
                                        text ("Press %s" % cw_key_label(CW_KEYS[power])) style "cw_dim" size 26 xalign 0.5
                                elif cost is None:
                                    text "MAXED" style "cw_label" size 38 color CW_GOLD xsize 210 text_align 0.5 yalign 0.5
                                else:
                                    button:
                                        style "cw_button"
                                        xsize 210
                                        yalign 0.5
                                        padding (20, 14, 20, 20)
                                        action Function(cw_buy, key)
                                        sensitive (cw_blood >= cost)
                                        hbox:
                                            xalign 0.5
                                            spacing 10
                                            add cw_drop(cw_blood >= cost, 2) yalign 0.5
                                            text ("%d" % cost) style "cw_button_text" yalign 0.5

            null height 10
            textbutton "Back to the hunt" style "cw_button" xalign 0.5 action Return(True)
