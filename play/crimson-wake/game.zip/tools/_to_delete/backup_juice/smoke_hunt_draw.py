"""Headless smoke test for hunt.rpy's HuntDisplayable.

Ren'Py isn't available here, so this stubs the handful of engine names the
displayable touches (renpy.Render/render, im.Data, Transform, Solid, Text,
pygame_sdl2) and runs real frames of draw() on every level's generated map.
It catches NameErrors, bad attribute use and out-of-range blits -- not how
anything looks (use make_pixel_sheet.py for that).

    python tools/smoke_hunt_draw.py
"""
import math
import os
import random
import re
import sys
import textwrap
import types

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "game", "python-packages"))


class Render(object):
    def __init__(self, w, h):
        self.w, self.h, self.blits = w, h, []

    def blit(self, other, pos):
        self.blits.append((other, pos))

    def subsurface(self, rect):
        return Render(rect[2], rect[3])

    def get_size(self):
        return self.w, self.h


class Stub(object):
    def __init__(self, *a, **k):
        self.a, self.k = a, k


calls = {"render": 0}


def fake_render(d, w, h, st, at):
    calls["render"] += 1
    if isinstance(d, Stub) and getattr(d, "data", None) is not None:
        assert d.data[:8] == b"\x89PNG\r\n\x1a\n", "im.Data got non-PNG bytes"
    return Render(8, 8)


class Displayable(object):
    def __init__(self, **k):
        pass


renpy = types.SimpleNamespace(Render=Render, render=fake_render, Displayable=Displayable,
                              redraw=lambda *a: None, timeout=lambda *a: None,
                              loadable=lambda p: False, IgnoreEvent=Exception)


class Data(Stub):
    def __init__(self, data, filename):
        self.data, self.filename = data, filename


ns = {"renpy": renpy, "im": types.SimpleNamespace(Data=Data), "Transform": Stub, "Solid": Stub,
      "Text": Stub, "Image": Stub}
sdl = types.ModuleType("pygame_sdl2")
for name in ("K_LEFT", "K_a", "K_RIGHT", "K_d", "K_UP", "K_w", "K_DOWN", "K_s", "K_SPACE", "K_q", "KEYDOWN", "KEYUP"):
    setattr(sdl, name, hash(name) % 1000)
sys.modules["pygame_sdl2"] = sdl

src = open(os.path.join(HERE, "..", "game", "hunt.rpy")).read()
a = src.index("init python:") + len("init python:\n")
b = src.index("\ndefault cw_blood")
exec(compile(textwrap.dedent(src[a:b]), "hunt.rpy[init python]", "exec"), ns)

hunt_core = ns["hunt_core"]
for i, lv in enumerate(hunt_core.LEVELS):
    game = hunt_core.HuntGame(config=hunt_core.level_cfg(i, 3), seed=3)
    hd = ns["HuntDisplayable"](game, lv)
    rng = random.Random(i)
    for frame in range(240):
        game.update(1 / 60.0, rng.uniform(-1, 1), rng.uniform(-1, 1), lunge=rng.random() < 0.05)
        for e in game.events:
            pass
        hd.render(1920, 1080, frame / 60.0, frame / 60.0)
    assert hd.view_w <= ns["DISPLAY_W"] and hd.view_h <= ns["DISPLAY_H"], "view does not fit the box"
    assert 0 <= hd.cam_x <= hd.aw - hd.view_w and 0 <= hd.cam_y <= hd.ah - hd.view_h, "camera left the map"
    assert hd.cam_x % hd.nz == 0 and hd.cam_y % hd.nz == 0, "camera not snapped to the pixel grid"
    print("%-10s arena %dx%d px, view %dx%d, %d base + %d crown sprites, frames OK"
          % (lv["key"], hd.aw, hd.ah, hd.view_w, hd.view_h, len(hd.base_items), len(hd.crown_items)))
print("smoke OK, %d render calls" % calls["render"])
