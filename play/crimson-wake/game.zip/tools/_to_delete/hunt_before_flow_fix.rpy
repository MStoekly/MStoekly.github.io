# The hunt minigame: you are the vampire, prey is currency, hunters are the cost.
# Rules and tuning live in game/python-packages/hunt_core.py (restart the game
# after editing it -- Shift+R does not re-import python packages).

init python:
    import math
    import time
    import hunt_core
    import pygame_sdl2 as pygame
    import hunt_mapgen
    import pixel_art
    import hunt_juice

    # Where the arena sits inside the 1920x1080 window, and the box its
    # rendering is scaled to fit -- whatever the level's actual arena_w/h is,
    # the whole map is always visible, just smaller for a bigger map.
    HUNT_X = 260
    HUNT_Y = 170
    DISPLAY_W = 1400.0
    DISPLAY_H = 820.0

    # One native pixel of art = PIXEL_ZOOM screen pixels, always an integer so
    # the pixels stay square and crisp (the PNGs are upscaled in code, not by
    # the engine). The 1400x820 box shows ~29x17 tiles at this zoom; maps
    # bigger than that scroll with a camera that follows the vampire.
    PIXEL_ZOOM = 3

    # Per-level track, keyed by LEVELS[i]["key"] -- not derived from the
    # display name, since those don't always match the file (e.g. the
    # village level is named "Blackmere Village" but its track is
    # "Blackmere Gate.mp3"). Add new entries here as tracks arrive.
    HUNT_MUSIC = {
        "forest": "music/Wailing Wood.mp3",
        "road": "music/Old Coast Road.mp3",
        "outskirts": "music/Village Outskirts.mp3",
        "village": "music/Blackmere Gate.mp3",
        "town": "music/Harrow's Gate.mp3",
    }

    # Sound effects (synthesized by tools/make_sfx.py into game/audio/). A few
    # extra channels on the sfx mixer so overlapping sounds don't cut each
    # other off; missing files are silently skipped.
    HUNT_SFX_CHANNELS = ["sound", "hunt_sfx2", "hunt_sfx3", "hunt_sfx4"]
    for _name in HUNT_SFX_CHANNELS[1:]:
        renpy.music.register_channel(_name, "sfx", False)

    BLOOD_COLORS = ["#c81428", "#8e0f1e", "#e8465a"]
    SPARK_COLORS = ["#ffe9a0", "#ffffff", "#e8c04a"]
    DUST_COLORS = ["#7d746d", "#5f5853", "#948a82"]
    BLINK_COLORS = ["#6e44a0", "#4a2a6a", "#c81428", "#f2ece6"]
    POOF_COLORS = ["#1c1030", "#3a1f52", "#6e3a6e", "#c27aa8"]
    DAWN_COLORS = ["#d79ac8", "#a86aa8", "#f0d6f0", "#7a4a8a"]      # muddy mauve, not sunny
    HEAL_COLORS = ["#ff9cc4", "#ffffff", "#ffd0e4", "#e8465a"]
    CHARM_COLORS = ["#ff7fb0", "#ff4f8a", "#ffd0e4", "#a67ee0"]
    FRENZY_COLORS = ["#c81428", "#ff2a3d", "#ff8a5a", "#5a0a18"]
    ICE_COLORS = ["#b8e8ff", "#ffffff", "#7ac8f0", "#e8f8ff"]
    ASH_COLORS = ["#6a6068", "#8a7e86", "#4a424c", "#a898a4"]

    # The three unlockable powers, each earned at 5/5 of a stat (see shop.rpy).
    # R is kept free for the ultimate.
    CW_POWERS = ("blink", "charm", "bloodlust")
    CW_POWER_TITLE = {"blink": "Blink", "charm": "Charm", "bloodlust": "Bloodlust", "drain": "Drain Life"}   # drain is a passive: no key, no bar

    # Controls. Every action has one rebindable key, kept in `persistent` so it
    # survives new games. The arrow keys always move you as well, so a bad
    # binding can never lock you out of the game.
    CW_MOVE_ACTIONS = ("up", "down", "left", "right")
    CW_ACTIONS = CW_MOVE_ACTIONS + CW_POWERS + ("ultimate",)
    CW_ACTION_TITLE = {"up": "Move up", "down": "Move down", "left": "Move left", "right": "Move right",
                       "blink": "Blink", "charm": "Charm", "bloodlust": "Bloodlust", "ultimate": "Harvest"}
    CW_DEFAULT_KEYS = {"up": pygame.K_w, "down": pygame.K_s, "left": pygame.K_a, "right": pygame.K_d,
                       "blink": pygame.K_f, "charm": pygame.K_e, "bloodlust": pygame.K_SPACE, "ultimate": pygame.K_r}
    CW_MOVE_DIR = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}
    CW_ARROWS = {pygame.K_LEFT: (-1, 0), pygame.K_RIGHT: (1, 0), pygame.K_UP: (0, -1), pygame.K_DOWN: (0, 1)}
    CW_MODIFIERS = (pygame.K_LSHIFT, pygame.K_RSHIFT, pygame.K_LCTRL, pygame.K_RCTRL, pygame.K_LALT, pygame.K_RALT)

    def cw_key_label(code):
        n = pygame.key.name(code)
        if isinstance(n, bytes):          # pygame_sdl2 returns bytes
            n = n.decode("utf-8", "replace")
        n = n or "?"
        n = n.upper() if len(n) == 1 else n.title()
        return n.replace("[", "[[").replace("{", "{{")      # the text engine would read these as markup

    def cw_keys():
        """action -> key code, from the saved bindings (defaults for anything missing or broken)."""
        saved = persistent.cw_binds or {}
        keys = dict(CW_DEFAULT_KEYS)
        for a in CW_ACTIONS:
            k = saved.get(a)
            if isinstance(k, int) and k not in CW_ARROWS and k != pygame.K_ESCAPE and k not in CW_MODIFIERS:
                keys[a] = k
        if len(set(keys.values())) != len(keys):     # two actions on one key: a damaged save, start over
            keys = dict(CW_DEFAULT_KEYS)
        return keys

    def cw_key(action):
        return cw_keys()[action]

    def cw_move_map():
        """key code -> (dx, dy): the arrows plus the four movement bindings."""
        m = dict(CW_ARROWS)
        keys = cw_keys()
        for a in CW_MOVE_ACTIONS:
            m[keys[a]] = CW_MOVE_DIR[a]
        return m

    def cw_bind(action, code):
        """Give `action` this key. If another action holds it, that one gets the old key (a swap).
        Returns the action that was swapped, or None."""
        keys = cw_keys()
        old = keys[action]
        swapped = None
        for other in CW_ACTIONS:
            if other != action and keys[other] == code:
                keys[other] = old
                swapped = other
        keys[action] = code
        persistent.cw_binds = keys
        renpy.save_persistent()
        return swapped

    def cw_binds_reset():
        persistent.cw_binds = None
        renpy.save_persistent()
        renpy.restart_interaction()

    class KeyCapture(renpy.Displayable):
        """Invisible. While `action` is set, the next key pressed becomes that action's binding.
        `action` is a class attribute so it survives the screen being rebuilt."""
        action = None

        def render(self, width, height, st, at):
            return renpy.Render(1, 1)

        def event(self, ev, x, y, st):
            cls = KeyCapture
            if cls.action is None or ev.type != pygame.KEYDOWN or ev.key in CW_MODIFIERS:
                return None
            if ev.key == pygame.K_ESCAPE:
                cls.action = None
            elif ev.key in CW_ARROWS:
                renpy.notify("The arrow keys always move you.")
            else:
                swapped = cw_bind(cls.action, ev.key)
                if swapped:
                    renpy.notify("Swapped with %s." % CW_ACTION_TITLE[swapped])
                cls.action = None
            renpy.restart_interaction()
            raise renpy.IgnoreEvent()

    def cw_capture(action):
        KeyCapture.action = None if KeyCapture.action == action else action
        renpy.restart_interaction()

    def cw_capture_end():
        KeyCapture.action = None

    # Load tracing: milestones go to log.txt (renpy.log), "hunt +N.NNs ...".
    # A plain class holds the clock so nothing lands in the rollback store.
    class HuntClock(object):
        t0 = 0.0

    def hunt_log(msg, reset=False):
        if reset:
            HuntClock.t0 = time.time()
        renpy.log("hunt +%.2fs %s" % (time.time() - HuntClock.t0, msg))

    def hunt_build(level_index, upgrades):
        """Everything a level needs, built while the loading screen is up.
        Returns (game, displayable). The caller keeps them in renpy.session,
        NOT in the store: Ren'Py walks and tracks everything reachable from
        the store on every interaction and save, and this holds the whole
        map, hundreds of sprites and MBs of PNG bytes."""
        lv = hunt_core.LEVELS[level_index]
        cfg = hunt_core.level_cfg(level_index)
        hunt_log("map generated: %s" % lv["key"])
        game = hunt_core.HuntGame(config=cfg, upgrades=dict(upgrades))
        hunt_log("game built")
        disp = HuntDisplayable(game, lv)
        hunt_log("displayable built (ground + sprites)")
        return game, disp

    # Cheat code: hold Shift and press Up, Up, Up, Down (on the hunt menu, shop or
    # results screen) to set your blood to CW_CHEAT_BLOOD.
    CW_CHEAT_BLOOD = 999999

    class CheatListener(renpy.Displayable):
        """Invisible; watches the keys. The sequence position is a class attribute
        so it survives the screen being rebuilt."""
        SEQ = (pygame.K_UP, pygame.K_UP, pygame.K_UP, pygame.K_DOWN)
        pos = 0

        def render(self, width, height, st, at):
            return renpy.Render(1, 1)

        def event(self, ev, x, y, st):
            if ev.type != pygame.KEYDOWN or ev.key in (pygame.K_LSHIFT, pygame.K_RSHIFT):
                return None
            cls = CheatListener
            shift = bool(ev.mod & pygame.KMOD_SHIFT)
            if shift and ev.key == cls.SEQ[cls.pos]:
                cls.pos += 1
                if cls.pos == len(cls.SEQ):
                    cls.pos = 0
                    renpy.store.cw_blood = CW_CHEAT_BLOOD
                    renpy.notify("Blood: %d" % CW_CHEAT_BLOOD)
                    renpy.restart_interaction()
            else:
                cls.pos = 1 if (shift and ev.key == cls.SEQ[0]) else 0
            return None

    class HuntDisplayable(renpy.Displayable):

        DEATH_PAUSE = 1.1
        DAWN_PAUSE = 1.9          # the escape: puff, bat flies off, purple wipe, banner, bonus
        BAT_AT = 0.12             # when the vampire turns into a bat
        BAT_HALF = (              # half a bat (mirrored); two wing frames
            ("#...#..", "##..##.", "###.###", ".######", "..#.###", "....###", "......#"),
            ("....#..", "....##.", "#...###", "##.####", "###.###", ".#..###", "......#"),
        )

        def __init__(self, game, level, **kwargs):
            super(HuntDisplayable, self).__init__(**kwargs)
            self.game = game
            self.held = set()
            self.use_queued = set()      # powers pressed since the last frame
            self.move = cw_move_map()    # key -> (dx, dy)
            self.binds = dict((cw_key(_p), _p) for _p in CW_POWERS if game.lvl(_p) >= 1)   # key -> power, owned only
            if game.lvl("ultimate") >= 1:
                self.binds[cw_key("ultimate")] = "ultimate"
            self.ghosts = []             # bloodlust afterimages: [x, y, facing, age]
            self.aura_t = 0.0
            self.love_t = 0.0
            self.last_st = None
            self.end_at = None
            self.over_t0 = None          # st when the run ended
            self.bonus_played = False
            self.bat_from = None         # the vampire's screen position when the bat takes off
            self.bat_puff = False
            self.result_ready = False
            self.vfx = []

            # game feel (see hunt_juice.py)
            self.shake = hunt_juice.Shake()
            self.parts = hunt_juice.Particles()
            self.slow = hunt_juice.Particles()   # Harvest's own particles: they keep moving (slowly) while the world is frozen
            self.ult_fx = 0.0        # 0..1 fade of the time-stop grade
            self.ult_flash = 0.0     # white flash at the start and end of Harvest
            self.hbeat_t = 0.0       # Harvest heartbeat timer
            self.ult_aura_t = 0.0
            self.freeze = 0.0        # hit-stop: seconds the simulation is held
            self.hop_t = 9.0         # seconds since the vampire's feed hop began
            self.flash_t = 0.0       # white-silhouette flash time left
            self.dust_t = 0.0
            self.beat_t = 0.0
            self.last_pos = (game.x, game.y)
            self.started = False
            self.nframes = 0
            self.sfx_n = 0
            self.sfx_have = {}
            self.solids = {}

            self.level_name = level["name"]
            # world px -> screen px. The map can be bigger than the box (later
            # stages are), so a camera follows the vampire: `wr` below holds
            # the whole arena and only a view-sized window of it is shown.
            self.nz = PIXEL_ZOOM
            self.k = pixel_art.TILE_PX / hunt_mapgen.TILE      # world px -> native art px
            self.scale = self.nz * self.k
            self.aw = int(round(game.w * self.scale))
            self.ah = int(round(game.h * self.scale))
            self.view_w = min(self.aw, int(DISPLAY_W // self.nz) * self.nz)
            self.view_h = min(self.ah, int(DISPLAY_H // self.nz) * self.nz)
            self.vx = HUNT_X + int((DISPLAY_W - self.view_w) / 2)
            self.vy = HUNT_Y + int((DISPLAY_H - self.view_h) / 2)
            self.cam_x = 0
            self.cam_y = 0

            m = game.map
            self._imgs = {}
            self.ground = self.px_img(("ground", m["seed"]), pixel_art.ground_png(m, self.nz))

            # Static map objects, placed once. Trunks/props are depth-sorted
            # together with the characters by their feet (so the vampire is
            # hidden BEHIND a trunk when he stands north of it); crowns are
            # drawn over everything (you run UNDER the branches).
            # Tuples: (sort key in native px, image, screen x, screen y, w, h)
            self.base_items = []
            self.crown_items = []
            for o in m["objects"]:
                for layer, items in (("base", self.base_items), ("crown", self.crown_items)):
                    sp = pixel_art.object_sprite(o["kind"], o["variant"], layer, self.nz)
                    if sp is None:
                        continue
                    png, off_x, off_y, w, h, foot = sp
                    nx = int(round(o["x"] * self.k + off_x))
                    ny = int(round(o["y"] * self.k + off_y))
                    img = self.px_img((o["kind"], o["variant"] % pixel_art.OBJECTS[o["kind"]]["variants"], layer), png)
                    items.append((o["y"] * self.k + foot, img, nx * self.nz, ny * self.nz, w * self.nz, h * self.nz))

            self._facing = {}
            self.red = Solid("#c81428")
            self.ice = Solid("#b8e8ff")
            self.gray = Solid("#8c96aa")
            self.cold = Solid("#0a1830")
            self.white = Solid("#ffffff")
            self.bar_ice = Solid("#4fb8e8")
            self.bar_ice_hi = Solid("#d8f4ff")
            self.bar_fill = Solid("#c81428")
            self.bar_fill_hi = Solid("#ff5f6e")
            self.bar_full = Solid("#e8c04a")
            self.bar_full_hi = Solid("#fff0a0")
            # HUD art (gothic-pixel kit from ui_hunt.rpy)
            self.hud_panel = cw_panel("stone")
            self.hud_slot = cw_slot()
            self.hud_heart = cw_heart(True)
            self.hud_heart_empty = cw_heart(False)
            self.hud_heart_part = dict((q, cw_heart(True, fill=q / 4.0)) for q in (1, 2, 3))
            self.heal_t = 9.0        # seconds since the last Mend, drives the heart hop
            self.hud_drop = cw_drop(True)
            self.bar_blink = Solid("#6e44a0")
            self.bar_blink_hi = Solid("#a67ee0")
            self.bar_charm = Solid("#d8508a")
            self.bar_charm_hi = Solid("#ff9cc4")
            self.bar_frenzy = Solid("#ff2a3d")
            self.bar_frenzy_hi = Solid("#ff9a8a")
            self._text = {}

        # -- helpers -----------------------------------------------------

        def px_img(self, key, png):
            """Wrap generated PNG bytes as an image, one per distinct key."""
            d = self._imgs.get(key)
            if d is None:
                d = im.Data(png, "cw_px_%s.png" % "_".join(str(p) for p in key))
                self._imgs[key] = d
            return d

        def char_img(self, kind, facing, tier=0, flash=False):
            return self.px_img((kind, facing, tier, self.nz, flash),
                               pixel_art.character_png(kind, facing, self.nz, tier, flash))

        def solid(self, color):
            d = self.solids.get(color)
            if d is None:
                d = Solid(color)
                self.solids[color] = d
            return d

        def sfx(self, name, vol=1.0):
            path = "audio/sfx_%s.wav" % name
            ok = self.sfx_have.get(path)
            if ok is None:
                ok = renpy.loadable(path)
                self.sfx_have[path] = ok
            if not ok:
                return
            ch = HUNT_SFX_CHANNELS[self.sfx_n % len(HUNT_SFX_CHANNELS)]
            self.sfx_n += 1
            renpy.sound.play(path, channel=ch, relative_volume=vol)

        @staticmethod
        def face_of(dx, dy, default):
            if abs(dx) < 0.01 and abs(dy) < 0.01:
                return default
            if abs(dy) >= abs(dx):
                return "up" if dy < 0 else "down"
            return "right" if dx > 0 else "left"

        def label(self, s, size=36, color=CW_TEXT, font=None, outlines=None):
            key = (s, size, color, font)
            d = self._text.get(key)
            if d is None:
                if len(self._text) > 300:
                    self._text.clear()
                kw = {}
                if outlines:
                    kw["outlines"] = outlines
                d = Text(s, font=font or CW_FONT, size=size, color=color, **kw)
                self._text[key] = d
            return d

        def add_vfx(self, kind, x, y, life, extra=0, tier=0):
            self.vfx.append({"kind": kind, "x": x, "y": y, "t": 0.0,
                             "life": life, "extra": extra, "tier": tier})

        def hit_stop(self, secs):
            self.freeze = max(self.freeze, secs)

        def on_event(self, e):
            kind, x, y, a, b = e
            if kind == "feed":
                self.add_vfx("feed", x, y, 0.95, a, b)
                self.sfx("feed_%d" % max(0, min(4, b)))
                self.shake.add(0.10 + 0.03 * b)
                self.hit_stop(0.02 + 0.006 * b)
                self.hop_t = 0.0
                self.flash_t = 0.07
                self.parts.burst(x, y, 9 + 3 * b, 190.0, 0.55, BLOOD_COLORS, size=2, drag=3.0)
            elif kind == "heal":
                # Drain Life: a rise of pink sparks off the vampire, a soft chime, hearts hop in the HUD
                self.sfx("heal")
                self.heal_t = 0.0
                self.flash_t = 0.04
                self.parts.burst(x, y - 8.0, 14, 70.0, 0.8, HEAL_COLORS, size=2, drag=2.0, rise=-90.0)
            elif kind == "vanish":
                # a hunter that was trapped for good: mist where it was, mist where it comes back
                self.sfx("blink", 0.35)
                self.parts.burst(x, y, 14, 130.0, 0.6, POOF_COLORS, size=3, drag=3.0, rise=-40.0)
                self.parts.burst(a, b, 10, 110.0, 0.6, POOF_COLORS, size=2, drag=3.0, rise=-40.0)
            elif kind == "harvest":
                # time stops: a flash, a deep boom, a frozen ring and the title
                self.sfx("harvest")
                self.shake.add(1.0)
                self.hit_stop(0.12)
                self.ult_flash = 0.85
                self.hbeat_t = 0.3
                self.add_vfx("harvest_title", x, y, 1.5)
                self.slow.ring(x, y, 48, 520.0, 1.0, ICE_COLORS, size=3, drag=2.0)
                self.slow.ring(x, y, 28, 300.0, 1.2, ICE_COLORS, size=2, drag=1.5)
            elif kind == "harvest_kill":
                self.add_vfx("feed", x, y, 0.95, a, 3)
                self.sfx("kill", 0.9)
                self.shake.add(0.28)
                self.hit_stop(0.04)
                self.slow.burst(x, y, 22, 360.0, 0.8, ICE_COLORS + ["#ff5f6e"], size=3, drag=2.5)
            elif kind == "harvest_end":
                # the frozen moment shatters: shards across the whole view, time flows again
                self.sfx("shatter")
                self.shake.add(1.0)
                self.hit_stop(0.06)
                self.ult_flash = 0.7
                rnd = self.slow.rnd
                for _ in range(16):
                    self.slow.burst(x + rnd.uniform(-620.0, 620.0), y + rnd.uniform(-380.0, 380.0), 5, 300.0, 0.9,
                                    ICE_COLORS, size=3, drag=2.5)
                self.slow.ring(x, y, 40, 700.0, 0.6, ICE_COLORS, size=3, drag=3.5)
            elif kind == "clash":
                self.add_vfx("clash", x, y, 0.35)
                self.sfx("clash", 0.8)
                self.shake.add(0.30)
                self.hit_stop(0.04)
                self.parts.burst(x, y, 10, 320.0, 0.3, SPARK_COLORS, size=2, drag=5.0)
            elif kind == "block":
                # Iron Skin: steel on skin. A clang, a bright ring of sparks and a "Blocked" pop.
                self.add_vfx("blocked", x, y, 0.8)
                self.sfx("clash", 1.0)
                self.shake.add(0.35)
                self.hit_stop(0.06)
                self.flash_t = 0.08
                self.parts.ring(x, y, 18, 260.0, 0.3, SPARK_COLORS + ["#c8ccd8"], size=2, drag=4.5)
                self.parts.burst(x, y, 10, 200.0, 0.4, ["#c8ccd8", "#ffffff", "#8a8fa0"], size=2, drag=4.0)
            elif kind == "shock":
                self.add_vfx("shock", x, y, 0.45, a)
                self.sfx("clash", 0.9)
                self.parts.ring(x, y, 20, a * 2.2, 0.35, SPARK_COLORS, size=2, drag=4.0)
            elif kind == "charm":
                # a = pulse radius, b = how many were caught
                self.sfx("charm")
                self.shake.add(0.10)
                self.flash_t = 0.05
                self.parts.ring(x, y, 36, a * 2.6, 0.38, CHARM_COLORS, size=3, drag=5.5)
                self.parts.ring(x, y, 22, a * 1.5, 0.45, CHARM_COLORS, size=2, drag=3.5)
            elif kind == "charmed":
                self.parts.burst(x, y - 10.0, 10, 90.0, 0.7, CHARM_COLORS, size=2, drag=2.0, rise=-70.0)
            elif kind == "fizzle":
                self.sfx("clash", 0.35)
                self.parts.ring(x, y, 14, a * 1.2, 0.3, ["#a67ee0", "#6e44a0"], size=2, drag=5.0)
            elif kind == "bloodlust_ready":
                self.sfx("ready")
                self.add_vfx("ready", x, y, 1.4)
                self.parts.burst(x, y, 18, 220.0, 0.6, SPARK_COLORS + FRENZY_COLORS[:2], size=2, drag=3.0)
            elif kind == "bloodlust":
                self.sfx("bloodlust")
                self.shake.add(0.9)
                self.hit_stop(0.10)
                self.flash_t = 0.12
                self.parts.ring(x, y, 40, 700.0, 0.55, FRENZY_COLORS, size=3, drag=4.0)
                self.parts.burst(x, y, 40, 380.0, 0.8, FRENZY_COLORS, size=3, drag=3.0)
            elif kind == "bloodlust_end":
                self.parts.burst(x, y, 16, 160.0, 0.5, DUST_COLORS + FRENZY_COLORS[:1], size=2, drag=3.0, rise=-40.0)
            elif kind == "kill":
                self.add_vfx("feed", x, y, 0.95, a, 3)
                self.sfx("kill")
                self.shake.add(0.38)
                self.hit_stop(0.05)
                self.parts.burst(x, y, 26, 330.0, 0.7, BLOOD_COLORS + ["#ffffff"], size=3, drag=3.0)
            elif kind == "stagger":
                self.sfx("clash", 0.55)
                self.shake.add(0.14)
                self.hit_stop(0.03)
                self.parts.burst(x, y, 6, 240.0, 0.28, SPARK_COLORS, size=2, drag=5.0)
            elif kind == "hurt":
                self.add_vfx("hurt", x, y, 0.55)
                self.sfx("hurt")
                self.shake.add(0.80)
                self.hit_stop(0.07)
                self.flash_t = 0.09
                self.parts.burst(x, y, 20, 280.0, 0.6, BLOOD_COLORS + ["#ffffff"], size=2, drag=3.0)
            elif kind == "over":
                self.sfx("death")
                self.shake.add(1.0)
                self.hit_stop(0.12)
                self.parts.burst(x, y, 36, 330.0, 0.9, BLOOD_COLORS, size=3, drag=2.5)
            elif kind == "blink":
                # x, y = where you landed; a, b = where you left
                self.sfx("blink")
                self.shake.add(0.12)
                self.flash_t = 0.06
                self.parts.burst(a, b, 16, 170.0, 0.45, BLINK_COLORS, size=3, drag=3.0)
                self.parts.burst(x, y, 16, 170.0, 0.45, BLINK_COLORS, size=3, drag=3.0)
                n = 8
                for i in range(1, n):
                    self.parts.burst(a + (x - a) * i / float(n), b + (y - b) * i / float(n), 2, 40.0, 0.35,
                                     BLINK_COLORS, size=2, drag=3.0)
            elif kind == "dawn":
                # x, y = you; a = blood taken; b = the bonus. The sun turns every hunter to ash.
                self.sfx("dawn")
                self.shake.add(0.5)
                self.parts.burst(x, y, 40, 300.0, 1.0, DAWN_COLORS, size=3, drag=2.0, rise=-60.0)
                for h_ in self.game.hunters:
                    self.parts.burst(h_.x, h_.y, 16, 150.0, 1.1, ASH_COLORS, size=2, drag=2.0, rise=-70.0)
                    self.parts.burst(h_.x, h_.y, 6, 90.0, 1.2, ["#ffffff", "#f0d6f0"], size=2, drag=2.5, rise=-110.0)

        # -- frame -------------------------------------------------------

        def render(self, width, height, st, at):
            g = self.game

            if self.last_st is None:
                self.last_st = st
            dt = st - self.last_st
            self.last_st = st
            if dt < 0.0:
                dt = 0.0
            elif dt > 0.05:      # a lag spike must not teleport anyone
                dt = 0.05

            if not self.started:
                self.started = True
                self.sfx("start", 0.8)

            # hit-stop: the world holds still for a few frames on impact, while
            # shake and the freeze timer itself keep running on real time.
            sim_dt = dt
            if self.freeze > 0.0:
                self.freeze -= dt
                sim_dt = 0.0
            self.shake.update(dt)

            if not g.over:
                if sim_dt > 0.0:
                    mx = my = 0
                    for k in self.held:
                        d = self.move.get(k)
                        if d:
                            mx += d[0]
                            my += d[1]
                    mx = max(-1, min(1, mx))
                    my = max(-1, min(1, my))
                    use = tuple(self.use_queued)
                    self.use_queued = set()
                    for e in g.update(sim_dt, mx, my, use):
                        self.on_event(e)
                    if g.over:
                        self.over_t0 = st
                        self.end_at = st + (self.DAWN_PAUSE if g.dawn else self.DEATH_PAUSE)
            elif self.end_at is not None and st >= self.end_at:
                self.result_ready = True
                renpy.timeout(0.0)

            if sim_dt > 0.0 and not g.over:
                # dust kicked up while running (position delta, so walls and
                # obstacles that stop you stop the dust too)
                moved = math.hypot(g.x - self.last_pos[0], g.y - self.last_pos[1])
                self.dust_t -= sim_dt
                if moved > 0.4 and self.dust_t <= 0.0 and not g.harvest_on:
                    self.dust_t = 0.09
                    self.parts.burst(g.x, g.y + 28.0, 1, 34.0, 0.4, DUST_COLORS, size=2, drag=2.0, rise=-34.0)
                # heartbeat on the last heart
                if g.harvest_on:
                    # a slow, heavy heartbeat while time is stopped
                    self.hbeat_t -= sim_dt
                    if self.hbeat_t <= 0.0:
                        self.hbeat_t = 0.8
                        self.sfx("beat", 0.9)
                elif g.hp <= 1 and g.max_hp > 1:
                    self.beat_t -= sim_dt
                    if self.beat_t <= 0.0:
                        self.beat_t = 0.9
                        self.sfx("beat", 0.7)
                else:
                    self.beat_t = 0.0
            self.last_pos = (g.x, g.y)

            if sim_dt > 0.0 and not g.over:
                # Bloodlust: red embers off the vampire and white afterimages behind him
                if g.harvest_on:
                    # cold sparkles drifting off the vampire
                    self.ult_aura_t -= sim_dt
                    if self.ult_aura_t <= 0.0:
                        self.ult_aura_t = 0.05
                        self.slow.burst(g.x, g.y + 4.0, 2, 80.0, 0.9, ICE_COLORS, size=2, drag=2.0, rise=-70.0)
                if g.bloodlust_on and not g.harvest_on:
                    self.aura_t -= sim_dt
                    if self.aura_t <= 0.0:
                        self.aura_t = 0.045
                        self.parts.burst(g.x, g.y + 6.0, 2, 70.0, 0.55, FRENZY_COLORS, size=2, drag=2.0, rise=-90.0)
                        if moved > 0.4:
                            self.ghosts.append([g.x, g.y, self.face_of(math.cos(g.facing), math.sin(g.facing), "up"), 0.0])
                # Charm: little hearts floating off whatever is charmed
                self.love_t -= sim_dt
                if self.love_t <= 0.0:
                    self.love_t = 0.28
                    for t_ in g.hunters + g.prey:
                        if t_.charm > 0.0 and not g.harvest_on:
                            self.parts.burst(t_.x, t_.y - 22.0, 1, 26.0, 0.8, CHARM_COLORS, size=2, drag=1.0, rise=-55.0)
            for gh in self.ghosts:
                gh[3] += sim_dt
            self.ghosts = [gh for gh in self.ghosts if gh[3] < 0.30]

            self.hop_t += sim_dt
            self.heal_t += dt
            self.flash_t = max(0.0, self.flash_t - dt)
            for v in self.vfx:
                v["t"] += sim_dt
            self.vfx = [v for v in self.vfx if v["t"] < v["life"]]
            self.parts.update(0.0 if g.harvest_on else sim_dt)       # frozen mid-air while time is stopped
            self.slow.update(sim_dt * (0.3 if g.harvest_on else 1.0))
            if g.harvest_on and not g.over:
                self.ult_fx = min(1.0, self.ult_fx + dt * 6.0)
            else:
                self.ult_fx = max(0.0, self.ult_fx - dt * 3.0)
            self.ult_flash = max(0.0, self.ult_flash - dt * 1.6)

            t_draw = time.time()
            rv = self.draw(width, height, st, at)
            self.nframes += 1
            if self.nframes <= 3 or self.nframes == 120:
                hunt_log("frame %d drawn in %.0f ms" % (self.nframes, (time.time() - t_draw) * 1000.0))
            return rv

        def draw(self, width, height, st, at):
            g = self.game
            sc = self.scale
            nz = self.nz
            k = self.k
            r = renpy.Render(width, height)

            # camera: centred on the vampire, clamped to the map, snapped to
            # the native pixel grid so the art never shimmers.
            cx = int(round((g.x * sc - self.view_w / 2.0) / nz)) * nz
            cy = int(round((g.y * sc - self.view_h / 2.0) / nz)) * nz
            self.cam_x = max(0, min(self.aw - self.view_w, cx))
            self.cam_y = max(0, min(self.ah - self.view_h, cy))
            cam_x, cam_y, vw, vh = self.cam_x, self.cam_y, self.view_w, self.view_h

            # Everything draws into `wr` (arena-sized, arena coordinates) and
            # the view window is cropped out of it, so nothing spills over the
            # HUD. Only things near the window are drawn.
            wr = renpy.Render(self.aw, self.ah)
            m = 4 * nz

            def visible(x, y, w, h):
                return x + w > cam_x - m and x < cam_x + vw + m and y + h > cam_y - m and y < cam_y + vh + m

            wr.blit(renpy.render(self.ground, self.aw, self.ah, st, at), (0, 0))

            # depth-sorted layer: trunks/props + characters, ordered by feet
            layer = []
            for key, d, x, y, w, h in self.base_items:
                if visible(x, y, w, h):
                    layer.append((key, d, x, y))

            harv = g.harvest_on and not g.over

            def char(d, wx, wy, dy=0, ol=None):
                # 16x16 native sprites centred on a world position, snapped to
                # the native pixel grid; sorted by their feet (~7px below centre).
                # `ol` is the white silhouette drawn 4 times around it: Harvest outlines.
                nx = int(round(wx * k - 8))
                ny = int(round(wy * k - 8)) + dy
                if ol is not None:
                    for ox_, oy_ in ((nz, 0), (-nz, 0), (0, nz), (0, -nz)):
                        layer.append((wy * k + 6.9, ol, nx * nz + ox_, ny * nz + oy_))
                layer.append((wy * k + 7.0, d, nx * nz, ny * nz))

            for p in g.prey:
                char(self.char_img("prey", "down", p.tier), p.x, p.y,
                     ol=self.char_img("prey", "down", p.tier, flash=True) if harv else None)

            facing = {}
            for h in ([] if g.dawn else g.hunters):
                px_, py_, f = self._facing.get(id(h), (h.x, h.y, "down"))
                f = self.face_of(h.x - px_, h.y - py_, f)
                facing[id(h)] = (h.x, h.y, f)
                scared = g.bloodlust_on and h.charm <= 0.0
                d = self.char_img("hunter", f, flash=scared and int(g.time * 12) % 2 == 0)
                if h.stun > 0.0:
                    d = Transform(d, alpha=0.55)
                if h.appear > 0.0:
                    d = Transform(d, alpha=max(0.0, 1.0 - h.appear / g.cfg["hunter_appear"]))
                char(d, h.x + ((4.0 if int(g.time * 22) % 2 else -4.0) if scared else 0.0), h.y,
                     ol=self.char_img("hunter", f, flash=True) if harv else None)
            self._facing = facing

            # blink while invulnerable so the player can read the i-frames.
            # No rotation (it would smear the pixels): pick the down/up/side
            # sprite from the last direction moved.
            for gx_, gy_, gf_, ga_ in self.ghosts:
                char(Transform(self.char_img("vampire", gf_, flash=True), alpha=0.32 * (1.0 - ga_ / 0.30)), gx_, gy_)
            gone = g.dawn and self.over_t0 is not None and st - self.over_t0 >= self.BAT_AT
            if not gone and (g.invuln <= 0.0 or int(g.invuln * 14) % 2 == 0 or g.harvest_on):   # the i-frame blink freezes with time, so never hide him during Harvest
                f = self.face_of(math.cos(g.facing), math.sin(g.facing), "up")
                hop = hunt_juice.hop_offset(self.hop_t / 0.26, 2)
                char(self.char_img("vampire", f, flash=self.flash_t > 0.0), g.x, g.y, hop,
                     ol=self.char_img("vampire", f, flash=True) if harv else None)

            layer.sort(key=lambda t: t[0])
            for _key, d, x, y in layer:
                wr.blit(renpy.render(d, self.aw, self.ah, st, at), (x, y))

            for pt in self.parts.items + self.slow.items:
                ps = hunt_juice.Particles.size_now(pt) * nz
                px_ = int(round(pt["x"] * k)) * nz
                py_ = int(round(pt["y"] * k)) * nz
                if visible(px_, py_, ps, ps):
                    wr.blit(renpy.render(self.solid(pt["color"]), ps, ps, st, at), (px_, py_))

            hurt = 0.0
            ready_flash = 0.0
            for v in self.vfx:
                p = v["t"] / v["life"]
                a = max(0.0, 1.0 - p)
                kind = v["kind"]
                if kind == "shock" or kind == "clash":
                    world_r = v["extra"] * (0.55 + 0.45 * p) if kind == "shock" else 110.0 * (0.35 + 1.3 * p)
                    rn = max(3, int(world_r * k))
                    ring = self.px_img(("ring", rn, nz), pixel_art.ring_png(rn, nz))
                    size = rn * 2 + 3
                    nx = int(round(v["x"] * k - size / 2.0))
                    ny = int(round(v["y"] * k - size / 2.0))
                    wr.blit(renpy.render(Transform(ring, alpha=a), self.aw, self.ah, st, at), (nx * nz, ny * nz))
                elif kind == "feed":
                    pop = hunt_juice.ease_out_back(v["t"] / 0.22)
                    t = Transform(self.label("+%d" % v["extra"], 34 + 4 * v["tier"], "#ff5f6e"),
                                  alpha=a, zoom=max(0.1, pop))
                    rend = renpy.render(t, self.aw, self.ah, st, at)
                    w, h = rend.get_size()
                    wr.blit(rend, (int(v["x"] * sc - w / 2), int(v["y"] * sc - 70.0 * p * sc - h / 2)))
                elif kind == "blocked":
                    pop = hunt_juice.ease_out_back(v["t"] / 0.2)
                    t = Transform(self.label("Blocked", 40, "#e8ecf4", CW_TITLE_FONT, [(3, "#120e18", 0, 3)]),
                                  alpha=a, zoom=max(0.1, pop))
                    rend = renpy.render(t, self.aw, self.ah, st, at)
                    w, h = rend.get_size()
                    wr.blit(rend, (int(v["x"] * sc - w / 2), int(v["y"] * sc - (50.0 + 40.0 * p) * sc - h / 2)))
                elif kind == "hurt":
                    hurt = max(hurt, 0.45 * a)
                elif kind == "ready":
                    ready_flash = max(ready_flash, 0.28 * a)

            # canopies last: everything above sits "under" the branches. Only
            # the HUD (drawn after the crop) stays on top.
            for key, d, x, y, w, h in self.crown_items:
                if visible(x, y, w, h):
                    wr.blit(renpy.render(d, self.aw, self.ah, st, at), (x, y))

            # screen shake: whole native pixels, so the art stays on the grid
            sdx, sdy = self.shake.offset(3)
            ox, oy = self.vx + sdx * nz, self.vy + sdy * nz
            r.blit(wr.subsurface((cam_x, cam_y, vw, vh)), (ox, oy))

            # the night: a colour wash that follows the clock, deep night to sunrise glare
            if g.cfg["night_length"] > 0:
                tr, tg, tb, ta = hunt_juice.night_tint(g.night_phase())
                if ta > 0.0:
                    hexc = "#%02x%02x%02x" % (tr // 8 * 8, tg // 8 * 8, tb // 8 * 8)
                    r.blit(renpy.render(Transform(self.solid(hexc), alpha=ta), vw, vh, st, at), (ox, oy))

            if self.ult_fx > 0.0:
                # time stopped: drained of colour, cold, edges throbbing with a slow heartbeat
                fx = self.ult_fx
                r.blit(renpy.render(Transform(self.gray, alpha=0.42 * fx), vw, vh, st, at), (ox, oy))
                r.blit(renpy.render(Transform(self.cold, alpha=0.22 * fx), vw, vh, st, at), (ox, oy))
                hp_ = max(0.0, 1.0 - ((0.8 - self.hbeat_t) / 0.8) * 2.2) if g.harvest_on else 0.0
                self.draw_vignette(r, st, at, ox, oy, pulse=hp_, boost=0.10 * fx, color=self.ice)
            if g.bloodlust_on and not g.over:
                # the world goes crimson and throbs while the bloodlust lasts
                throb = 0.5 + 0.5 * math.sin(g.time * 9.0)
                r.blit(renpy.render(Transform(self.red, alpha=0.10 + 0.07 * throb), vw, vh, st, at), (ox, oy))
                self.draw_vignette(r, st, at, ox, oy, pulse=throb, boost=0.12)
            if ready_flash > 0.0:
                r.blit(renpy.render(Transform(self.solid("#ffe9a0"), alpha=ready_flash), vw, vh, st, at), (ox, oy))
            if hurt > 0.0:
                r.blit(renpy.render(Transform(self.red, alpha=hurt), vw, vh, st, at), (ox, oy))
            if self.ult_flash > 0.0:
                r.blit(renpy.render(Transform(self.white, alpha=min(1.0, self.ult_flash)), vw, vh, st, at), (ox, oy))
            if g.hp <= 1 and g.max_hp > 1 and not g.over and not g.bloodlust_on:
                self.draw_vignette(r, st, at, ox, oy)

            if g.dawn and self.over_t0 is not None:
                self.draw_bat_exit(r, st, at, ox, oy, st - self.over_t0)
            for v in self.vfx:
                if v["kind"] == "harvest_title":
                    p_ = v["t"] / v["life"]
                    pop = max(0.05, hunt_juice.ease_out_back(min(1.0, v["t"] / 0.30)))
                    t_ = Transform(self.label("Time stops", 130, "#e8f8ff", CW_TITLE_FONT, [(6, "#0a2038", 0, 6)]),
                                   zoom=pop, alpha=max(0.0, min(1.0, (1.0 - p_) * 2.2)))
                    rend = renpy.render(t_, self.aw, self.ah, st, at)
                    w_, h_ = rend.get_size()
                    r.blit(rend, (int(self.vx + vw / 2.0 - w_ / 2.0), int(self.vy + vh / 2.0 - 120 - h_ / 2.0)))
            self.draw_arrows(r, st, at)
            self.draw_hud(r, width, height, st, at)
            renpy.redraw(self, 0)
            return r

        def draw_bat(self, layer, st, at, x, y, px, frame, alpha=1.0, rim=True):
            # Pixel bat from BAT_HALF (mirrored), centred on x, y. Dark body with a
            # rose rim so it reads on dark ground; red eyes.
            rows = [rw + rw[::-1][1:] for rw in self.BAT_HALF[frame]]
            left = int(x - 6.5 * px)
            top = int(y - 3.5 * px)

            def runs(dx, dy, body):
                for yy, rw in enumerate(rows):
                    xx = 0
                    while xx < len(rw):
                        if rw[xx] != "#":
                            xx += 1
                            continue
                        eye = (yy == 2 and xx in (5, 7))
                        x1 = xx + 1
                        while x1 < len(rw) and rw[x1] == "#" and not (yy == 2 and x1 in (5, 7)) and not eye:
                            x1 += 1
                        col = "#ff3040" if (eye and body) else ("#140c20" if body else "#a8629a")
                        d_ = self.solid(col)
                        if alpha < 1.0:
                            d_ = Transform(d_, alpha=alpha)
                        w_, h_ = (x1 - xx) * px, px
                        layer.blit(renpy.render(d_, w_, h_, st, at), (left + xx * px + dx, top + yy * px + dy))
                        xx = x1

            if rim:
                o = self.nz
                for dx, dy in ((o, 0), (-o, 0), (0, o), (0, -o)):
                    runs(dx, dy, False)
            runs(0, 0, True)

        def draw_bat_exit(self, r, st, at, ox, oy, tt):
            # The finish: a puff, the vampire turns into a bat and shoots off to the
            # right while a muddy-violet wipe sweeps the view away behind it.
            g = self.game
            vw, vh = self.view_w, self.view_h
            nz = self.nz
            if self.bat_from is None:
                self.bat_from = (g.x * self.scale - self.cam_x, g.y * self.scale - self.cam_y)
            x0, y0 = self.bat_from
            if tt >= self.BAT_AT and not self.bat_puff:
                self.bat_puff = True
                self.sfx("blink")
                self.shake.add(0.18)
                self.parts.burst(g.x, g.y, 26, 170.0, 0.5, POOF_COLORS, size=3, drag=3.0, rise=-40.0)
            layer = renpy.Render(vw, vh)

            def bat_pos(u):
                return (x0 + (vw + 260 - x0) * (u ** 1.7),
                        y0 - vh * 0.30 * (u ** 1.3) + math.sin(u * 16.0) * 10.0)

            u = (tt - self.BAT_AT) / 0.70
            if 0.0 <= u <= 1.0:
                for k in range(5, 0, -1):                      # smoke trail
                    uu = u - k * 0.035
                    if uu > 0.0:
                        tx, ty = bat_pos(uu)
                        s_ = int(nz * (5.0 - k * 0.6))
                        layer.blit(renpy.render(Transform(self.solid("#6e3a6e"), alpha=0.40 - 0.06 * k), s_, s_, st, at),
                                   (int(tx - s_ / 2), int(ty - s_ / 2)))
                bx, by = bat_pos(u)
                self.draw_bat(layer, st, at, bx, by, 2 * nz, int(tt * 18.0) % 2)

            u2 = (tt - 0.28) / 0.62                            # the wipe, a ragged edge
            if u2 > 0.0:
                s2 = min(1.0, u2)
                edge = -90.0 + (vw + 190.0) * (s2 ** 1.4)
                bands = ("#1c1030", "#2a1640", "#3a1f52", "#52295e", "#6e3a6e", "#8a4c78")
                n_rows = 12
                bh = vh / float(n_rows)
                for i in range(n_rows):
                    w = int(min(vw, edge + ((i * 7) % 5 - 2) * 18))
                    if w <= 0:
                        continue
                    y = int(i * bh)
                    layer.blit(renpy.render(self.solid(bands[i * len(bands) // n_rows]), w, int(bh) + 1, st, at), (0, y))
                    if w < vw:
                        rw_ = min(10, w)
                        layer.blit(renpy.render(self.solid("#c27aa8"), rw_, int(bh) + 1, st, at), (w - rw_, y))

            if tt < 0.22:                                      # the flash as he transforms
                layer.blit(renpy.render(Transform(self.solid("#e0b0d8"), alpha=0.55 * (1.0 - tt / 0.22)), vw, vh, st, at), (0, 0))
            r.blit(layer.subsurface((0, 0, vw, vh)), (ox, oy))

        def draw_vignette(self, r, st, at, ox, oy, pulse=None, boost=0.0, color=None):
            """Red edge glow that throbs with the heartbeat while on the last heart
            (or with `pulse` 0..1 and extra `boost` alpha, for Bloodlust)."""
            vw, vh = self.view_w, self.view_h
            if pulse is None:
                phase = (0.9 - self.beat_t) / 0.9 if self.beat_t > 0.0 else 0.0
                pulse = max(0.0, 1.0 - phase * 2.2)     # thump, then fade until the next beat
            for th, base in ((6, 0.20), (14, 0.11), (26, 0.05)):
                t = th * self.nz
                al = min(0.9, base + 0.10 * pulse + boost)
                s_ = Transform(color or self.red, alpha=al)
                for (x, y, w, h) in ((0, 0, vw, t), (0, vh - t, vw, t), (0, t, t, vh - 2 * t), (vw - t, t, t, vh - 2 * t)):
                    r.blit(renpy.render(s_, w, h, st, at), (ox + x, oy + y))

        def draw_arrows(self, r, st, at):
            """Edge-of-screen pointers to hunters (red) and prey (tier colour)
            that are outside the camera window."""
            g = self.game
            sc = self.scale
            nz = self.nz
            vw, vh = self.view_w, self.view_h
            inset = 16 * nz // 2 + 6
            targets = [(h.x, h.y, "hunter") for h in g.hunters] + [(p.x, p.y, p.tier) for p in g.prey]
            for wx, wy, who in targets:
                sx = wx * sc - self.cam_x
                sy = wy * sc - self.cam_y
                if -8 <= sx <= vw + 8 and -8 <= sy <= vh + 8:
                    continue
                dx = sx - vw / 2.0
                dy = sy - vh / 2.0
                t = min((vw / 2.0 - inset) / max(abs(dx), 1e-6), (vh / 2.0 - inset) / max(abs(dy), 1e-6))
                ax = vw / 2.0 + dx * t
                ay = vh / 2.0 + dy * t
                bucket = int(round(math.atan2(dy, dx) / (2.0 * math.pi) * pixel_art.ARROW_BUCKETS)) % pixel_art.ARROW_BUCKETS
                img = self.px_img(("arrow", bucket, who, nz), pixel_art.arrow_png(bucket, who, nz))
                size = 11 * nz
                r.blit(renpy.render(img, size, size, st, at),
                       (int(self.vx + ax - size / 2), int(self.vy + ay - size / 2)))

        def draw_hud(self, r, width, height, st, at):
            g = self.game

            def blit(d, x, y, w=None, h=None, anchor="l"):
                # w may legitimately be 0 (empty cooldown bar), so test for None.
                rw = width if w is None else max(0, int(w))
                rh = height if h is None else max(0, int(h))
                rr = renpy.render(d, rw, rh, st, at)
                if anchor != "l":
                    sw = rr.get_size()[0]
                    x = x - sw / 2.0 if anchor == "c" else x - sw
                r.blit(rr, (int(x), int(y)))

            x0, y0, pw, ph = HUNT_X, 8, int(DISPLAY_W), 156
            pad = 40
            blit(self.hud_panel, x0, y0, pw, ph)

            # left: blood
            blit(self.label("BLOOD", 22, CW_DIM), x0 + pad, y0 + 30)
            blit(self.hud_drop, x0 + pad, y0 + 68)
            blit(self.label("%d" % g.blood, 56, CW_TEXT, CW_FONT_BOLD), x0 + pad + 52, y0 + 54)

            # centre: where you are hunting, and what time of the night it is
            blit(self.label(self.level_name, 60, CW_GOLD, CW_TITLE_FONT, [(3, "#120e18", 0, 3)]),
                 x0 + pw / 2.0, y0 + 26, anchor="c")
            nl = g.cfg["night_length"]
            if nl > 0:
                left = nl - g.time
                late = left <= 30.0
                blit(self.label(hunt_juice.night_clock(g.night_phase()), 32, "#b8e8ff" if g.harvest_on else (CW_BLOOD if late else CW_DIM)),
                     x0 + pw / 2.0, y0 + 96, anchor="c")

            # right: hearts over one bar per unlocked power
            right = x0 + pw - pad
            hw = 15 * CW_UI_ZOOM + 6
            hop = int(round(hunt_juice.hop_offset(self.heal_t / 0.3, 2))) * CW_UI_ZOOM if self.heal_t < 0.3 else 0
            for i in range(g.max_hp):
                q = int(round((g.hp - i) * 4.0))          # quarters of this heart that are filled
                if q >= 4:
                    d = self.hud_heart
                elif q <= 0:
                    d = self.hud_heart_empty
                else:
                    d = self.hud_heart_part[q]
                blit(d, right - (g.max_hp - i) * hw + 6, y0 + 14 + (hop if q > 0 else 0))

            bw, bh, inset = 300, 24, 9

            def power_bar(name, by, ready, frac, fill, fill_hi, left=False):
                bx = x0 + pad if left else right - bw
                if left:
                    blit(self.label(name, 22, CW_GOLD if ready else CW_DIM), bx + bw + 14, by - 3)
                else:
                    blit(self.label(name, 22, CW_GOLD if ready else CW_DIM), bx - 14, by - 3, anchor="r")
                blit(self.hud_slot, bx, by, bw, bh)
                fw = int((bw - 2 * inset) * max(0.0, min(1.0, frac)))
                blit(self.bar_full if ready else fill, bx + inset, by + inset, fw, bh - 2 * inset)
                blit(self.bar_full_hi if ready else fill_hi, bx + inset, by + inset, fw, 2)

            bars = []
            if g.has_blink:
                bars.append(("BLINK", g.blink_cd <= 0.0,
                             1.0 - g.blink_cd / max(g.cfg["blink_cd"], 0.001), self.bar_blink, self.bar_blink_hi))
            if g.has_charm:
                bars.append(("CHARM", g.charm_cd <= 0.0,
                             1.0 - g.charm_cd / max(g.cfg["charm_cd"], 0.001), self.bar_charm, self.bar_charm_hi))
            if g.has_bloodlust:
                on = g.bloodlust_on
                bars.append(("BLOODLUST", g.frenzy >= 1.0 and not on,
                             g.frenzy, self.bar_frenzy if on else self.bar_fill, self.bar_frenzy_hi if on else self.bar_fill_hi))
            for i, (nm, rdy, fr, fl, fh) in enumerate(bars):
                power_bar(nm, y0 + 66 + 30 * i, rdy, fr, fl, fh)
            if g.has_ultimate:
                # the ultimate sits under the blood count: full = ready, drains while active, empty once spent
                if g.harvest_on:
                    u_ = (g.harvest_t / max(g.cfg["harvest_time"], 0.001), False)
                elif g.harvest_used:
                    u_ = (0.0, False)
                else:
                    u_ = (1.0, True)
                power_bar("HARVEST", y0 + 122, u_[1], u_[0], self.bar_ice, self.bar_ice_hi, left=True)

            if g.time < 7.0:
                hint = "%s / arrows to move" % "".join(cw_key_label(cw_key(a_)) for a_ in ("up", "left", "down", "right"))
                for p_ in CW_POWERS:
                    if g.lvl(p_) >= 1:
                        hint += "    %s to %s" % (cw_key_label(cw_key(p_)), CW_POWER_TITLE[p_].lower())
                if g.has_ultimate:
                    hint += "    %s to harvest" % cw_key_label(cw_key("ultimate"))
                blit(Transform(self.label(hint, 28, CW_DIM),
                               alpha=min(1.0, (7.0 - g.time) / 1.5)),
                     self.vx, self.vy + self.view_h + 16)

            if g.has_bloodlust and g.frenzy >= 1.0 and not g.bloodlust_on and not g.over:
                pulse = 0.65 + 0.35 * math.sin(g.time * 7.0)
                blit(Transform(self.label("Bloodlust ready", 64, CW_BLOOD, CW_TITLE_FONT, [(4, "#120e18", 0, 4)]), alpha=pulse),
                     self.vx + self.view_w / 2.0, self.vy + 24, anchor="c")

            if nl > 0 and not g.over and nl - g.time <= 30.0:
                pulse = 0.65 + 0.35 * math.sin(g.time * 5.0)
                blit(Transform(self.label("Dawn is near", 72, "#d79ac8", CW_TITLE_FONT, [(4, "#120e18", 0, 4)]), alpha=pulse),
                     self.vx + self.view_w / 2.0, self.vy + self.view_h - 110, anchor="c")

            if g.over:
                if g.dawn:
                    tt = (st - self.over_t0) if self.over_t0 is not None else 9.0
                    pop = max(0.05, hunt_juice.ease_out_back(min(1.0, max(0.0, tt - 0.80) / 0.35)))
                    banner = Transform(self.label("Sunrise", 150, "#f0d6f0", CW_TITLE_FONT, [(6, "#2a1640", 0, 6)]), zoom=pop, alpha=(1.0 if tt >= 0.80 else 0.0))
                    if tt > 1.05:
                        a_ = min(1.0, (tt - 1.05) / 0.25)
                        blit(Transform(self.label("Dawn bonus  +%d" % g.dawn_bonus, 64, "#f0d6f0", CW_TITLE_FONT, [(4, "#2a1640", 0, 4)]), alpha=a_),
                             self.vx + self.view_w / 2.0, self.vy + self.view_h / 2.0 + 70, anchor="c")
                        if not self.bonus_played:
                            self.bonus_played = True
                            self.sfx("bonus")
                else:
                    banner = self.label("Drained", 150, CW_BLOOD, CW_TITLE_FONT, [(6, "#120e18", 0, 6)])
                blit(banner, self.vx + self.view_w / 2.0, self.vy + self.view_h / 2.0 - 80, anchor="c")

        # -- input -------------------------------------------------------

        def event(self, ev, x, y, st):
            if self.result_ready:
                # A tuple is always truthy, so a 0-blood run still ends cleanly.
                return ("hunt_done", self.game.blood)

            if ev.type == pygame.KEYDOWN:
                if ev.key in self.move:
                    self.held.add(ev.key)
                    raise renpy.IgnoreEvent()
                power = self.binds.get(ev.key)
                if power:
                    self.use_queued.add(power)
                    raise renpy.IgnoreEvent()

            elif ev.type == pygame.KEYUP:
                if ev.key in self.move:
                    self.held.discard(ev.key)
                    raise renpy.IgnoreEvent()

            return None


default cw_blood = 0
default cw_upgrades = {"speed": 0, "constitution": 0, "allure": 0, "strength": 0, "blink": 0, "charm": 0, "bloodlust": 0, "drain": 0, "ultimate": 0}
default cw_level = 0

# DEBUG: testing cheats, applied on every launch. Comment out either line below independently to disable just that cheat (leave "init python:" and "pass" -- the block needs at least one line in it).
#init python:
#    cw_blood = 999999                                                           # unlimited blood
#    cw_upgrades = {"speed": 5, "constitution": 5, "allure": 5, "strength": 5, "blink": 1, "charm": 1, "bloodlust": 1}   # everything maxed and unlocked
#    pass


screen hunt_screen(hd):
    modal True
    add cw_backdrop()
    add hd
    key "game_menu" action NullAction()
    key "rollback" action NullAction()


screen hunt_loading(name):
    # Shown with `call screen`, so it draws one frame and the window keeps
    # showing it while hunt_run builds the level. It ends itself with the timer
    # below: a renpy.pause() would sit on a layer under this modal screen and
    # never see its own timeout until the player pressed something.
    modal True
    add cw_backdrop()
    timer 0.3 action Return(True)

    vbox:
        align (0.5, 0.5)
        spacing 26

        text "Entering" style "cw_dim" size 34 xalign 0.5
        text "[name]" style "cw_title" xalign 0.5
        add cw_divider(110) xalign 0.5
        hbox:
            xalign 0.5
            spacing 22
            add cw_drop(True) at cw_blink(0.0)
            add cw_drop(True) at cw_blink(0.3)
            add cw_drop(True) at cw_blink(0.6)


screen level_select():
    add CheatListener()
    modal True
    add cw_backdrop()

    $ power = sum(cw_upgrades.values())

    frame:
        background cw_panel("stone")
        align (0.5, 0.5)
        padding (72, 56, 72, 60)

        vbox:
            xsize 1100
            spacing 14

            text "Choose your hunting ground" style "cw_title" xalign 0.5
            add cw_divider(110) xalign 0.5

            hbox:
                xalign 0.5
                spacing 60
                hbox:
                    spacing 12
                    add cw_icon("strength", 2) yalign 0.5
                    text ("Vampiric strength  %d" % power) style "cw_text" size 28 yalign 0.5
                hbox:
                    spacing 12
                    add cw_drop(True, 2) yalign 0.5
                    text ("%d" % cw_blood) style "cw_text" size 28 color CW_GOLD yalign 0.5

            null height 4

            for i, lv in enumerate(hunt_core.LEVELS):
                $ unlocked = power >= lv["unlock_power"]

                frame:
                    background cw_card("stone" if unlocked else "dim")
                    xfill True
                    padding (34, 12, 34, 16)

                    hbox:
                        xfill True
                        yalign 0.5

                        vbox:
                            xsize 700
                            yalign 0.5
                            text lv["name"] style "cw_label" color (CW_TEXT if unlocked else CW_LOCKED)
                            if unlocked:
                                hbox:
                                    spacing 10
                                    add cw_drop(True, 2) yalign 0.5
                                    text ("payout x%.2f" % lv["cfg"].get("blood_mult", 1.0)) style "cw_dim" size 22
                            else:
                                text ("needs %d vampiric strength" % lv["unlock_power"]) style "cw_dim" size 22 color CW_LOCKED

                        if unlocked:
                            textbutton "Hunt":
                                style "cw_button"
                                xalign 1.0
                                yalign 0.5
                                xminimum 200
                                action [SetVariable("cw_level", i), Return("hunt")]
                        else:
                            add cw_lock(3) xalign 1.0 yalign 0.5 xoffset -40

            null height 6
            hbox:
                xalign 0.5
                spacing 30
                textbutton "Blood Market" style "cw_button" action Return("shop")
                textbutton "Controls" style "cw_button" action Show("cw_controls")


screen cw_controls():
    modal True
    add cw_backdrop()

    frame:
        background cw_panel("stone")
        align (0.5, 0.5)
        padding (72, 52, 72, 56)

        vbox:
            xsize 1000
            spacing 12

            text "Controls" style "cw_title" xalign 0.5
            add cw_divider(110) xalign 0.5
            text "Click a key, then press the new one. Esc cancels. The arrow keys always move you." style "cw_dim" size 22 xalign 0.5 text_align 0.5
            null height 4

            $ keys = cw_keys()
            for act in CW_ACTIONS:
                $ waiting = (KeyCapture.action == act)
                frame:
                    background cw_card("blood" if waiting else "stone")
                    xfill True
                    padding (30, 8, 30, 12)

                    hbox:
                        xfill True
                        yalign 0.5
                        text CW_ACTION_TITLE[act] style "cw_label" size 30 yalign 0.5
                        textbutton ("Press a key..." if waiting else cw_key_label(keys[act])):
                            style "cw_button"
                            xalign 1.0
                            xminimum 280
                            yalign 0.5
                            action Function(cw_capture, act)

            null height 8
            hbox:
                xalign 0.5
                spacing 30
                textbutton "Defaults" style "cw_button" action Function(cw_binds_reset)
                textbutton "Back" style "cw_button" action [Function(cw_capture_end), Hide("cw_controls")]

    key "game_menu" action [Function(cw_capture_end), Hide("cw_controls")]
    add KeyCapture()          # last, so it sees the key before the Esc binding above does


screen hunt_results(earned, fed, secs, dawn=False, bonus=0):
    add CheatListener()
    modal True
    add Solid("#000000d0")

    frame:
        background cw_panel("blood")
        align (0.5, 0.5)
        padding (90, 60, 90, 64)

        vbox:
            spacing 16

            if dawn:
                text "Dawn breaks" style "cw_title" color "#d79ac8" xalign 0.5
            else:
                text "The night closes in" style "cw_title" color CW_BLOOD xalign 0.5
            add cw_divider(110) xalign 0.5
            null height 8

            $ rows = [("drop", "Blood taken", earned - bonus)]
            if dawn:
                $ rows.append(("pip", "Dawn bonus", "+%d" % bonus))
            $ rows += [("fangs", "Prey drained", fed), ("heart", "Survived", "%d s" % secs)]
            for ico, name, val in rows:
                fixed:
                    xsize 640
                    ysize 54
                    if ico == "drop":
                        add cw_drop(True, 2) yalign 0.5
                    elif ico == "pip":
                        add cw_pip(True, 3) yalign 0.5
                    elif ico == "fangs":
                        add cw_icon("strength", 2) yalign 0.5
                    else:
                        add cw_heart(True, 2) yalign 0.5
                    text name style "cw_text" size 36 xpos 64 yalign 0.5
                    text ("%s" % val) style "cw_label" xalign 1.0 yalign 0.5

            null height 8
            hbox:
                xalign 0.5
                spacing 14
                add cw_drop(True, 2) yalign 0.5
                text ("Blood on hand  %d" % cw_blood) style "cw_text" size 34 color CW_GOLD yalign 0.5
            null height 16

            textbutton "Hunt again" style "cw_button" xalign 0.5 xsize 640 action Return("again")
            textbutton "Hunting ground" style "cw_button" xalign 0.5 xsize 640 action Return("lobby")
            textbutton "Blood market" style "cw_button" xalign 0.5 xsize 640 action Return("shop")
            textbutton "Leave the streets" style "cw_button" xalign 0.5 xsize 640 action Return("leave")


label hunt_lobby:
    call screen level_select
    if _return == "shop":
        call screen blood_shop
        jump hunt_lobby
    else:
        jump hunt_run


label hunt_run:
    window hide
    $ _hunt_lv = hunt_core.LEVELS[cw_level]
    call screen hunt_loading(_hunt_lv["name"])
    $ hunt_log("loading screen shown, building", reset=True)
    $ renpy.session["hunt"] = hunt_build(cw_level, cw_upgrades)
    # Per-level music, once it exists -- drop a file at the path below and it
    # starts playing automatically, no code change needed. Silent no-op
    # until then (renpy.loadable check), so this is safe to leave in.
    $ _hunt_track = HUNT_MUSIC.get(_hunt_lv["key"])
    if _hunt_track and renpy.loadable(_hunt_track):
        play music _hunt_track loop fadein 1.0
    $ hunt_log("showing hunt screen")
    call screen hunt_screen(renpy.session["hunt"][1])
    $ _hunt_earned = _return[1]
    $ cw_blood += _hunt_earned
    $ _hunt_fed, _hunt_secs = renpy.session["hunt"][0].fed, int(renpy.session["hunt"][0].time)
    $ _hunt_dawn = renpy.session["hunt"][0].dawn
    $ _hunt_bonus = renpy.session["hunt"][0].dawn_bonus
    $ renpy.session["hunt"] = None
    call screen hunt_results(_hunt_earned, _hunt_fed, _hunt_secs, _hunt_dawn, _hunt_bonus)
    if _return == "again":
        jump hunt_run
    elif _return == "shop":
        call screen blood_shop
        jump hunt_run
    elif _return == "lobby":
        stop music fadeout 1.0
        jump hunt_lobby
    stop music fadeout 1.0
    return
