"""Headless smoke test for hunt.rpy's HuntDisplayable.

Ren'Py isn't available here, so this stubs the handful of engine names the
displayable touches (renpy.Render/render, im.Data, Transform, Solid, Text,
pygame_sdl2) and runs real frames of draw() on every level's generated map.
It catches NameErrors, bad attribute use and out-of-range blits -- not how
anything looks (use make_pixel_sheet.py for that).

    python tools/smoke_hunt_draw.py
"""
import math
import os
import random
import re
import sys
import textwrap
import types

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "game", "python-packages"))


class Render(object):
    def __init__(self, w, h):
        self.w, self.h, self.blits = w, h, []

    def blit(self, other, pos):
        self.blits.append((other, pos))

    def subsurface(self, rect):
        return Render(rect[2], rect[3])

    def get_size(self):
        return self.w, self.h


class Stub(object):
    def __init__(self, *a, **k):
        self.a, self.k = a, k


calls = {"render": 0}


def fake_render(d, w, h, st, at):
    calls["render"] += 1
    if isinstance(d, Stub) and getattr(d, "data", None) is not None:
        assert d.data[:8] == b"\x89PNG\r\n\x1a\n", "im.Data got non-PNG bytes"
    return Render(8, 8)


class Displayable(object):
    def __init__(self, **k):
        pass


plays = []
channels = []
notes = []
GAME_DIR = os.path.join(HERE, "..", "game")
renpy = types.SimpleNamespace(
    Render=Render, render=fake_render, Displayable=Displayable,
    redraw=lambda *a: None, log=lambda *a: None, session={}, timeout=lambda *a: None,
    store=types.SimpleNamespace(cw_blood=0), notify=lambda msg: notes.append(msg), restart_interaction=lambda: None,
    save_persistent=lambda: None,
    loadable=lambda p: os.path.exists(os.path.join(GAME_DIR, p)), IgnoreEvent=Exception,

    sound=types.SimpleNamespace(play=lambda path, channel=None, **k: plays.append((path, channel, k))),
    music=types.SimpleNamespace(register_channel=lambda *a, **k: channels.append(a)))


class Data(Stub):
    def __init__(self, data, filename):
        self.data, self.filename = data, filename


persistent = types.SimpleNamespace(cw_binds=None)
ns = {"renpy": renpy, "persistent": persistent, "im": types.SimpleNamespace(Data=Data), "Transform": Stub, "Solid": Stub,
      "Text": Stub, "Image": Stub, "Frame": Stub, "Tile": Stub}
sdl = types.ModuleType("pygame_sdl2")
for name in ("K_LEFT", "K_a", "K_RIGHT", "K_d", "K_UP", "K_w", "K_DOWN", "K_s", "K_SPACE", "K_f", "K_e", "K_ESCAPE",
             "K_g", "K_LSHIFT", "K_RSHIFT", "K_LCTRL", "K_RCTRL", "K_LALT", "K_RALT", "K_q", "K_r", "K_LEFTBRACKET",
             "KMOD_SHIFT", "KEYDOWN", "KEYUP"):
    setattr(sdl, name, 1 + sum(ord(c) * (i + 3) for i, c in enumerate(name)))
_names = {sdl.K_SPACE: "space", sdl.K_f: "f", sdl.K_e: "e", sdl.K_g: "g", sdl.K_q: "q", sdl.K_r: "r",
          sdl.K_LEFTBRACKET: "["}
sdl.key = types.SimpleNamespace(name=lambda code: _names.get(code, "").encode())   # the real pygame_sdl2 returns bytes
sys.modules["pygame_sdl2"] = sdl

# UI kit helpers first (init -1 in the game): ui_hunt.rpy up to its end-of-helpers marker.
ui_src = open(os.path.join(HERE, "..", "game", "ui_hunt.rpy")).read()
ua = ui_src.index("init -1 python:") + len("init -1 python:\n")
ub = ui_src.index("# ---- end helpers")
exec(compile(textwrap.dedent(ui_src[ua:ub]), "ui_hunt.rpy[init -1 python]", "exec"), ns)
for kind in ("stone", "blood", "gold", "dim"):
    assert isinstance(ns["cw_panel"](kind), Stub) and isinstance(ns["cw_card"](kind), Stub)
for st_ in ("idle", "hover", "insensitive"):
    ns["cw_button_bg"](st_)
for n_ in ("speed", "constitution", "allure", "strength", "blink", "charm", "bloodlust", "drain"):
    assert ns["cw_icon"](n_, 2).data[:8] == b"\x89PNG\r\n\x1a\n"
for full in (True, False):
    ns["cw_heart"](full), ns["cw_drop"](full), ns["cw_pip"](full)
for q_ in (1, 2, 3):
    assert ns["cw_heart"](True, fill=q_ / 4.0).data[:8] == b"\x89PNG\r\n\x1a\n"
assert len(set(ns["cw_heart"](True, fill=f_).data for f_ in (0.25, 0.5, 0.75, 1.0))) == 4, "part hearts must differ"
ns["cw_slot"](), ns["cw_lock"](), ns["cw_divider"](110), ns["cw_backdrop"](), ns["cw_ring"](20), ns["cw_vampire"]()
assert ns["cw_panel"]("stone") is ns["cw_panel"]("stone"), "UI images must be cached"
print("ui kit helpers OK")

src = open(os.path.join(HERE, "..", "game", "hunt.rpy")).read()
a = src.index("init python:") + len("init python:\n")
b = src.index("\ndefault cw_blood")
exec(compile(textwrap.dedent(src[a:b]), "hunt.rpy[init python]", "exec"), ns)

hunt_core = ns["hunt_core"]
for i, lv in enumerate(hunt_core.LEVELS):
    game = hunt_core.HuntGame(config=hunt_core.level_cfg(i, 3), seed=3,
                              upgrades={"blink": 1, "charm": 1, "bloodlust": 1, "strength": 3, "allure": 3})
    hd = ns["HuntDisplayable"](game, lv)
    rng = random.Random(i)
    for frame in range(240):
        # drive the game the way the engine does: held keys + queued powers
        hd.held = set(k for k in hd.move if rng.random() < 0.3)
        hd.use_queued = set(p_ for p_ in ("blink", "charm", "bloodlust") if rng.random() < 0.03)
        hd.render(1920, 1080, frame / 60.0, frame / 60.0)
        if frame == 60:
            game.frenzy = 1.0    # exercise the Bloodlust-ready banner and mode
        if frame == 100:
            game.hp = 1          # exercise the low-HP vignette + heartbeat
    assert hd.view_w <= ns["DISPLAY_W"] and hd.view_h <= ns["DISPLAY_H"], "view does not fit the box"
    assert 0 <= hd.cam_x <= hd.aw - hd.view_w and 0 <= hd.cam_y <= hd.ah - hd.view_h, "camera left the map"
    assert hd.cam_x % hd.nz == 0 and hd.cam_y % hd.nz == 0, "camera not snapped to the pixel grid"
    print("%-10s arena %dx%d px, view %dx%d, %d base + %d crown sprites, frames OK"
          % (lv["key"], hd.aw, hd.ah, hd.view_w, hd.view_h, len(hd.base_items), len(hd.crown_items)))

# --- juice: every event kind fires something, nothing breaks, shake stays on the pixel grid
game = hunt_core.HuntGame(config=hunt_core.level_cfg(0, 5), seed=5)
hd = ns["HuntDisplayable"](game, hunt_core.LEVELS[0])
del plays[:]
t = 0.0
KINDS = ("feed", "clash", "shock", "stagger", "hurt", "over", "charm", "charmed", "fizzle",
         "bloodlust_ready", "bloodlust", "bloodlust_end", "kill", "heal")
for kind in KINDS:
    hd.parts.items = []
    hd.on_event((kind, game.x, game.y, 40, 2))
    assert len(hd.parts.items) > 0, kind + " spawned no particles"
assert hd.freeze > 0.0 and hd.shake.trauma > 0.9 and hd.flash_t > 0.0 and hd.hop_t == 0.0
assert len(plays) >= 10, "expected a sound for most event kinds, got %r" % plays
for snd in ("charm", "bloodlust", "ready", "kill", "heal"):
    assert any(p_[0].endswith("sfx_%s.wav" % snd) for p_ in plays), "no sound for " + snd
assert all(p[0].startswith("audio/sfx_") and p[1] in ("sound", "hunt_sfx2", "hunt_sfx3", "hunt_sfx4") for p in plays)
assert len(channels) == 3
hd.freeze = 0.1
t0 = game.time
hd.render(1920, 1080, t + 0.016, t + 0.016)
assert game.time == t0, "hit-stop did not hold the simulation"
for frame in range(30):
    t += 1 / 60.0
    hd.render(1920, 1080, t, t)
assert hd.freeze <= 0.0
print("juice events OK: %d sounds, shake now %.2f, %d particles alive" % (len(plays), hd.shake.trauma, len(hd.parts.items)))
# part hearts: every quarter draws, and the heal hop is bounded
for hp_ in (3.0, 2.75, 2.5, 2.25, 2.0, 0.5, 0.25):
    game.over = False
    game.hp = hp_
    hd.heal_t = 0.1
    t += 1 / 60.0
    hd.render(1920, 1080, t, t)
print("part hearts OK")
game.over = True        # the DRAINED banner path of draw_hud
for frame in range(5):
    t += 1 / 60.0
    hd.render(1920, 1080, t, t)
print("drained HUD OK")

# --- night + blink: tint draws every phase, blink input fires the event, dawn ends the run with its banner
game = hunt_core.HuntGame(config=hunt_core.level_cfg(0, 5), upgrades={"speed": 5, "blink": 1}, seed=5)
hd = ns["HuntDisplayable"](game, hunt_core.LEVELS[0])
del plays[:]
t = 0.0
for ph in (0.0, 0.1, 0.5, 0.9, 0.99):
    game.time = ph * game.cfg["night_length"]
    t += 1 / 60.0
    hd.render(1920, 1080, t, t)
hd.use_queued = {"blink"}
hd.held = set([ns["pygame"].K_RIGHT])
x_before = game.x
t += 1 / 60.0
hd.render(1920, 1080, t, t)
assert game.blink_cd > 0.0 and any(p_[0].endswith("sfx_blink.wav") for p_ in plays), "blink input did not blink"
assert not hd.use_queued
game.time = game.cfg["night_length"] - 0.01
for frame in range(400):
    t += 1 / 60.0
    hd.render(1920, 1080, t, t)
    if hd.result_ready:
        break
assert game.dawn and hd.result_ready and any(p_[0].endswith("sfx_dawn.wav") for p_ in plays), "dawn did not end the run"
assert game.dawn_bonus >= 20 and any(p_[0].endswith("sfx_bonus.wav") for p_ in plays), "dawn bonus / its sound missing"
n_before = calls["render"]
hd.over_t0 = 0.0
hd.bat_from, hd.bat_puff = None, False
for tt_ in (0.0, 0.1, 0.15, 0.3, 0.5, 0.8, 1.0, 1.3, 1.9):     # every stage of the bat escape draws
    hd.draw_bat_exit(Render(1920, 1080), 0.0, 0.0, hd.vx, hd.vy, tt_)
assert hd.bat_puff and any(p_[0].endswith("sfx_blink.wav") for p_ in plays), "bat puff did not fire"
assert calls["render"] > n_before + 100, "bat exit drew almost nothing"
print("night + blink + dawn OK")

# --- powers through the displayable: the fixed keys queue them, Charm and Bloodlust play out with their effects
pg = ns["pygame"]
assert ns["cw_key"]("blink") == pg.K_f and ns["cw_key"]("charm") == pg.K_e and ns["cw_key"]("bloodlust") == pg.K_SPACE
assert ns["cw_key_label"](pg.K_SPACE) == "Space" and ns["cw_key_label"](pg.K_e) == "E"
ev = types.SimpleNamespace(type=pg.KEYDOWN, key=pg.K_e)
game = hunt_core.HuntGame(config=hunt_core.level_cfg(0, 5), upgrades={"blink": 1, "charm": 1, "bloodlust": 1}, seed=5)
hd = ns["HuntDisplayable"](game, hunt_core.LEVELS[0])
try:
    hd.event(ev, 0, 0, 0)
    raise AssertionError("bound key was not swallowed")
except Exception as exc:
    assert not isinstance(exc, AssertionError), exc
assert hd.use_queued == {"charm"}, hd.use_queued
hd.use_queued = set()
ev_unbound = types.SimpleNamespace(type=pg.KEYDOWN, key=pg.K_g)
assert hd.event(ev_unbound, 0, 0, 0) is None and not hd.use_queued
game2 = hunt_core.HuntGame(config=hunt_core.level_cfg(0, 5), upgrades={}, seed=5)
hd2 = ns["HuntDisplayable"](game2, hunt_core.LEVELS[0])
assert hd2.event(ev, 0, 0, 0) is None and not hd2.use_queued, "an unowned power must not respond to its key"
hunter = hunt_core.Hunter(game.x + 90, game.y)
game.hunters = [hunter]
del plays[:]
hd.use_queued = {"charm"}
t = 0.0
for _ in range(3):
    t += 1 / 60.0
    hd.render(1920, 1080, t, t)
assert hunter.charm > 0 and any(p_[0].endswith("sfx_charm.wav") for p_ in plays), "charm did not fire"
game.frenzy = 1.0
game.hunters = [hunt_core.Hunter(game.x + 400, game.y)]
hd.use_queued = {"bloodlust"}
hd.held = set(k for k in hd.move if hd.move[k] == (1, 0))
for _ in range(60):
    t += 1 / 60.0
    hd.render(1920, 1080, t, t)
assert game.bloodlust_on and hd.ghosts, "bloodlust did not start / left no afterimages"
assert any(p_[0].endswith("sfx_bloodlust.wav") for p_ in plays)
print("powers through the displayable OK")

# --- cheat code: Shift + Up Up Up Down sets the blood; anything else resets it
CL = ns["CheatListener"]
cl = CL()
SH = pg.KMOD_SHIFT


def press(key, mod=SH):
    cl.event(types.SimpleNamespace(type=pg.KEYDOWN, key=key, mod=mod), 0, 0, 0)


renpy.store.cw_blood = 0
for key in (pg.K_UP, pg.K_UP, pg.K_UP):
    press(key)
assert renpy.store.cw_blood == 0, "cheat fired too early"
press(pg.K_DOWN, mod=0)                                     # Down without Shift: no
assert renpy.store.cw_blood == 0
for key in (pg.K_UP, pg.K_UP, pg.K_DOWN, pg.K_UP, pg.K_UP, pg.K_UP):   # wrong order, then restart
    press(key)
assert renpy.store.cw_blood == 0
press(pg.K_DOWN)
assert renpy.store.cw_blood == ns["CW_CHEAT_BLOOD"] == 999999 and notes, "cheat did not fire"
renpy.store.cw_blood = 0
press(pg.K_UP); press(pg.K_LSHIFT); press(pg.K_UP); press(pg.K_UP); press(pg.K_DOWN)   # shift key presses are ignored
assert renpy.store.cw_blood == 999999, "pressing Shift itself broke the sequence"
print("cheat code OK")
# --- controls: rebinding, swap, reserved keys, persistence, and the displayable obeying them
KC, cw_bind, cw_keys, cw_key = ns["KeyCapture"], ns["cw_bind"], ns["cw_keys"], ns["cw_key"]
assert persistent.cw_binds is None and cw_keys() == ns["CW_DEFAULT_KEYS"], "defaults first"
assert cw_bind("blink", pg.K_q) is None and cw_key("blink") == pg.K_q and persistent.cw_binds["blink"] == pg.K_q
assert cw_bind("charm", pg.K_q) == "blink", "binding a held key swaps"
assert cw_key("charm") == pg.K_q and cw_key("blink") == pg.K_e, "swap gave the old key to the other action"
assert len(set(cw_keys().values())) == 7, "keys must stay unique"
persistent.cw_binds = dict(cw_keys(), up=pg.K_LEFT)                 # a damaged save: an arrow, and a duplicate
persistent.cw_binds["down"] = persistent.cw_binds["left"]
assert cw_keys() == ns["CW_DEFAULT_KEYS"], "damaged bindings must fall back to defaults"
persistent.cw_binds = None
cw_bind("left", pg.K_q)
mm = ns["cw_move_map"]()
assert mm[pg.K_q] == (-1, 0) and pg.K_a not in mm and mm[pg.K_LEFT] == (-1, 0) and mm[pg.K_w] == (0, -1), "move map"
game = hunt_core.HuntGame(config=hunt_core.level_cfg(0, 5), upgrades={"blink": 1}, seed=5)
hd = ns["HuntDisplayable"](game, hunt_core.LEVELS[0])
for key, want in ((pg.K_q, True), (pg.K_a, False), (pg.K_LEFT, True)):
    try:
        r_ = hd.event(types.SimpleNamespace(type=pg.KEYDOWN, key=key), 0, 0, 0)
        swallowed = False
    except Exception:
        swallowed = True
    assert swallowed == want, (key, want)
    hd.held.clear()
cw_bind("blink", pg.K_r)
hd = ns["HuntDisplayable"](game, hunt_core.LEVELS[0])
try:
    hd.event(types.SimpleNamespace(type=pg.KEYDOWN, key=pg.K_r), 0, 0, 0)
except Exception:
    pass
assert hd.use_queued == {"blink"}, "the rebound power key must queue the power"
# the capture displayable
del notes[:]
cap = KC()
ev_ = lambda k: types.SimpleNamespace(type=pg.KEYDOWN, key=k)
assert cap.event(ev_(pg.K_g), 0, 0, 0) is None and persistent.cw_binds["blink"] == pg.K_r, "idle capture must ignore keys"
ns["cw_capture"]("bloodlust")
assert KC.action == "bloodlust"
for key in (pg.K_LSHIFT,):
    assert cap.event(ev_(key), 0, 0, 0) is None and KC.action == "bloodlust", "a lone modifier must not bind"
try:
    cap.event(ev_(pg.K_UP), 0, 0, 0); raise AssertionError("arrow was not refused")
except AssertionError:
    raise
except Exception:
    pass
assert KC.action == "bloodlust" and notes, "arrows refused, still waiting, player told"
try:
    cap.event(ev_(pg.K_LEFTBRACKET), 0, 0, 0)
except Exception:
    pass
assert KC.action is None and cw_key("bloodlust") == pg.K_LEFTBRACKET, "key bound, capture over"
assert ns["cw_key_label"](pg.K_LEFTBRACKET) == "[[", "text markup characters must be escaped"
ns["cw_capture"]("charm")
try:
    cap.event(ev_(pg.K_ESCAPE), 0, 0, 0)
except Exception:
    pass
assert KC.action is None and cw_key("charm") != pg.K_ESCAPE, "Esc cancels"
ns["cw_binds_reset"]()
assert cw_keys() == ns["CW_DEFAULT_KEYS"], "reset"
print("controls OK")

g_, d_ = ns["hunt_build"](4, {"speed": 0, "constitution": 0, "allure": 0, "strength": 0})
assert g_ is d_.game and d_.nframes == 0, "hunt_build must return (game, displayable) untouched"
print("hunt_build OK (town)")
print("smoke OK, %d render calls" % calls["render"])
