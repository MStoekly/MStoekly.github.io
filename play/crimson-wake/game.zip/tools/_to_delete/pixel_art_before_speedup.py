"""Pixel art for the Crimson Wake hunt minigame, drawn entirely in code.

No Ren'Py imports and no image libraries: sprites are painted onto a tiny
Canvas of palette colours, and a ~15-line PNG encoder turns them into bytes
that hunt.rpy hands to im.Data. That means:

  * every sprite is exactly the pixels written here (no resampling),
  * integer upscaling is baked into the PNG (nearest-neighbour by
    construction), so crispness never depends on an engine setting,
  * it all runs headless -- tools/make_pixel_sheet.py renders a contact sheet.

Native resolution: one map tile = TILE_PX (16) pixels. The simulation still
works in "world" pixels (hunt_mapgen.TILE = 70 world px per tile).

Compatible with Python 2 (Ren'Py 7) and 3 (Ren'Py 8): no f-strings, no
bytes([...]) tricks.
"""

import math
import random
import struct
import zlib

import hunt_mapgen

TILE_PX = 16


# ---------------------------------------------------------------------------
# palette -- one shared, hand-picked set so everything looks like one game
# ---------------------------------------------------------------------------

def _rgb(h):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), 255)


C = dict((k, _rgb(v)) for k, v in {
    "ink": "#120e18", "ink2": "#1c1424",
    # skin
    "skin_pale": "#e4d6d8", "skin_pale_d": "#b9a3b0",
    "skin": "#d9a98a", "skin_d": "#b07f66",
    # vampire cloak
    "cloak_d": "#2a0d1d", "cloak": "#4a1430", "cloak_l": "#6e2043",
    "red": "#c81428", "red_l": "#ff5f6e",
    "hair": "#1a1424",
    "white": "#f2ece6", "bone": "#d9ccb8", "silver": "#c8ccd8", "silver_d": "#8a8fa0",
    # leather / wood
    "wood_d": "#2e1c14", "wood": "#5a3a24", "wood_l": "#8a5c38",
    "tan": "#b88a58", "tan_l": "#d9b27c",
    # cloth
    "slate_d": "#262c3c", "slate": "#3b4458", "slate_l": "#566280",
    "purple_d": "#321a4a", "purple": "#4a2a6a", "purple_l": "#6e44a0",
    "green_c_d": "#24402e", "green_c": "#3a6a4a",
    "rag_d": "#4a4038", "rag": "#6e6050", "rag_l": "#8c7c68",
    "gold": "#e8c04a", "gold_d": "#a8832a",
    "hay": "#c9a23c", "hay_d": "#8e6e22", "hay_l": "#e6c660",
    # foliage
    "leaf0": "#102a1c", "leaf1": "#1a3d27", "leaf2": "#27552f", "leaf3": "#3a7038", "leaf4": "#58914a",
    "pine0": "#0e2426", "pine1": "#17383a", "pine2": "#234f48", "pine3": "#336a58", "pine4": "#4c8468",
    "berry": "#c81e3a",
    # stone
    "stone0": "#22222c", "stone1": "#363642", "stone2": "#4e4e5c", "stone3": "#6a6a7a", "stone4": "#8a8a98",
    "moss": "#3f6a3a",
    # ground
    "grass0": "#14241d", "grass1": "#1b3125", "grass2": "#233e2e", "grass3": "#2c4c37", "grass4": "#3a6042",
    "mead0": "#243a22", "mead1": "#2e4a2a", "mead2": "#3a5a32", "mead3": "#486c3a", "mead4": "#5a8044",
    "dirt0": "#2e2118", "dirt1": "#40301f", "dirt2": "#54402a", "dirt3": "#6c5334", "dirt4": "#826440",
    "cob0": "#24222a", "cob1": "#34323e", "cob2": "#46444f", "cob3": "#5a5864", "cob4": "#6e6c78",
    "leafy": "#4a3a1c", "water": "#10202c",
}.items())


def ramp(*names):
    return [C[n] for n in names]


_B4 = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]


def _hash(x, y, seed=0):
    """Small deterministic integer hash -> float in [0, 1)."""
    h = (x * 374761393 + y * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h ^= h >> 16
    return (h & 0xFFFF) / 65536.0


# ---------------------------------------------------------------------------
# canvas
# ---------------------------------------------------------------------------

class Canvas(object):
    """A w x h grid of RGBA tuples; None = transparent."""

    def __init__(self, w, h):
        self.w = w
        self.h = h
        self.p = [[None] * w for _ in range(h)]

    # -- primitives ------------------------------------------------------

    def px(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.p[y][x] = C[c] if isinstance(c, str) else c

    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return self.p[y][x]
        return None

    def rect(self, x0, y0, x1, y1, c):
        """Filled, x1/y1 exclusive."""
        for y in range(y0, y1):
            for x in range(x0, x1):
                self.px(x, y, c)

    def ellipse(self, cx, cy, rx, ry, c):
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                nx = (x + 0.5 - cx) / rx
                ny = (y + 0.5 - cy) / ry
                if nx * nx + ny * ny <= 1.0:
                    self.px(x, y, c)

    def shade_ellipse(self, cx, cy, rx, ry, colors, light=(-0.55, -0.75), dither=0.8):
        """Ellipse lit from the upper left, banded through `colors`
        (dark -> light) with a Bayer dither between bands."""
        n = len(colors)
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                nx = (x + 0.5 - cx) / rx
                ny = (y + 0.5 - cy) / ry
                if nx * nx + ny * ny <= 1.0:
                    b = nx * light[0] + ny * light[1]
                    t = (b + 1.0) / 2.0 * (n - 1)
                    t += ((_B4[y & 3][x & 3] + 0.5) / 16.0 - 0.5) * dither
                    i = max(0, min(n - 1, int(t + 0.5)))
                    self.px(x, y, colors[i])

    def line(self, x0, y0, x1, y1, c):
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        while True:
            self.px(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy

    def triangle(self, cx, top, bottom, half_w, colors):
        """Isoceles triangle, lit from the left, for pine tiers."""
        n = len(colors)
        for y in range(top, bottom):
            w = half_w * (y - top + 0.5) / float(bottom - top)
            for x in range(int(cx - w), int(cx + w) + 1):
                if abs(x + 0.5 - cx) <= w:
                    side = (x + 0.5 - cx) / max(w, 0.5)       # -1 left .. 1 right
                    t = (1.0 - side) / 2.0 * (n - 1) - 0.4 + (y - top) * 0.02
                    t += ((_B4[y & 3][x & 3] + 0.5) / 16.0 - 0.5) * 0.8
                    self.px(x, y, colors[max(0, min(n - 1, int(t + 0.5)))])

    # -- whole-canvas passes ---------------------------------------------

    def outline(self, c):
        """1px outline in colour c, drawn around every opaque pixel (into
        the transparent margin, so leave 1px of empty border)."""
        col = C[c] if isinstance(c, str) else c
        marks = []
        for y in range(self.h):
            for x in range(self.w):
                if self.p[y][x] is None:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        if self.get(x + dx, y + dy) is not None:
                            marks.append((x, y))
                            break
        for x, y in marks:
            self.p[y][x] = col

    def flipped(self):
        o = Canvas(self.w, self.h)
        o.p = [list(reversed(row)) for row in self.p]
        return o

    def blit(self, other, x0, y0):
        for y in range(other.h):
            for x in range(other.w):
                c = other.p[y][x]
                if c is not None:
                    self.px(x0 + x, y0 + y, c)

    # -- output ----------------------------------------------------------

    def rgba(self, scale=1):
        """Raw RGBA rows, each pixel repeated `scale` times both ways."""
        rows = []
        for y in range(self.h):
            row = bytearray()
            for c in self.p[y]:
                px = bytearray(c if c is not None else (0, 0, 0, 0))
                row += px * scale
            for _ in range(scale):
                rows.append(bytes(row))
        return rows

    def png(self, scale=1):
        return encode_png(self.w * scale, self.h * scale, self.rgba(scale))


def encode_png(w, h, rows):
    def chunk(tag, data):
        body = tag + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"".join([b"\x00" + r for r in rows]), 6))
            + chunk(b"IEND", b""))


# ---------------------------------------------------------------------------
# characters (16x16, facing "down" / "up" / "side" = right; flip for left)
# ---------------------------------------------------------------------------

def vampire(facing="down"):
    c = Canvas(16, 16)
    cloak = ramp("cloak_d", "cloak", "cloak_l")
    skin = ramp("skin_pale_d", "skin_pale")
    if facing == "side":
        c.shade_ellipse(4.5, 11.5, 3.2, 3.2, cloak)               # trailing cape
        c.shade_ellipse(7.5, 10.2, 4.6, 4.8, cloak)
        c.shade_ellipse(8.5, 5.4, 3.0, 3.0, skin)
        c.ellipse(7.6, 4.2, 3.0, 2.4, "hair")
        c.rect(4, 5, 7, 7, "hair")
        c.px(10, 6, "red")
        c.px(11, 6, "skin_pale")
        c.px(10, 8, "white")                                       # fang
        c.px(9, 8, "red")                                          # cravat
        c.px(8, 10, "cloak_l")
    elif facing == "up":
        c.shade_ellipse(8, 10.4, 5.0, 4.8, cloak)
        c.line(8, 9, 8, 14, "cloak_d")
        c.shade_ellipse(8, 5.2, 3.0, 3.0, ramp("hair", "ink2"))
        c.px(8, 8, "gold")                                         # clasp
    else:
        c.shade_ellipse(8, 10.4, 5.0, 4.8, cloak)
        c.rect(7, 8, 10, 13, "ink2")                               # shirt
        c.px(7, 8, "red")
        c.px(8, 8, "red")
        c.px(9, 8, "red")
        c.shade_ellipse(8, 5.2, 3.0, 3.0, skin)
        c.rect(5, 2, 11, 5, "hair")
        c.px(7, 5, "hair")
        c.px(9, 5, "hair")
        c.px(7, 6, "red")                                          # eyes
        c.px(9, 6, "red")
        c.px(7, 7, "white")                                        # fangs
        c.px(9, 7, "white")
        c.px(4, 8, "cloak_l")                                      # collar tips
        c.px(11, 8, "cloak_l")
    c.outline("ink")
    return c


def hunter(facing="down"):
    c = Canvas(16, 16)
    coat = ramp("slate_d", "slate", "slate_l")
    if facing == "side":
        c.shade_ellipse(7.5, 10.6, 4.4, 4.2, coat)
        c.shade_ellipse(8.5, 6.4, 2.6, 2.4, ramp("skin_d", "skin"))
        c.px(10, 6, "ink")
        c.ellipse(8.5, 3.6, 5.0, 1.5, "wood")
        c.ellipse(8.5, 2.8, 2.8, 1.7, "wood_l")
        c.line(11, 5, 14, 8, "wood_l")                             # stake
        c.px(14, 9, "silver")
        c.px(14, 10, "silver")
    elif facing == "up":
        c.shade_ellipse(8, 10.6, 4.8, 4.2, coat)
        c.shade_ellipse(8, 6.4, 2.7, 2.4, ramp("skin_d", "skin"))
        c.ellipse(8, 4.2, 3.2, 2.4, "hair")
        c.ellipse(8, 3.6, 5.2, 1.5, "wood")
        c.ellipse(8, 2.8, 2.8, 1.7, "wood_l")
        c.px(13, 8, "silver")
    else:
        c.shade_ellipse(8, 10.6, 4.8, 4.2, coat)
        c.rect(5, 11, 11, 12, "wood")                              # belt
        c.px(8, 11, "gold")
        c.px(8, 9, "white")                                        # cross
        c.px(7, 10, "white")
        c.px(8, 10, "white")
        c.px(9, 10, "white")
        c.shade_ellipse(8, 6.4, 2.7, 2.4, ramp("skin_d", "skin"))
        c.px(7, 6, "ink")
        c.px(9, 6, "ink")
        c.ellipse(8, 3.8, 5.2, 1.5, "wood")
        c.ellipse(8, 2.9, 2.9, 1.7, "wood_l")
        c.line(13, 6, 13, 11, "silver")                            # stake
        c.px(13, 12, "wood_l")
        c.px(13, 13, "wood_l")
    c.outline("ink")
    return c


def prey(tier):
    """Five villagers, poorest -> richest (= more blood)."""
    c = Canvas(16, 16)
    bodies = [
        ramp("rag_d", "rag", "rag_l"),
        ramp("wood", "wood_l", "tan"),
        ramp("green_c_d", "green_c", "leaf3"),
        ramp("purple_d", "purple", "purple_l"),
        ramp("bone", "white", "white"),
    ]
    c.shade_ellipse(8, 10.8, 4.6, 4.0, bodies[tier])
    c.shade_ellipse(8, 6.2, 2.7, 2.5, ramp("skin_d", "skin"))
    c.px(7, 6, "ink")
    c.px(9, 6, "ink")
    if tier == 0:                                  # peasant: tousled hair
        c.rect(5, 3, 11, 5, "wood")
        c.px(6, 5, "wood")
        c.px(10, 5, "wood")
    elif tier == 1:                                # farmer: straw hat
        c.ellipse(8, 4.0, 5.3, 1.5, "hay")
        c.ellipse(8, 3.0, 2.8, 1.6, "hay_l")
        c.rect(6, 4, 10, 5, "hay_d")
    elif tier == 2:                                # merchant: cap + coin purse
        c.ellipse(8, 3.6, 3.3, 2.0, "wood_d")
        c.px(12, 10, "gold")
        c.px(12, 11, "gold_d")
    elif tier == 3:                                # noble: gold trim + plume
        c.ellipse(8, 3.8, 3.2, 1.9, "ink2")
        c.line(10, 2, 12, 0, "red_l")
        c.rect(5, 12, 11, 13, "gold")
        c.px(8, 9, "gold")
    else:                                          # bishop: mitre + gold cross
        c.triangle(8, 0, 5, 3.4, ramp("gold_d", "gold", "gold"))
        c.px(8, 9, "gold")
        c.px(8, 10, "gold")
        c.px(7, 10, "gold")
        c.px(9, 10, "gold")
        c.px(8, 11, "gold")
        c.rect(5, 13, 11, 14, "gold_d")
    c.outline("ink")
    return c


def lunge_ring(radius_native):
    """Dotted pixel circle, 1px thick; radius in native pixels."""
    r = max(3, int(radius_native))
    size = r * 2 + 3
    c = Canvas(size, size)
    cx = cy = size / 2.0
    steps = int(r * 8)
    for i in range(steps):
        if (i // 2) % 2:
            continue
        a = i * 2.0 * math.pi / steps
        c.px(int(cx + math.cos(a) * r), int(cy + math.sin(a) * r), "red_l")
    return c


# ---------------------------------------------------------------------------
# map objects. A tree is TWO sprites: a trunk (drawn under the entities) and
# a crown (drawn over them), so you run under the branches but are stopped by
# the trunk. (Placement and collision both come from the art: see footprint().)
# ---------------------------------------------------------------------------

def _trunk(seed, w=10, h=14, dark=False):
    rnd = random.Random(seed)
    c = Canvas(w, h)
    cols = ramp("wood_d", "wood", "wood", "wood_l") if not dark else ramp("ink2", "wood_d", "wood_d", "wood")
    mid = w // 2
    for y in range(h):
        flare = 1 if y >= h - 3 else 0
        half = 3 + flare
        for x in range(mid - half, mid + half):
            t = (x - (mid - half)) / float(2 * half - 1)       # 0 left .. 1 right
            idx = 3 - int(t * 3.99)                            # left = light
            c.px(x, y, cols[max(0, min(3, idx))])
    for _ in range(h // 2):                                    # bark marks
        c.px(mid - 2 + rnd.randint(0, 3), rnd.randint(1, h - 4), cols[0])
    c.outline("ink")
    return c


def oak_trunk(variant=0):
    return _trunk(100 + variant)


def oak_crown(variant=0):
    rnd = random.Random(7 + variant * 31)
    c = Canvas(34, 28)
    colors = ramp("leaf0", "leaf1", "leaf2", "leaf3", "leaf4")
    blobs = [(17, 17, 12, 8)]
    for _ in range(5):
        blobs.append((rnd.uniform(9, 25), rnd.uniform(9, 19), rnd.uniform(5, 8), rnd.uniform(4, 7)))
    blobs.sort(key=lambda b: -b[1])                            # lower blobs first, upper blobs on top
    for cx, cy, rx, ry in blobs:
        c.shade_ellipse(cx, cy + 1, rx, ry, colors)
    for _ in range(26):                                        # leaf specks
        x, y = rnd.randint(4, 29), rnd.randint(3, 22)
        cur = c.get(x, y)
        if cur is not None:
            c.px(x, y, colors[4] if y < 12 else colors[0])
    c.outline("leaf0")
    return c


def pine_trunk(variant=0):
    return _trunk(200 + variant, w=8, h=12, dark=True)


def pine_crown(variant=0):
    c = Canvas(28, 38)
    colors = ramp("pine0", "pine1", "pine2", "pine3", "pine4")
    tiers = [(1, 14, 7), (8, 22, 10), (16, 32, 13)] if variant == 0 else [(2, 12, 6), (7, 19, 9), (13, 27, 11), (19, 36, 13)]
    for top, bottom, half in tiers:
        c.triangle(14, top, bottom, half, colors)
    c.outline("pine0")
    return c


def dead_tree(variant=0):
    rnd = random.Random(300 + variant)
    c = Canvas(24, 32)
    cols = ramp("ink2", "rag_d", "rag", "rag_l")
    for y in range(8, 30):
        flare = 1 if y >= 27 else 0
        for x in range(10 - flare, 14 + flare):
            c.px(x, y, cols[3 if x == 10 else (2 if x < 12 else 1)])
    c.line(12, 14, 5, 6, cols[2])
    c.line(12, 12, 19, 4, cols[2])
    c.line(12, 18, 20, 13, cols[1])
    c.line(5, 6, 3, 2, cols[1])
    c.line(19, 4, 21, 1, cols[1])
    c.line(5, 6, 7, 3, cols[1])
    for _ in range(4):
        c.px(10 + rnd.randint(0, 3), rnd.randint(10, 26), cols[0])
    c.outline("ink")
    return c


def rock(variant=0):
    rnd = random.Random(400 + variant)
    big = variant % 2 == 1
    w, h = (24, 18) if big else (16, 12)
    c = Canvas(w, h)
    colors = ramp("stone0", "stone1", "stone2", "stone3", "stone4")
    c.shade_ellipse(w * 0.5, h * 0.62, w * 0.44, h * 0.36, colors)
    c.shade_ellipse(w * 0.36, h * 0.5, w * 0.26, h * 0.3, colors)
    for _ in range(3 if big else 1):
        x, y = rnd.randint(4, w - 6), rnd.randint(4, h - 5)
        c.line(x, y, x + rnd.randint(1, 3), y + rnd.randint(1, 3), "stone0")
    for _ in range(4 if big else 2):
        x, y = rnd.randint(3, w - 4), rnd.randint(2, h - 4)
        if c.get(x, y) is not None:
            c.px(x, y, "moss")
    c.outline("ink")
    return c


def bush(variant=0):
    rnd = random.Random(500 + variant)
    c = Canvas(14, 11)
    colors = ramp("leaf0", "leaf1", "leaf2", "leaf3", "leaf4")
    c.shade_ellipse(5, 6.5, 4.2, 3.6, colors)
    c.shade_ellipse(9, 6, 4.2, 3.8, colors)
    if variant % 2:
        for _ in range(4):
            x, y = rnd.randint(3, 10), rnd.randint(3, 8)
            if c.get(x, y) is not None:
                c.px(x, y, "berry")
    c.outline("leaf0")
    return c


def gravestone(variant=0):
    c = Canvas(11, 14)
    colors = ramp("stone1", "stone2", "stone3", "stone4")
    c.rect(2, 4, 9, 12, colors[1])
    c.ellipse(5.5, 4.5, 3.5, 3.0, colors[1])
    c.rect(2, 4, 4, 12, colors[2])
    c.rect(8, 4, 9, 12, colors[0])
    c.px(5, 4, "stone0")
    c.px(5, 5, "stone0")
    c.px(5, 6, "stone0")
    c.px(4, 5, "stone0")
    c.px(6, 5, "stone0")
    c.rect(1, 12, 10, 13, "grass1")
    c.outline("ink")
    return c


def crate(variant=0):
    c = Canvas(14, 14)
    c.rect(1, 1, 13, 13, C["wood"])
    c.rect(1, 1, 13, 2, C["wood_l"])
    c.rect(1, 1, 2, 13, C["wood_l"])
    c.rect(12, 1, 13, 13, C["wood_d"])
    c.rect(1, 12, 13, 13, C["wood_d"])
    c.line(2, 2, 11, 11, "wood_d")
    c.line(11, 2, 2, 11, "wood_d")
    c.outline("ink")
    return c


def barrel(variant=0):
    c = Canvas(12, 14)
    c.shade_ellipse(6, 7.5, 4.6, 5.8, ramp("wood_d", "wood", "wood_l"))
    c.rect(2, 4, 10, 5, "silver_d")
    c.rect(2, 9, 10, 10, "silver_d")
    c.ellipse(6, 2.6, 4.0, 1.6, "wood_l")
    c.outline("ink")
    return c


def haybale(variant=0):
    c = Canvas(18, 13)
    c.rect(1, 2, 17, 12, C["hay"])
    c.rect(1, 2, 17, 4, C["hay_l"])
    c.rect(1, 10, 17, 12, C["hay_d"])
    for x in (5, 11):
        c.rect(x, 2, x + 1, 12, C["wood"])
    for i in range(6):
        c.px(2 + i * 3, 6 + (i % 2) * 2, "hay_d")
    c.outline("ink")
    return c


def well(variant=0):
    c = Canvas(24, 22)
    c.shade_ellipse(12, 12, 10.5, 8.5, ramp("stone1", "stone2", "stone3", "stone4"))
    c.ellipse(12, 11, 6.5, 4.8, "water")
    c.ellipse(11, 10, 3.0, 2.0, "stone0")
    c.rect(2, 16, 22, 19, C["stone1"])
    c.outline("ink")
    return c


def lamp(variant=0):
    c = Canvas(8, 26)
    c.rect(3, 6, 5, 24, C["ink2"])
    c.rect(3, 6, 4, 24, C["stone2"])
    c.rect(1, 1, 7, 7, C["ink2"])
    c.rect(2, 2, 6, 6, C["gold"])
    c.rect(2, 2, 4, 4, C["hay_l"])
    c.rect(1, 24, 7, 25, C["stone1"])
    c.outline("ink")
    return c


# kind -> sprite builders.
#   solid      has a collision circle (decor like bushes does not)
#   fp_rows    how many of the sprite's lowest opaque rows define its footprint
#              (3 = a trunk's base; half the sprite for a wide prop like a rock)
#   crown_rise how many native px the crown's bottom edge sits above the
#              trunk's bottom edge
OBJECTS = {
    "oak":   {"base": oak_trunk,  "crown": oak_crown,  "variants": 3, "solid": True, "fp_rows": 3, "crown_rise": 8},
    "pine":  {"base": pine_trunk, "crown": pine_crown, "variants": 2, "solid": True, "fp_rows": 3, "crown_rise": 7},
    "dead":  {"base": dead_tree,  "crown": None,       "variants": 2, "solid": True, "fp_rows": 3},
    "rock":  {"base": rock,       "crown": None,       "variants": 2, "solid": True, "fp_rows": 6},
    "bush":  {"base": bush,       "crown": None,       "variants": 4, "solid": False, "fp_rows": 3},
    "grave": {"base": gravestone, "crown": None,       "variants": 1, "solid": True, "fp_rows": 4},
    "crate": {"base": crate,      "crown": None,       "variants": 1, "solid": True, "fp_rows": 7},
    "barrel": {"base": barrel,    "crown": None,       "variants": 1, "solid": True, "fp_rows": 6},
    "hay":   {"base": haybale,    "crown": None,       "variants": 1, "solid": True, "fp_rows": 6},
    "well":  {"base": well,       "crown": None,       "variants": 1, "solid": True, "fp_rows": 9},
    "lamp":  {"base": lamp,       "crown": None,       "variants": 1, "solid": True, "fp_rows": 2},
}


def _bounds(c):
    """(top, bottom, left, right) of the opaque pixels, bottom/right exclusive."""
    rows = [y for y in range(c.h) if any(p is not None for p in c.p[y])]
    cols = [x for x in range(c.w) if any(c.p[y][x] is not None for y in range(c.h))]
    return rows[0], rows[-1] + 1, cols[0], cols[-1] + 1


def footprint(kind, variant):
    """Collision circle measured from the art itself: the opaque width of the
    base sprite's lowest rows (minus the 1px outline on each side) is the
    circle's diameter, and the circle's bottom touches the sprite's bottom
    edge. Returns radius in native px, and the centre's x within the sprite."""
    spec = OBJECTS[kind]
    v = variant % spec["variants"]

    def build():
        c = spec["base"](v)
        top, bottom, _l, _r = _bounds(c)
        xs = []
        for y in range(max(top, bottom - spec["fp_rows"]), bottom):
            xs += [x for x in range(c.w) if c.p[y][x] is not None]
        left, right = min(xs), max(xs) + 1
        return {"r": max(2.0, (right - left - 2) / 2.0), "cx": (left + right) / 2.0}
    return _cached(("fp", kind, v), build)


# ---------------------------------------------------------------------------
# ground
# ---------------------------------------------------------------------------

_BIOME_STYLE = {
    "forest":    {"base": ("grass0", "grass1", "grass2", "grass3", "grass4"), "tuft": "grass4", "fleck": "leafy"},
    "road":      {"base": ("mead0", "mead1", "mead2", "mead3", "mead4"), "tuft": "mead4", "fleck": "dirt3"},
    "outskirts": {"base": ("mead0", "mead1", "mead2", "mead3", "mead4"), "tuft": "mead4", "fleck": "hay_d"},
    "village":   {"base": ("dirt0", "dirt1", "dirt2", "dirt3", "dirt4"), "tuft": "mead3", "fleck": "dirt4"},
    "town":      {"base": ("cob0", "cob1", "cob2", "cob3", "cob4"), "tuft": "cob4", "fleck": "cob0"},
}


class _Noise(object):
    """Smooth value noise on a lattice, seeded."""

    def __init__(self, seed, cell, gw, gh):
        rnd = random.Random(seed)
        self.cell = float(cell)
        self.g = [[rnd.random() for _ in range(gw + 2)] for _ in range(gh + 2)]

    def at(self, x, y):
        fx, fy = x / self.cell, y / self.cell
        ix, iy = int(fx), int(fy)
        tx, ty = fx - ix, fy - iy
        tx = tx * tx * (3 - 2 * tx)
        ty = ty * ty * (3 - 2 * ty)
        g = self.g
        a = g[iy][ix] * (1 - tx) + g[iy][ix + 1] * tx
        b = g[iy + 1][ix] * (1 - tx) + g[iy + 1][ix + 1] * tx
        return a * (1 - ty) + b * ty


def render_ground(game_map):
    """Paint the whole arena floor. Deterministic for a given map dict."""
    biome = game_map["biome"]
    style = _BIOME_STYLE[biome]
    base = ramp(*style["base"])
    tw, th = game_map["tiles_w"], game_map["tiles_h"]
    W, H = tw * TILE_PX, th * TILE_PX
    seed = game_map["seed"]
    road = game_map.get("road")
    c = Canvas(W, H)
    # lattices cover the arena plus the 70px offset the road sampling uses
    big = _Noise(seed, 40, (W + 80) // 40 + 1, (H + 80) // 40 + 1)
    small = _Noise(seed + 1, 9, (W + 80) // 9 + 1, (H + 80) // 9 + 1)
    field = _Noise(seed + 2, 90, W // 90 + 1, H // 90 + 1)
    dirt = ramp("dirt1", "dirt2", "dirt3", "dirt3", "dirt4")
    cob = ramp("cob0", "cob1", "cob2", "cob3", "cob4")
    world_per_px = hunt_mapgen.TILE / float(TILE_PX)

    for y in range(H):
        for x in range(W):
            v = 0.55 * big.at(x, y) + 0.45 * small.at(x, y)
            v += ((_B4[y & 3][x & 3] + 0.5) / 16.0 - 0.5) * 0.16
            v += (_hash(x, y, seed) - 0.5) * 0.10
            col = base[max(0, min(4, int(v * 5.0)))]

            if biome == "outskirts" and field.at(x, y) > 0.58:
                # ploughed field: furrow stripes every 3 rows
                if y % 3 == 0:
                    col = C["dirt3"] if v > 0.45 else C["dirt2"]
                elif y % 3 == 1:
                    col = C["dirt2"] if v > 0.5 else C["dirt1"]
                else:
                    col = C["hay_d"] if v > 0.55 else C["dirt3"]
            elif biome == "village" and field.at(x, y) > 0.60:
                col = _cobble(x, y, seed, cob, 0.5)
            elif biome == "town":
                col = _cobble(x, y, seed, cob, v)

            if road is not None:
                d = abs(y * world_per_px - hunt_mapgen.road_center(road, x * world_per_px))
                half = road["half"]
                edge = half + (_hash(x, y, seed + 5) - 0.5) * 36.0
                if d < edge:
                    dv = 0.5 * big.at(x + 70, y) + 0.5 * small.at(x, y + 70)
                    dv += (_hash(x, y, seed + 9) - 0.5) * 0.25
                    col = dirt[max(0, min(4, int(dv * 5.0)))]
                    if _hash(x, y, seed + 11) > 0.965:
                        col = C["stone2"]
            c.p[y][x] = col

    # tufts and flecks scattered on top
    rnd = random.Random(seed + 3)
    tuft = C[style["tuft"]]
    fleck = C[style["fleck"]]
    count = (W * H) // 120
    for _ in range(count):
        x, y = rnd.randint(1, W - 3), rnd.randint(1, H - 3)
        if biome == "town":
            if rnd.random() < 0.5:
                c.px(x, y, fleck)
            continue
        if rnd.random() < 0.6:
            c.px(x, y, tuft)
            c.px(x - 1, y - 1, tuft)
            c.px(x + 1, y - 1, tuft)
        else:
            c.px(x, y, fleck)
    return c


def _cobble(x, y, seed, cob, v):
    row = y // 4
    off = 4 if row % 2 else 0
    bx = (x + off) // 8
    if y % 4 == 3 or (x + off) % 8 == 7:
        return cob[0]
    shade = _hash(bx, row, seed + 21)
    i = 1 + int(shade * 2.99)
    if (y % 4 == 0) or ((x + off) % 8 == 0):
        i = min(4, i + 1)
    return cob[i]


# ---------------------------------------------------------------------------
# cache: (name, variant, scale, flip) -> png bytes
# ---------------------------------------------------------------------------

_cache = {}


def _cached(key, build):
    v = _cache.get(key)
    if v is None:
        v = build()
        _cache[key] = v
    return v


def character_canvas(kind, facing, tier=0):
    flip = facing == "left"
    face = "side" if facing in ("left", "right") else facing
    if kind == "vampire":
        c = vampire(face)
    elif kind == "hunter":
        c = hunter(face)
    else:
        c = prey(tier)
    return c.flipped() if flip else c


def character_png(kind, facing, scale, tier=0):
    return _cached(("char", kind, facing, tier, scale),
                   lambda: character_canvas(kind, facing, tier).png(scale))


def object_canvas(kind, variant, layer):
    spec = OBJECTS[kind]
    fn = spec[layer]
    if fn is None:
        return None
    return fn(variant % spec["variants"])


def object_layout(kind, variant, layer):
    """(canvas, off_x, off_y, foot) or None when this kind has no sprite on
    that layer. off_x/off_y are native px from the object's collision-circle
    centre to the sprite's top-left corner; foot is the native y of the
    trunk's bottom edge relative to that centre (the depth-sort line)."""
    spec = OBJECTS[kind]
    v = variant % spec["variants"]

    def build():
        c = object_canvas(kind, v, layer)
        if c is None:
            return None
        fp = footprint(kind, v)
        foot = fp["r"]                 # circle bottom == trunk bottom edge
        top, bottom, left, right = _bounds(c)
        if layer == "base":
            return (c, -fp["cx"], foot - bottom, foot)
        return (c, -(left + right) / 2.0, foot - spec["crown_rise"] - bottom, foot)
    return _cached(("layout", kind, v, layer), build)


def object_sprite(kind, variant, layer, scale):
    """(png bytes, off_x, off_y, w, h, foot): object_layout plus the PNG
    baked at `scale` (native px * scale = screen px)."""
    lay = object_layout(kind, variant, layer)
    if lay is None:
        return None
    c, ox, oy, foot = lay
    spec = OBJECTS[kind]
    return _cached(("objpng", kind, variant % spec["variants"], layer, scale),
                   lambda: (c.png(scale), ox, oy, c.w, c.h, foot))


ARROW_BUCKETS = 16
_ARROW_COLORS = {"hunter": "red_l", 0: "rag_l", 1: "tan_l", 2: "leaf4", 3: "purple_l", 4: "gold"}


def arrow(bucket, color):
    """9x9 pixel arrow pointing at angle bucket/16 of a turn (0 = east,
    clockwise, y down), for off-screen hunters and prey."""
    c = Canvas(11, 11)
    a = bucket * 2.0 * math.pi / ARROW_BUCKETS
    fx, fy = math.cos(a), math.sin(a)
    sx, sy = -fy, fx
    tip = (5.5 + fx * 4.2, 5.5 + fy * 4.2)
    b1 = (5.5 - fx * 2.6 + sx * 3.0, 5.5 - fy * 2.6 + sy * 3.0)
    b2 = (5.5 - fx * 2.6 - sx * 3.0, 5.5 - fy * 2.6 - sy * 3.0)

    def side(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])

    for y in range(11):
        for x in range(11):
            pt = (x + 0.5, y + 0.5)
            d1, d2, d3 = side(tip, b1, pt), side(b1, b2, pt), side(b2, tip, pt)
            if (d1 >= 0 and d2 >= 0 and d3 >= 0) or (d1 <= 0 and d2 <= 0 and d3 <= 0):
                c.px(x, y, color)
    c.outline("ink")
    return c


def arrow_png(bucket, who, scale):
    """who = "hunter" or a prey tier 0-4."""
    return _cached(("arrow", bucket, who, scale),
                   lambda: arrow(bucket, _ARROW_COLORS[who]).png(scale))


def ring_png(radius_native, scale):
    return _cached(("ring", int(radius_native), scale), lambda: lunge_ring(radius_native).png(scale))


def ground_png(game_map, scale):
    return render_ground(game_map).png(scale)
