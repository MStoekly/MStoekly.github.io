"""Render one camera-sized frame per level (ground, objects, hero, soldiers, prey)
without Ren'Py, stacked into one PNG: the visual judge's evidence.

    python tools/judge_frames.py <out.png> [mutation stage per level, default 0..4]

Works on any project with the same engine (run it with that project's tools/).
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "game", "python-packages"))

import hunt_core
import hunt_mapgen
import pixel_art as pa
import make_pixel_sheet as mps

VIEW_W, VIEW_H = 466, 273          # the 1398x819 view at 3x


def frame(i, stage):
    lv = hunt_core.LEVELS[i]
    c, m = mps.map_sheet(lv["biome"], lv["tiles"], 11)
    k = mps.NATIVE_PER_WORLD
    sx, sy = m["spawn"]
    # extra cast so every character kind shows up near the camera
    for dx, dy, who, t in ((120, -60, "prey", 0), (-140, 40, "prey", 2), (60, 110, "prey", 3), (-60, -110, "hunter", 0)):
        c.blit(pa.character_canvas(who, "down", t), int((sx + dx) * k - 8), int((sy + dy) * k - 8))
    c.blit(pa.character_canvas("vampire", "down", stage), int(sx * k - 8), int(sy * k - 8))
    x0 = int(max(0, min(c.w - VIEW_W, sx * k - VIEW_W / 2)))
    y0 = int(max(0, min(c.h - VIEW_H, sy * k - VIEW_H / 2)))
    out = pa.Canvas(VIEW_W, VIEW_H)
    out.p = [row[x0:x0 + VIEW_W] for row in c.p[y0:y0 + VIEW_H]]
    return out


def main():
    path = sys.argv[1]
    stages = [int(s) for s in sys.argv[2].split(",")] if len(sys.argv) > 2 else [0, 1, 2, 3, 4]
    n = len(hunt_core.LEVELS)
    cols = 2
    rows = (n + cols - 1) // cols
    gap = 4
    sheet = pa.Canvas(cols * VIEW_W + (cols + 1) * gap, rows * VIEW_H + (rows + 1) * gap)
    for i in range(n):
        f = frame(i, stages[i % len(stages)])
        sheet.blit(f, gap + (i % cols) * (VIEW_W + gap), gap + (i // cols) * (VIEW_H + gap))
    with open(path, "wb") as fh:
        fh.write(sheet.png(2))
    print("wrote", path)


if __name__ == "__main__":
    main()
