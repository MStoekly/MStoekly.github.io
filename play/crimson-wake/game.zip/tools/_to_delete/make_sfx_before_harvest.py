"""Synthesize the hunt minigame's sound effects (chiptune style), pure stdlib.

    python tools/make_sfx.py            # writes game/audio/sfx_*.wav
    python tools/make_sfx.py --check    # also asserts every file is sane

22050 Hz, mono, 16-bit. Deterministic (seeded noise), so re-running gives
identical files. Tweak the recipes below and re-run; no engine restart needed
beyond what Ren'Py already needs for new audio files.
"""
import math
import os
import random
import struct
import sys
import wave

RATE = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "game", "audio")


def n_samples(sec):
    return int(sec * RATE)


def square(freq, sec, duty=0.5, sweep_to=None):
    n = n_samples(sec)
    out = []
    phase = 0.0
    for i in range(n):
        f = freq if sweep_to is None else freq + (sweep_to - freq) * (i / float(n))
        phase = (phase + f / RATE) % 1.0
        out.append(1.0 if phase < duty else -1.0)
    return out


def sine(freq, sec, sweep_to=None):
    n = n_samples(sec)
    out = []
    phase = 0.0
    for i in range(n):
        f = freq if sweep_to is None else freq + (sweep_to - freq) * (i / float(n))
        phase += 2.0 * math.pi * f / RATE
        out.append(math.sin(phase))
    return out


def noise(sec, rnd, lp_start=1.0, lp_end=1.0):
    """White noise through a one-pole low-pass whose coefficient glides."""
    n = n_samples(sec)
    out = []
    y = 0.0
    for i in range(n):
        a = lp_start + (lp_end - lp_start) * (i / float(n))
        y += a * (rnd.uniform(-1.0, 1.0) - y)
        out.append(y)
    return out


def env(samples, attack=0.003, decay=4.0, release=0.01):
    """Fast attack, exponential decay, short release to avoid clicks."""
    n = len(samples)
    a = max(1, n_samples(attack))
    r = max(1, n_samples(release))
    out = []
    for i, s in enumerate(samples):
        g = min(1.0, i / float(a)) * math.exp(-decay * i / float(n))
        if i > n - r:
            g *= (n - i) / float(r)
        out.append(s * g)
    return out


def mix(*tracks):
    n = max(len(t) for t in tracks)
    out = [0.0] * n
    for t in tracks:
        for i, s in enumerate(t):
            out[i] += s
    return out


def seq(*parts):
    out = []
    for p in parts:
        out.extend(p)
    return out


def gain(samples, g):
    return [s * g for s in samples]


def note(semitones_from_a4):
    return 440.0 * 2.0 ** (semitones_from_a4 / 12.0)


def write(name, samples, vol=0.5):
    peak = max(1e-9, max(abs(s) for s in samples))
    path = os.path.join(OUT, name)
    w = wave.open(path, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(RATE)
    w.writeframes(b"".join(struct.pack("<h", int(s / peak * vol * 32767)) for s in samples))
    w.close()
    return path


def build():
    rnd = random.Random(7)
    files = {}

    # feed: little rising arpeggio, higher and longer for richer prey, over a
    # wet low-passed "slurp". tier 0..4
    for tier in range(5):
        base = -9 + tier * 3                      # semitones from A4
        notes = [base, base + 4, base + 7] + ([base + 12] if tier >= 2 else []) + ([base + 16] if tier >= 4 else [])
        seg = 0.055 + 0.01 * tier
        arp = seq(*[env(square(note(s), seg, duty=0.25), decay=2.5) for s in notes])
        slurp = env(noise(0.16, rnd, 0.05, 0.4), attack=0.02, decay=3.0)
        files["sfx_feed_%d.wav" % tier] = mix(gain(arp, 0.8), gain(slurp, 0.35))

    thud = env(square(210.0, 0.28, duty=0.5, sweep_to=50.0), decay=3.0)
    crunch = env(noise(0.1, rnd, 1.0, 0.3), attack=0.001, decay=5.0)
    files["sfx_hurt.wav"] = mix(gain(thud, 0.8), gain(crunch, 0.7))

    c1 = env(noise(0.14, rnd, 1.0, 0.5), attack=0.001, decay=6.0)
    c2 = env(square(note(-2), 0.1, duty=0.125), decay=6.0)
    c3 = env(square(note(-1) * 1.0, 0.1, duty=0.125), decay=6.0)
    files["sfx_clash.wav"] = mix(gain(c1, 0.8), gain(c2, 0.3), gain(c3, 0.3))

    desc = seq(*[env(square(note(s), 0.17, duty=0.5), decay=2.0) for s in (4, 1, -3, -8, -15)])
    files["sfx_death.wav"] = mix(gain(desc, 0.8), gain(env(noise(0.9, rnd, 0.05, 0.02), attack=0.1, decay=2.0), 0.3))

    ups = seq(*[env(square(note(s), 0.08, duty=0.25), decay=2.0) for s in (-5, 0, 7)])
    files["sfx_start.wav"] = ups

    # blink: a quick downward "pop" swoosh with a puff of air
    pop = env(sine(1300.0, 0.13, sweep_to=220.0), attack=0.002, decay=3.5)
    puff = env(noise(0.15, rnd, 0.9, 0.15), attack=0.001, decay=5.0)
    files["sfx_blink.wav"] = mix(gain(pop, 0.8), gain(puff, 0.5))

    # dawn: bright rising chime that rings out
    chime = seq(*[env(square(note(s), 0.16, duty=0.25), decay=2.0) for s in (-5, 0, 4, 7, 12, 16)])
    shimmer = env(sine(note(28), 1.0), attack=0.1, decay=2.5)
    files["sfx_dawn.wav"] = mix(gain(chime, 0.8), gain([0.0] * n_samples(0.3) + shimmer, 0.35))

    # charm: a soft, wavering rising chime
    wob = seq(*[env(sine(note(n), 0.14), attack=0.01, decay=2.0) for n in (-2, 3, 7, 10, 15)])
    veil = env(sine(note(22), 0.7, sweep_to=note(24)), attack=0.08, decay=2.5)
    files["sfx_charm.wav"] = mix(gain(wob, 0.8), gain([0.0] * n_samples(0.1) + veil, 0.3))

    # bloodlust: a low roar, noise over a falling growl
    growl = env(square(95.0, 0.7, duty=0.5, sweep_to=48.0), attack=0.01, decay=1.6)
    roar = env(noise(0.7, rnd, 0.35, 0.08), attack=0.02, decay=1.8)
    files["sfx_bloodlust.wav"] = mix(gain(growl, 0.8), gain(roar, 0.7))

    # meter full: a bright two-note ping
    files["sfx_ready.wav"] = seq(env(square(note(7), 0.09, duty=0.25), decay=3.0),
                                 env(square(note(14), 0.2, duty=0.25), decay=2.5))

    # a hunter killed during bloodlust: heavy crunch with a rising snarl
    kthud = env(square(150.0, 0.22, duty=0.5, sweep_to=45.0), decay=3.0)
    kcrunch = env(noise(0.12, rnd, 1.0, 0.25), attack=0.001, decay=5.0)
    ksnarl = env(sine(180.0, 0.16, sweep_to=520.0), decay=3.0)
    files["sfx_kill.wav"] = mix(gain(kthud, 0.8), gain(kcrunch, 0.7), gain(ksnarl, 0.3))

    # dawn bonus: a rich little rising "ka-ching" of blood coins
    coins = seq(*[env(square(note(s), 0.07, duty=0.25), decay=2.5) for s in (4, 9, 12, 16, 21)])
    files["sfx_bonus.wav"] = mix(gain(coins, 0.8), gain([0.0] * n_samples(0.2) + env(sine(note(33), 0.6), attack=0.02, decay=3.0), 0.25))

    # Mend: a soft, warm rising chime (quieter and rounder than a feed)
    heal = seq(*[env(sine(note(n), 0.13), attack=0.01, decay=2.2) for n in (0, 4, 7, 12)])
    files["sfx_heal.wav"] = mix(gain(heal, 0.8), gain([0.0] * n_samples(0.08) + env(sine(note(19), 0.5), attack=0.05, decay=3.0), 0.25))

    # low-HP heartbeat: two soft low thumps
    def thump(f):
        return env(sine(f, 0.14, sweep_to=f * 0.5), attack=0.004, decay=5.0)
    files["sfx_beat.wav"] = seq(thump(90.0), [0.0] * n_samples(0.06), gain(thump(75.0), 0.8), [0.0] * n_samples(0.05))
    return files


def main():
    if not os.path.isdir(OUT):
        os.makedirs(OUT)
    files = build()
    total = 0
    for name in sorted(files):
        p = write(name, files[name])
        total += os.path.getsize(p)
        print("%-18s %.2fs  %5d KB" % (name, len(files[name]) / float(RATE), os.path.getsize(p) // 1024))
    if "--check" in sys.argv:
        for name in files:
            w = wave.open(os.path.join(OUT, name), "rb")
            assert w.getnchannels() == 1 and w.getsampwidth() == 2 and w.getframerate() == RATE
            frames = w.readframes(w.getnframes())
            vals = struct.unpack("<%dh" % w.getnframes(), frames)
            assert 0.05 < w.getnframes() / float(RATE) < 1.5, name
            assert max(abs(v) for v in vals) > 8000, name + " too quiet"
            assert abs(vals[0]) < 800 and abs(vals[-1]) < 800, name + " clicks at the edges"
            w.close()
        print("CHECK OK (%d files, %d KB)" % (len(files), total // 1024))


if __name__ == "__main__":
    main()
