"""Game-feel helpers for the hunt minigame: screen shake, particles, easing.

No Ren'Py imports, so it runs headless:

    python game/python-packages/hunt_juice.py     # runs the self-test

Everything here is deliberately tiny and stateless-ish; hunt.rpy decides when
to fire each effect (see HuntDisplayable.on_event). Units: particles live in
world pixels (like the simulation); shake offsets are whole NATIVE art pixels
so the pixel grid never breaks.
"""

import math
import random


# -- easing (t in 0..1) ------------------------------------------------------

def ease_out_quad(t):
    t = min(1.0, max(0.0, t))
    return 1.0 - (1.0 - t) * (1.0 - t)


def ease_out_back(t):
    """Overshoots past 1, then settles -- the 'luxurious' curve from the talk."""
    t = min(1.0, max(0.0, t))
    c1 = 1.70158
    c3 = c1 + 1.0
    return 1.0 + c3 * (t - 1.0) ** 3 + c1 * (t - 1.0) ** 2


def hop_offset(t, height):
    """Vertical hop: 0 -> -height -> 0 over t in 0..1 (negative = up)."""
    if t >= 1.0:
        return 0
    return int(round(-height * math.sin(math.pi * ease_out_quad(t) ** 0.8)))


# -- night cycle -------------------------------------------------------------
# One run is one night, midnight (00:00) to sunrise (06:00). phase runs 0..1.

NIGHT_START_HOUR = 0.0
NIGHT_HOURS = 6.0

# (phase, (r, g, b), alpha): the colour laid over the arena, linearly blended.
NIGHT_KEYS = [
    (0.00, (8, 16, 48), 0.34),        # deep night from the first frame
    (0.62, (8, 16, 48), 0.34),
    (0.82, (110, 40, 90), 0.24),      # pre-dawn magenta
    (0.93, (255, 150, 70), 0.22),     # first light
    (1.00, (255, 240, 190), 0.60),    # sunrise glare
]


def night_tint(phase):
    """(r, g, b, alpha 0..1) for a night phase."""
    p = min(1.0, max(0.0, phase))
    for i in range(len(NIGHT_KEYS) - 1):
        p0, c0, a0 = NIGHT_KEYS[i]
        p1, c1, a1 = NIGHT_KEYS[i + 1]
        if p <= p1:
            t = (p - p0) / (p1 - p0) if p1 > p0 else 1.0
            return (int(round(c0[0] + (c1[0] - c0[0]) * t)), int(round(c0[1] + (c1[1] - c0[1]) * t)),
                    int(round(c0[2] + (c1[2] - c0[2]) * t)), a0 + (a1 - a0) * t)
    _, c, a = NIGHT_KEYS[-1]
    return (c[0], c[1], c[2], a)


def night_clock(phase):
    """Clock text for a phase: 12:00 AM ... 5:59 AM, then 6:00 AM at sunrise."""
    minutes = int(NIGHT_START_HOUR * 60 + min(1.0, max(0.0, phase)) * NIGHT_HOURS * 60) % (24 * 60)
    h, m = divmod(minutes, 60)
    return "%d:%02d %s" % (h % 12 or 12, m, "AM" if h < 12 else "PM")


# -- screen shake ------------------------------------------------------------

class Shake(object):
    """'Trauma' model: events add trauma (0..1), it decays linearly, and the
    shake amplitude is trauma squared so small hits stay subtle and big ones
    really land."""

    def __init__(self, seed=None, decay=1.7):
        self.trauma = 0.0
        self.decay = decay
        self.rnd = random.Random(seed)

    def add(self, amount):
        self.trauma = min(1.0, self.trauma + amount)

    def update(self, dt):
        self.trauma = max(0.0, self.trauma - self.decay * dt)

    def offset(self, max_native=3):
        """(dx, dy) in whole native pixels."""
        a = self.trauma * self.trauma * max_native
        if a < 0.5:
            return 0, 0
        return int(round(self.rnd.uniform(-a, a))), int(round(self.rnd.uniform(-a, a)))


# -- particles ---------------------------------------------------------------

class Particles(object):
    """Square pixel particles in world coordinates. Each shrinks over its life
    (size -> 1 native px) instead of fading, which suits pixel art."""

    MAX = 400

    def __init__(self, seed=None):
        self.items = []
        self.rnd = random.Random(seed)

    def burst(self, x, y, n, speed, life, colors, size=2, drag=3.0, rise=0.0, arc=(0.0, 2.0 * math.pi)):
        for _ in range(n):
            if len(self.items) >= self.MAX:
                self.items.pop(0)
            a = self.rnd.uniform(arc[0], arc[1])
            s = speed * self.rnd.uniform(0.35, 1.0)
            self.items.append({"x": x, "y": y, "vx": math.cos(a) * s, "vy": math.sin(a) * s,
                               "t": 0.0, "life": life * self.rnd.uniform(0.7, 1.15),
                               "color": self.rnd.choice(colors), "size": size,
                               "drag": drag, "rise": rise})

    def update(self, dt):
        keep = []
        for p in self.items:
            p["t"] += dt
            if p["t"] >= p["life"]:
                continue
            damp = math.exp(-p["drag"] * dt)
            p["vx"] *= damp
            p["vy"] = p["vy"] * damp + p["rise"] * dt
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            keep.append(p)
        self.items = keep

    @staticmethod
    def size_now(p):
        """Native px size: starts at p['size'], drops to 1 for the last 40%."""
        return p["size"] if p["t"] < 0.6 * p["life"] else 1


# -- self-test ---------------------------------------------------------------

def _selftest():
    ok = True

    def check(label, cond):
        print("%-56s %s" % (label, "PASS" if cond else "FAIL"))
        return cond

    ok &= check("ease_out_back: 0 -> 0, 1 -> 1, overshoots between",
                abs(ease_out_back(0.0)) < 1e-9 and abs(ease_out_back(1.0) - 1.0) < 1e-9
                and max(ease_out_back(i / 100.0) for i in range(101)) > 1.05)
    ok &= check("ease_out_quad monotonic 0..1",
                all(ease_out_quad(i / 100.0) <= ease_out_quad((i + 1) / 100.0) for i in range(100)))
    ok &= check("hop: starts and ends at 0, peaks upward",
                hop_offset(0.0, 3) == 0 and hop_offset(1.0, 3) == 0 and min(hop_offset(i / 20.0, 3) for i in range(21)) == -3)

    sh = Shake(seed=1)
    ok &= check("shake: no trauma -> no offset", sh.offset() == (0, 0))
    sh.add(0.9)
    big = max(abs(sh.offset(3)[0]) + abs(sh.offset(3)[1]) for _ in range(50))
    sh.update(0.3)
    mid = sh.trauma
    for _ in range(100):
        sh.update(0.05)
    ok &= check("shake: big hit moves the screen, then decays to rest",
                big >= 2 and 0.0 < mid < 0.9 and sh.trauma == 0.0 and sh.offset() == (0, 0))
    sh = Shake(seed=2)
    sh.add(5.0)
    ok &= check("shake: trauma is capped at 1", sh.trauma == 1.0)
    sh = Shake(seed=3)
    sh.add(0.15)
    ok &= check("shake: a light hit stays subtle (no whole-pixel jump)",
                all(sh.offset(3) == (0, 0) for _ in range(20)))

    ps = Particles(seed=1)
    ps.burst(100.0, 100.0, 12, 200.0, 0.5, ["#fff"], size=2)
    n0 = len(ps.items)
    sizes0 = set(Particles.size_now(p) for p in ps.items)
    for _ in range(200):
        ps.update(1.0 / 60.0)
    ok &= check("particles: burst spawns, all expire", n0 == 12 and ps.items == [])
    ok &= check("particles: start at their size", sizes0 == set([2]))
    ps = Particles(seed=2)
    for _ in range(50):
        ps.burst(0, 0, 20, 100.0, 5.0, ["#fff"])
    ok &= check("particles: capped at MAX", len(ps.items) <= Particles.MAX)
    ps = Particles(seed=3)
    ps.burst(0.0, 0.0, 1, 100.0, 1.0, ["#fff"], drag=0.0, rise=0.0)
    p = ps.items[0]
    x0 = p["x"]
    ps.update(0.1)
    ok &= check("particles: move along their velocity", abs(ps.items[0]["x"] - (x0 + p["vx"] * 0.1)) < 1e-6)
    ok &= check("night_clock: 12:00 AM at the start, 3:00 AM halfway, 6:00 AM at sunrise",
                night_clock(0.0) == "12:00 AM" and night_clock(0.5) == "3:00 AM" and night_clock(1.0) == "6:00 AM")
    ok &= check("night_clock never goes backwards across the night",
                all(night_clock(i / 200.0) is not None for i in range(201)))
    ok &= check("night_tint: dark blue from the very first frame (no dusk), sunrise bright",
                night_tint(0.0)[0] < 30 and night_tint(0.0)[2] < 60 and night_tint(0.5)[2] < 60 and night_tint(1.0)[3] > 0.5)
    ok &= check("night_tint: alpha stays in 0..1 and colours in 0..255 everywhere",
                all(0.0 <= night_tint(i / 500.0)[3] <= 1.0 and all(0 <= c <= 255 for c in night_tint(i / 500.0)[:3]) for i in range(501)))
    ok &= check("night_tint: no jumps (the sunrise glare ramps hardest, under 8% alpha per 1%)",
                all(abs(night_tint((i + 1) / 100.0)[3] - night_tint(i / 100.0)[3]) < 0.08 for i in range(100)))
    print("\n%s" % ("ALL PASS" if ok else "FAILURES ABOVE"))
    return ok


if __name__ == "__main__":
    import sys
    sys.exit(0 if _selftest() else 1)
