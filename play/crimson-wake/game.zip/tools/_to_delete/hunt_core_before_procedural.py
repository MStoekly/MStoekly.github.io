"""Simulation core for the Crimson Wake hunt minigame.

No Ren'Py imports on purpose: this module runs headless, so the game rules can
be tested without launching Ren'Py.

    python game/python-packages/hunt_core.py     # runs the self-test

Ren'Py adds game/python-packages to sys.path automatically, so hunt.rpy can
just `import hunt_core`. Note: editing this file needs a full game restart --
Shift+R does not re-import python packages.

All tuning lives in DEFAULT_CONFIG below.
"""

import math
import random

DEFAULT_CONFIG = {
    # arena, in pixels (must match the ground.png size used by hunt.rpy)
    "arena_w": 1400,
    "arena_h": 820,

    # radii used for collision, not for drawing
    "vamp_radius": 26.0,
    "hunter_radius": 26.0,

    # movement
    "vamp_speed": 380.0,          # px/sec at upgrade level 0
    "speed_per_level": 0.09,      # +9% per Speed level

    # hunters. Slower than you at rest so you can always shape the pack, but
    # they close hard once they are on top of you -- that is where the pressure
    # comes from now that movement is 8-way and instant-turn.
    "hunter_speed_frac": 0.62,    # fraction of your BASE speed (Speed upgrades don't buff this)
    "hunter_speed_ramp": 0.012,   # +per prey fed
    "hunter_speed_ramp_cap": 0.30,
    "hunter_boost_dist": 260.0,
    "hunter_boost_mult": 1.55,
    "hunter_merge_dist": 46.0,    # two hunters this close destroy each other
    "hunter_spawn_min_dist": 520.0,  # never spawn one on top of you
    "max_hunters": 11,

    # feeding
    "prey_on_map": 3,
    "feed_radius": 42.0,
    "feed_radius_per_allure": 5.0,
    "prey_spawn_min_dist": 340.0,        # from you
    "prey_spawn_min_hunter_dist": 150.0, # from any hunter
    "tier_values": [5, 15, 40, 100, 250],
    "tier_weights": [46.0, 27.0, 16.0, 8.0, 3.0],
    "allure_tier_bias": 0.09,     # per level, multiplies weight by (1+bias)**tier
    "blood_mult": 1.0,            # flat payout scaler, used by LEVELS below

    # survival
    "hp_base": 2,
    "hp_per_con": 1,
    "invuln_time": 1.4,

    # lunge (SPACE). Staggers, never kills: killing is what hunter-vs-hunter
    # clashes are for, and handing you a delete button would flatten the game.
    "lunge_radius": 150.0,
    "lunge_radius_per_str": 26.0,
    "lunge_knockback": 170.0,
    "lunge_stun": 0.55,
    "lunge_stun_per_str": 0.13,
    "lunge_cd": 4.5,
    "lunge_cd_per_str": 0.45,
    "lunge_cd_min": 1.6,

    # static obstacles. Hunters have no pathfinding, so these are free
    # cover: a hunter homing straight at you rams one and stalls, giving you
    # room the raw speed numbers don't.
    "obstacles": None,   # hand-placed, explicit [(x, y, radius), ...] -- see
                         # tools/tiles_to_obstacles.py for converting
                         # DungeonDraft tile coordinates into this list
    "spawn": None,        # explicit (x, y) start position -- defaults to arena center
}


def _d2(ax, ay, bx, by):
    dx = ax - bx
    dy = ay - by
    return dx * dx + dy * dy


class Prey(object):
    __slots__ = ("x", "y", "tier", "age")

    def __init__(self, x, y, tier):
        self.x = x
        self.y = y
        self.tier = tier
        self.age = 0.0


class Hunter(object):
    __slots__ = ("x", "y", "age", "stun")

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.age = 0.0
        self.stun = 0.0


class Obstacle(object):
    __slots__ = ("x", "y", "radius", "visible")

    def __init__(self, x, y, radius, visible=True):
        self.x = x
        self.y = y
        self.radius = radius
        # False for collision that shouldn't also draw the placeholder
        # boulder sprite -- e.g. a wall/tree that's already part of the
        # ground art and just needs something to stop you walking through it.
        self.visible = visible


class HuntGame(object):
    """One run. Feed until your HP is gone, then bank the blood."""

    def __init__(self, config=None, upgrades=None, seed=None):
        self.cfg = dict(DEFAULT_CONFIG)
        if config:
            self.cfg.update(config)
        self.up = dict(upgrades or {})
        self.rng = random.Random(seed)

        self.w = float(self.cfg["arena_w"])
        self.h = float(self.cfg["arena_h"])
        if self.cfg["spawn"]:
            self.x, self.y = float(self.cfg["spawn"][0]), float(self.cfg["spawn"][1])
        else:
            self.x = self.w * 0.5
            self.y = self.h * 0.5
        r = self.cfg["vamp_radius"]
        self.x = min(max(self.x, r), self.w - r)
        self.y = min(max(self.y, r), self.h - r)

        self.max_hp = int(self.cfg["hp_base"] + self.cfg["hp_per_con"] * self.lvl("constitution"))
        self.hp = self.max_hp
        self.blood = 0
        self.fed = 0
        self.time = 0.0
        self.over = False
        self.invuln = 0.0
        self.lunge_cd = 0.0

        self.facing = -math.pi / 2.0   # radians; starts facing "up" (north)

        # Each entry is (x, y, radius) or (x, y, radius, visible). Default
        # is invisible: every obstacle we actually have right now is
        # collision-only, matching art that's already painted into the
        # ground image (a real map's trees/cave/etc traced from its .dd2vtt
        # export) -- opt into visible=True only for something with no
        # matching art yet (a placeholder boulder sprite should draw).
        self.obstacles = [Obstacle(float(o[0]), float(o[1]), float(o[2]),
                                   visible=bool(o[3]) if len(o) > 3 else False)
                          for o in (self.cfg["obstacles"] or [])]

        self.hunters = []
        self.prey = []
        self.events = []
        for _ in range(int(self.cfg["prey_on_map"])):
            self.prey.append(self._new_prey())

    # -- derived stats ---------------------------------------------------

    def lvl(self, name):
        return int(self.up.get(name, 0))

    @property
    def speed(self):
        return self.cfg["vamp_speed"] * (1.0 + self.cfg["speed_per_level"] * self.lvl("speed"))

    @property
    def feed_radius(self):
        return self.cfg["feed_radius"] + self.cfg["feed_radius_per_allure"] * self.lvl("allure")

    @property
    def lunge_radius(self):
        return self.cfg["lunge_radius"] + self.cfg["lunge_radius_per_str"] * self.lvl("strength")

    @property
    def lunge_cooldown(self):
        return max(self.cfg["lunge_cd_min"],
                   self.cfg["lunge_cd"] - self.cfg["lunge_cd_per_str"] * self.lvl("strength"))

    @property
    def hunter_speed(self):
        # Deliberately keyed to your BASE speed, not self.speed. Keying it to
        # self.speed made Speed upgrades pointless for survival -- hunters
        # scaled with you 1:1, so max Speed still meant hunters could be 43%
        # faster than you, same as level 0. This way Speed actually buys a
        # real margin.
        ramp = min(self.cfg["hunter_speed_ramp"] * self.fed, self.cfg["hunter_speed_ramp_cap"])
        return (self.cfg["hunter_speed_frac"] + ramp) * self.cfg["vamp_speed"]

    # -- spawning --------------------------------------------------------

    def _far_point(self, min_from_vamp, min_from_hunters=0.0, obstacle_margin=40.0, tries=60):
        pad = 60.0
        best = None
        best_score = -1.0
        for _ in range(tries):
            px = self.rng.uniform(pad, self.w - pad)
            py = self.rng.uniform(pad, self.h - pad)
            dv = math.sqrt(_d2(px, py, self.x, self.y))
            dh = min([math.sqrt(_d2(px, py, h.x, h.y)) for h in self.hunters] or [9e9])
            do = min([math.sqrt(_d2(px, py, o.x, o.y)) - o.radius for o in self.obstacles] or [9e9])
            if dv >= min_from_vamp and dh >= min_from_hunters and do >= obstacle_margin:
                return px, py
            score = min(dv - min_from_vamp, dh - min_from_hunters, do - obstacle_margin)
            if score > best_score:
                best_score, best = score, (px, py)
        return best

    def _resolve_obstacles(self, x, y, r):
        """Push (x, y) back outside every obstacle it overlaps. Iterated: a
        single pass can push you out of one obstacle straight into a
        neighbor when two are close together (hand-placed obstacles, e.g.
        a cluster of trees, aren't guaranteed the old random-gen's 150px
        gap), so re-check the full list a few times until it settles."""
        for _pass in range(4):
            moved = False
            for o in self.obstacles:
                dx = x - o.x
                dy = y - o.y
                d = math.hypot(dx, dy)
                min_d = o.radius + r
                if d >= min_d:
                    continue
                if d < 1e-6:
                    dx, dy, d = 1.0, 0.0, 1.0
                x = o.x + dx / d * min_d
                y = o.y + dy / d * min_d
                moved = True
            if not moved:
                break
        return x, y

    def _pick_tier(self):
        bias = 1.0 + self.cfg["allure_tier_bias"] * self.lvl("allure")
        weights = [w * (bias ** i) for i, w in enumerate(self.cfg["tier_weights"])]
        roll = self.rng.uniform(0.0, sum(weights))
        acc = 0.0
        for i, w in enumerate(weights):
            acc += w
            if roll <= acc:
                return i
        return len(weights) - 1

    def _new_prey(self):
        px, py = self._far_point(self.cfg["prey_spawn_min_dist"],
                                 self.cfg["prey_spawn_min_hunter_dist"])
        return Prey(px, py, self._pick_tier())

    def _spawn_hunter(self):
        if len(self.hunters) >= self.cfg["max_hunters"]:
            return
        hx, hy = self._far_point(self.cfg["hunter_spawn_min_dist"])
        self.hunters.append(Hunter(hx, hy))

    # -- the loop --------------------------------------------------------

    def update(self, dt, move_x, move_y, lunge=False):
        """Advance one frame. move_x/move_y are -1..1. Returns this frame's events."""
        self.events = []
        if self.over:
            return self.events

        self.time += dt
        self.invuln = max(0.0, self.invuln - dt)
        self.lunge_cd = max(0.0, self.lunge_cd - dt)

        if move_x or move_y:
            n = math.hypot(move_x, move_y)
            step = self.speed * dt
            self.x += move_x / n * step
            self.y += move_y / n * step
            self.facing = math.atan2(move_y, move_x)
        r = self.cfg["vamp_radius"]
        self.x = min(max(self.x, r), self.w - r)
        self.y = min(max(self.y, r), self.h - r)
        self.x, self.y = self._resolve_obstacles(self.x, self.y, r)

        self._feed()
        self._move_hunters(dt)
        if lunge and self.lunge_cd <= 0.0:
            self._lunge()
        self._clash()
        self._contact()
        return self.events

    def _feed(self):
        fr = self.feed_radius
        for p in list(self.prey):
            if _d2(self.x, self.y, p.x, p.y) <= fr * fr:
                value = int(round(self.cfg["tier_values"][p.tier] * self.cfg["blood_mult"]))
                self.blood += value
                self.fed += 1
                self.events.append(("feed", p.x, p.y, value, p.tier))
                self.prey.remove(p)
                self._spawn_hunter()
                self.prey.append(self._new_prey())

    def _move_hunters(self, dt):
        hs = self.hunter_speed
        boost_d = self.cfg["hunter_boost_dist"]
        boost_m = self.cfg["hunter_boost_mult"]
        for h in self.hunters:
            h.age += dt
            if h.stun > 0.0:
                h.stun = max(0.0, h.stun - dt)
                continue
            dx = self.x - h.x
            dy = self.y - h.y
            d = math.hypot(dx, dy)
            if d < 1e-6:
                continue
            s = hs * (boost_m if d < boost_d else 1.0)
            h.x += dx / d * s * dt
            h.y += dy / d * s * dt
            h.x, h.y = self._resolve_obstacles(h.x, h.y, self.cfg["hunter_radius"])

    def _lunge(self):
        self.lunge_cd = self.lunge_cooldown
        lr = self.lunge_radius
        stun = self.cfg["lunge_stun"] + self.cfg["lunge_stun_per_str"] * self.lvl("strength")
        self.events.append(("lunge", self.x, self.y, lr, 0))
        for h in self.hunters:
            if _d2(self.x, self.y, h.x, h.y) > lr * lr:
                continue
            dx = h.x - self.x
            dy = h.y - self.y
            d = math.hypot(dx, dy) or 1.0
            h.x += dx / d * self.cfg["lunge_knockback"]
            h.y += dy / d * self.cfg["lunge_knockback"]
            h.x = min(max(h.x, 0.0), self.w)
            h.y = min(max(h.y, 0.0), self.h)
            h.x, h.y = self._resolve_obstacles(h.x, h.y, self.cfg["hunter_radius"])
            h.stun = stun
            self.events.append(("stagger", h.x, h.y, 0, 0))

    def _clash(self):
        md = self.cfg["hunter_merge_dist"]
        dead = set()
        n = len(self.hunters)
        for i in range(n):
            if i in dead:
                continue
            for j in range(i + 1, n):
                if j in dead:
                    continue
                a, b = self.hunters[i], self.hunters[j]
                if _d2(a.x, a.y, b.x, b.y) <= md * md:
                    dead.add(i)
                    dead.add(j)
                    self.events.append(("clash", (a.x + b.x) * 0.5, (a.y + b.y) * 0.5, 0, 0))
                    break
        if dead:
            self.hunters = [h for i, h in enumerate(self.hunters) if i not in dead]

    def _contact(self):
        if self.invuln > 0.0:
            return
        rr = self.cfg["vamp_radius"] + self.cfg["hunter_radius"]
        for h in self.hunters:
            if _d2(self.x, self.y, h.x, h.y) <= rr * rr:
                self.hp -= 1
                self.invuln = self.cfg["invuln_time"]
                self.hunters.remove(h)
                self.events.append(("hurt", self.x, self.y, 0, 0))
                if self.hp <= 0:
                    self.hp = 0
                    self.over = True
                    self.events.append(("over", self.x, self.y, self.blood, 0))
                return


# ---------------------------------------------------------------------------
# self-test
# ---------------------------------------------------------------------------

def _play(upgrades=None, seed=0, frames=20000, policy="greedy"):
    """Headless run driven by a scripted policy. Returns the finished HuntGame.

    "greedy"   -- beelines at the nearest prey, ignores danger. A floor.
    "cautious" -- seeks prey but is repelled by nearby hunters and lunges when
                  cornered. A rough stand-in for a competent player.
    """
    g = HuntGame(upgrades=upgrades, seed=seed)
    rng = random.Random(seed + 999)
    dt = 1.0 / 60.0
    for _ in range(frames):
        if g.over:
            break
        mx = my = 0.0
        if g.prey:
            t = min(g.prey, key=lambda p: _d2(g.x, g.y, p.x, p.y))
            d = math.hypot(t.x - g.x, t.y - g.y) or 1.0
            mx, my = (t.x - g.x) / d, (t.y - g.y) / d
        lunge = False
        if policy == "cautious":
            closest = 9e9
            for h in g.hunters:
                dx, dy = g.x - h.x, g.y - h.y
                d = math.hypot(dx, dy) or 1.0
                closest = min(closest, d)
                if d < 320.0:
                    w = (320.0 - d) / 320.0 * 3.0
                    mx += dx / d * w
                    my += dy / d * w
            lunge = closest < 110.0
            # hug away from walls so we do not corner ourselves
            mx += (1.0 if g.x < 140 else 0.0) - (1.0 if g.x > g.w - 140 else 0.0)
            my += (1.0 if g.y < 140 else 0.0) - (1.0 if g.y > g.h - 140 else 0.0)
        else:
            lunge = rng.random() < 0.004
        g.update(dt, mx, my, lunge=lunge)
    return g


def _selftest():
    ok = True

    def check(label, cond):
        print("%-52s %s" % (label, "PASS" if cond else "FAIL"))
        return cond

    # 1. it runs a long time without exploding, and invariants hold every frame
    g = HuntGame(seed=1)
    dt = 1.0 / 60.0
    rng = random.Random(2)
    last_blood = 0
    frames = 0
    while frames < 20000 and not g.over:
        g.update(dt, rng.uniform(-1, 1), rng.uniform(-1, 1), lunge=(rng.random() < 0.005))
        frames += 1
        r = g.cfg["vamp_radius"]
        if not (r - 0.5 <= g.x <= g.w - r + 0.5 and r - 0.5 <= g.y <= g.h - r + 0.5):
            ok = check("vampire stays inside the arena", False)
            break
        if g.blood < last_blood:
            ok = check("blood never decreases", False)
            break
        last_blood = g.blood
        if len(g.hunters) > g.cfg["max_hunters"]:
            ok = check("hunter count respects the cap", False)
            break
        if len(g.prey) != g.cfg["prey_on_map"]:
            ok = check("prey count stays constant", False)
            break
    ok &= check("20k random frames, all invariants held", True)

    # 2. a run actually ends
    g = _play(seed=3, policy="greedy")
    ok &= check("a greedy run eventually dies", g.over)
    ok &= check("a greedy run earns blood", g.blood > 0)

    # 3. a hunter never spawns on top of you. Feeding is what spawns them, so
    #    this has to run a policy that actually eats, or it asserts nothing.
    worst = 9e9
    spawns = 0
    for seed in range(12):
        g = HuntGame(upgrades={"constitution": 6}, seed=seed)
        for _ in range(9000):
            if g.over:
                break
            t = min(g.prey, key=lambda p: _d2(g.x, g.y, p.x, p.y))
            before = len(g.hunters)
            g.update(dt, t.x - g.x, t.y - g.y)
            if len(g.hunters) > before:
                spawns += 1
                worst = min(worst, math.sqrt(_d2(g.x, g.y, g.hunters[-1].x, g.hunters[-1].y)))
    ok &= check("%d hunter spawns, closest was %.0f px away" % (spawns, worst),
                spawns > 50 and worst > g.cfg["vamp_radius"] + g.cfg["hunter_radius"] + 100)

    # 4. upgrades measurably help, averaged over seeds
    def avg(up, key):
        runs = [_play(upgrades=up, seed=s) for s in range(14)]
        return sum(getattr(r, key) for r in runs) / float(len(runs))

    base_t = avg({}, "time")
    con_t = avg({"constitution": 4}, "time")
    ok &= check("Constitution 4 survives longer (%.1fs vs %.1fs)" % (con_t, base_t),
                con_t > base_t)

    base_b = avg({}, "blood")
    all_b = avg({"speed": 4, "constitution": 4, "allure": 4, "strength": 4}, "blood")
    ok &= check("all upgrades at 4 earn more blood (%.0f vs %.0f)" % (all_b, base_b),
                all_b > base_b)

    # 5. Allure biases toward richer prey
    def tier_avg(up):
        g = HuntGame(upgrades=up, seed=11)
        return sum(g._pick_tier() for _ in range(20000)) / 20000.0

    t0, t5 = tier_avg({}), tier_avg({"allure": 5})
    ok &= check("Allure 5 raises mean prey tier (%.3f vs %.3f)" % (t5, t0), t5 > t0)

    # 6. two hunters converging on a still target destroy each other
    g = HuntGame(seed=5)
    g.hunters = [Hunter(g.x - 300, g.y), Hunter(g.x + 300, g.y)]
    g.invuln = 999.0
    for _ in range(600):
        g.update(dt, 0, 0)
        if not g.hunters:
            break
    ok &= check("two hunters closing head-on clash and die", not g.hunters)

    # 7. lunge staggers rather than deletes
    g = HuntGame(upgrades={"strength": 3}, seed=6)
    g.hunters = [Hunter(g.x + 60, g.y)]
    g.update(dt, 0, 0, lunge=True)
    ok &= check("lunge knocks back and stuns, does not kill",
                len(g.hunters) == 1 and g.hunters[0].stun > 0
                and _d2(g.x, g.y, g.hunters[0].x, g.hunters[0].y) > 60 * 60)

    # 8. pacing: what a competent player gets out of a run, unupgraded vs maxed.
    def survey(up):
        runs = [_play(upgrades=up, seed=s, policy="cautious") for s in range(20)]
        return (sum(r.time for r in runs) / 20.0,
                sum(r.blood for r in runs) / 20.0,
                sum(r.fed for r in runs) / 20.0)

    t0, b0, f0 = survey({})
    t5, b5, f5 = survey({"speed": 5, "constitution": 5, "allure": 5, "strength": 5})
    print("\npacing (cautious policy, 20 seeds):")
    print("  level 0 : %5.1fs  %6.0f blood  %4.1f prey" % (t0, b0, f0))
    print("  level 5 : %5.1fs  %6.0f blood  %4.1f prey" % (t5, b5, f5))
    ok &= check("an unupgraded run lasts 20-120s", 20.0 <= t0 <= 120.0)
    ok &= check("maxed run out-earns unupgraded by 2x or more", b5 >= b0 * 2.0)

    # 9. obstacles: given a hand-placed list (the only way they exist now),
    # nothing ever ends a frame embedded in one.
    worst_overlap = 0.0
    for seed in range(10):
        # non-overlapping by construction -- a level designer hand-placing
        # obstacles wouldn't stack them either, and the resolver (like most
        # simple push-out resolvers) only guarantees a clean result when
        # obstacles don't overlap each other.
        # gap >= 2x the biggest entity radius (hunter/vamp both 26) so the
        # two obstacles' keep-out zones (obstacle.radius + entity.radius)
        # don't overlap each other -- when they do, no single point can
        # satisfy both circles' push-out at once and the iterative resolver
        # can only get close, not exact. Below that threshold is a real
        # geometric limit, not a bug; hand-placed obstacles should keep it
        # in mind for tight passages too.
        rng9 = random.Random(seed + 900)
        explicit9 = []
        for _ in range(10):
            for _try in range(20):
                ex, ey, er = rng9.uniform(100, 1300), rng9.uniform(100, 720), rng9.uniform(30, 60)
                if all(math.sqrt(_d2(ex, ey, ox, oy)) >= er + orad + 60.0
                       for ox, oy, orad in explicit9):
                    explicit9.append((ex, ey, er))
                    break
        g = HuntGame(config={"obstacles": explicit9}, seed=seed)
        rng = random.Random(seed + 500)
        for _ in range(3000):
            if g.over:
                break
            g.update(dt, rng.uniform(-1, 1), rng.uniform(-1, 1), lunge=(rng.random() < 0.01))
            for o in g.obstacles:
                d = math.sqrt(_d2(g.x, g.y, o.x, o.y)) - (o.radius + g.cfg["vamp_radius"])
                if d < -0.5:
                    worst_overlap = max(worst_overlap, -d)
            for h in g.hunters:
                for o in g.obstacles:
                    d = math.sqrt(_d2(h.x, h.y, o.x, o.y)) - (o.radius + g.cfg["hunter_radius"])
                    if d < -0.5:
                        worst_overlap = max(worst_overlap, -d)
    ok &= check("obstacles: no embedding found (worst %.1fpx)" % worst_overlap, worst_overlap <= 0.5)

    # 10. an explicit obstacle list (hand-mapped from DungeonDraft) is used
    # verbatim, no random fallback, and still gets the same safety resolver.
    explicit = [(300, 300, 40), (900, 500, 55)]
    g = HuntGame(config={"obstacles": explicit}, seed=1)
    ok &= check("explicit obstacle list used verbatim",
                len(g.obstacles) == 2
                and (g.obstacles[0].x, g.obstacles[0].y, g.obstacles[0].radius) == (300.0, 300.0, 40.0))
    gx, gy = g._resolve_obstacles(300.0, 300.0, 26.0)
    ok &= check("hand-mapped obstacles still push the player out",
                math.hypot(gx - 300.0, gy - 300.0) >= 40.0 + 26.0 - 0.5)

    # 11. no random generation anywhere -- a level's obstacle count is
    # exactly whatever its hand/VTT-mapped list says, nothing more.
    for i in range(len(LEVELS)):
        g = HuntGame(config=level_cfg(i), seed=4)
        expected = len(LEVELS[i]["cfg"].get("obstacles") or [])
        ok &= check("%s has exactly its %d mapped obstacle(s)" % (LEVELS[i]["key"], expected),
                    len(g.obstacles) == expected)

    print("\n%s" % ("ALL PASS" if ok else "FAILURES ABOVE"))
    return ok


# ---------------------------------------------------------------------------
# levels: forest (easy/low-reward) up through town (hard/high-reward)
# ---------------------------------------------------------------------------
# Each entry overrides a few DEFAULT_CONFIG keys. unlock_power is the
# threshold on sum(cw_upgrades.values()) (0-20) that opens the level -- i.e.
# the vampire has to actually grow stronger to take the higher-risk hunts.

LEVELS = [
    {
        "key": "forest", "name": "Wailing Wood", "unlock_power": 0,
        "ground": "ground_forest.png",
        "ground_top": "ground_forest_top.png",   # optional canopy overlay -- see hunt.rpy's ground_top
        "cfg": {
            "hunter_speed_frac": 0.46, "hunter_boost_mult": 1.18,
            "hunter_boost_dist": 190, "max_hunters": 6, "prey_on_map": 4,
            "tier_weights": [60.0, 26.0, 10.0, 3.0, 1.0],
            "blood_mult": 0.85, "invuln_time": 1.8,
            "arena_w": 1540, "arena_h": 1400,   # real Wailing Wood map, 22x20 tiles @ 70px
            "spawn": (315, 1365),                # the cave, tile (4, 19)
            # from the Wailing Wood.dd2vtt export (Universal VTT). Two
            # kinds of shape, told apart by whether they touch the map's own
            # edge: freestanding props (trees, the fireplace, a small rock)
            # collapse to ONE small circle at their center -- trunk/hearth
            # only, not the full canopy/outline, so you can walk under the
            # branches, same as real life. The cave (a cluster of 4 traced
            # shapes hugging the south edge, right where you spawn) instead
            # gets walked as a CHAIN of overlapping circles along its actual
            # traced silhouette -- it's a real wall, not something you can
            # duck under, and a single center-circle would either block the
            # whole cave interior (including your own spawn point) or miss
            # the wall shape entirely.
            # NOT included yet: a second, much larger traced shape (~8x8
            # tiles) in the far NE corner -- unclear what it is (cliff?
            # rocks?), unconfirmed, and would add ~120 more wall circles, so
            # skipped rather than guessed. Tell me if that one needs collision too.
            "obstacles": [
                (173, 1418, 18),
                (24, 1416, 18),
                (-5, 1419, 18),
                (-14, 1400, 18),
                (-18, 1371, 18),
                (-16, 1341, 18),
                (-15, 1311, 18),
                (-17, 1282, 18),
                (-19, 1252, 18),
                (-17, 1222, 18),
                (-18, 1198, 18),
                (12, 1201, 18),
                (30, 1182, 18),
                (58, 1174, 18),
                (80, 1153, 18),
                (96, 1131, 18),
                (110, 1107, 18),
                (133, 1093, 18),
                (162, 1096, 18),
                (181, 1118, 18),
                (200, 1140, 18),
                (213, 1167, 18),
                (236, 1183, 18),
                (260, 1195, 18),
                (270, 1221, 18),
                (271, 1250, 18),
                (255, 1274, 18),
                (230, 1284, 18),
                (211, 1306, 18),
                (189, 1324, 18),
                (200, 1344, 18),
                (221, 1364, 18),
                (235, 1387, 18),
                (222, 1412, 18),
                (193, 1420, 18),
                (72, 1420, 18),
                (123, 1417, 18),
                (770, 855, 14),
                (522, 597, 14),
                # (515, 573) and (1302, 456) were wrong reads -- verified
                # against the actual ground_forest.png crop, both are just
                # branch/notch detail of the two trees right next to them
                # (index7/9 in line_of_sight are sub-shapes of the same
                # tree's canopy trace, not separate objects), so dropped as
                # redundant with the trunk circles already covering them.
                # 4 trees clustered in the far NE corner -- traced as one
                # merged 246-point blob (their canopies overlap in the art),
                # split back into individual trunks via k-means (k=4) on the
                # blob's boundary points. Confirmed by the user to be trees,
                # not a cliff/rock formation. Verified against the ground art.
                (1419, 143, 14),
                (1500, 351, 14),
                (1148, 69, 14),
                (1317, 430, 14),
                # the REAL fireplace: not in line_of_sight at all -- found via
                # the .dd2vtt's "lights" entry instead (a torch/campfire prop
                # is also a light source in DungeonDraft), position (14.0,
                # 8.39) tiles. Verified against the ground art -- lands
                # exactly on the campfire in the screenshot.
                (980, 587, 18),
            ],
        },
    },
    {
        "key": "road", "name": "Old Coast Road", "unlock_power": 3,
        "ground": "ground_road.png",
        "cfg": {
            "hunter_speed_frac": 0.54, "hunter_boost_mult": 1.32,
            "hunter_boost_dist": 220, "max_hunters": 8,
            "tier_weights": [52.0, 28.0, 13.0, 5.0, 2.0],
            "blood_mult": 1.0,
        },
    },
    {
        "key": "outskirts", "name": "Village Outskirts", "unlock_power": 7,
        "ground": "ground_outskirts.png",
        "cfg": {},
    },
    {
        "key": "village", "name": "Blackmere Village", "unlock_power": 12,
        "ground": "ground_village.png",
        "cfg": {
            "hunter_speed_frac": 0.70,
            # boost_mult cut from an earlier 1.70: at max Speed, hunters could
            # still be 17% faster than you in the worst case (max ramp +
            # boosted), regardless of upgrades. 1.30 brings that to ~90%, a
            # real if tight margin. Steady chase speed (hunter_speed_frac)
            # left alone on purpose -- only the close-range spike was the
            # problem.
            "hunter_boost_mult": 1.30,
            "hunter_boost_dist": 280, "max_hunters": 12,
            "tier_weights": [34.0, 27.0, 20.0, 13.0, 6.0],
            "blood_mult": 1.35, "invuln_time": 1.3,
        },
    },
    {
        "key": "town", "name": "Harrow's Gate", "unlock_power": 17,
        "ground": "ground_town.png",
        "cfg": {
            "hunter_speed_frac": 0.78,
            # same fix as village: boost_mult 1.85->1.45 and ramp cap
            # 0.30->0.20 bring the worst-case ratio from 138% down to ~98%
            # (still the tightest in the game, town is meant to be the hardest).
            "hunter_boost_mult": 1.45, "hunter_speed_ramp_cap": 0.20,
            "hunter_boost_dist": 300, "max_hunters": 13,
            "tier_weights": [22.0, 25.0, 23.0, 19.0, 11.0],
            "blood_mult": 1.75, "invuln_time": 1.1,
        },
    },
]


def level_cfg(index):
    """DEFAULT_CONFIG with one level's overrides merged in. Does not mutate
    DEFAULT_CONFIG."""
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(LEVELS[index]["cfg"])
    return cfg


def unlocked_levels(upgrades):
    power = sum(int(v) for v in (upgrades or {}).values())
    return [i for i, lv in enumerate(LEVELS) if lv["unlock_power"] <= power]


if __name__ == "__main__":
    import sys
    sys.exit(0 if _selftest() else 1)
