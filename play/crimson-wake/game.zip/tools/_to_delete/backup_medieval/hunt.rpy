# The hunt minigame: you are the vampire, prey is currency, hunters are the cost.
# Rules and tuning live in game/python-packages/hunt_core.py (restart the game
# after editing it -- Shift+R does not re-import python packages).

init python:
    import math
    import hunt_core
    import pygame_sdl2 as pygame
    import hunt_mapgen
    import pixel_art
    import hunt_juice

    # Where the arena sits inside the 1920x1080 window, and the box its
    # rendering is scaled to fit -- whatever the level's actual arena_w/h is,
    # the whole map is always visible, just smaller for a bigger map.
    HUNT_X = 260
    HUNT_Y = 170
    DISPLAY_W = 1400.0
    DISPLAY_H = 820.0

    # One native pixel of art = PIXEL_ZOOM screen pixels, always an integer so
    # the pixels stay square and crisp (the PNGs are upscaled in code, not by
    # the engine). The 1400x820 box shows ~29x17 tiles at this zoom; maps
    # bigger than that scroll with a camera that follows the vampire.
    PIXEL_ZOOM = 3

    # Per-level track, keyed by LEVELS[i]["key"] -- not derived from the
    # display name, since those don't always match the file (e.g. the
    # village level is named "Blackmere Village" but its track is
    # "Blackmere Gate.mp3"). Add new entries here as tracks arrive.
    HUNT_MUSIC = {
        "forest": "music/Wailing Wood.mp3",
        "road": "music/Old Coast Road.mp3",
        "outskirts": "music/Village Outskirts.mp3",
        "village": "music/Blackmere Gate.mp3",
        "town": "music/Harrow's Gate.mp3",
    }

    # Sound effects (synthesized by tools/make_sfx.py into game/audio/). A few
    # extra channels on the sfx mixer so overlapping sounds don't cut each
    # other off; missing files are silently skipped.
    HUNT_SFX_CHANNELS = ["sound", "hunt_sfx2", "hunt_sfx3", "hunt_sfx4"]
    for _name in HUNT_SFX_CHANNELS[1:]:
        renpy.music.register_channel(_name, "sfx", False)

    BLOOD_COLORS = ["#c81428", "#8e0f1e", "#e8465a"]
    SPARK_COLORS = ["#ffe9a0", "#ffffff", "#e8c04a"]
    DUST_COLORS = ["#7d746d", "#5f5853", "#948a82"]

    class HuntDisplayable(renpy.Displayable):

        MOVE = {
            pygame.K_LEFT: (-1, 0), pygame.K_a: (-1, 0),
            pygame.K_RIGHT: (1, 0), pygame.K_d: (1, 0),
            pygame.K_UP: (0, -1), pygame.K_w: (0, -1),
            pygame.K_DOWN: (0, 1), pygame.K_s: (0, 1),
        }

        DEATH_PAUSE = 1.1

        def __init__(self, game, level, **kwargs):
            super(HuntDisplayable, self).__init__(**kwargs)
            self.game = game
            self.held = set()
            self.lunge_queued = False
            self.last_st = None
            self.end_at = None
            self.result_ready = False
            self.vfx = []

            # game feel (see hunt_juice.py)
            self.shake = hunt_juice.Shake()
            self.parts = hunt_juice.Particles()
            self.freeze = 0.0        # hit-stop: seconds the simulation is held
            self.hop_t = 9.0         # seconds since the vampire's feed hop began
            self.flash_t = 0.0       # white-silhouette flash time left
            self.dust_t = 0.0
            self.beat_t = 0.0
            self.last_pos = (game.x, game.y)
            self.started = False
            self.sfx_n = 0
            self.sfx_have = {}
            self.solids = {}

            self.level_name = level["name"]
            # world px -> screen px. The map can be bigger than the box (later
            # stages are), so a camera follows the vampire: `wr` below holds
            # the whole arena and only a view-sized window of it is shown.
            self.nz = PIXEL_ZOOM
            self.k = pixel_art.TILE_PX / hunt_mapgen.TILE      # world px -> native art px
            self.scale = self.nz * self.k
            self.aw = int(round(game.w * self.scale))
            self.ah = int(round(game.h * self.scale))
            self.view_w = min(self.aw, int(DISPLAY_W // self.nz) * self.nz)
            self.view_h = min(self.ah, int(DISPLAY_H // self.nz) * self.nz)
            self.vx = HUNT_X + int((DISPLAY_W - self.view_w) / 2)
            self.vy = HUNT_Y + int((DISPLAY_H - self.view_h) / 2)
            self.cam_x = 0
            self.cam_y = 0

            m = game.map
            self._imgs = {}
            self.ground = self.px_img(("ground", m["seed"]), pixel_art.ground_png(m, self.nz))

            # Static map objects, placed once. Trunks/props are depth-sorted
            # together with the characters by their feet (so the vampire is
            # hidden BEHIND a trunk when he stands north of it); crowns are
            # drawn over everything (you run UNDER the branches).
            # Tuples: (sort key in native px, image, screen x, screen y, w, h)
            self.base_items = []
            self.crown_items = []
            for o in m["objects"]:
                for layer, items in (("base", self.base_items), ("crown", self.crown_items)):
                    sp = pixel_art.object_sprite(o["kind"], o["variant"], layer, self.nz)
                    if sp is None:
                        continue
                    png, off_x, off_y, w, h, foot = sp
                    nx = int(round(o["x"] * self.k + off_x))
                    ny = int(round(o["y"] * self.k + off_y))
                    img = self.px_img((o["kind"], o["variant"] % pixel_art.OBJECTS[o["kind"]]["variants"], layer), png)
                    items.append((o["y"] * self.k + foot, img, nx * self.nz, ny * self.nz, w * self.nz, h * self.nz))

            self._facing = {}
            self.red = Solid("#c81428")
            self.bar_bg = Solid("#00000099")
            self.bar_fill = Solid("#c81428")
            self.bar_full = Solid("#e8c04a")
            self.heart_empty = Solid("#3a2a2e")
            self._text = {}

        # -- helpers -----------------------------------------------------

        def px_img(self, key, png):
            """Wrap generated PNG bytes as an image, one per distinct key."""
            d = self._imgs.get(key)
            if d is None:
                d = im.Data(png, "cw_px_%s.png" % "_".join(str(p) for p in key))
                self._imgs[key] = d
            return d

        def char_img(self, kind, facing, tier=0, flash=False):
            return self.px_img((kind, facing, tier, self.nz, flash),
                               pixel_art.character_png(kind, facing, self.nz, tier, flash))

        def solid(self, color):
            d = self.solids.get(color)
            if d is None:
                d = Solid(color)
                self.solids[color] = d
            return d

        def sfx(self, name, vol=1.0):
            path = "audio/sfx_%s.wav" % name
            ok = self.sfx_have.get(path)
            if ok is None:
                ok = renpy.loadable(path)
                self.sfx_have[path] = ok
            if not ok:
                return
            ch = HUNT_SFX_CHANNELS[self.sfx_n % len(HUNT_SFX_CHANNELS)]
            self.sfx_n += 1
            renpy.sound.play(path, channel=ch, relative_volume=vol)

        @staticmethod
        def face_of(dx, dy, default):
            if abs(dx) < 0.01 and abs(dy) < 0.01:
                return default
            if abs(dy) >= abs(dx):
                return "up" if dy < 0 else "down"
            return "right" if dx > 0 else "left"

        def label(self, s, size=36, color="#e8dcd0"):
            key = (s, size, color)
            d = self._text.get(key)
            if d is None:
                if len(self._text) > 300:
                    self._text.clear()
                d = Text(s, size=size, color=color)
                self._text[key] = d
            return d

        def add_vfx(self, kind, x, y, life, extra=0, tier=0):
            self.vfx.append({"kind": kind, "x": x, "y": y, "t": 0.0,
                             "life": life, "extra": extra, "tier": tier})

        def hit_stop(self, secs):
            self.freeze = max(self.freeze, secs)

        def on_event(self, e):
            kind, x, y, a, b = e
            if kind == "feed":
                self.add_vfx("feed", x, y, 0.95, a, b)
                self.sfx("feed_%d" % max(0, min(4, b)))
                self.shake.add(0.10 + 0.03 * b)
                self.hit_stop(0.02 + 0.006 * b)
                self.hop_t = 0.0
                self.flash_t = 0.07
                self.parts.burst(x, y, 9 + 3 * b, 190.0, 0.55, BLOOD_COLORS, size=2, drag=3.0)
            elif kind == "clash":
                self.add_vfx("clash", x, y, 0.35)
                self.sfx("clash", 0.8)
                self.shake.add(0.30)
                self.hit_stop(0.04)
                self.parts.burst(x, y, 10, 320.0, 0.3, SPARK_COLORS, size=2, drag=5.0)
            elif kind == "lunge":
                self.add_vfx("lunge", x, y, 0.45, a)
                self.sfx("lunge")
                self.shake.add(0.18)
                self.parts.burst(x, y + 26.0, 7, 140.0, 0.35, DUST_COLORS, size=2, drag=4.0)
            elif kind == "stagger":
                self.sfx("clash", 0.55)
                self.shake.add(0.14)
                self.hit_stop(0.03)
                self.parts.burst(x, y, 6, 240.0, 0.28, SPARK_COLORS, size=2, drag=5.0)
            elif kind == "hurt":
                self.add_vfx("hurt", x, y, 0.55)
                self.sfx("hurt")
                self.shake.add(0.80)
                self.hit_stop(0.07)
                self.flash_t = 0.09
                self.parts.burst(x, y, 20, 280.0, 0.6, BLOOD_COLORS + ["#ffffff"], size=2, drag=3.0)
            elif kind == "over":
                self.sfx("death")
                self.shake.add(1.0)
                self.hit_stop(0.12)
                self.parts.burst(x, y, 36, 330.0, 0.9, BLOOD_COLORS, size=3, drag=2.5)

        # -- frame -------------------------------------------------------

        def render(self, width, height, st, at):
            g = self.game

            if self.last_st is None:
                self.last_st = st
            dt = st - self.last_st
            self.last_st = st
            if dt < 0.0:
                dt = 0.0
            elif dt > 0.05:      # a lag spike must not teleport anyone
                dt = 0.05

            if not self.started:
                self.started = True
                self.sfx("start", 0.8)

            # hit-stop: the world holds still for a few frames on impact, while
            # shake and the freeze timer itself keep running on real time.
            sim_dt = dt
            if self.freeze > 0.0:
                self.freeze -= dt
                sim_dt = 0.0
            self.shake.update(dt)

            if not g.over:
                if sim_dt > 0.0:
                    mx = my = 0
                    for k in self.held:
                        d = self.MOVE.get(k)
                        if d:
                            mx += d[0]
                            my += d[1]
                    mx = max(-1, min(1, mx))
                    my = max(-1, min(1, my))
                    for e in g.update(sim_dt, mx, my, self.lunge_queued):
                        self.on_event(e)
                    self.lunge_queued = False
                    if g.over:
                        self.end_at = st + self.DEATH_PAUSE
            elif self.end_at is not None and st >= self.end_at:
                self.result_ready = True
                renpy.timeout(0.0)

            if sim_dt > 0.0 and not g.over:
                # dust kicked up while running (position delta, so walls and
                # obstacles that stop you stop the dust too)
                moved = math.hypot(g.x - self.last_pos[0], g.y - self.last_pos[1])
                self.dust_t -= sim_dt
                if moved > 0.4 and self.dust_t <= 0.0:
                    self.dust_t = 0.09
                    self.parts.burst(g.x, g.y + 28.0, 1, 34.0, 0.4, DUST_COLORS, size=2, drag=2.0, rise=-34.0)
                # heartbeat on the last heart
                if g.hp <= 1 and g.max_hp > 1:
                    self.beat_t -= sim_dt
                    if self.beat_t <= 0.0:
                        self.beat_t = 0.9
                        self.sfx("beat", 0.7)
                else:
                    self.beat_t = 0.0
            self.last_pos = (g.x, g.y)

            self.hop_t += sim_dt
            self.flash_t = max(0.0, self.flash_t - dt)
            for v in self.vfx:
                v["t"] += sim_dt
            self.vfx = [v for v in self.vfx if v["t"] < v["life"]]
            self.parts.update(sim_dt)

            return self.draw(width, height, st, at)

        def draw(self, width, height, st, at):
            g = self.game
            sc = self.scale
            nz = self.nz
            k = self.k
            r = renpy.Render(width, height)

            # camera: centred on the vampire, clamped to the map, snapped to
            # the native pixel grid so the art never shimmers.
            cx = int(round((g.x * sc - self.view_w / 2.0) / nz)) * nz
            cy = int(round((g.y * sc - self.view_h / 2.0) / nz)) * nz
            self.cam_x = max(0, min(self.aw - self.view_w, cx))
            self.cam_y = max(0, min(self.ah - self.view_h, cy))
            cam_x, cam_y, vw, vh = self.cam_x, self.cam_y, self.view_w, self.view_h

            # Everything draws into `wr` (arena-sized, arena coordinates) and
            # the view window is cropped out of it, so nothing spills over the
            # HUD. Only things near the window are drawn.
            wr = renpy.Render(self.aw, self.ah)
            m = 4 * nz

            def visible(x, y, w, h):
                return x + w > cam_x - m and x < cam_x + vw + m and y + h > cam_y - m and y < cam_y + vh + m

            wr.blit(renpy.render(self.ground, self.aw, self.ah, st, at), (0, 0))

            # depth-sorted layer: trunks/props + characters, ordered by feet
            layer = []
            for key, d, x, y, w, h in self.base_items:
                if visible(x, y, w, h):
                    layer.append((key, d, x, y))

            def char(d, wx, wy, dy=0):
                # 16x16 native sprites centred on a world position, snapped to
                # the native pixel grid; sorted by their feet (~7px below centre)
                nx = int(round(wx * k - 8))
                ny = int(round(wy * k - 8)) + dy
                layer.append((wy * k + 7.0, d, nx * nz, ny * nz))

            for p in g.prey:
                char(self.char_img("prey", "down", p.tier), p.x, p.y)

            facing = {}
            for h in g.hunters:
                px_, py_, f = self._facing.get(id(h), (h.x, h.y, "down"))
                f = self.face_of(h.x - px_, h.y - py_, f)
                facing[id(h)] = (h.x, h.y, f)
                d = self.char_img("hunter", f)
                if h.stun > 0.0:
                    d = Transform(d, alpha=0.55)
                char(d, h.x, h.y)
            self._facing = facing

            # blink while invulnerable so the player can read the i-frames.
            # No rotation (it would smear the pixels): pick the down/up/side
            # sprite from the last direction moved.
            if g.invuln <= 0.0 or int(g.invuln * 14) % 2 == 0:
                f = self.face_of(math.cos(g.facing), math.sin(g.facing), "up")
                hop = hunt_juice.hop_offset(self.hop_t / 0.26, 2)
                char(self.char_img("vampire", f, flash=self.flash_t > 0.0), g.x, g.y, hop)

            layer.sort(key=lambda t: t[0])
            for _key, d, x, y in layer:
                wr.blit(renpy.render(d, self.aw, self.ah, st, at), (x, y))

            for pt in self.parts.items:
                ps = hunt_juice.Particles.size_now(pt) * nz
                px_ = int(round(pt["x"] * k)) * nz
                py_ = int(round(pt["y"] * k)) * nz
                if visible(px_, py_, ps, ps):
                    wr.blit(renpy.render(self.solid(pt["color"]), ps, ps, st, at), (px_, py_))

            hurt = 0.0
            for v in self.vfx:
                p = v["t"] / v["life"]
                a = max(0.0, 1.0 - p)
                kind = v["kind"]
                if kind == "lunge" or kind == "clash":
                    world_r = v["extra"] * (0.55 + 0.45 * p) if kind == "lunge" else 110.0 * (0.35 + 1.3 * p)
                    rn = max(3, int(world_r * k))
                    ring = self.px_img(("ring", rn, nz), pixel_art.ring_png(rn, nz))
                    size = rn * 2 + 3
                    nx = int(round(v["x"] * k - size / 2.0))
                    ny = int(round(v["y"] * k - size / 2.0))
                    wr.blit(renpy.render(Transform(ring, alpha=a), self.aw, self.ah, st, at), (nx * nz, ny * nz))
                elif kind == "feed":
                    pop = hunt_juice.ease_out_back(v["t"] / 0.22)
                    t = Transform(self.label("+%d" % v["extra"], 34 + 4 * v["tier"], "#ff5f6e"),
                                  alpha=a, zoom=max(0.1, pop))
                    rend = renpy.render(t, self.aw, self.ah, st, at)
                    w, h = rend.get_size()
                    wr.blit(rend, (int(v["x"] * sc - w / 2), int(v["y"] * sc - 70.0 * p * sc - h / 2)))
                elif kind == "hurt":
                    hurt = max(hurt, 0.45 * a)

            # canopies last: everything above sits "under" the branches. Only
            # the HUD (drawn after the crop) stays on top.
            for key, d, x, y, w, h in self.crown_items:
                if visible(x, y, w, h):
                    wr.blit(renpy.render(d, self.aw, self.ah, st, at), (x, y))

            # screen shake: whole native pixels, so the art stays on the grid
            sdx, sdy = self.shake.offset(3)
            ox, oy = self.vx + sdx * nz, self.vy + sdy * nz
            r.blit(wr.subsurface((cam_x, cam_y, vw, vh)), (ox, oy))

            if hurt > 0.0:
                r.blit(renpy.render(Transform(self.red, alpha=hurt), vw, vh, st, at), (ox, oy))
            if g.hp <= 1 and g.max_hp > 1 and not g.over:
                self.draw_vignette(r, st, at, ox, oy)

            self.draw_arrows(r, st, at)
            self.draw_hud(r, width, height, st, at)
            renpy.redraw(self, 0)
            return r

        def draw_vignette(self, r, st, at, ox, oy):
            """Red edge glow that throbs with the heartbeat while on the last heart."""
            vw, vh = self.view_w, self.view_h
            phase = (0.9 - self.beat_t) / 0.9 if self.beat_t > 0.0 else 0.0
            pulse = max(0.0, 1.0 - phase * 2.2)         # thump, then fade until the next beat
            for th, base in ((6, 0.20), (14, 0.11), (26, 0.05)):
                t = th * self.nz
                al = (base + 0.10 * pulse)
                s_ = Transform(self.red, alpha=al)
                for (x, y, w, h) in ((0, 0, vw, t), (0, vh - t, vw, t), (0, t, t, vh - 2 * t), (vw - t, t, t, vh - 2 * t)):
                    r.blit(renpy.render(s_, w, h, st, at), (ox + x, oy + y))

        def draw_arrows(self, r, st, at):
            """Edge-of-screen pointers to hunters (red) and prey (tier colour)
            that are outside the camera window."""
            g = self.game
            sc = self.scale
            nz = self.nz
            vw, vh = self.view_w, self.view_h
            inset = 16 * nz // 2 + 6
            targets = [(h.x, h.y, "hunter") for h in g.hunters] + [(p.x, p.y, p.tier) for p in g.prey]
            for wx, wy, who in targets:
                sx = wx * sc - self.cam_x
                sy = wy * sc - self.cam_y
                if -8 <= sx <= vw + 8 and -8 <= sy <= vh + 8:
                    continue
                dx = sx - vw / 2.0
                dy = sy - vh / 2.0
                t = min((vw / 2.0 - inset) / max(abs(dx), 1e-6), (vh / 2.0 - inset) / max(abs(dy), 1e-6))
                ax = vw / 2.0 + dx * t
                ay = vh / 2.0 + dy * t
                bucket = int(round(math.atan2(dy, dx) / (2.0 * math.pi) * pixel_art.ARROW_BUCKETS)) % pixel_art.ARROW_BUCKETS
                img = self.px_img(("arrow", bucket, who, nz), pixel_art.arrow_png(bucket, who, nz))
                size = 11 * nz
                r.blit(renpy.render(img, size, size, st, at),
                       (int(self.vx + ax - size / 2), int(self.vy + ay - size / 2)))

        def draw_hud(self, r, width, height, st, at):
            g = self.game

            def blit(d, x, y, w=None, h=None):
                # w may legitimately be 0 (empty cooldown bar), so test for None.
                rw = width if w is None else max(0, int(w))
                rh = height if h is None else max(0, int(h))
                r.blit(renpy.render(d, rw, rh, st, at), (int(x), int(y)))

            blit(self.label(self.level_name, 26, "#8a7f78"), HUNT_X, 40)
            blit(self.label("BLOOD", 28, "#8a7f78"), HUNT_X, 74)
            blit(self.label("%d" % g.blood, 54, "#e8dcd0"), HUNT_X, 100)

            # hearts
            for i in range(g.max_hp):
                d = self.red if i < g.hp else self.heart_empty
                blit(d, HUNT_X + 240 + i * 40, 116, 28, 28)

            # lunge cooldown
            ready = g.lunge_cd <= 0.0
            frac = 1.0 if ready else 1.0 - (g.lunge_cd / max(g.lunge_cooldown, 0.001))
            blit(self.label("LUNGE", 24, "#8a7f78"), HUNT_X + 240 + g.max_hp * 40 + 60, 96)
            bx = HUNT_X + 240 + g.max_hp * 40 + 60
            blit(self.bar_bg, bx, 126, 220, 16)
            blit(self.bar_full if ready else self.bar_fill, bx, 126, int(220 * frac), 16)

            if g.time < 7.0:
                hint = "WASD / arrows to move    SPACE to lunge    Q to break off"
                blit(Transform(self.label(hint, 30, "#8a7f78"),
                               alpha=min(1.0, (7.0 - g.time) / 1.5)),
                     self.vx, self.vy + self.view_h + 16)

            if g.over:
                blit(self.label("DRAINED", 72, "#c81428"),
                     self.vx + self.view_w / 2 - 150, self.vy + self.view_h / 2 - 40)

        # -- input -------------------------------------------------------

        def event(self, ev, x, y, st):
            if self.result_ready:
                # A tuple is always truthy, so a 0-blood run still ends cleanly.
                return ("hunt_done", self.game.blood)

            if ev.type == pygame.KEYDOWN:
                if ev.key in self.MOVE:
                    self.held.add(ev.key)
                    raise renpy.IgnoreEvent()
                if ev.key == pygame.K_SPACE:
                    self.lunge_queued = True
                    raise renpy.IgnoreEvent()
                if ev.key == pygame.K_q:
                    return ("hunt_done", self.game.blood)

            elif ev.type == pygame.KEYUP:
                if ev.key in self.MOVE:
                    self.held.discard(ev.key)
                    raise renpy.IgnoreEvent()

            return None


default cw_blood = 999999
default cw_upgrades = {"speed": 0, "constitution": 0, "allure": 0, "strength": 0}
default cw_level = 0

# DEBUG: testing cheats, applied on every launch. Comment out either line below independently to disable just that cheat (leave "init python:" and "pass" -- the block needs at least one line in it).
#init python:
#    cw_blood = 999999                                                           # unlimited blood
#    cw_upgrades = {"speed": 5, "constitution": 5, "allure": 5, "strength": 5}   # all upgrades maxed
#    pass


screen hunt_screen(hd):
    modal True
    add Solid("#05060a")
    add hd
    key "game_menu" action NullAction()
    key "rollback" action NullAction()


screen level_select():
    modal True
    add Solid("#07070c")

    $ power = sum(cw_upgrades.values())

    vbox:
        align (0.5, 0.5)
        spacing 16

        text "Choose your hunting ground" size 56 color "#c81428" xalign 0.5
        text ("Vampiric strength: %d" % power) size 28 color "#8a7f78" xalign 0.5
        null height 10

        for i, lv in enumerate(hunt_core.LEVELS):
            $ unlocked = power >= lv["unlock_power"]

            frame:
                xsize 900
                padding (30, 18)

                hbox:
                    xfill True
                    vbox:
                        xsize 620
                        yalign 0.5
                        text lv["name"] size 34 color ("#e8dcd0" if unlocked else "#4a4441")
                        if unlocked:
                            text ("payout x%.2f" % lv["cfg"].get("blood_mult", 1.0)) size 22 color "#8a7f78"
                        else:
                            text ("requires %d vampiric strength" % lv["unlock_power"]) size 22 color "#6a4a4a"

                    if unlocked:
                        textbutton "Hunt" action [SetVariable("cw_level", i), Return("hunt")] xalign 1.0
                    else:
                        text "LOCKED" size 28 color "#4a4441" xalign 1.0

        null height 10
        textbutton "Blood Market" action Return("shop") xalign 0.5


screen hunt_results(earned, fed, secs):
    modal True
    add Solid("#000000cc")

    frame:
        align (0.5, 0.5)
        padding (70, 50)
        has vbox
        spacing 18

        text "The night closes in" size 52 color "#c81428"
        null height 10
        text ("Blood taken     %d" % earned) size 38
        text ("Prey drained    %d" % fed) size 38
        text ("Survived        %d s" % secs) size 38
        null height 10
        text ("Blood on hand   %d" % cw_blood) size 34 color "#8a7f78"
        null height 20

        textbutton "Hunt again" action Return("again")
        textbutton "Choose another hunting ground" action Return("lobby")
        textbutton "Blood market" action Return("shop")
        textbutton "Leave the streets" action Return("leave")


label hunt_lobby:
    call screen level_select
    if _return == "shop":
        call screen blood_shop
        jump hunt_lobby
    else:
        jump hunt_run


label hunt_run:
    window hide
    $ _hunt_lv = hunt_core.LEVELS[cw_level]
    $ _hunt_game = hunt_core.HuntGame(config=hunt_core.level_cfg(cw_level), upgrades=cw_upgrades)
    # Per-level music, once it exists -- drop a file at the path below and it
    # starts playing automatically, no code change needed. Silent no-op
    # until then (renpy.loadable check), so this is safe to leave in.
    $ _hunt_track = HUNT_MUSIC.get(_hunt_lv["key"])
    if _hunt_track and renpy.loadable(_hunt_track):
        play music _hunt_track loop fadein 1.0
    call screen hunt_screen(HuntDisplayable(_hunt_game, _hunt_lv))
    $ _hunt_earned = _return[1]
    $ cw_blood += _hunt_earned
    $ _hunt_fed, _hunt_secs = _hunt_game.fed, int(_hunt_game.time)
    $ _hunt_game = None
    call screen hunt_results(_hunt_earned, _hunt_fed, _hunt_secs)
    if _return == "again":
        jump hunt_run
    elif _return == "shop":
        call screen blood_shop
        jump hunt_run
    elif _return == "lobby":
        stop music fadeout 1.0
        jump hunt_lobby
    stop music fadeout 1.0
    return
