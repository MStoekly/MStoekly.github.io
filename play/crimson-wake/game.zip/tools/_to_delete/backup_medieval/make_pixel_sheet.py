"""Contact sheet for the pixel art: every sprite, plus sample generated maps.

    python tools/make_pixel_sheet.py [outdir]

Writes sheet_sprites.png and sheet_map_<biome>.png using pixel_art's own PNG
encoder (no PIL needed). Maps are composed the way hunt.rpy draws them:
ground, trunks/props, entities, then crowns on top.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "game", "python-packages"))

import hunt_mapgen
import pixel_art as pa

NATIVE_PER_WORLD = pa.TILE_PX / hunt_mapgen.TILE


def sprite_sheet():
    W, H = 330, 190
    sheet = pa.Canvas(W, H)
    sheet.rect(0, 0, W, H, pa.C["grass1"])
    x = 6
    for who in ("vampire", "hunter"):
        for facing in ("down", "up", "right", "left"):
            sheet.blit(pa.character_canvas(who, facing), x, 6 if who == "vampire" else 26)
            x += 18
        x = 6 if who == "vampire" else x
    x = 6
    for t in range(5):
        sheet.blit(pa.character_canvas("prey", "down", t), x, 48)
        x += 18
    sheet.blit(pa.lunge_ring(14), 110, 44)
    x, y, rowh = 6, 72, 0
    for kind in sorted(pa.OBJECTS):
        spec = pa.OBJECTS[kind]
        for v in range(spec["variants"]):
            for layer in ("base", "crown"):
                c = pa.object_canvas(kind, v, layer)
                if c is None:
                    continue
                if x + c.w + 4 > W:
                    x, y, rowh = 6, y + rowh + 4, 0
                sheet.blit(c, x, y)
                x += c.w + 4
                rowh = max(rowh, c.h)
    return sheet


def map_sheet(biome, tiles, seed):
    m = hunt_mapgen.generate(biome, tiles[0], tiles[1], seed)
    c = pa.render_ground(m)
    k = NATIVE_PER_WORLD

    def put(kind, variant, layer, wx, wy):
        lay = pa.object_layout(kind, variant, layer)
        if lay is None:
            return
        canvas, ox, oy, _foot = lay
        c.blit(canvas, int(round(wx * k + ox)), int(round(wy * k + oy)))

    # depth order: trunks/props and the characters sorted together by their
    # feet, crowns over everything -- same rule hunt.rpy uses.
    drawn = []
    for o in m["objects"]:
        lay = pa.object_layout(o["kind"], o["variant"], "base")
        drawn.append((o["y"] * k + lay[3], "obj", o))
    sx, sy = m["spawn"]
    drawn.append((sy * k + 7, "char", ("vampire", "down", 0, sx, sy)))
    for dx, dy, who, t in ((300, -200, "hunter", 0), (-380, 180, "hunter", 0), (160, 260, "prey", 1), (-220, -260, "prey", 4)):
        drawn.append(((sy + dy) * k + 7, "char", (who, "down", t, sx + dx, sy + dy)))
    drawn.sort(key=lambda t: t[0])
    for _key, what, d in drawn:
        if what == "obj":
            put(d["kind"], d["variant"], "base", d["x"], d["y"])
        else:
            c.blit(pa.character_canvas(d[0], d[1], d[2]), int(d[3] * k - 8), int(d[4] * k - 8))
    for o in m["objects"]:
        put(o["kind"], o["variant"], "crown", o["x"], o["y"])
    return c, m


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "_to_delete")
    if not os.path.isdir(out):
        os.makedirs(out)
    with open(os.path.join(out, "sheet_sprites.png"), "wb") as f:
        f.write(sprite_sheet().png(4))
    import hunt_core
    for lv in hunt_core.LEVELS:
        c, m = map_sheet(lv["biome"], lv["tiles"], 11)
        with open(os.path.join(out, "sheet_map_%s.png" % lv["key"]), "wb") as f:
            f.write(c.png(2))
    print("ok", out)
