"""Random map generator for the Crimson Wake hunt minigame.

Pure data, no Ren'Py and no drawing: generate() returns a dict of objects
(trees, rocks, crates...) with a collision radius each, plus a road for the
road biome. pixel_art.py paints it; hunt_core.py turns the collision radii
into obstacles. Headless-testable:

    python game/python-packages/hunt_mapgen.py

Units: world pixels, 70 per tile (same convention as the rest of hunt_core).
Rules that keep the sim honest (the obstacle resolver has no pathfinding):
  * collision objects keep >= GAP px between their edges, so a 52px-wide
    entity (2x radius 26) can always slip between any two of them;
  * nothing collides within SPAWN_CLEAR of the spawn point;
  * collision objects stay >= EDGE_GAP from the arena border (no pockets
    between an object and the wall);
  * the road band stays free of objects.
"""

import math
import random

TILE = 70.0
GAP = 64.0
EDGE_GAP = 58.0
SPAWN_CLEAR = 170.0

# Collision radii come from the art (pixel_art.footprint): the opaque width
# of each sprite's base, so what you bump into is what you see. Decor kinds
# (bushes) have none.

# Minimum edge-to-edge distance between solids when placing. GAP below is the
# hard floor the passability tests assert; SPACING is the softer, roomier
# target so obstacles read as scattered rather than clumped.
SPACING = 110.0

# biome -> list of (kind, objects per 100 tiles)
BIOMES = {
    "forest":    [("pine", 2.6), ("oak", 2.6), ("dead", 0.4), ("rock", 0.9), ("grave", 0.5), ("bush", 7.0)],
    "road":      [("oak", 1.0), ("pine", 0.6), ("rock", 1.4), ("bush", 6.0), ("grave", 0.2)],
    "outskirts": [("oak", 0.8), ("hay", 1.8), ("crate", 0.8), ("barrel", 0.8), ("bush", 4.0), ("lamp", 0.4)],
}


def road_center(road, wx):
    """y of the road's centreline at world x."""
    return road["cy"] + road["amp"] * math.sin(wx * road["freq"] + road["phase"])


def _radius(kind, variant):
    import pixel_art      # local import: pixel_art imports this module
    if not pixel_art.OBJECTS[kind]["solid"]:
        return 0.0
    return pixel_art.footprint(kind, variant)["r"] * TILE / pixel_art.TILE_PX


# ---------------------------------------------------------------------------
# structured layouts: town (streets, blocks, plaza with a church, a park) and
# village (crossroads with a well, houses along the roads, farm clusters).
# Everything is built from tile rectangles; buildings are collision RECTANGLES.
# ---------------------------------------------------------------------------

BUILDING_GAP = 1                 # tiles between two buildings
LAMP_WALL_GAP = 36.0             # lamps may stand this close to a wall
SPAWN_CLEAR_RECT = 100.0


def _building_tiles(kind):
    import pixel_art
    return pixel_art.BUILDINGS[kind]["w"], pixel_art.BUILDINGS[kind]["d"]


class _Placer(object):
    """Keeps track of what is solid so new things can keep clear of it."""

    def __init__(self):
        self.circles = []        # (x, y, r)
        self.rects = []          # (x0, y0, x1, y1) in world px

    def clearance(self, x, y):
        best = 9e9
        for cx, cy, r in self.circles:
            best = min(best, math.hypot(x - cx, y - cy) - r)
        for x0, y0, x1, y1 in self.rects:
            best = min(best, math.hypot(max(x0 - x, 0.0, x - x1), max(y0 - y, 0.0, y - y1)))
        return best

    def circle_free(self, x, y, r, rect_gap=GAP, circle_gap=GAP):
        for cx, cy, cr in self.circles:
            if math.hypot(x - cx, y - cy) - cr - r < circle_gap:
                return False
        for x0, y0, x1, y1 in self.rects:
            if math.hypot(max(x0 - x, 0.0, x - x1), max(y0 - y, 0.0, y - y1)) - r < rect_gap:
                return False
        return True

    def rect_free(self, r, margin):
        x0, y0, x1, y1 = r
        for a0, b0, a1, b1 in self.rects:
            if x0 - margin < a1 and x1 + margin > a0 and y0 - margin < b1 and y1 + margin > b0:
                return False
        for cx, cy, cr in self.circles:
            d = math.hypot(max(x0 - cx, 0.0, cx - x1), max(y0 - cy, 0.0, cy - y1))
            if d - cr < margin:
                return False
        return True


class _Town(object):
    def __init__(self, rnd, tw, th, default_zone):
        self.rnd = rnd
        self.tw, self.th = tw, th
        self.grid = [[default_zone] * tw for _ in range(th)]
        self.placer = _Placer()
        self.objects = []
        self.spawn = None                # set by the layout: props keep clear of it

    def zone(self, x0, y0, x1, y1, code):
        for ty in range(max(0, y0), min(self.th, y1)):
            for tx in range(max(0, x0), min(self.tw, x1)):
                self.grid[ty][tx] = code

    def zone_at(self, wx, wy):
        tx, ty = int(wx // TILE), int(wy // TILE)
        if 0 <= tx < self.tw and 0 <= ty < self.th:
            return self.grid[ty][tx]
        return "s"

    def building(self, kind, tx0, ty0, margin_tiles=BUILDING_GAP, variant=None, on_plaza=False):
        """Place a building with its footprint's top-left at tile (tx0, ty0).
        Returns True if it fit (inside the map, clear of other buildings)."""
        w, d = _building_tiles(kind)
        if tx0 < 1 or ty0 < 1 or tx0 + w > self.tw - 1 or ty0 + d > self.th - 1:
            return False
        rect = (tx0 * TILE, ty0 * TILE, (tx0 + w) * TILE, (ty0 + d) * TILE)
        if not self.placer.rect_free(rect, margin_tiles * TILE - 1.0):
            return False
        if self.spawn is not None:
            sx, sy = self.spawn
            if math.hypot(max(rect[0] - sx, 0.0, sx - rect[2]), max(rect[1] - sy, 0.0, sy - rect[3])) < SPAWN_CLEAR_RECT + 40.0:
                return False
        for ty in range(ty0, ty0 + d):                 # never on a road (or the plaza, unless asked)
            for tx in range(tx0, tx0 + w):
                if self.grid[ty][tx] in ("s" if on_plaza else "sp"):
                    return False
        self.placer.rects.append(rect)
        self.objects.append({"kind": kind, "variant": self.rnd.randint(0, 3) if variant is None else variant,
                             "x": (rect[0] + rect[2]) / 2.0, "y": (rect[1] + rect[3]) / 2.0,
                             "r": 0.0, "rect": list(rect)})
        return True

    def prop(self, kind, x, y, rect_gap=GAP, circle_gap=GAP):
        """A solid prop (circle) or decoration at world (x, y), if it fits."""
        r = _radius(kind, 0)
        if self.spawn is not None and math.hypot(x - self.spawn[0], y - self.spawn[1]) < SPAWN_CLEAR_RECT + 40.0 + r:
            return False
        if self.zone_at(x, y) in "sp" and kind not in ("lamp", "grave", "bench", "barrel", "crate", "hay", "well"):
            return False
        if r > 0:
            if not self.placer.circle_free(x, y, r, rect_gap, circle_gap):
                return False
            self.placer.circles.append((x, y, r))
        else:
            if self.placer.clearance(x, y) < 14.0:
                return False
        self.objects.append({"kind": kind, "variant": self.rnd.randint(0, 7), "x": x, "y": y, "r": r})
        return True

    def row_of_buildings(self, x0, x1, bottom, kinds, skip=0.12):
        """Fill [x0, x1) tiles left to right with buildings whose footprint
        bottom edge is at tile row `bottom`."""
        x = x0
        while x + 3 <= x1:
            kind = self.rnd.choice(kinds)
            w, d = _building_tiles(kind)
            if x + w > x1:
                kind = "shed" if x1 - x >= 3 else None
                if kind is None:
                    break
                w, d = _building_tiles(kind)
            if self.rnd.random() < skip:
                x += 3
                continue
            if self.building(kind, x, bottom - d):
                x += w + BUILDING_GAP
            else:
                x += 1

    def props_near_buildings(self, chance, kinds=("barrel", "crate", "hay")):
        for o in list(self.objects):
            if "rect" not in o or o["kind"] in ("church", "stable") or self.rnd.random() > chance:
                continue
            x0, y0, x1, y1 = o["rect"]
            side = self.rnd.choice((-1, 1))
            x = x0 - 40.0 if side < 0 else x1 + 40.0
            self.prop(self.rnd.choice(kinds), x, y1 + 44.0, rect_gap=LAMP_WALL_GAP + 4.0)

    def scatter(self, kind, count, area, tries=30, rect_gap=GAP + 20.0, avoid="spd"):
        """Random props inside area=(tx0, ty0, tx1, ty1) tiles."""
        placed = 0
        for _ in range(count):
            for _t in range(tries):
                x = self.rnd.uniform(area[0], area[2]) * TILE
                y = self.rnd.uniform(area[1], area[3]) * TILE
                if self.zone_at(x, y) in avoid:
                    continue
                if self.prop(kind, x, y, rect_gap=rect_gap, circle_gap=SPACING):
                    placed += 1
                    break
        return placed

    def result(self, biome, seed, spawn):
        return {"biome": biome, "seed": seed, "tiles_w": self.tw, "tiles_h": self.th,
                "w": self.tw * TILE, "h": self.th * TILE, "spawn": spawn, "road": None,
                "objects": sorted(self.objects, key=lambda o: o["y"]),
                "grid": ["".join(row) for row in self.grid]}


def _layout_town(rnd, seed, tw, th):
    """64x40 tiles: ring road, three avenues, a plaza with a church in the
    middle, a park in one of the central blocks, houses everywhere else."""
    t = _Town(rnd, tw, th, "s")                          # everything starts as street
    cx = tw // 2
    t.spawn = (cx * TILE, 23.2 * TILE)
    blocks = [(2, 2, 14, 11), (18, 2, 30, 11), (34, 2, 46, 11), (50, 2, 62, 11),
              (2, 15, 14, 25), (18, 15, 25, 25), (39, 15, 46, 25), (50, 15, 62, 25),
              (2, 29, 14, 38), (18, 29, 30, 38), (34, 29, 46, 38), (50, 29, 62, 38)]
    for b in blocks:
        t.zone(b[0], b[1], b[2], b[3], "y")
    plaza = (cx - 7, 15, cx + 7, 25)
    t.zone(plaza[0], plaza[1], plaza[2], plaza[3], "p")
    t.zone(25, 11, 39, 15, "s")

    # the church: centre of the plaza, back to the north
    t.building("church", cx - 4, 15, variant=0, on_plaza=True)
    church_rect = t.placer.rects[0]

    # a park in one of the four central top/bottom blocks
    park = rnd.choice([(18, 2, 30, 11), (34, 2, 46, 11), (18, 29, 30, 38), (34, 29, 46, 38)])
    t.zone(park[0], park[1], park[2], park[3], "g")
    midx, midy = (park[0] + park[2]) // 2, (park[1] + park[3]) // 2
    t.zone(park[0], midy - 1, park[2], midy + 1, "d")
    t.zone(midx - 1, park[1], midx + 1, park[3], "d")
    t.scatter("oak", 7, (park[0] + 1, park[1] + 1, park[2] - 1, park[3] - 1), avoid="d")
    t.scatter("pine", 4, (park[0] + 1, park[1] + 1, park[2] - 1, park[3] - 1), avoid="d")
    for bx, by in ((midx - 3, midy - 1), (midx + 3, midy - 1), (midx - 3, midy + 2), (midx + 3, midy + 2)):
        t.prop("bench", bx * TILE, by * TILE, rect_gap=20.0, circle_gap=20.0)
    t.scatter("flowers", 7, (park[0] + 1, park[1] + 1, park[2] - 1, park[3] - 1), avoid="d")
    t.scatter("bush", 8, (park[0] + 1, park[1] + 1, park[2] - 1, park[3] - 1), avoid="d")

    # the tavern beside the plaza, a stable in an outer block
    mid_left, mid_right = (18, 15, 25, 25), (39, 15, 46, 25)
    tb = rnd.choice([mid_left, mid_right])
    t.building("tavern", tb[0], tb[3] - 1 - 4, variant=0)
    stable_block = rnd.choice([(2, 2, 14, 11), (50, 2, 62, 11), (2, 29, 14, 38), (50, 29, 62, 38)])
    t.building("stable", stable_block[0] + 2, stable_block[3] - 1 - 3, variant=0)

    # houses: two rows per tall block, one along the south edge for the rest
    houses = ["house_s", "house_m", "house_m", "house_l"]
    for b in blocks:
        if b == park:
            continue
        x0, y0, x1, y1 = b
        inner_x0, inner_x1 = (x0, x1) if b in (mid_left, mid_right) else (x0 + 1, x1 - 1)
        bottom = y1 - 1
        while bottom - 3 >= y0:
            t.row_of_buildings(inner_x0, inner_x1, bottom, houses)
            bottom -= 3 + BUILDING_GAP
    # tavern/stable/church are placed first, so row_of_buildings skipped any
    # overlap on its own (building() refuses conflicts).

    # lamps along the streets, the churchyard's graves, doorstep clutter
    for ty in (11, 25):                                # the two avenues, lamps alternate sides
        for i, tx in enumerate(range(5, tw - 3, 8)):
            t.prop("lamp", (tx + 0.5) * TILE, (ty + (0.8 if i % 2 else 3.2)) * TILE, rect_gap=LAMP_WALL_GAP)
    for tx in (14, 46):                                # the side streets
        for i, ty in enumerate(range(5, th - 3, 10)):
            t.prop("lamp", (tx + (0.8 if i % 2 else 3.2)) * TILE, (ty + 0.5) * TILE, rect_gap=LAMP_WALL_GAP)
    for _ in range(6):
        for _t in range(20):
            x = rnd.uniform(plaza[0] + 0.7, plaza[2] - 0.7) * TILE
            y = rnd.uniform(plaza[1] + 0.7, plaza[3] - 0.7) * TILE
            if y > church_rect[3] + 2.4 * TILE and abs(x - cx * TILE) < 3.0 * TILE:
                continue                                # keep the spawn area open
            if t.prop("grave", x, y, rect_gap=60.0):
                break
    t.props_near_buildings(0.45)
    t.scatter("bush", 30, (2, 2, tw - 2, th - 2), avoid="spdg")
    return t.result("town", seed, t.spawn)


def _layout_village(rnd, seed, tw, th):
    """Crossroads with a well on a small cobbled square, a tavern and a
    stable beside it, houses lining both roads, a few outlying farmsteads."""
    t = _Town(rnd, tw, th, "g")
    cx, cy = tw // 2, th // 2
    t.spawn = ((cx + 0.5) * TILE, (cy + 6.2) * TILE)
    t.zone(0, cy - 1, tw, cy + 2, "d")                   # main road, 3 tiles
    t.zone(cx - 1, 0, cx + 2, th, "d")                   # cross road
    sq = (cx - 4, cy - 4, cx + 5, cy + 5)
    t.zone(sq[0], sq[1], sq[2], sq[3], "p")
    t.prop("well", (cx + 0.5) * TILE, (cy + 0.5) * TILE)

    t.building("tavern", cx + 6, cy - 2 - 4, variant=0)
    t.building("stable", cx - 14, cy + 3, variant=0)

    kinds = ["house_s", "house_m", "house_m", "house_l"]
    # along the main road (north side faces the road with its south wall)
    for side in (-1, 1):
        x = 2
        while x < tw - 6:
            kind = rnd.choice(kinds)
            w, d = _building_tiles(kind)
            ty0 = (cy - 2 - d) if side < 0 else (cy + 3)
            if rnd.random() < 0.2:
                x += 3
            elif t.building(kind, x, ty0):
                x += w + rnd.randint(1, 3)
            else:
                x += 1
    # along the cross road
    for side in (-1, 1):
        y = 2
        while y < th - 5:
            kind = rnd.choice(kinds)
            w, d = _building_tiles(kind)
            tx0 = (cx - 2 - w) if side < 0 else (cx + 3)
            if rnd.random() < 0.25:
                y += 3
            elif t.building(kind, tx0, y):
                y += d + rnd.randint(1, 3)
            else:
                y += 1
    # outlying farmsteads
    for _ in range(5):
        for _t in range(30):
            fx, fy = rnd.randint(4, tw - 12), rnd.randint(4, th - 8)
            if abs(fx - cx) < 8 or abs(fy - cy) < 5:
                continue
            if t.building("house_m", fx, fy):
                t.building("shed", fx + 7, fy + 1)
                t.prop("hay", (fx + 3) * TILE, (fy + 5) * TILE)
                t.prop("crate", (fx - 1) * TILE, (fy + 4) * TILE)
                break
    t.props_near_buildings(0.35)
    t.scatter("oak", 10, (2, 2, tw - 2, th - 2))
    t.scatter("pine", 6, (2, 2, tw - 2, th - 2))
    t.scatter("rock", 4, (2, 2, tw - 2, th - 2))
    t.scatter("bush", 40, (2, 2, tw - 2, th - 2), avoid="spd")
    t.scatter("flowers", 14, (2, 2, tw - 2, th - 2), avoid="spd")
    return t.result("village", seed, t.spawn)


LAYOUTS = {"town": _layout_town, "village": _layout_village}


def generate(biome, tiles_w, tiles_h, seed=None, spawn=None):
    if seed is None:
        seed = random.SystemRandom().randrange(1, 2 ** 31)
    rnd = random.Random(seed)
    if biome in LAYOUTS:
        return LAYOUTS[biome](rnd, seed, tiles_w, tiles_h)
    W, H = tiles_w * TILE, tiles_h * TILE
    if spawn is None:
        spawn = (W / 2.0, H / 2.0)

    road = None
    if biome == "road":
        road = {"cy": H * rnd.uniform(0.40, 0.60), "amp": H * rnd.uniform(0.10, 0.20),
                "freq": rnd.uniform(1.2, 2.2) * math.pi / W, "phase": rnd.uniform(0, 2 * math.pi),
                "half": 78.0}

    objects = []        # dicts: kind, variant, x, y, r
    solid = []          # (x, y, r) of collision objects, for gap checks

    area = tiles_w * tiles_h / 100.0
    table = BIOMES[biome]
    # place big things first so small ones fit around them
    order = sorted(table, key=lambda t: -max(_radius(t[0], 0), _radius(t[0], 1)))
    for kind, per100 in order:
        n = int(round(per100 * area + rnd.uniform(-0.5, 0.5)))
        for _ in range(max(0, n)):
            for _try in range(40):
                variant = rnd.randint(0, 7)
                r = _radius(kind, variant)
                y = rnd.uniform(EDGE_GAP + r, H - EDGE_GAP - r) if r else rnd.uniform(20, H - 20)
                x = rnd.uniform(EDGE_GAP + r, W - EDGE_GAP - r) if r else rnd.uniform(20, W - 20)
                if road is not None and abs(y - road_center(road, x)) < road["half"] + r + 36.0:
                    continue
                if math.hypot(x - spawn[0], y - spawn[1]) < SPAWN_CLEAR + r:
                    continue
                if r > 0:
                    if any(math.hypot(x - sx, y - sy) < sr + r + SPACING for sx, sy, sr in solid):
                        continue
                    solid.append((x, y, r))
                else:
                    if any(math.hypot(x - sx, y - sy) < sr + 14.0 for sx, sy, sr in solid):
                        continue
                objects.append({"kind": kind, "variant": variant, "x": x, "y": y, "r": r})
                break

    objects.sort(key=lambda o: o["y"])
    return {"biome": biome, "seed": seed, "tiles_w": tiles_w, "tiles_h": tiles_h,
            "w": W, "h": H, "spawn": spawn, "road": road, "objects": objects}


def obstacles_of(game_map):
    """Collision shapes for HuntGame: (x, y, r) circles and
    ("rect", x0, y0, x1, y1) building footprints."""
    out = []
    for o in game_map["objects"]:
        if "rect" in o:
            out.append(("rect",) + tuple(o["rect"]))
        elif o["r"] > 0:
            out.append((o["x"], o["y"], o["r"]))
    return out


def _clearance(m, x, y):
    best = 9e9
    for o in m["objects"]:
        if "rect" in o:
            x0, y0, x1, y1 = o["rect"]
            best = min(best, math.hypot(max(x0 - x, 0.0, x - x1), max(y0 - y, 0.0, y - y1)))
        elif o["r"] > 0:
            best = min(best, math.hypot(x - o["x"], y - o["y"]) - o["r"])
    return best


def _reachable_fraction(m, entity_r=26.0, cell=35.0):
    """Flood fill over a half-tile grid of points an entity centre can occupy;
    returns the fraction of those points reachable from the spawn."""
    cols, rows = int(m["w"] // cell), int(m["h"] // cell)
    free = {}
    for j in range(rows):
        for i in range(cols):
            x, y = (i + 0.5) * cell, (j + 0.5) * cell
            free[(i, j)] = (entity_r <= x <= m["w"] - entity_r and entity_r <= y <= m["h"] - entity_r
                            and _clearance(m, x, y) >= entity_r)
    start = (int(m["spawn"][0] // cell), int(m["spawn"][1] // cell))
    if not free.get(start):
        return 0.0
    seen, stack = set([start]), [start]
    while stack:
        i, j = stack.pop()
        for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
            n = (i + di, j + dj)
            if n not in seen and free.get(n):
                seen.add(n)
                stack.append(n)
    return len(seen) / float(max(1, sum(1 for v in free.values() if v)))


def _selftest():
    ok = True

    def check(label, cond):
        print("%-64s %s" % (label, "PASS" if cond else "FAIL"))
        return cond

    sizes = {"forest": (34, 22), "road": (40, 26), "outskirts": (48, 30), "village": (56, 34), "town": (64, 40)}
    for biome, (tw, th) in sorted(sizes.items()):
        bad_gap = bad_spawn = bad_edge = bad_road = bad_rect = bad_oob = bad_reach = 0
        counts = []
        for seed in range(25 if biome not in LAYOUTS else 6):
            m = generate(biome, tw, th, seed)
            sol = [o for o in m["objects"] if o["r"] > 0]
            rects = [o for o in m["objects"] if "rect" in o]
            counts.append(len(sol) + len(rects))
            if _clearance(m, m["spawn"][0], m["spawn"][1]) < (SPAWN_CLEAR_RECT if biome in LAYOUTS else 0):
                bad_spawn += 1
            if _reachable_fraction(m) < 0.97:
                bad_reach += 1
            for i, a in enumerate(sol):
                if biome not in LAYOUTS:
                    if a["x"] - a["r"] < EDGE_GAP - 1e-6 or a["y"] - a["r"] < EDGE_GAP - 1e-6 \
                            or a["x"] + a["r"] > m["w"] - EDGE_GAP + 1e-6 or a["y"] + a["r"] > m["h"] - EDGE_GAP + 1e-6:
                        bad_edge += 1
                    if math.hypot(a["x"] - m["spawn"][0], a["y"] - m["spawn"][1]) < SPAWN_CLEAR + a["r"] - 1e-6:
                        bad_spawn += 1
                if m["road"] and abs(a["y"] - road_center(m["road"], a["x"])) < m["road"]["half"] + a["r"]:
                    bad_road += 1
                if not (0 <= a["x"] - a["r"] and a["x"] + a["r"] <= m["w"] and 0 <= a["y"] - a["r"] and a["y"] + a["r"] <= m["h"]):
                    bad_oob += 1
                for b in sol[i + 1:]:
                    if math.hypot(a["x"] - b["x"], a["y"] - b["y"]) - a["r"] - b["r"] < GAP - 1e-6 and biome not in LAYOUTS:
                        bad_gap += 1
            for i, a in enumerate(rects):
                x0, y0, x1, y1 = a["rect"]
                if x0 < 0 or y0 < 0 or x1 > m["w"] or y1 > m["h"]:
                    bad_oob += 1
                for b in rects[i + 1:]:
                    bx0, by0, bx1, by1 = b["rect"]
                    gx = max(bx0 - x1, x0 - bx1)
                    gy = max(by0 - y1, y0 - by1)
                    if max(gx, gy) < TILE - 1.5:      # buildings keep a tile apart
                        bad_rect += 1
            # circles vs rects: always enough room for a 52px entity
            for c in sol:
                for r_ in rects:
                    x0, y0, x1, y1 = r_["rect"]
                    d = math.hypot(max(x0 - c["x"], 0.0, c["x"] - x1), max(y0 - c["y"], 0.0, c["y"] - y1)) - c["r"]
                    if d < LAMP_WALL_GAP - 1e-6:
                        bad_rect += 1
        ok &= check("%s: spacing, edges, spawn, road, rects, in-bounds clean (avg %.0f solids)"
                    % (biome, sum(counts) / float(len(counts))),
                    bad_gap == bad_spawn == bad_edge == bad_road == bad_rect == bad_oob == 0 and min(counts) > 0)
        ok &= check("%s: >=97%% of free space reachable from spawn" % biome, bad_reach == 0)
    a, b = generate("forest", 34, 22, 5), generate("forest", 34, 22, 5)
    ok &= check("same seed -> identical map", a == b)
    ok &= check("different seed -> different map", generate("forest", 34, 22, 6)["objects"] != a["objects"])
    t = generate("town", 64, 40, 1)
    kinds = [o["kind"] for o in t["objects"]]
    ok &= check("town has a church, a tavern, a stable, a park and houses",
                kinds.count("church") == 1 and kinds.count("tavern") == 1 and kinds.count("stable") == 1
                and sum(row.count("g") for row in t["grid"]) > 50 and sum(k.startswith("house") for k in kinds) >= 10)
    v = generate("village", 56, 34, 1)
    vk = [o["kind"] for o in v["objects"]]
    ok &= check("village has a well, a tavern, a stable and houses",
                vk.count("well") == 1 and vk.count("tavern") == 1 and vk.count("stable") == 1
                and sum(k.startswith("house") for k in vk) >= 8)
    return ok


if __name__ == "__main__":
    import sys
    sys.exit(0 if _selftest() else 1)
