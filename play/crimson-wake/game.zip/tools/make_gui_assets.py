"""Regenerates the Ren'Py GUI images (game/gui/**) as gothic pixel art, from
pixel_ui / pixel_title. Everything is drawn at 3x (1 art px = 3 screen px) so
all 9-slice borders are multiples of 3. Original files are copied once to
tools/_to_delete/backup_gui/ before the first overwrite.

    python tools/make_gui_assets.py            write the files
    python tools/make_gui_assets.py --check    verify sizes / borders without writing

Pair with gui.rpy (borders, sizes, colours, fonts) and ui_theme.rpy (style tweaks).
"""
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "game", "python-packages"))

import pixel_art as pa
from pixel_art import Canvas, C, _rgb, _B4
import pixel_ui as ui
import pixel_title

GUI = os.path.join(ROOT, "game", "gui")
BACKUP = os.path.join(HERE, "_to_delete", "backup_gui")
Z = 3


def rgba(h, a=255):
    r, g, b, _ = _rgb(h)
    return (r, g, b, a)


def transpose(c):
    o = Canvas(c.h, c.w)
    for y in range(c.h):
        for x in range(c.w):
            o.p[x][y] = c.p[y][x]
    return o


def bayer(x, y):
    return (_B4[y & 3][x & 3] + 0.5) / 16.0


# -- frames ------------------------------------------------------------------

def slot_frame(w, h, border="gold_d", field="stone0", fill=None, fill_frac=None):
    """Inset track: ink outline, coloured rim, ink, field. Used for bars/sliders."""
    c = Canvas(w, h)
    c.rect(0, 0, w, h, C["ink"])
    c.rect(1, 1, w - 1, h - 1, C[border])
    c.rect(2, 2, w - 2, h - 2, C["ink"])
    c.rect(3, 3, w - 3, h - 3, C[fill or field])
    if fill:
        c.rect(3, 3, w - 3, 4, C["red_l"] if fill == "red" else C["hay_l"])
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        c.p[y][x] = None
    return c


def thumb(w, h, hover=False):
    c = Canvas(w, h)
    body, light, dark = ("hay_l", "white", "gold") if hover else ("gold", "hay_l", "gold_d")
    c.rect(0, 0, w, h, C["ink"])
    c.rect(1, 1, w - 1, h - 1, C[body])
    c.rect(1, 1, 2, h - 1, C[light])
    c.rect(w - 2, 1, w - 1, h - 1, C[dark])
    c.rect(1, h - 2, w - 1, h - 1, C[dark])
    return c


def scroll_bar(length, thick=6):
    c = Canvas(length, thick)
    rows = ("ink", "stone1", "stone0", "stone0", "stone1", "ink")
    for y in range(thick):
        c.rect(0, y, length, y + 1, C[rows[y]])
    return c


def scroll_thumb(length, thick=6, hover=False):
    c = Canvas(length, thick)
    rows = ("ink", "hay_l" if hover else "gold", "gold", "gold_d", "gold_d", "ink")
    for y in range(thick):
        c.rect(0, y, length, y + 1, C[rows[y]])
    return c


def check_glyph(selected):
    c = Canvas(9, 16)
    c.rect(0, 3, 9, 12, C["ink"])
    c.rect(1, 4, 8, 11, C["gold_d"] if not selected else C["gold"])
    c.rect(2, 5, 7, 10, C["stone0"])
    if selected:
        for x, y in ((2, 7), (3, 8), (4, 9), (5, 8), (6, 7), (7, 6), (7, 5)):
            c.px(x, y - 1 if x > 4 else y, "red_l")
            c.px(x, y, "red")
    return c


def radio_glyph(selected):
    c = Canvas(9, 16)
    c.blit(ui.pip(selected), 0, 3)
    return c


# -- big flat pieces -----------------------------------------------------------

def textbox():
    w, h = 640, 93
    c = Canvas(w, h)
    for y in range(h):
        for x in range(w):
            r = pa._hash(x, y, 3)
            c.p[y][x] = rgba("#321a4a", 238) if r < 0.07 else rgba("#1c1424", 238)
    top = ("ink", "gold_d", "gold", "ink", "stone3", "stone2", "stone1", "ink")
    for y, name in enumerate(top):
        c.rect(0, y, w, y + 1, C[name])
    c.rect(0, 8, w, 9, rgba("#120e18", 255))
    for x in range(8, w - 8, 32):
        c.rect(x, 4, x + 3, 7, C["gold"])
        c.px(x, 4, "hay_l")
        c.px(x + 2, 6, "gold_d")
    return c


def strip_overlay(full_alpha=None, strip_w=160):
    """640x360 overlay: a stone-edged dark strip on the left; optionally a veil over the rest."""
    w, h = 640, 360
    c = Canvas(w, h)
    ring = ("ink", "stone1", "stone2", "stone3", "ink", "gold_d", "gold", "ink")      # inner -> outer
    body_w = strip_w - len(ring)
    for y in range(h):
        for x in range(w):
            if x < body_w:
                c.p[y][x] = rgba("#321a4a", 250) if pa._hash(x, y, 9) < 0.06 else rgba("#1c1424", 250)
            elif x < strip_w:
                c.p[y][x] = C[ring[x - body_w]]
            elif full_alpha:
                c.p[y][x] = rgba("#120e18", full_alpha)
    for y in range(12, h, 40):                                                     # gold studs on the band
        c.rect(body_w + 1, y, body_w + 4, y + 3, C["gold"])
        c.px(body_w + 1, y, "hay_l")
    return c


def veil(alpha):
    c = Canvas(640, 360)
    for y in range(360):
        c.rect(0, y, 640, y + 1, rgba("#0a0710", alpha))
    return c


# -- manifest ------------------------------------------------------------------

def manifest():
    """{relative path: (Canvas, scale)}"""
    m = {}
    m["gui/main_menu.png"] = (pixel_title.title_scene(), Z)
    m["gui/game_menu.png"] = (pixel_title.brick_wall(), Z)
    m["gui/overlay/main_menu.png"] = (strip_overlay(None), Z)
    m["gui/overlay/game_menu.png"] = (strip_overlay(190), Z)
    m["gui/overlay/confirm.png"] = (veil(176), Z)
    m["gui/textbox.png"] = (textbox(), Z)
    m["gui/namebox.png"] = (ui.card("gold"), Z)
    m["gui/frame.png"] = (ui.panel("stone"), Z)
    m["gui/confirm_frame.png"] = (ui.panel("blood"), Z)
    m["gui/skip.png"] = (ui.card("dim"), Z)
    m["gui/notify.png"] = (ui.card("stone"), Z)
    for state, name in (("idle", "idle"), ("hover", "hover")):
        m["gui/button/%s_background.png" % name] = (ui.button(state), Z)
        m["gui/button/choice_%s_background.png" % name] = (ui.button(state), Z)
    m["gui/button/selected_idle_background.png"] = (ui.button("hover"), Z)
    m["gui/button/selected_hover_background.png"] = (ui.button("hover"), Z)
    m["gui/button/insensitive_background.png"] = (ui.button("insensitive"), Z)
    m["gui/button/slot_idle_background.png"] = (ui.card("stone"), Z)
    m["gui/button/slot_hover_background.png"] = (ui.card("gold"), Z)
    m["gui/button/radio_foreground.png"] = (radio_glyph(False), Z)
    m["gui/button/radio_selected_foreground.png"] = (radio_glyph(True), Z)
    m["gui/button/check_foreground.png"] = (check_glyph(False), Z)
    m["gui/button/check_selected_foreground.png"] = (check_glyph(True), Z)
    # sliders + bars: 13 art px thick (gui.slider_size / gui.bar_size = 39)
    for state, border in (("idle", "gold_d"), ("hover", "gold")):
        bar = slot_frame(12, 13, border)
        m["gui/slider/horizontal_%s_bar.png" % state] = (bar, Z)
        m["gui/slider/vertical_%s_bar.png" % state] = (transpose(bar), Z)
        th = thumb(5, 13, state == "hover")
        m["gui/slider/horizontal_%s_thumb.png" % state] = (th, Z)
        m["gui/slider/vertical_%s_thumb.png" % state] = (transpose(th), Z)
        sb, st = scroll_bar(16), scroll_thumb(16, hover=(state == "hover"))
        m["gui/scrollbar/horizontal_%s_bar.png" % state] = (sb, Z)
        m["gui/scrollbar/horizontal_%s_thumb.png" % state] = (st, Z)
        m["gui/scrollbar/vertical_%s_bar.png" % state] = (transpose(sb), Z)
        m["gui/scrollbar/vertical_%s_thumb.png" % state] = (transpose(st), Z)
    full, empty = slot_frame(12, 13, "gold_d", fill="red"), slot_frame(12, 13, "gold_d")
    m["gui/bar/left.png"] = (full, Z)
    m["gui/bar/right.png"] = (empty, Z)
    m["gui/bar/bottom.png"] = (transpose(full), Z)
    m["gui/bar/top.png"] = (transpose(empty), Z)
    return m


EXPECT = {                                    # path -> (w, h) in screen px
    "gui/main_menu.png": (1920, 1080), "gui/game_menu.png": (1920, 1080),
    "gui/overlay/main_menu.png": (1920, 1080), "gui/overlay/game_menu.png": (1920, 1080),
    "gui/overlay/confirm.png": (1920, 1080), "gui/textbox.png": (1920, 279),
    "gui/namebox.png": (48, 48), "gui/frame.png": (72, 72), "gui/button/idle_background.png": (48, 48),
    "gui/slider/horizontal_idle_bar.png": (36, 39), "gui/slider/horizontal_idle_thumb.png": (15, 39),
    "gui/slider/vertical_idle_bar.png": (39, 36), "gui/slider/vertical_idle_thumb.png": (39, 15),
    "gui/scrollbar/horizontal_idle_bar.png": (48, 18), "gui/scrollbar/vertical_idle_bar.png": (18, 48),
    "gui/button/radio_foreground.png": (27, 48), "gui/button/check_foreground.png": (27, 48),
}


def main():
    check = "--check" in sys.argv
    m = manifest()
    ok = True
    for path, (canvas, z) in sorted(m.items()):
        want = EXPECT.get(path)
        got = (canvas.w * z, canvas.h * z)
        if want and got != want:
            print("SIZE MISMATCH %s: got %s want %s" % (path, got, want))
            ok = False
    print("%d files, size check %s" % (len(m), "PASS" if ok else "FAIL"))
    if check or not ok:
        return 0 if ok else 1
    if not os.path.isdir(BACKUP):
        os.makedirs(BACKUP)
        shutil.copytree(GUI, os.path.join(BACKUP, "gui"))
        print("originals backed up to tools/_to_delete/backup_gui/gui")
    for path, (canvas, z) in sorted(m.items()):
        dest = os.path.join(ROOT, "game", path)
        d = os.path.dirname(dest)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(dest, "wb") as f:
            f.write(canvas.png(z))
    print("written to game/gui/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
