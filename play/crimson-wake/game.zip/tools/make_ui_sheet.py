"""Contact sheet of the pixel UI assets, incl. 9-slice panels stretched to sizes. Usage: python tools/make_ui_sheet.py out.png"""
import io, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "game", "python-packages"))
from PIL import Image, ImageDraw, ImageFont
import pixel_ui as ui

S = 3
def img(c): return Image.open(io.BytesIO(c.png(S))).convert("RGBA")

def nine(c, border, w, h):
    """Stretch-free 9-slice at native scale: corners kept, edges/centre tiled."""
    src = img(c); b = border * S
    W, H = w * S, h * S
    out = Image.new("RGBA", (W, H))
    sw, sh = src.size
    def tile(box, dst):
        piece = src.crop(box)
        for y in range(dst[1], dst[3], piece.size[1]):
            for x in range(dst[0], dst[2], piece.size[0]):
                out.paste(piece.crop((0, 0, min(piece.size[0], dst[2] - x), min(piece.size[1], dst[3] - y))), (x, y))
    # centre first, then edges, then corners, so nothing overpaints a border
    tile((b, b, sw - b, sh - b), (b, b, W - b, H - b))
    tile((b, 0, sw - b, b), (b, 0, W - b, b)); tile((b, sh - b, sw - b, sh), (b, H - b, W - b, H))
    tile((0, b, b, sh - b), (0, b, b, H - b)); tile((sw - b, b, sw, sh - b), (W - b, b, W, H - b))
    out.paste(src.crop((0, 0, b, b)), (0, 0)); out.paste(src.crop((sw - b, 0, sw, b)), (W - b, 0))
    out.paste(src.crop((0, sh - b, b, sh)), (0, H - b)); out.paste(src.crop((sw - b, sh - b, sw, sh)), (W - b, H - b))
    return out

sheet = Image.new("RGBA", (1500, 900), (58, 46, 66, 255))
fnt = ImageFont.truetype("game/fonts/PixelifySans-Regular.ttf", 28)
ttl = ImageFont.truetype("game/fonts/PirataOne-Regular.ttf", 56)
d = ImageDraw.Draw(sheet)
x = 20
for kind in ("stone", "blood", "gold", "dim"):
    p = nine(ui.panel(kind), ui.PANEL_BORDER, 90, 70); sheet.alpha_composite(p, (x, 20)); x += p.size[0] + 14
d.text((60, 50), "Crimson Wake", font=ttl, fill=(235, 200, 90))
d.text((60, 120), "Pixelify Sans body", font=fnt, fill=(230, 224, 214))
x = 20
for st in ("idle", "hover", "insensitive"):
    b = nine(ui.button(st), ui.BUTTON_BORDER, 80, 20); sheet.alpha_composite(b, (x, 260))
    d.text((x + 30, 270), st, font=fnt, fill=(255, 240, 220) if st != "insensitive" else (120, 120, 130)); x += b.size[0] + 14
c = nine(ui.card("stone"), ui.CARD_BORDER, 150, 30); sheet.alpha_composite(c, (20, 360))
c = nine(ui.card("gold"), ui.CARD_BORDER, 150, 30); sheet.alpha_composite(c, (520, 360))
sl = nine(ui.slot(), ui.SLOT_BORDER, 100, 12); sheet.alpha_composite(sl, (20, 480))
x = 20
for f in (True, False):
    h = img(ui.heart(f)); sheet.alpha_composite(h, (x, 560)); x += h.size[0] + 10
for f in (True, False):
    h = img(ui.drop(f)); sheet.alpha_composite(h, (x, 560)); x += h.size[0] + 10
h = img(ui.lock()); sheet.alpha_composite(h, (x, 560)); x += h.size[0] + 10
for f in (True, False):
    h = img(ui.pip(f)); sheet.alpha_composite(h, (x, 560)); x += h.size[0] + 10
x = 20
for n in ("speed", "constitution", "allure", "strength"):
    h = img(ui.icon(n)); sheet.alpha_composite(h, (x, 650)); x += h.size[0] + 20
sheet.alpha_composite(img(ui.divider(120)), (20, 760))
sheet.convert("RGB").save(sys.argv[1] if len(sys.argv) > 1 else "tools/_to_delete/ui_sheet.png")
